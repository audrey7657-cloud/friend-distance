﻿# ==========================================================
# 엔딩 컬렉션 시스템
# - 엔딩 제목이 표시되는 순간 persistent에 자동 해금
# - 새 게임/게임 종료 후에도 해금 기록 유지
# - 메인 메뉴 우측 하단의 "엔딩 컬렉션" 버튼으로 확인
# ==========================================================

default persistent.ending_collection = {}

init -10 python:

    ENDING_COLLECTION_DATA = [
        # 성장 엔딩 5종
        {"id": "good_jiho", "title": "지호 성장 엔딩", "group": "성장", "thumb": "cg_jh_good"},
        {"id": "good_hayoung", "title": "하영 성장 엔딩", "group": "성장", "thumb": "cg_hy_good"},
        {"id": "good_naeun", "title": "나은 성장 엔딩", "group": "성장", "thumb": "cg_ne_good"},
        {"id": "good_sohee", "title": "소희 성장 엔딩", "group": "성장", "thumb": "cg_sh_good"},
        {"id": "good_seoyeon", "title": "서연 성장 엔딩", "group": "성장", "thumb": "cg_sy_good"},

        # 후회 엔딩 5종
        {"id": "bad_jiho", "title": "지호 후회 엔딩", "group": "후회", "thumb": "bg_jh_bad"},
        {"id": "bad_hayoung", "title": "하영 후회 엔딩", "group": "후회", "thumb": "bg_hy_bad"},
        {"id": "bad_naeun", "title": "나은 후회 엔딩", "group": "후회", "thumb": "bg_ne_bad"},
        {"id": "bad_sohee", "title": "소희 후회 엔딩", "group": "후회", "thumb": "bg_sh_bad"},
        {"id": "bad_seoyeon", "title": "서연 후회 엔딩", "group": "후회", "thumb": "bg_sy_bad"},

        # 함께 엔딩 10종
        {"id": "pair_jiho_hayoung", "title": "지호, 하영과 함께 엔딩", "group": "함께", "thumb": "cg_pair_jiho_hayoung"},
        {"id": "pair_jiho_naeun", "title": "지호, 나은과 함께 엔딩", "group": "함께", "thumb": "cg_pair_jiho_naeun"},
        {"id": "pair_jiho_sohee", "title": "지호, 소희와 함께 엔딩", "group": "함께", "thumb": "cg_pair_jiho_sohee"},
        {"id": "pair_jiho_seoyeon", "title": "서연, 지호와 함께 엔딩", "group": "함께", "thumb": "cg_pair_jiho_seoyeon"},
        {"id": "pair_hayoung_naeun", "title": "하영, 나은과 함께 엔딩", "group": "함께", "thumb": "cg_pair_hayoung_naeun"},
        {"id": "pair_hayoung_sohee", "title": "하영, 소희와 함께 엔딩", "group": "함께", "thumb": "cg_pair_hayoung_sohee"},
        {"id": "pair_hayoung_seoyeon", "title": "하영, 서연과 함께 엔딩", "group": "함께", "thumb": "cg_pair_hayoung_seoyeon"},
        {"id": "pair_naeun_sohee", "title": "나은, 소희와 함께 엔딩", "group": "함께", "thumb": "cg_pair_naeun_sohee"},
        {"id": "pair_naeun_seoyeon", "title": "나은, 서연과 함께 엔딩", "group": "함께", "thumb": "cg_pair_naeun_seoyeon"},
        {"id": "pair_sohee_seoyeon", "title": "소희, 서연과 함께 엔딩", "group": "함께", "thumb": "cg_pair_sohee_seoyeon"},

        # 기타 엔딩 2종
        {"id": "solo", "title": "혼자여도 괜찮아 엔딩", "group": "기타", "thumb": "cg_solo"},
        {"id": "burnout", "title": "지친 마음 쉬어가기 엔딩", "group": "기타", "thumb": "bg_corridor_day"},
    ]

    ENDING_COLLECTION_BY_TITLE = dict((item["title"], item) for item in ENDING_COLLECTION_DATA)
    ENDING_COLLECTION_BY_ID = dict((item["id"], item) for item in ENDING_COLLECTION_DATA)

    def unlock_ending_by_title(title):
        item = ENDING_COLLECTION_BY_TITLE.get(title)
        if item is None:
            return

        if persistent.ending_collection is None:
            persistent.ending_collection = {}

        ending_id = item["id"]
        if not persistent.ending_collection.get(ending_id, False):
            persistent.ending_collection[ending_id] = True
            renpy.save_persistent()

    def ending_is_unlocked(ending_id):
        if persistent.ending_collection is None:
            return False
        return bool(persistent.ending_collection.get(ending_id, False))

    def ending_collection_count():
        return sum(1 for item in ENDING_COLLECTION_DATA if ending_is_unlocked(item["id"]))

    def ending_collection_item(ending_id):
        return ENDING_COLLECTION_BY_ID.get(ending_id)


# 메인 메뉴의 실제 navigation 버튼에서 이 화면을 Show()로 호출합니다.

screen ending_collection_screen():
    modal True
    zorder 500

    add Solid("#0B0A0FEF")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 930
        ysize 760
        xpadding 24
        ypadding 22
        background Solid("#17151DEE")

        vbox:
            spacing 14

            hbox:
                xfill True

                vbox:
                    spacing 2
                    text "엔딩 컬렉션":
                        size 34
                        color "#FFF8EA"
                    text "[ending_collection_count()] / [len(ENDING_COLLECTION_DATA)] 수집":
                        size 20
                        color "#CFC6D8"

                null width 20

                textbutton "닫기":
                    xalign 1.0
                    yalign 0.5
                    xpadding 18
                    ypadding 8
                    background Solid("#302A39")
                    hover_background Solid("#494052")
                    text_color "#FFFFFF"
                    action Hide("ending_collection_screen")

            viewport:
                xfill True
                ysize 650
                draggable True
                mousewheel True
                scrollbars "vertical"

                vpgrid:
                    cols 3
                    spacing 14

                    for item in ENDING_COLLECTION_DATA:
                        button:
                            xsize 272
                            ysize 182
                            padding (8, 8)
                            background Solid("#24202CDD")
                            hover_background Solid("#352F40EE")
                            action If(
                                ending_is_unlocked(item["id"]),
                                Show("ending_collection_detail", ending_id=item["id"]),
                                NullAction()
                            )

                            fixed:
                                if ending_is_unlocked(item["id"]):
                                    add item["thumb"]:
                                        xpos 3
                                        ypos 3
                                        xysize (250, 120)

                                    frame:
                                        xpos 8
                                        ypos 8
                                        xpadding 8
                                        ypadding 3
                                        background Solid("#00000099")
                                        text item["group"]:
                                            size 15
                                            color "#FFF4D6"

                                    text item["title"]:
                                        xalign 0.5
                                        ypos 132
                                        xmaximum 250
                                        text_align 0.5
                                        size 18
                                        color "#FFFFFF"
                                else:
                                    add Solid("#121116"):
                                        xpos 3
                                        ypos 3
                                        xysize (250, 120)

                                    text "?":
                                        xalign 0.5
                                        ypos 32
                                        size 52
                                        color "#5C5662"

                                    text "???":
                                        xalign 0.5
                                        ypos 136
                                        size 19
                                        color "#77717E"

    key "game_menu" action Hide("ending_collection_screen")


screen ending_collection_detail(ending_id):
    modal True
    zorder 520

    $ item = ending_collection_item(ending_id)

    add Solid("#000000CC")

    if item:
        frame:
            xalign 0.5
            yalign 0.5
            xsize 850
            ysize 660
            xpadding 25
            ypadding 22
            background Solid("#17151DF5")

            vbox:
                xalign 0.5
                spacing 16

                text item["title"]:
                    xalign 0.5
                    size 32
                    color "#FFF8EA"
                    text_align 0.5

                text item["group"] + " 엔딩":
                    xalign 0.5
                    size 18
                    color "#CFC6D8"

                add item["thumb"]:
                    xalign 0.5
                    xysize (760, 470)

                textbutton "컬렉션으로 돌아가기":
                    xalign 0.5
                    xpadding 22
                    ypadding 9
                    background Solid("#302A39")
                    hover_background Solid("#494052")
                    text_color "#FFFFFF"
                    action Hide("ending_collection_detail")

    key "game_menu" action Hide("ending_collection_detail")
