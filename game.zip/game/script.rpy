﻿# ==========================================================
# 친구 사랑 일주일 - 전체 완성본
# 초등학교 6학년 친구 사랑 주간 학습용 비주얼 노벨
# Ren'Py script.rpy 용
# D1 월요일 ~ D8 다음 주 월요일 / D7 리포트 / 엔딩 포함
# ==========================================================

# ----------------------------------------------------------
# 0. 기본 설정
# ----------------------------------------------------------

define config.default_text_cps = 42
define narr = Character(None)
define n = Character("유진", color="#FFFFFF")      # 주인공: 흰색
define m = Character("엄마", color="#F2B880")      # 엄마: 따뜻한 살구색
define t = Character("선생님", color="#A9D6FF")    # 선생님: 차분한 하늘색

define jh = Character("지호", color="#7DB8FF")     # 지호: 밝은 파랑
define hy = Character("하영", color="#FF9ACD")     # 하영: 핑크
define ne = Character("나은", color="#BFA7FF")     # 나은: 연보라
define sh = Character("소희", color="#FFCF6E")     # 소희: 노랑
define sy = Character("서연", color="#9FE0C5")     # 서연: 민트
define ex_mj = Character("민준", color="#D0D0D0")
define ex_js = Character("준서", color="#D0D0D0")

define ex_ce = Character("채은", color="#D0D0D0")
define ex_dy = Character("도윤", color="#D0D0D0")

define ex_ja = Character("지안", color="#D0D0D0")
define ex_ms = Character("민서", color="#D0D0D0")

define ex_mw = Character("민우", color="#D0D0D0")

define ex_ej = Character("은지", color="#D0D0D0")
define ex_cr = Character("채린", color="#D0D0D0")
define ex_jm = Character("지민", color="#D0D0D0")
define ex_sb = Character("수빈", color="#D0D0D0")

style note_centered_text is centered_text:
    font FILE_FONT
    color "#000000"

define note_centered = Character(
    None,
    window_style="centered_window",
    what_style="note_centered_text",
    what_xalign=0.5,
    what_text_align=0.5
)
style ending_centered_window is centered_window:
    background None

style ending_centered_text is centered_text:
    font FILE_FONT
    size 35
    color "#000000"
    slow_cps 25
    slow_abortable True
    outlines [(1, "#FFFFFF88", 0, 0)]

define ending_centered = Character(
    None,
    window_style="ending_centered_window",
    what_style="ending_centered_text",
    what_xalign=0.5,
    what_text_align=0.5
)
# ----------------------------------------------------------
# BGM 파일 선언
# ----------------------------------------------------------

define audio.bgm_daily_morning = "audio/bgm/bgm_daily_morning.mp3"
define audio.bgm_evening = "audio/bgm/bgm_evening.mp3"
define audio.bgm_classroom_light = "audio/bgm/bgm_classroom_light.mp3"
define audio.bgm_classroom_light2 = "audio/bgm/bgm_classroom_light2.mp3"
define audio.bgm_naeun_soft = "audio/bgm/bgm_naeun_soft.mp3"
define audio.bgm_sohee_warm = "audio/bgm/bgm_sohee_warm.mp3"
define audio.bgm_hayoung_social = "audio/bgm/bgm_hayoung_social.mp3"
define audio.bgm_seoyeon_clear = "audio/bgm/bgm_seoyeon_clear.mp3"
define audio.bgm_jiho_active = "audio/bgm/bgm_jiho_active.mp3"
define audio.bgm_evening_reflection = "audio/bgm/bgm_evening_reflection.mp3"
define audio.bgm_good = "audio/bgm/bgm_good.mp3"
define audio.bgm_bad = "audio/bgm/bgm_bad.mp3"
define audio.bgm_pair = "audio/bgm/bgm_pair.mp3"
define audio.bgm_solo = "audio/bgm/bgm_solo.mp3"
define audio.bgm_burnout = "audio/bgm/bgm_burnout.mp3"
define audio.bgm_choice = "audio/bgm/bgm_choice.mp3"
define audio.bgm_leaf_activity = "audio/bgm/bgm_leaf_activity.mp3"


# ----------------------------------------------------------
# BGM 전환 함수
# 같은 곡이면 재시작하지 않고, 곡이 바뀔 때만 긴 fadeout 적용
# ----------------------------------------------------------

init python:
    def set_bgm(track, fadeout=4.0, fadein=2.0):
        renpy.music.play(
            track,
            channel="music",
            loop=True,
            fadeout=fadeout,
            fadein=fadein,
            if_changed=True
        )

    def stop_bgm(fadeout=4.0):
        renpy.music.stop(channel="music", fadeout=fadeout)


define slow_fade = Fade(0.8, 0.2, 0.8)
define day_fade = Fade(0.8, 0.4, 0.9)
define soft_fade = Dissolve(0.8)
# ----------------------------------------------------------
# 1. 이미지 선언
# 이미지는 마지막 작업 단계에서 실제 파일명에 맞게 교체
# ----------------------------------------------------------

image bg_bus_stop_morning = "images/bg_bus_stop_morning.jpg"
image bg_classroom_morning = "images/bg_classroom_day.jpg"
image bg_playground_day = "images/bg_playground_day.jpg"
image bg_gym_day = "images/bg_gym_day.jpg"
image bg_library_day = "images/bg_library_day.jpg"
image bg_cafeteria_day = "images/bg_cafeteria_day.jpg"
image bg_restroom_mirror = "images/bg_restroom_mirror.jpg"
image bg_daycare_day = "images/bg_daycare_day.jpg"
image bg_infirmary_day = "images/bg_infirmary_day.jpg"
image bg_counseling_room = "images/bg_counseling_room.jpg"
image bg_garden_day = "images/bg_garden_day.jpg"
image bg_classroom_after = "images/bg_classroom_after.jpg"
image bg_diary = "images/bg_diary.jpg"
image bg_black = Solid("#000000")
image bg_corridor_day = "images/bg_corridor_day.jpg"
image bg_teacher_room_day = "images/bg_teacher_room_day.jpg"
image bg_room_evening = "images/bg_room_evening.jpg"
image bg_room_morning = "images/bg_room_morning.jpg"
image bg_kitchen_evening = "images/bg_kitchen_evening.jpg"
image bg_classroom_day = "images/bg_classroom_day.jpg"
image bg_home_evening = "images/bg_room_evening.jpg"
image bg_cafeteria_after = "images/bg_cafeteria_after.jpg"
image bg_school_day = "images/bg_school_day.png"
image bg_board = "images/bg_board.jpg"
image bg_board2 = "images/bg_board2.jpg"
image bg_cup = "images/bg_cup.png"
image bg_classroom_evening = "images/bg_classroom_evening.png"   
image bg_basketball = "images/bg_basketball.jpg"    
image bg_front_house = "images/bg_front_house.jpg" 
image bg_library_after = "images/bg_library_after.jpg"  
image bg_cafe_day = "images/bg_cafe_day.jpg"
image bg_art = "images/bg_art.png"
image bg_art2 = "images/bg_art2.png"
image d6_sohee_room = "images/d6_sohee_room.jpg"
image bg_shouse = "images/bg_shouse.jpg"
image ending_dim = Solid("#000000")
image bg_ending = "images/bg_ending.jpg"
image bg_leaf = "images/bg_leaf.jpg"
image bg_ne_bad = "images/bg_ne_bad.png"
image bg_sy_bad = "images/bg_sy_bad.png"
image bg_jh_bad = "images/bg_jh_bad.png"
image bg_hy_bad = "images/bg_hy_bad.png"
image bg_sh_bad = "images/bg_sh_bad.png"
image bg_snack = "images/bg_snack.jpg"
image bg_d5_observation = "images/bg_d5_observation.jpg"
image bg_relation_book = "images/note.png"
image bg_board3 = "images/bg_board3.jpg"
image bg_board_plain = "images/bg_board_plain.jpg"
# ----------------------------------------------------------
# 주말 이벤트 영상 선언
# ----------------------------------------------------------
image hy_weekend = Movie(play="videos/hy_weekend.webm")
image ne_weekend = Movie(play="videos/ne_weekend.webm")
image jh_weekend = Movie(play="videos/jh_weekend.webm")
image sh_weekend = Movie(play="videos/sh_weekend.webm")
image sy_weekend = Movie(play="videos/sy_weekend.webm")
transform weekend_movie_full:
    xalign 0.5
    yalign 0.5
    xsize 1280
    ysize 720

transform cg_slow_fadein:
    alpha 0.0
    linear 2.0 alpha 1.0
# ==========================================================
# 페어 엔딩 CG 이미지 선언
# ==========================================================

image cg_pair_jiho_naeun = "cg_jihonaeun.jpg"
image cg_pair_jiho_seoyeon = "cg_jihoseoyeon.jpg"
image cg_pair_jiho_sohee = "cg_jihosohee.jpg"
image cg_pair_hayoung_sohee = "cg_hayoungsohee.jpg"
image cg_pair_hayoung_naeun = "cg_naeunhayoung.jpg"
image cg_pair_naeun_sohee = "cg_naeunsohee.jpg"
image cg_pair_naeun_seoyeon = "cg_naeunseoyeon.jpg"
image cg_pair_jiho_hayoung = "cg_jihohayoung.jpg"
image cg_pair_hayoung_seoyeon = "cg_hayoungseoyeon.jpg"
image cg_pair_sohee_seoyeon = "cg_soheeseoyeon.jpg"
image cg_solo = "cg_solo.jpg"
image cg_sy_good = "cg_sy_good.jpg"
image cg_hy_good = "cg_hy_good.jpg"
image cg_jh_good = "cg_jh_good.jpg"
image cg_ne_good = "cg_ne_good.jpg"
image cg_sh_good = "cg_sh_good.jpg"
# ----------------------------------------------------------
# 관계 노트용 인물 썸네일
# --------------------------------------------------

image rel_jh = "images/ui/jh.png"
image rel_hy = "images/ui/hy.png"
image rel_ne = "images/ui/ne.png"
image rel_sh = "images/ui/sh.png"
image rel_sy = "images/ui/sy.png"

image relation_note_bg = "images/ui/relation_note_bg.png"

image main_menu_video = Movie(
    play="videos/main.webm",
    loop=True,
    size=(1280, 720)
)
# ----------------------------------------------------------
# 영상 스프라이트 크기 기준
# 배경: 1280x720
# 원본 영상: 750x1000
# 학생: 작게 / 어른: 크게
# ----------------------------------------------------------

# 학생용 크기: 465 x 620
# 어른용 크기: 525 x 700


# ----------------------------------------------------------
# 하영 영상 스프라이트 - 학생
# ----------------------------------------------------------
image h1 = Movie(play="videos/hayoung/h1.webm", side_mask=True, loop=True, size=(465, 620))
image h2 = Movie(play="videos/hayoung/h2.webm", side_mask=True, loop=True, size=(465, 620))
image h3 = Movie(play="videos/hayoung/h3.webm", side_mask=True, loop=True, size=(465, 620))
image h4 = Movie(play="videos/hayoung/h4.webm", side_mask=True, loop=True, size=(465, 620))
image h5 = Movie(play="videos/hayoung/h5.webm", side_mask=True, loop=True, size=(465, 620))
image h6 = Movie(play="videos/hayoung/h6.webm", side_mask=True, loop=True, size=(465, 620))


# ----------------------------------------------------------
# 서연 영상 스프라이트 - 학생
# ----------------------------------------------------------
image sy1 = Movie(play="videos/seoyeon/sy1.webm", side_mask=True, loop=True, size=(465, 620))
image sy2 = Movie(play="videos/seoyeon/sy2.webm", side_mask=True, loop=True, size=(465, 620))
image sy3 = Movie(play="videos/seoyeon/sy3.webm", side_mask=True, loop=True, size=(465, 620))
image sy4 = Movie(play="videos/seoyeon/sy4.webm", side_mask=True, loop=True, size=(465, 620))
image sy5 = Movie(play="videos/seoyeon/sy5.webm", side_mask=True, loop=True, size=(465, 620))
image sy6 = Movie(play="videos/seoyeon/sy6.webm", side_mask=True, loop=True, size=(465, 620))


# ----------------------------------------------------------
# 지호 영상 스프라이트 - 학생
# ----------------------------------------------------------
image jh1 = Movie(play="videos/jiho/jh1.webm", side_mask=True, loop=True, size=(465, 620))
image jh2 = Movie(play="videos/jiho/jh2.webm", side_mask=True, loop=True, size=(465, 620))
image jh3 = Movie(play="videos/jiho/jh3.webm", side_mask=True, loop=True, size=(465, 620))
image jh4 = Movie(play="videos/jiho/jh4.webm", side_mask=True, loop=True, size=(465, 620))
image jh5 = Movie(play="videos/jiho/jh5.webm", side_mask=True, loop=True, size=(465, 620))
image jh6 = Movie(play="videos/jiho/jh6.webm", side_mask=True, loop=True, size=(465, 620))


# ----------------------------------------------------------
# 나은 영상 스프라이트 - 학생
# ----------------------------------------------------------
image ne1 = Movie(play="videos/naeun/ne1.webm", side_mask=True, loop=True, size=(465, 620))
image ne2 = Movie(play="videos/naeun/ne2.webm", side_mask=True, loop=True, size=(465, 620))
image ne3 = Movie(play="videos/naeun/ne3.webm", side_mask=True, loop=True, size=(465, 620))
image ne4 = Movie(play="videos/naeun/ne4.webm", side_mask=True, loop=True, size=(465, 620))
image ne5 = Movie(play="videos/naeun/ne5.webm", side_mask=True, loop=True, size=(465, 620))


# ----------------------------------------------------------
# 소희 영상 스프라이트 - 학생
# ----------------------------------------------------------
image sh1 = Movie(play="videos/sohee/sh1.webm", side_mask=True, loop=True, size=(465, 620))
image sh2 = Movie(play="videos/sohee/sh2.webm", side_mask=True, loop=True, size=(465, 620))
image sh3 = Movie(play="videos/sohee/sh3.webm", side_mask=True, loop=True, size=(465, 620))
image sh4 = Movie(play="videos/sohee/sh4.webm", side_mask=True, loop=True, size=(465, 620))
image sh5 = Movie(play="videos/sohee/sh5.webm", side_mask=True, loop=True, size=(465, 620))
image sh6 = Movie(play="videos/sohee/sh6.webm", side_mask=True, loop=True, size=(465, 620))


# ----------------------------------------------------------
# 담임 영상 스프라이트 - 어른
# ----------------------------------------------------------
image t1 = Movie(play="videos/teacher/t1.webm", side_mask=True, loop=True, size=(525, 700))
image t2 = Movie(play="videos/teacher/t2.webm", side_mask=True, loop=True, size=(525, 700))
image t3 = Movie(play="videos/teacher/t3.webm", side_mask=True, loop=True, size=(525, 700))
image t4 = Movie(play="videos/teacher/t4.webm", side_mask=True, loop=True, size=(525, 700))
image t5 = Movie(play="videos/teacher/t5.webm", side_mask=True, loop=True, size=(525, 700))


# ----------------------------------------------------------
# 엄마 영상 스프라이트 - 어른
# ----------------------------------------------------------
image m1 = Movie(play="videos/mom/m1.webm", side_mask=True, loop=True, size=(525, 700))
image m2 = Movie(play="videos/mom/m2.webm", side_mask=True, loop=True, size=(525, 700))
image m3 = Movie(play="videos/mom/m3.webm", side_mask=True, loop=True, size=(525, 700))
# ----------------------------------------------------------
# 영상 캐릭터 위치 transform
# 1280x720 기준 / 발이 바닥에 닿도록 하단 정렬
# ----------------------------------------------------------
# ----------------------------------------------------------
# D6 주말 이벤트 영상 배경
# 대사 출력 가능
# ----------------------------------------------------------

image d6_jiho_video = Movie(
    play="videos/d6_jiho.webm",
    loop=True,
    size=(1280, 720)
)

image d6_naeun_video = Movie(
    play="videos/d6_naeun.webm",
    loop=True,
    size=(1280, 720)
)

image d6_hayoung_video = Movie(
    play="videos/d6_hayoung.webm",
    loop=True,
    size=(1280, 720)
)

image d6_seoyeon_video = Movie(
    play="videos/d6_seoyeon.webm",
    loop=True,
    size=(1280, 720)
)

image d6_sohee_video = Movie(
    play="videos/d6_sohee.webm",
    loop=True,
    size=(1280, 720)
)

transform center_stage:
    xalign 0.5
    yalign 1.0

transform left_stage:
    xalign 0.25
    yalign 1.0

transform right_stage:
    xalign 0.75
    yalign 1.0

transform slight_left:
    xalign 0.38
    yalign 1.0

transform slight_right:
    xalign 0.62
    yalign 1.0
# ----------------------------------------------------------
# 3. 변수
# ----------------------------------------------------------

default day = 1

# 성향 점수
default trait_close = 0       # 친밀형
default trait_social = 0      # 사교형
default trait_observe = 0     # 관찰형
default trait_myway = 0       # 마이페이스형
default player_trait = "none"


# D5 관찰 변수 (D5에서 사용, 미리 선언)
default d5_obs_jiho = False
default d5_obs_hayoung = False
default d5_obs_naeun = False
default d5_obs_sohee = False
default d5_obs_seoyeon = False

# D5 마음잎 텍스트 변수
default d5_leaf_strength_text = ""
default d5_leaf_advice_text = ""
default d5_leaf_strength = "none"
default d5_leaf_advice = "none"
default d5_accept_level = "none"
default d5_leaf_person = "none"
default d5_lunch_reaction_count = 0

default choice_question_text = ""
default diary_last_line = ""
# 호감도
default like_jiho = 0
default like_hayoung = 0
default like_naeun = 0
default like_sohee = 0
default like_seoyeon = 0

# 부정 수치
default neg_jiho = 0       # 장난선 / 욱함
default neg_hayoung = 0    # 동조
default neg_naeun = 0      # 부담
default neg_sohee = 0      # 의존
default neg_seoyeon = 0    # 상처

# 자기 소진
default burnout = 0

# 관계 노트 UI 표시 여부
default relation_note_enabled = True

# 만남 기록
default intro_seen = []
default d1_system_met = "none"
default d1_choice_met = "none"
default met_1on1 = []
default d1_people_met = []

# 선택 패턴 기록
default choice_log = []

# ----------------------------------------------------------
# 4. 공통 함수
# ----------------------------------------------------------

init python:
    def add_like(name, amount):
        global like_jiho, like_hayoung, like_naeun, like_sohee, like_seoyeon
        if name == "jiho":
            like_jiho = max(0, min(12, like_jiho + amount))
        elif name == "hayoung":
            like_hayoung = max(0, min(12, like_hayoung + amount))
        elif name == "naeun":
            like_naeun = max(0, min(12, like_naeun + amount))
        elif name == "sohee":
            like_sohee = max(0, min(12, like_sohee + amount))
        elif name == "seoyeon":
            like_seoyeon = max(0, min(12, like_seoyeon + amount))

    def add_neg(name, amount):
        global neg_jiho, neg_hayoung, neg_naeun, neg_sohee, neg_seoyeon
        if name == "jiho":
            neg_jiho = max(0, min(10, neg_jiho + amount))
        elif name == "hayoung":
            neg_hayoung = max(0, min(10, neg_hayoung + amount))
        elif name == "naeun":
            neg_naeun = max(0, min(10, neg_naeun + amount))
        elif name == "sohee":
            neg_sohee = max(0, min(10, neg_sohee + amount))
        elif name == "seoyeon":
            neg_seoyeon = max(0, min(10, neg_seoyeon + amount))

    def apply_d5_leaf_score(name, result, trap_count):
        valid_names = ["jiho", "hayoung", "naeun", "sohee", "seoyeon"]

        if name not in valid_names:
            return

        if result == "deep_good":
            add_like(name, 2)
            add_neg(name, -1)

        elif result == "trap":
            add_like(name, 1)
            add_neg(name, trap_count)

        else:
            add_like(name, 1)   

    def add_burnout(amount):
        global burnout
        burnout = max(0, min(10, burnout + amount))

    def mark_met(name):
        global met_1on1, d1_people_met
        if name not in met_1on1:
            met_1on1.append(name)
        if name not in d1_people_met:
            d1_people_met.append(name)

    def mark_intro(name):
        global intro_seen, d1_people_met
        if name not in intro_seen:
            intro_seen.append(name)
        if name not in d1_people_met:
            d1_people_met.append(name)

    def decide_trait():
        scores = {
            "close": trait_close,
            "social": trait_social,
            "observe": trait_observe,
            "myway": trait_myway,
        }
        # 동점일 때는 친밀 > 관찰 > 사교 > 마이페이스 순으로 안정적 배정
        priority = ["close", "observe", "social", "myway"]
        best = priority[0]
        for key in priority:
            if scores[key] > scores[best]:
                best = key
        return best

    def d1_system_person_by_trait(trait):
        if trait == "close":
            return "sohee"
        elif trait == "social":
            return "hayoung"
        elif trait == "observe":
            return "seoyeon"
        elif trait == "myway":
            return "naeun"
        return "sohee"

    def display_name(name):
        table = {
            "jiho": "지호",
            "hayoung": "하영",
            "naeun": "나은",
            "sohee": "소희",
            "seoyeon": "서연",
        }
        return table.get(name, name)

    def diary_focus_face(name):

        table = {
            "jiho": "rel_jh",
            "hayoung": "rel_hy",
            "naeun": "rel_ne",
            "sohee": "rel_sh",
            "seoyeon": "rel_sy",
        }
        return table.get(name, None)

init python:
    def d5_obs_mark(name):
        if name == "jiho" and d5_obs_jiho:
            return "✓ "
        elif name == "hayoung" and d5_obs_hayoung:
            return "✓ "
        elif name == "naeun" and d5_obs_naeun:
            return "✓ "
        elif name == "sohee" and d5_obs_sohee:
            return "✓ "
        elif name == "seoyeon" and d5_obs_seoyeon:
            return "✓ "
        return ""

init python:
    def relation_status_text(like, neg):
        if like >= 7 and neg <= 3:
            return "안정적 관계"
        elif like >= 5 and neg >= 4:
            return "가깝지만 위험함"
        elif like >= 5:
            return "가까워지는 중"
        elif neg >= 4:
            return "불편함 누적"
        else:
            return "아직 알아가는 중"

# ----------------------------------------------------------
# 5. 게임 시작
# ----------------------------------------------------------

label start:
    show screen relation_note_button
    jump d1_start


# ==========================================================
# D1 월요일

# ==========================================================

label d1_start:  

    $ day = 1 

    $ set_bgm(audio.bgm_daily_morning)
    scene bg_black with fade 

    pause 0.5

    "방 안을 가득 채웠던 짐 박스들이 사라진 첫날 아침이다."

    "창문 밖에서는 낯선 동네 소리가 들렸다."

    "거울 앞에 서서 엄마가 새로 사준 옷을 한 번 더 만져봤다."

    "괜찮아 보이긴 했다."
    "그런데 너무 꾸민 것처럼 보이면 어떡하지?"

    "손바닥에 땀이 나서 가방끈을 꽉 쥐었다가 폈다."

    "오늘은 새 학교에 처음 가는 날이다."

    jump d1_morning_bus_stop

label d1_morning_bus_stop: 
    scene bg_bus_stop_morning with fade 
    
    "정류장에는 교복 입은 중학생 몇 명이 서 있었다."
    
    show m3 at center_stage with dissolve
    m "유진아, 버스 전광판 보이지?"
    m "3분 뒤에 온대."

    n "응..."
    
    "엄마도 나처럼 버스가 올 쪽을 보고 있었다."
    
    m "입술 너무 꾹 다문 거 아니야?"
    m "너 그러다 로봇 되겠다."

    n "아, 엄마..."
    n "아니거든."

    m "맞는데?"
    m "방금 팔 움직일 때 치익, 칙 소리 났는데?"
    
    "엄마가 팔을 삐걱거리듯 움직였다."
    "나도 모르게 입꼬리가 조금 올라갔다."
    "어깨에 들어갔던 힘도 조금 빠졌다."
    
    hide m3
    with Dissolve(0.18)
    show m2 at center_stage with dissolve

    m "교실 문 열고 들어가면,"
    m "처음에 어떻게 하고 싶어?"

    "나는 교실 문 앞의 내 모습을 가만히 상상해봤다."

    $ choice_question_text = "교실에 들어가면 어떻게 하고 싶어?"
    window hide

    menu:
        "조용히 들어가서 앉고 싶어.":
            window show
            $ trait_observe += 1
            $ choice_log.append("D1_Q1_observe")

            n "그냥 조용히 앉아 있으려고."
            n "누가 먼저 말 걸기 전까지는 교실을 좀 보고 싶어."

            m "그래."
            m "첫날부터 꼭 많이 말 안 해도 돼."

        "먼저 웃으면서 인사하고 싶어.":
            window show
            $ trait_social += 1
            $ choice_log.append("D1_Q1_social")

            n "어색해도 먼저 웃고 인사해 보려고."
            n "그러면 조금 덜 어색하지 않을까 싶어서."

            m "좋네."
            m "웃으면서 인사하면 엄마도 기분 좋을 것 같아."

        "편해 보이는 친구에게 먼저 다가가고 싶어.":
            window show
            $ trait_close += 1
            $ choice_log.append("D1_Q1_close")

            n "반 애들 모두랑 바로 친해질 수는 없잖아."
            n "옆자리나 편해 보이는 친구한테 먼저 말해보고 싶어."

            m "응."
            m "한 명만 편해져도 첫날은 훨씬 낫지."

        "그냥 평소처럼 행동할래.":
            window show
            $ trait_myway += 1
            $ choice_log.append("D1_Q1_myway")

            n "억지로 친한 척하면 더 어색할 것 같아."
            n "그냥 평소처럼 있어보려고."

            m "맞아."
            m "너무 애쓰면 금방 피곤해져."

    m "그런데 학교 다니다 보면,"
    m "너랑 잘 안 맞는 친구도 있을 수 있잖아."
    m "그럴 땐 어떻게 할 거야?"

    $ choice_question_text = "나와 잘 안 맞는 친구가 생기면?"
    window hide

    menu:
        "싸우기 싫으니까 조금 맞춰볼래.":
            window show
            $ trait_social += 1
            $ trait_close += 1
            $ choice_log.append("D1_Q2_try")

            n "같은 반인데 서로 불편하면 힘들잖아."
            n "웬만하면 내가 조금 맞춰볼래."

            m "그래도 너무 많이 참지는 마."
            m "네 마음도 중요하니까."

        "내 생각을 조심해서 말해볼래.":
            window show
            $ trait_observe += 1
            $ trait_myway += 1
            $ choice_log.append("D1_Q2_honest")

            n "계속 참으면 나중에 더 속상할 것 같아."
            n "그래서 조심해서 말해보고 싶어."

            m "그래."
            m "말은 조심히 해도, 네 마음은 말해도 돼."

        "억지로 친해지지 않고 거리를 둘래.":
            window show
            $ trait_myway += 1
            $ trait_observe += 1
            $ choice_log.append("D1_Q2_distance")

            n "모든 친구랑 다 친해질 수는 없으니까."
            n "잘 안 맞으면 조금 떨어져 지내도 될 것 같아."

            m "그럴 수도 있지."
            m "같은 반이라고 꼭 다 붙어 다닐 필요는 없으니까."

        "어떤 친구인지 조금 보고, 편해지면 가까워질래.":
            window show
            $ trait_close += 1
            $ trait_observe += 1
            $ choice_log.append("D1_Q2_wait")

            n "처음부터 바로 정하긴 어려울 것 같아."
            n "어떤 친구인지 조금 보고,"
            n "편해지면 그때 가까워져도 될 것 같아."

            m "응."
            m "처음부터 다 알 수는 없으니까."
            m "조금 지켜보다가, 마음이 편한 친구랑 천천히 가까워지면 돼."

    hide m2
    with Dissolve(0.18)
    show m3 at center_stage with dissolve 

    m "그럼 학교 끝나고는?"
    m "집에 어떻게 오고 싶어?"

    $ choice_question_text = "학교 끝나고 집에 올 때는?"
    window hide

    menu:
        "마음이 편한 친구가 생기면 같이 오고 싶어.":
            window show
            $ trait_close += 2
            $ choice_log.append("D1_Q3_friend")

            n "학교 끝나고 그냥 헤어지는 건 조금 아쉬울 것 같아."
            n "마음이 편한 친구가 생기면,"
            n "오늘 있었던 일도 이야기하면서 같이 오고 싶어."

            m "응."
            m "편한 친구랑 같이 오면 길도 덜 낯설겠지."

        "학교에서 기운을 많이 쓰니까 혼자 쉬면서 오고 싶어.":
            window show
            $ trait_myway += 2
            $ choice_log.append("D1_Q3_alone")

            n "학교에서는 계속 새 얼굴을 봐야 하잖아."
            n "그러면 집에 올 때쯤에는 좀 조용히 있고 싶을 것 같아."
            n "버스 창밖 보면서 혼자 쉬고 싶어."

            m "그럴 수도 있지."
            m "친구랑 안 온다고 해서 이상한 건 아니야."

        "그날 기분에 따라 같이 올지 혼자 올지 정하고 싶어.":
            window show
            $ trait_observe += 1
            $ trait_social += 1
            $ choice_log.append("D1_Q3_both")

            n "어떤 날은 친구랑 이야기하면서 오고 싶을 수도 있고,"
            n "어떤 날은 혼자 조용히 오고 싶을 수도 있잖아."
            n "그날 기분 보고 정하고 싶어."

            m "그래."
            m "그때 네 마음에 편한 쪽으로 하면 돼."

        "누구랑 오느냐가 제일 중요할 것 같아.":
            window show
            $ trait_observe += 2
            $ choice_log.append("D1_Q3_depends")

            n "같이 오는 게 싫은 건 아닌데,"
            n "아직 어색한 친구랑 억지로 오면 더 불편할 것 같아."
            n "편한 친구인지 먼저 보고 싶어."

            m "맞아."
            m "같이 오는 것보다 누구랑 오는지가 더 중요할 때도 있지."

    $ player_trait = decide_trait()
    
    hide m3
    with Dissolve(0.18)
    show m2 at center_stage
    with Dissolve(0.12)

    m "아 맞다."
    m "이번 주가 친구 사랑 주간이라며?"
    m "어제 가정통신문 봤어." 
    m "다음 달 학예회 준비도 같이 시작한다던데."

    n "응."
    n "반이 좀 바쁠 것 같아."

    "저 멀리서 파란색 버스 한 대가 모퉁이를 돌아 나타났다."

    hide m2
    with Dissolve(0.18)
    show m1 at center_stage
    with Dissolve(0.12)    

    m "버스 온다."
    m "다 잘하려고 하지 마."
    m "네가 할 수 있는 만큼만 해."

    n "응."
    n "다녀올게, 엄마."
    
    "버스 계단을 오르며 뒤를 돌아보자,"
    "엄마는 손을 흔드는 대신 조용히 고개를 끄덕여 주셨다."
    
    hide m1
    scene bg_black with fade
    pause 0.5

    jump d1_classroom_intro
# ----------------------------------------------------------
# D1 학교 도착 — 담임 안내와 5인 소개 선택
# ----------------------------------------------------------
label d1_classroom_intro:
    scene bg_classroom_morning with fade
    $ set_bgm(audio.bgm_classroom_light)

    "교실 뒷문을 열자마자 낯선 교실 냄새가 코끝에 훅 끼쳤다."
    "왁자지껄하던 소리가 갑자기 조용해지고," 
    "반 아이들이 모두 나를 바라봤다."

    "심장이 크게 뛰었다."
    "그런데 한편으로는 이상하게 조금 설레기도 했다."

    "이 교실에서 나는 누구와 먼저 말을 하게 될까."

    show t1 at center_stage as teacher with dissolve
    t "자, 다들 주목."
    t "오늘부터 우리 반에서 같이 지내게 된 전학생 유진이야."
    t "갑자기 질문을 많이 해서 당황하게 하지 말고,"
    t "천천히 적응할 수 있게 도와주자."

    t "우선 학교 주요 시설을 안내해줄 사람 있을까?"

    "선생님 말이 끝나자, 교실 여기저기서 작은 말소리가 들렸다."
    "나는 칠판 앞에 서서 손가락 끝을 살짝 쥐었다."

    hide teacher
    show jh5 at center_stage as jiho with dissolve
    jh "쌤, 운동장이랑 체육관은 제가 안내할게요!"
    jh "거기는 제가 제일 잘 알아요."

    hide jiho
    show sy5 at center_stage as seoyeon with dissolve
    sy "도서실이랑 교무실 위치는 제가 알려줄 수 있어요."
    sy "제가 회장이니까요."

    hide seoyeon
    show h5 at center_stage as hayoung with dissolve
    hy "유진아, 나도 시간 돼."
    hy "급식실이랑 화장실, 물 마시는 곳 알려줄게."

    hide hayoung
    show sh1 at center_stage as sohee with dissolve
    sh "저요! 저도요!"
    sh "유진아, 괜찮으면 나랑 같이 가도 돼."

    hide sohee
    show ne5 at center_stage as naeun with dissolve
    ne "…저도, 괜찮으면…"
    ne "위클래스랑 보건실 쪽은 알려줄 수 있는데."

    hide naeun
    show t1 at center_stage as teacher with dissolve
    t "좋아."
    t "유진이가 선택하렴."
    t "1교시 종 치기 전까지만 돌아오고."
    jump d1_intro_select_loop


label d1_intro_select_loop:
    scene bg_classroom_morning

    if len(intro_seen) >= 2:
        jump d1_intro_end
    $ choice_question_text = "누구에게 학교 안내를 받을까? 2명 선택 가능"
    window hide

    menu:
        "{color=#7DB8FF}지호{/color} — 운동장과 체육관" if "jiho" not in intro_seen:
            window show
            call d1_intro_jiho
            jump d1_intro_select_loop

        "{color=#9FE0C5}서연{/color} — 도서실과 교무실" if "seoyeon" not in intro_seen:
            window show
            call d1_intro_seoyeon
            jump d1_intro_select_loop

        "{color=#FF9ACD}하영{/color} — 급식실과 화장실 거울 앞" if "hayoung" not in intro_seen:
            window show
            call d1_intro_hayoung
            jump d1_intro_select_loop

        "{color=#FFCF6E}소희{/color} — 돌봄교실과 보건실" if "sohee" not in intro_seen:
            window show
            call d1_intro_sohee
            jump d1_intro_select_loop

        "{color=#BFA7FF}나은{/color} — 상담실과 옆 정원" if "naeun" not in intro_seen:
            window show
            call d1_intro_naeun
            jump d1_intro_select_loop

# ----------------------------------------------------------
# 지호 소개 분기 — 활기, 장난, 승부욕의 씨앗
# ----------------------------------------------------------
label d1_intro_jiho:
    $ mark_intro("jiho")
    scene bg_playground_day with fade
    $ set_bgm(audio.bgm_jiho_active)

    show jh1 at center_stage as jiho with dissolve
    jh "여기가 운동장이야."
    jh "우리 반 애들 점심시간에 여기 제일 많이 나와."

    "지호는 손에 들고 있던 농구공을 가볍게 튕겼다."
    "그러더니 공을 내 쪽으로 통통 굴려 보냈다."

    jh "자, 한번 받아봐."
    jh "어렵지 않아."

    "갑자기 굴러온 농구공에 나는 두 손을 허둥지둥 내밀었다."
    "공은 내 손끝을 스치고 바닥에 통통 튀었다."

    hide jiho
    show jh4 at center_stage as jiho with dissolve
    jh "아, 미안!"
    jh "갑자기 해서 놀랐지?"

    "지호는 바로 뛰어가 농구공을 주워 왔다."

    hide jiho
    show jh1 at center_stage as jiho with dissolve
    jh "처음엔 다 그래."
    jh "나도 처음부터 잘한 건 아니거든."

    "말은 가볍고 장난스러웠지만,"
    "내가 당황한 걸 보자 금방 사과했다."

    "그때 옆에서 축구를 하던 남자아이가 우리 쪽으로 가까이 왔다."

    hide jiho
    show jh5 at center_stage as jiho with dissolve
    jh "야, 잠깐만!"
    jh "지금 전학생 안내 중이야."
    jh "이따 점심시간에 같이 하자. 그때 제대로 보여줄게."

    "지호는 웃으면서 말했지만,"
    "손에 든 공은 계속 톡톡 튀기고 있었다."

    hide jiho
    scene bg_gym_day with dissolve

    show jh1 at center_stage as jiho with dissolve
    jh "여긴 체육관이야."
    jh "비 오는 날에는 여기서 체육하고,"
    jh "가끔 반 대항 게임도 해."

    jh "저기 골대 보이지?"
    jh "쉬는 시간에 슛 연습하는 애들도 있어."

    "지호는 골대 쪽을 보자마자 자세를 잡았다."
    "그리고 바로 슛을 던졌다."

    "농구공은 골대 링을 맞고 살짝 빗나갔다."

    hide jiho
    show jh2 at center_stage as jiho with dissolve
    jh "어?"
    jh "잠깐만. 왜 안 들어가지?"

    "지호는 공을 다시 주워 들었다."
    "이번에는 조금 더 가까이 서서 슛을 던졌다."

    "하지만 공은 또 링 옆을 맞고 튕겨 나왔다."

    jh "아, 이번엔 진짜 들어갈 줄 알았는데."

    "지호는 나를 안내하던 것도 잠깐 잊은 듯,"
    "공이 들어갈 때까지 몇 번이고 다시 슛을 던졌다."

    "나는 그 옆에서 튕겨 나오는 농구공을 멍하니 바라보고 있었다."

    "마침내 공이 골대 안으로 쏙 들어갔다."

    hide jiho
    show jh1 at center_stage as jiho with dissolve
    jh "됐다!"

    "지호는 환하게 웃다가 그제야 나를 돌아봤다."

    hide jiho
    show jh3 at center_stage as jiho with dissolve
    jh "아, 미안."
    jh "너 안내해 주는 중이었지."

    "지호는 머쓱한 듯 머리를 긁적였다."

    "지호와 빠르게 돌아다니다 보니,"
    "전학 첫날의 어색함도 조금 줄었다."

    return

# ----------------------------------------------------------
# 서연 소개 분기 — 책임감, 정확함, 딱딱한 말투의 씨앗
# ----------------------------------------------------------

label d1_intro_seoyeon:
    $ set_bgm(audio.bgm_seoyeon_clear)
    $ mark_intro("seoyeon")
    scene bg_library_day with fade

    show sy5 at center_stage as seoyeon with dissolve
    sy "여긴 도서실이야."
    sy "책 빌리는 방법은 나중에 적어서 네 책상에 둘게."
    sy "처음 오면 이런 거 헷갈리잖아."

    "서연이는 도서실 앞에 붙은 종이를 손가락으로 짚으며 설명했다."
    "어디부터 말할지 미리 정해둔 것처럼 보였다."

    "도서실을 둘러보는 중이었다."
    "가방에 달린 작은 인형이 바닥으로 툭 떨어졌다."

    "서연이는 그걸 보더니 말없이 다가와 인형을 주웠다."
    "그러고는 가방끈에 다시 풀리지 않게 반듯하게 묶어주었다."

    n "아, 고마워."

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve
    sy "이런 건 풀리기 전에 묶어두는 게 나아."
    sy "잃어버리면 찾기 힘드니까."

    "말투는 조금 딱딱했다."
    "그래도 그냥 지나치지는 않았다."

    scene bg_teacher_room_day with dissolve

    show sy5 at center_stage as seoyeon with dissolve
    sy "여긴 교무실이야."
    sy "들어갈 때는 먼저 똑똑 하고,"
    sy "선생님이 들어오라고 하시면 들어가면 돼."

    sy "어렵진 않아."
    sy "순서만 기억하면 돼."

    "그때 교무실 앞 복도에서 몇 명이 크게 웃으며 장난을 치기 시작했다."
    "서연이는 그쪽을 힐끗 보더니 곧장 다가갔다."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve
    sy "여기 교무실 앞이야."
    sy "너무 크게 떠들면 선생님들이 들으시잖아."

    "웃던 아이들은 잠시 조용해졌다."

    sy "장난칠 거면 운동장에서 해."

    "한 아이가 입술을 삐죽였다."
    "다른 아이가 그 친구의 팔을 잡고 복도 끝으로 걸어갔다."

    "서연이는 다시 내 쪽으로 돌아왔다."

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve
    sy "가자."
    sy "계단도 알려줄게."

    "서연이는 가는 곳마다 하나씩 알려주었다."
    "말투는 조금 딱딱했지만," 
    "처음 온 학교에서 길을 잃지는 않을 것 같았다."

    return

# ----------------------------------------------------------
# 하영 소개 분기 — 자신감, 센스, 분위기를 주도하는 힘
# ----------------------------------------------------------
label d1_intro_hayoung:
    $ mark_intro("hayoung")
    $ set_bgm(audio.bgm_hayoung_social)

    scene bg_restroom_mirror with dissolve
    show h4 at center_stage as hayoung with dissolve
    hy "여긴 화장실 앞 거울이야."
    hy "우리 반 애들 쉬는 시간에 자주 와."
    hy "앞머리 보거나 머리끈 다시 묶을 때."

    "하영이는 거울 앞에 서자마자 앞머리를 손끝으로 쓸어 넘겼다."
    "거울 앞에 있던 아이들이 잠깐 하영이 쪽을 봤다."
    "하영이는 익숙한 듯 가볍게 웃었다."

    hy "아, 너 5반 지민이지?"
    hy "머리끈 풀릴 것 같은데."

    "하영이는 손목에 있던 머리끈 하나를 빼서 지민이에게 건넸다."

    hy "이거 써."
    hy "네 옷엔 이 색이 더 어울릴 것 같아."

    "지민이의 얼굴이 바로 밝아졌다."

    ex_jm "고마워."

    hy "괜찮아."

    "하영이는 상냥하게 웃어주고는 나와 함께 화장실 앞을 나왔다."

    hy "지민이는 저런 색 좋아해."
    hy "전에 필통도 비슷한 색이었거든."

    "하영이는 아무렇지 않게 말했다."
    "하영이는 친구들에 대해 알고 있는 게 많아 보였다."

    scene bg_cafeteria_day with fade

    show h5 at center_stage as hayoung with dissolve
    hy "여기가 급식실이야."
    hy "우리 학교는 수요일 메뉴가 제일 괜찮아."

    "하영이는 급식실 안쪽을 자연스럽게 가리켰다."

    hy "우리 반 애들은 보통 저쪽 창가 테이블에 많이 앉아."
    hy "꼭 정해진 건 아닌데, 거의 그래."

    "그때 지나가던 다른 반 아이가 하영이에게 손을 흔들었다."
    "하영이도 짧게 웃으며 손을 흔들어 주었다."

    "그 아이가 멀어지자, 하영이는 목소리를 조금 낮췄다."

    hide hayoung
    show h2 at center_stage as hayoung with dissolve
    hy "쟤는 4반이야."
    hy "전에는 우리랑 자주 다녔는데,"
    hy "요즘은 다른 애들이랑 더 많이 다녀."

    "하영이는 별일 아니라는 듯 말했지만,"
    "말끝이 아주 조금 뾰족했다."

    "나는 뭐라고 해야 할지 몰라서 고개만 끄덕였다."

    "하영이 덕에 벌써 다른 반 아이 이름까지 알게 됐다."
    "이름을 아는 아이들이 생기니" 
    "전학 첫날의 긴장이 좀 내려가는 것 같았다."

    return

# ----------------------------------------------------------
# 소희 소개 분기 — 따뜻함, 빠른 친밀감, 부담의 씨앗
# ----------------------------------------------------------

label d1_intro_sohee:
    $ mark_intro("sohee")
    $ set_bgm(audio.bgm_sohee_warm)
    scene bg_daycare_day with fade
    show sh1 at center_stage as sohee with dissolve
    sh "유진아!"
    sh "아까 선생님이 네 이름 부르는데, 이름 진짜 예쁘다고 생각했어."
    sh "내가 첫날부터 학교 소개해 주게 돼서 완전 좋아."

    "소희는 말을 하면서 내 옆으로 가까이 다가왔다."
    "처음 만났는데도 오래전부터 알던 친구처럼 환하게 웃고 있었다."

    sh "나 새 친구 생기는 거 진짜 좋아하거든."
    sh "처음 오면 어디가 어딘지 헷갈리잖아."
    sh "모르면 나한테 물어봐."
    sh "내가 알려줄게!"

    sh "여기는 돌봄교실이야."
    sh "가끔 선생님이 간식 나눠주실 때가 있거든."
    sh "그때 맛있는 거 고르는 법도 알려줄게."

    hide sohee
    show sh4 at center_stage as sohee with dissolve

    "소희는 꺄르르 웃으며 내 소매 끝을 살짝 잡았다."
    "말이 빠르고 표정도 밝아서, 나까지 조금 웃게 됐다."

    scene bg_infirmary_day with dissolve

    show sh1 at center_stage as sohee with dissolve
    sh "여긴 보건실이야."
    sh "아픈 애들이 오기도 하고,"
    sh "너무 피곤하면 잠깐 쉬러 오는 애들도 있어."

    sh "보건 선생님 되게 친절하셔."

    "소희는 설명하는 내내 내 옆에 바짝 붙어 걸었다."

    sh "아, 이따 쉬는 시간에 나랑 같이 앉을래?"
    sh "나 너한테 물어보고 싶은 거 많아."

    "소희는 내 얼굴을 빤히 보며 눈을 반짝였다."

    hide sohee
    show sh5 at center_stage as sohee with dissolve

    sh "근데 네가 다른 애들이랑 먼저 얘기하면..."
    sh "나 조금 아쉬울 것 같아."

    n "어?"

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "아니, 아니."
    sh "꼭 그래야 한다는 건 아니고."
    sh "그냥 나랑 제일 많이 얘기하면 좋겠다는 뜻이야."

    "소희는 웃으려고 했지만, 입술이 살짝 삐죽 나와 있었다."
    "소희는 전학 첫날부터 나를 친한 친구처럼 대해 주었다."
    "덕분에 전학 첫날의 긴장감이 좀 내려간 것 같았다."

    return
# ----------------------------------------------------------
# 나은 소개 분기 — 조심스러운 공감, 자기 경계의 흐림
# ----------------------------------------------------------
label d1_intro_naeun:
    $ mark_intro("naeun")
    $ set_bgm(audio.bgm_naeun_soft)
    scene bg_counseling_room with fade

    show ne5 at center_stage as naeun with dissolve
    ne "여기는 상담실이야."
    ne "꼭 큰일이 있을 때만 오는 곳은 아니고..."
    ne "속상할 때 잠깐 앉아 있어도 된대."

    ne "아까 애들이 한꺼번에 쳐다봐서 놀랐지?"
    ne "천천히 말해도 괜찮아."

    "나은이는 내가 대답할 때까지 조용히 기다려주었다."

    n "응..."
    n "좀 그랬어."

    ne "그럴 수 있어."
    ne "그냥 전학생이라 궁금했던 걸 거야."

    "나은이의 목소리는 작았지만 차분했다."
    "나은이의 말을 듣고 마음이 조금 편해졌다."

    ne "가방에 달린 이 배지..."
    ne "내가 좋아하는 캐릭터랑 비슷하네."

    n "응."
    n "나도 이 캐릭터 좋아해."

    hide naeun
    show ne3 at center_stage as naeun with dissolve
    ne "아..."
    ne "그렇구나."
    ne "나도 좋아해."

    "나은이의 표정이 아주 조금 밝아졌다."
    "나은이는 말을 많이 하지는 않았다."
    "대신 내가 불편하지 않게 기다려주었다."

    scene bg_garden_day with dissolve

    show ne5 at center_stage as naeun with dissolve
    ne "여기가 내가 제일 좋아하는 정원이야."
    ne "교실이 시끄러울 때 여기 오면 조금 편해져."

    "나은이는 앞서 걷지 않고, 내 걸음에 맞춰 천천히 걸었다."

    "그때 지나가던 아이 하나가 나은이를 불렀다."

    ex_ja "나은아, 너 그림 잘 그리잖아."
    ex_ja "내 강아지 사진 보고 작게 그려줄 수 있어?"

    hide naeun
    show ne2 at center_stage as naeun with dissolve
    ne "지금...?"

    "나은이는 옷자락을 잡고 우물쭈물했다."

    ne "응..."
    ne "그래."

    ex_ja "진짜?"
    ex_ja "고마워!"

    "옆에 있던 다른 아이가 바로 끼어들었다."

    ex_ms "어, 나도 나도!"
    ex_ms "그럼 내 얼굴도 귀엽게 그려줘."
    ex_ms "쉬는 시간에 해줄 수 있지?"

    "나은이는 잠깐 입을 열었다가 다시 다물었다."

    hide naeun
    show ne1 at center_stage as naeun with dissolve
    ne "어..."
    ne "시간 되면... 해볼게."

    "아이들은 고맙다며 웃고는 먼저 걸어갔다."
    "나은이는 웃어 보였지만, 손은 아직 옷자락을 잡고 있었다."

    n "괜찮아?"
    n "싫으면 안 해도 되는 거 아니야?"

    ne "괜찮아."
    ne "그냥... 금방 하니까."

    "나은이는 급히 대답했다."
    "그리고 곧바로 정원 쪽으로 시선을 돌렸다."
    "괜찮다고 했지만, 별로 괜찮아 보이지는 않았다."
    "그래도 배려심 깊은 나은이와 걸어다니니"
    "전학 첫날의 긴장이 좀 내려간 것 같았다."

    return

label d1_intro_end:
    $ set_bgm(audio.bgm_classroom_light)

    scene bg_classroom_morning with fade

    "안내를 마치고 교실로 돌아오자, 1교시 시작 종이 울렸다."

    "수업 시간은 정신없이 지나갔다."

    "쉬는 시간마다 아이들은 복도로 나가거나 책상에 엎드렸다."
    "나는 어디에 있어야 할지 몰라 필통만 만지작거렸다."

    "4교시가 끝나고 급식 종이 울렸다."
    "아이들이 하나둘 자리에서 일어났다."

    jump d1_lunch_system_meeting
# ----------------------------------------------------------
# D1 점심 — 성향 기반 시스템 1:1
# 지호는 D1 안내/오후 선택에서 충분히 다루므로 점심 시스템에서는 제외
# ----------------------------------------------------------

label d1_lunch_system_meeting:
    $ d1_system_met = d1_system_person_by_trait(player_trait)

    if d1_system_met == "sohee":
        jump d1_system_sohee
    elif d1_system_met == "hayoung":
        jump d1_system_hayoung
    elif d1_system_met == "seoyeon":
        jump d1_system_seoyeon
    elif d1_system_met == "naeun":
        jump d1_system_naeun
# ----------------------------------------------------------
# D1 점심 — 소희
# 따뜻하지만 가까워지는 속도가 빠른 친구
# ----------------------------------------------------------
label d1_system_sohee:
    $ set_bgm(audio.bgm_sohee_warm)

    $ mark_met("sohee")
    scene bg_classroom_after with fade

    "점심을 먹고 교실로 돌아왔다."
    "소희가 내 책상 쪽으로 거의 뛰어왔다."

    show sh3 at center_stage as sohee with dissolve
    sh "유진아!"
    sh "급식 괜찮았어?"
    sh "아까 줄 설 때 좀 어색해 보이던데, 자리 찾는 건 괜찮았어?"

    n "응."
    n "아직 누가 누구랑 앉는지 잘 모르겠더라."

    hide sohee
    show sh4 at center_stage as sohee with dissolve
    sh "그치, 첫날엔 진짜 헷갈려!"
    sh "나도 알려줄 수 있어."
    sh "누가 어디 앉는지, 누구한테 물어보면 되는지."

    "소희는 내 책상 옆에 바짝 서서 빠르게 말했다."

    hide sohee
    show sh1 at center_stage as sohee with dissolve
    sh "그러니까 오늘 쉬는 시간이나 청소할 때,"
    sh "같이 다닐 사람 없으면 나랑 있어."
    sh "내가 옆에 있으면 덜 어색할 거야!"

    "소희는 환하게 웃었다."
    "고마운 말이었다."

    "하지만 소희는 내가 바로 대답하기를 기다리는 것처럼,"
    "내 얼굴을 계속 보고 있었다."

    $ choice_question_text = "소희에게 어떻게 답할까?"
    window hide

    menu:

        "고마워. 오늘은 네가 알려주는 대로 다녀볼게.":
            window show
            $ add_like("sohee", 1)
            $ add_neg("sohee", 2)
            $ choice_log.append("D1_sohee_C_depend")

            n "응."
            n "오늘은 네가 알려주는 대로 다녀볼게."
            n "아직 누가 누군지 잘 모르겠어서."

            hide sohee
            show sh4 at center_stage as sohee with dissolve
            sh "진짜?"
            sh "완전 좋아!"

            "소희의 얼굴이 바로 밝아졌다."

            sh "그럼 쉬는 시간에도 나랑 가고,"
            sh "청소할 때도 나랑 같이 있자."
            sh "다른 애들이 말 걸면 내가 누구인지 알려줄게."

            "소희는 장난처럼 말했지만, 목소리는 꽤 신나 있었다."

            hide sohee
            show sh1 at center_stage as sohee with dissolve
            sh "오늘은 나만 따라오면 돼!"

            "소희는 환하게 웃었다."
            "고맙긴 했지만, 조금 빠른 느낌도 들었다."


        "고마워. 다른 애들이랑도 천천히 얘기해볼게.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", -1)
            $ choice_log.append("D1_sohee_A_equal")

            n "고마워, 소희야."
            n "네가 챙겨준다고 하니까 마음이 좀 놓여."
            n "그래도 나도 반 애들이 어떤지 천천히 알아가보고 싶어."

            hide sohee
            show sh2 at center_stage as sohee with dissolve
            sh "아..."
            sh "응, 맞아."
            sh "전학 첫날인데 한 명이랑만 있으면 더 어색할 수도 있겠다."
            hide sohee
            show sh3 at center_stage as sohee with dissolve
            "소희는 아쉬운 듯 입술을 살짝 모았다."
            "그러다 곧 고개를 끄덕였다."
            hide sohee
            show sh1 at center_stage as sohee with dissolve
            sh "그럼 모르는 거 생기면 나한테 물어봐."
            sh "나도 다른 애들이랑 얘기할 수 있게 알려줄게."

            n "응."
            n "그게 좋겠어."

            "소희는 다시 웃었다."

        "괜찮아. 오늘은 혼자 있어볼게.":
            window show
            $ add_like("sohee", 0)
            $ add_neg("sohee", 1)
            $ choice_log.append("D1_sohee_B_plain")

            n "괜찮아."
            n "아직 새 학교라 그런지 좀 정신이 없어서,"
            n "오늘은 혼자 있어볼게."

            hide sohee
            show sh2 at center_stage as sohee with dissolve
            sh "아..."
            sh "그래?"

            "소희의 목소리가 조금 작아졌다."
            "방금 전까지 밝던 표정도 조금 가라앉았다."

            sh "그럼..."
            sh "나중에 심심하면 불러."

            "소희는 자기 자리로 가려다가,"
            "한 번 더 내 쪽을 돌아봤다."
             
    if "D1_sohee_A_equal" in choice_log:
        "그때 다른 아이가 소희를 불렀다."
        "소희는 내 쪽을 한 번 보고는 고개를 끄덕였다."

        hide sohee
        show sh1 at center_stage as sohee with dissolve

        sh "나 잠깐 갔다 올게."
        sh "모르는 거 생기면 진짜 물어봐도 돼!"

        "소희는 여전히 밝았다."
        "그래도 아까처럼 내 옆에 바짝 붙어 있지는 않았다."

        "나는 그제야 의자에 등을 살짝 기대었다."


    elif "D1_sohee_C_depend" in choice_log:
        "그때 다른 아이가 소희를 불렀다."
        "소희는 바로 대답하지 않고, 먼저 내 팔을 톡 건드렸다."

        hide sohee
        show sh4 at center_stage as sohee with dissolve

        sh "나 잠깐만 갔다 올게."
        sh "금방 올 테니까 기다려줘!"

        "소희는 신난 얼굴로 뛰어갔다."
        "소희가 가고 나서도, 내 팔에는 방금 톡 건드린 느낌이 남아 있었다."


    elif "D1_sohee_B_plain" in choice_log:
        "그때 다른 아이가 소희를 불렀다."
        "소희는 대답하려다가, 내 얼굴을 한 번 더 봤다."

        hide sohee
        show sh3 at center_stage as sohee with dissolve

        sh "그럼... 나 갈게."
        sh "나중에라도 필요하면 불러."

        "소희는 웃어 보였지만, 발걸음은 조금 느렸다."

        "나는 괜히 필통 끝을 손가락으로 밀었다가,"
        "다시 제자리에 놓았다."


    "곧 수업 종이 울리고 오후 수업이 시작됐다."
    "청소와 종례까지 마치고 나니,"
    "어느새 전학 첫날이 끝나 있었다."

    jump d1_go_home

# ----------------------------------------------------------
# D1 점심 — 하영
# 자신감 있고 분위기를 잘 읽지만, 무리의 선을 자연스럽게 나누는 친구
# ----------------------------------------------------------
label d1_system_hayoung:
    $ set_bgm(audio.bgm_hayoung_social)
    $ mark_met("hayoung")
    scene bg_cafeteria_after with fade

    "급식판을 받아 들고 빈자리를 찾고 있는데, 창가 자리에서 하영이가 손짓했다."

    show h4 at center_stage as hayoung with dissolve
    hy "유진아, 여기 자리 있어."
    hy "처음엔 어디 앉아야 할지 좀 헷갈리지?"

    "하영이 주변에는 이미 몇 명이 앉아 밥을 먹고 있었다."
    "하영이가 옆 의자를 살짝 빼주었다."
    "다른 아이들도 자리를 조금씩 비켜주었다."

    n "응."
    n "아직 누가 누구랑 앉는지 잘 모르겠어."

    hy "처음엔 그게 제일 어렵지."
    hy "우리 반 애들은 창가 쪽에 많이 앉아."
    hy "저쪽은 계속 얘기하는 애들이 많고,"
    hy "뒤쪽은 조용히 먹는 애들이 자주 앉아."

    hide hayoung
    show h5 at center_stage as hayoung with dissolve
    "하영이는 급식실을 익숙하게 둘러보고 다시 나를 봤다."

    hy "유진이는 어디가 편해?"
    hy "내가 아는 건 알려줄게."
    $ choice_question_text = "하영이에게 어떻게 답할까?"
    window hide

    menu:

        "오늘은 조용한 자리에서 먹을래.":
            window show
            $ add_like("hayoung", 0)
            $ choice_log.append("D1_hayoung_B_plain")

            n "오늘은 조용한 자리에서 먹을래."
            n "첫날이라 그런지 아직 좀 정신이 없어서."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve
            hy "아, 그런 쪽?"

            "하영이는 바로 고개를 끄덕였다."

            hy "그럼 나은이나 서연 쪽이 편할 수도 있겠다."
            hy "둘 다 막 시끄러운 편은 아니니까."

            "하영이는 더 붙잡지 않았다."
            "대신 손가락으로 조용한 테이블 쪽을 가볍게 가리켜주었다."

        "네 얘기도 듣고, 직접 알아볼래.":
            window show
            $ add_like("hayoung", 2)
            $ add_neg("hayoung", -1)
            $ choice_log.append("D1_hayoung_A_equal")

            n "네가 알려주는 것도 듣고 싶어."
            n "근데 누가 어떤 애인지는 직접 얘기해보면서 천천히 알아가고 싶어."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve
            hy "오, 괜찮은데?"
            hy "말만 듣고 정하면 다를 때도 있거든."

            "하영이는 눈꼬리를 접으며 웃었다."

            hy "그럼 일단 이름만 알려줄게."
            hy "궁금한 거 있으면 그때 물어봐."

            "하영이는 다시 젓가락을 들었다."
            "내 식판 놓을 자리는 그대로 비워두었다."


        "누가 누구랑 친한지 알려줘.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", 2)
            $ choice_log.append("D1_hayoung_C_follow")

            n "누가 누구랑 친한지 알려줘."
            n "아직 나는 누가 어떤 애인지 잘 모르니까."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve
            hy "그래?"
            hy "그럼 내가 아는 만큼만 말해줄게."

            "하영이는 급식실 쪽을 한 번 둘러봤다."

            hy "저쪽 애들은 같이 있으면 재밌어."
            hy "근데 말이 많아서 처음엔 조금 정신없을 수도 있어."

            "옆에 앉아 있던 친구가 킥 하고 웃었다."

            hy "저쪽은 조용한데,"
            hy "친해지려면 시간이 좀 걸릴걸?"

            "하영이는 목소리를 조금 낮췄다."

            hy "그리고 처음엔 착해 보여도,"
            hy "계속 같이 있으면 조금 피곤한 애들도 있어."

            "하영이의 말에 주변 아이들이 웃었다."
            "나는 누구에게 먼저 말을 걸어야 할지 더 헷갈렸다."


    if "D1_hayoung_A_equal" in choice_log:
        "점심을 먹는 동안, 하영이는 반 아이들 이름을 몇 명 알려주었다."
        "누가 어디에 자주 앉는지도 짧게 말해주었다."

        hide hayoung    
        show h5 at center_stage as hayoung with dissolve

        hy "일단 이 정도만 알아도 덜 헷갈릴 거야."
        hy "나머지는 네가 직접 얘기해보면 되고."

        "하영이는 장난스럽게 웃었다."
        "나는 조금 편해진 마음으로 식판을 내려놓았다."


    elif "D1_hayoung_C_follow" in choice_log:
        "점심을 먹는 동안, 나는 하영이 말을 계속 듣게 됐다."
        "하영이는 밥을 먹으면서도 아이들 쪽을 살짝살짝 가리켰다."

        hide hayoung
        show h2 at center_stage as hayoung with dissolve

        hy "아, 저 애는 처음엔 말 걸기 쉬워 보여도,"
        hy "가끔 장난이 좀 세."

        "하영이가 말하자 옆에 있던 친구가 작게 웃었다."
        "나는 아직 말도 안 해본 아이들을 먼저 조심하게 됐다."

        "정보를 많이 들은 것 같았는데,"
        "오히려 누구에게 먼저 말을 걸어야 할지 더 어려워졌다."


    elif "D1_hayoung_B_plain" in choice_log:
        "나는 하영이가 가리킨 쪽을 한 번 보고, 식판을 고쳐 들었다."

        hide hayoung
        show h5 at center_stage as hayoung with dissolve

        hy "필요하면 말해."
        hy "자리 헷갈리면 알려줄게."

        "하영이는 웃었지만, 더 붙잡지는 않았다."
        "나는 조금 떨어진 빈자리를 찾아 천천히 걸어갔다."

    "시끌벅적했던 점심시간이 끝나고 오후 수업이 시작됐다."
    "청소와 종례까지 마치고 나니,"
    "어느새 전학 첫날이 끝나 있었다."
    jump d1_go_home

# ----------------------------------------------------------
# D1 점심 — 서연
# 필요한 일을 챙기지만, 말이 곧게 나가는 친구
# ----------------------------------------------------------
label d1_system_seoyeon:
    $ set_bgm(audio.bgm_seoyeon_clear)
    $ mark_met("seoyeon")
    scene bg_cafeteria_day with fade

    "점심을 먹고 식판을 들고 나왔다."
    "그런데 그릇 놓는 곳이 두 군데로 나뉘어 있었다."
    "한쪽은 국그릇을 놓는 곳 같고, 다른 한쪽은 식판을 놓는 곳 같았다."

    "처음이라 어디부터 놓아야 할지 바로 알 수 없었다."
    "나는 앞에 있는 아이들을 따라 하려고 잠깐 멈춰 섰다."

    show sy5 at center_stage as seoyeon with dissolve
    sy "유진아."

    n "어?"
    n "응, 서연아."

    sy "거기 아니야."
    sy "식판은 오른쪽, 국그릇은 왼쪽."

    "서연이가 바로 말하자, 앞줄에 있던 아이 몇 명이 뒤를 돌아봤다."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve
    sy "그리고 거기 서 있으면 뒤에 애들 못 지나가."
    sy "일단 옆으로 비켜."

    "서연이 말은 틀리지 않았다."

    n "아..."
    n "미안."

    "나는 급히 옆으로 비켜섰다."
    "서연이는 내 식판을 보고 순서를 하나씩 짚어주었다."

    sy "국그릇 먼저."
    sy "그다음 식판."
    sy "수저는 저 통."

    "어쩐지 두 볼이 화끈거렸다."
    "그래도 서연이가 말해주지 않았으면,"
    "나는 식판을 들고 더 오래 서 있었을지도 몰랐다."

    $ choice_question_text = "서연이에게 어떻게 답할까?"
    window hide

    menu:
        "다음엔 '이렇게 하면 돼.'라고 말해주면 좋겠어.":
            window show
            $ add_like("seoyeon", 2)
            $ add_neg("seoyeon", -1)
            $ choice_log.append("D1_seoyeon_A_equal")

            n "알려줘서 고마워, 서연아."
            n "근데 방금은 애들이 다 봐서 조금 민망했어."
            n "내가 혼나는 것처럼 들렸거든."

            n "다음엔 '거기 아니야'보다,"
            n "'이렇게 하면 돼'라고 말해주면 좋겠어."

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve
            sy "아."

            "서연이는 잠깐 내 얼굴을 보더니, 그릇 놓는 곳 쪽을 봤다."

            sy "혼내려고 한 건 아니었어."
            sy "그냥 순서가 틀려서 말한 건데."

            n "응."
            n "알아."
            n "그래도 조금 놀랐어."

            sy "그럼 다음엔 그렇게 말할게."
            sy "'이렇게 하면 돼'라고."

            "서연이는 짧게 고개를 끄덕였다."
            "말은 여전히 짧았지만, 내 말을 그냥 넘기지는 않았다."


        "아, 미안. 덕분에 알았어. 고마워.":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", 2)
            $ choice_log.append("D1_seoyeon_D_label")

            n "아, 미안."
            n "덕분에 알았어. 고마워."

            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve
            sy "그래."
            sy "처음이면 헷갈릴 수 있어."

            sy "대신 멈춰 서기 전에 옆을 먼저 봐."
            sy "네가 멈추면 뒤에 애들이 기다리게 돼."

            n "응..."

            "얼굴이 조금 뜨거워졌다."
            "나는 서연이 눈을 바로 보지 못하고 식판 끝만 내려다봤다."

            hide seoyeon
            show sy3 at center_stage as seoyeon with dissolve
            sy "급식실에서는 줄 막히면 바로 보여."
            sy "모르면 빨리 물어보는 게 나아."

            n "응."
            n "알겠어."

            "서연이 말은 맞았다."
            "하지만 대답할수록 내가 더 혼나는 것 같았다."


        "알겠어. 다음엔 내가 먼저 찾아봐도 될까?":
            window show
            $ add_like("seoyeon", 0)
            $ add_neg("seoyeon", 1)
            $ choice_log.append("D1_seoyeon_D_reject")

            n "알겠어."
            n "그런데 다음부터는 내가 먼저 찾아보고 해도 될까?"

            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve
            sy "그래."
            sy "표지판 보면 돼."

            n "응."

            hide seoyeon
            show sy3 at center_stage as seoyeon with dissolve
            sy "그래도 모르면 물어봐."
            sy "혼자 찾다가 또 막히면 더 오래 걸리니까."

            "서연이는 틀린 말을 하지는 않았다."
            "그래도 나는 더 묻지 않고 식판을 들었다."

            "급식실 소리가 아까보다 더 크게 들렸다."


    if "D1_seoyeon_A_equal" in choice_log:
        "반납을 마치고 교실로 돌아가는 길이었다."

        scene bg_corridor_day
        with dissolve

        show sy5 as seoyeon at center_stage
        with Dissolve(0.25)

        "서연이는 내 걸음보다 반 발짝 앞에서 걸었다."

        sy "사물함 번호도 아직 못 받았지."
        sy "종례 전에 선생님께 말하면 돼."

        n "응."
        n "고마워."

        "서연이는 잠깐 나를 봤다."

        hide seoyeon
        show sy2 as seoyeon at center_stage
        with Dissolve(0.25)

        sy "방금은 괜찮았어?"

        n "응."
        n "아까보다 괜찮았어."

        "서연이는 짧게 고개를 끄덕였다."


    elif "D1_seoyeon_D_label" in choice_log:
        "반납을 마치고 교실로 돌아가는 길에, 서연이는 하나씩 더 알려주기 시작했다."

        scene bg_corridor_day
        with dissolve

        show sy5 as seoyeon at center_stage
        with Dissolve(0.25)

        sy "급식실 나올 때는 오른쪽 문."
        sy "우유갑은 접어서 따로."
        sy "사물함 번호 못 받았으면 종례 전에 말해야 해."

        "서연이의 설명은 정확했다."
        "하지만 나는 어느 순간부터 대답보다 고개만 더 많이 끄덕였다."


    elif "D1_seoyeon_D_reject" in choice_log:
        "반납을 마치고 교실로 돌아가는 길에, 서연이는 더 설명하지 않았다."

        scene bg_corridor_day
        with dissolve

        show sy3 as seoyeon at center_stage
        with Dissolve(0.25)

        sy "사물함 번호는 종례 전에 선생님께 물어봐."
        sy "까먹지 말고."

        n "응."

        "서연이는 짧게 말하고 먼저 걸어갔다."


    "교실로 돌아오자 곧 오후 수업이 시작됐다."
    "청소와 종례까지 마치고 나니,"
    "어느새 전학 첫날이 끝나 있었다."

    jump d1_go_home

    jump d1_go_home

# ----------------------------------------------------------
# D1 점심 — 나은
# 조용히 배려하지만, 자기 마음은 쉽게 말하지 못하는 친구
# ----------------------------------------------------------
label d1_system_naeun:
    $ mark_met("naeun")
    scene bg_library_day with fade
    $ set_bgm(audio.bgm_naeun_soft)

    "점심시간이 끝나기 조금 전, 나는 도서실에 들렀다."
    "맨 구석 창가 자리에는 나은이가 앉아 있었다."
    "나은이는 공책을 펴놓고 뭔가를 그리고 있었다."

    "공책 한쪽에는 작은 강아지 그림이 있었다."

    show ne5 at center_stage as naeun with dissolve
    ne "유진아..."

    n "아, 나은아."
    n "여기 있었구나."

    ne "응..."
    ne "교실이 조금 시끄러워서."

    "나은이는 자기 옆 의자를 조용히 빼주었다."

    n "여기 앉아도 돼?"

    ne "응."
    ne "괜찮아."

    "나는 의자에 앉다가 공책에 그려진 그림을 봤다."

    n "와."
    n "이거 네가 그린 거야?"

    hide naeun
    show ne2 at center_stage as naeun with dissolve
    ne "아..."
    ne "그냥 낙서야."

    "나은이는 웃어 보였지만, 손가락으로 그림을 살짝 가렸다."

    $ choice_question_text = "나은이에게 어떻게 말할까?"
    window hide

    menu:

        "나은이 너 그림 잘 그리는구나! 혹시 다른 것도 보여줄래?":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", 2)
            $ choice_log.append("D1_naeun_C_burden")

            n "나은이 너 그림 잘 그리는구나!"
            n "그림 진짜 귀엽다."
            n "혹시 다른 것도 조금만 보여줄 수 있어?"

            hide naeun
            show ne2 at center_stage as naeun with dissolve
            ne "어..."
            ne "그냥 낙서라서..."

            "나은이는 공책을 덮으려다 말고, 다시 천천히 펼쳤다."

            hide naeun
            show ne1 at center_stage as naeun with dissolve
            ne "그..."
            ne "괜찮으면 조금만 보여줄게."

            "나은이는 몇 장을 조심스럽게 넘겼다."
            "웃고 있었지만, 종이를 넘기는 속도는 아주 느렸다."

            n "와, 너 진짜 잘 그린다."

            ne "아냐..."
            ne "그 정도는 아니야."

            "나은이는 작게 웃고는 공책을 다시 덮었다."
            "그리고 공책을 다시 펼치지 않은 채, 어색하게 창밖으로 시선을 돌렸다."


        "아, 그림 그리는구나. 나는 책 좀 보고 있을게.":
            window show
            $ add_like("naeun", 0)
            $ choice_log.append("D1_naeun_B_plain")

            n "아, 그림 그리는구나."
            n "나는 책 좀 보고 있어도 돼?"
            n "여기 조용해서 좋다."

            hide naeun
            show ne5 at center_stage as naeun with dissolve
            ne "응..."
            ne "저쪽에 권장 도서 책장 있어."

            n "고마워."

            "나는 얇은 책 한 권을 꺼내 들었다."
            "나은이는 다시 그림을 그렸다."
            "우리는 잠깐 말없이 각자 할 일을 했다."

            "도서실 창가 쪽은 교실보다 훨씬 조용했다."


        "혹시 보여주는 거 불편해? 안 봐도 괜찮아.":
            window show
            $ add_like("naeun", 2)
            $ add_neg("naeun", -1)
            $ choice_log.append("D1_naeun_A_equal")

            n "혹시 보여주는 거 불편해?"
            n "네가 불편하면 안 봐도 괜찮아."

            hide naeun
            show ne1 at center_stage as naeun with dissolve
            ne "아..."
            ne "조금... 부끄러워서."

            "나은이는 공책을 조심스럽게 덮었다."

            n "그럼 안 볼게."
            n "그냥 그림이 귀엽다고 생각했어."

            ne "고마워."
            ne "나중에... 완성하면 보여줄게."

            "나은이는 그림을 가리고 있던 손을 천천히 내렸다."


    if "D1_naeun_A_equal" in choice_log:
        "종이 울리기 전, 나은이가 빈 종이를 내 쪽으로 살짝 밀었다."

        hide naeun
        show ne5 at center_stage as naeun with dissolve
        ne "여기에 같이 그림 그릴래?"

        "나는 연필을 들고 종이 한쪽에 작은 별을 그렸다."
        "나은이는 그 옆에 작은 강아지 발자국을 그렸다."


    elif "D1_naeun_C_burden" in choice_log:
        "종이 울리기 전, 나은이는 공책을 가방 안쪽에 조심스럽게 넣었다."

        hide naeun
        show ne2 at center_stage as naeun with dissolve
        ne "어..."
        ne "종 치겠다. 우리 이제 올라갈까?"

        "점심시간은 조금 남아 있었다."
        "하지만 나은이는 공책을 들고 일어섰다."

        n "응."
        n "가자."

        "나은이는 웃어 보였지만, 발걸음은 조금 빨랐다."


    elif "D1_naeun_B_plain" in choice_log:
        "종이 울리기 전, 나는 책을 덮고 자리에서 일어났다."

        n "책장 알려줘서 고마워."

        hide naeun
        show ne5 at center_stage as naeun with dissolve
        ne "응..."
        ne "나중에 조용한 데 필요하면 또 와도 돼."

        "나은이는 작게 웃었다."


    "수업 종이 울리고 교실로 돌아오자, 오후 수업이 시작됐다."
    "청소와 종례까지 마치고 나니,"
    "어느새 전학 첫날이 끝나 있었다."

    jump d1_go_home


# ----------------------------------------------------------
# D1 하교 + 일기 자동 생성
# ----------------------------------------------------------

label d1_go_home:
    $ set_bgm(audio.bgm_evening)

    scene bg_room_evening
    with slow_fade

    "집에 도착하자마자 신발을 대충 벗어두고 방으로 들어왔다."
    "책가방을 바닥에 내려놓자 어깨가 욱씬거렸다."

    "교과서가 무거워서만은 아니었다."

    "교실 뒷문을 열던 순간이 떠올랐다."
    "내가 들어가자 웅성웅성거리던 교실."
    "나를 빤히 쳐다보던 아이들의 눈빛."

    "그리고 오늘 처음 알게 된 이름들도 떠올랐다."

    "지호."
    "하영."
    "나은."
    "소희."
    "서연."

    "잊어버리기 전에 적어두는 게 좋겠다."

    "나는 책가방에서 일기장을 꺼냈다."

    jump d1_diary

label d1_diary:
    scene bg_diary with fade
    window hide

    $ _focus = d1_system_met
    $ _focus_name = display_name(_focus)
    $ _focus_like = like_of(_focus)
    $ _focus_neg = neg_of(_focus)

    $ diary_text1 = ""
    $ diary_text1 += "전학 첫날이 끝났다.\n"
    $ diary_text1 += "오늘은 새로 외워야 할 이름이 많았다.\n"
    $ diary_text1 += "지호, 하영, 나은, 소희, 서연.\n\n"

    if player_trait == "observe":
        $ diary_text1 += "나는 처음부터 많이 말하지는 않았다.\n"
        $ diary_text1 += "대신 애들이 말하고 행동하는 걸 조용히 지켜봤다.\n"
    elif player_trait == "social":
        $ diary_text1 += "나는 먼저 웃고 인사해보려고 했다.\n"
        $ diary_text1 += "그때는 괜찮은 줄 알았는데, 집에 오니 조금 피곤했다.\n"
    elif player_trait == "close":
        $ diary_text1 += "나는 빨리 편한 친구를 찾고 싶었다.\n"
        $ diary_text1 += "누구랑 있으면 덜 어색할지 계속 보게 됐다.\n"
    elif player_trait == "myway":
        $ diary_text1 += "나는 억지로 친한 척하지 않으려고 했다.\n"
        $ diary_text1 += "역시, 낯선 교실에 하루 종일 있는 건 생각보다 힘들었다.\n"
    else:
        $ diary_text1 += "나는 새 교실에서 어떻게 지내야 할지 계속 생각했다.\n"

    $ diary_text1 += "\n오늘은 뭘 해도 조심스러웠다.\n"
    $ diary_text1 += "아직 어색하지만, 내일은 오늘보다 조금 나았으면 좋겠다.\n"

    call screen diary_page(title="월요일 일기", content=diary_text1, body_yoffset=35)

    $ renpy.movie_cutscene("videos/diary.webm", stop_music=False)

    $ diary_text2 = ""

    if d1_system_met == "sohee":
        $ diary_text2 += "점심시간에는 소희가 나에게 다가왔다.\n"
        $ diary_text2 += "소희는 나를 더 챙겨주려는 것 같았다.\n\n"
        if "D1_sohee_A_equal" in choice_log:
            $ diary_text2 += "나는 고맙다고 했다.\n"
            $ diary_text2 += "하지만 다른 친구들도 천천히 알아가고 싶다고 말했다.\n"
        elif "D1_sohee_C_depend" in choice_log:
            $ diary_text2 += "나는 고맙다며, 소희 옆에 있겠다고 했다.\n"
            $ diary_text2 += "편하긴 했지만, 다른 친구들과 이야기해 볼 기회는 적어진 것 같다.\n"
        elif "D1_sohee_B_plain" in choice_log:
            $ diary_text2 += "하지만 나는 혼자 있어보겠다고 했다.\n"
            $ diary_text2 += "소희는 알았다며 웃었지만 조금 서운해 보였다.\n"

    elif d1_system_met == "hayoung":
        $ diary_text2 += "점심시간에는 하영이가 앉을 자리를 알려줬다.\n"
        $ diary_text2 += "하영이는 어떤 친구랑 친해지고 싶은지도 물었다.\n\n"
        if "D1_hayoung_A_equal" in choice_log:
            $ diary_text2 += "나는 직접 알아보겠다고 했다.\n"
            $ diary_text2 += "하영이는 조금 당황한 듯 보였지만, 알겠다고 했다.\n"
        elif "D1_hayoung_C_follow" in choice_log:
            $ diary_text2 += "나는 하영이에게 어떤 친구들이 있는지 알려달라고 했다.\n"
            $ diary_text2 += "그런데 대화를 해보기도 전에, 조심할 친구들부터 알게 된 것 같다.\n"
        elif "D1_hayoung_B_plain" in choice_log:
            $ diary_text2 += "나는 조용히 혼자 자리에서 먹겠다고 했다.\n"
            $ diary_text2 += "하영이는 더 붙잡지 않고 자리를 알려줬다.\n"

    elif d1_system_met == "seoyeon":
        $ diary_text2 += "급식실에서는 서연이가 반납 순서를 알려줬다.\n"
        $ diary_text2 += "고마웠지만 서연이의 목소리가 커서 조금 무안했다.\n\n"
        if "D1_seoyeon_A_equal" in choice_log:
            $ diary_text2 += "그래서 나는 다음엔 작게 말해주면 좋겠다고 했다.\n"
            $ diary_text2 += "서연이는 내 말을 듣고 고개를 끄덕였다.\n"
        elif "D1_seoyeon_D_label" in choice_log:
            $ diary_text2 += "그래도 나는 고맙다고만 말했다.\n"
            $ diary_text2 += "도움은 받았지만, 어쩐지 조금 작아진 기분도 들었다.\n"
        elif "D1_seoyeon_D_reject" in choice_log:
            $ diary_text2 += "그래서 나는 다음엔 내가 먼저 찾아보겠다고 했다.\n"
            $ diary_text2 += "서연이는 알겠다며 더 설명하지 않고 갔다.\n"

    elif d1_system_met == "naeun":
        $ diary_text2 += "점심시간에는 도서실에서 나은이를 만났다.\n"
        $ diary_text2 += "나은이는 조용히 옆자리를 비워주었다.\n\n"

        if "D1_naeun_A_equal" in choice_log:
            $ diary_text2 += "나는 나은이 그림을 계속 봐도 되는지 조심스럽게 물어봤다.\n"
            $ diary_text2 += "나은이는 조금 편해 보이는 얼굴로 그림을 더 보여줬다.\n"

        elif "D1_naeun_C_burden" in choice_log:
            $ diary_text2 += "나는 나은이의 다른 그림도 더 보고 싶어서 보여달라고 했다.\n"
            $ diary_text2 += "나은이는 조금 당황한 것 같았지만, 그림을 보여줬다.\n"

        elif "D1_naeun_B_plain" in choice_log:
            $ diary_text2 += "나는 나은이가 그리고 있는 그림 이야기를 꺼내지 않았다.\n"
            $ diary_text2 += "그래서 그런지, 나와 나은이는 조용히 같이 앉아 시간을 보냈다.\n"

    else:
        $ diary_text2 += "점심시간에도 여러 친구를 보았다.\n"
        $ diary_text2 += "하지만 아직 누가 어떤 친구인지 바로 알기는 어려웠다.\n"

    call screen diary_page(title="월요일 일기", content=diary_text2, body_yoffset=35)

    $ renpy.movie_cutscene("videos/diary.webm", stop_music=False)

    $ diary_text3 = ""
    if _focus == "none":
        $ diary_text3 += "아직 특별히 가까워진 친구는 없는 것 같다.\n"
        $ diary_text3 += "내일은 친구들을 조금 더 천천히 알아가보고 싶다.\n"

    else:
        $ diary_text3 += relation_status_text(_focus_like, _focus_neg) + "\n\n"

        if _focus_neg >= 4:
            $ diary_text3 += "그 친구랑 있을 때 조금 불편한 순간도 있었다.\n"
            $ diary_text3 += "다음엔 그냥 웃고 넘기기 전에 내 기분도 생각해봐야겠다.\n"

        elif _focus_like >= 5 and _focus_neg <= 2:
            $ diary_text3 += "그 친구랑은 조금 더 가까워진 것 같다.\n"
            $ diary_text3 += "그래도 아직 첫날이니까 천천히 알아가고 싶다.\n"

        elif _focus_like >= 3 and _focus_neg >= 3:
            $ diary_text3 += "그 친구랑 있으면 좋은 점도 있고, 어려운 점도 있었다.\n"
            $ diary_text3 += "다음엔 불편한 게 있으면 조금씩 말해보고 싶다.\n"

        else:
            $ diary_text3 += "아직은 어떤 친구인지 잘 모르겠다.\n"
            $ diary_text3 += "내일도 조금 더 지켜봐야겠다.\n"

    if burnout >= 4:
        $ diary_text3 += "\n나의 상태: 오늘은 많이 힘들었다.\n"
        $ diary_text3 += "내일은 모든 일을 다 하려고 하지 말기.\n"

    elif burnout >= 3:
        $ diary_text3 += "\n나의 상태: 생각할 일이 많았다.\n"
        $ diary_text3 += "그래도 처음보다는 교실이 조금 덜 낯설게 느껴졌다.\n"

    else:
        $ diary_text3 += "\n나의 상태: 조금 피곤했지만 괜찮았다.\n"

    if _focus != "none":
        show screen diary_focus_badge(_focus)
    call screen diary_page(title="월요일 관계 메모", content=diary_text3, body_yoffset=145)
    if _focus != "none":
        hide screen diary_focus_badge

    scene bg_room_evening with fade
    window show


    "내일은 화요일이다."
    "가방 지퍼를 닫고 나니 딸깍 소리가 났다."

    jump d2_start

# ==========================================================
# D2 화요일
# - 오전: 등교 및 반 분위기 관찰
# - 점심 후: 5교시 전 쉬는 시간, 갈등 목격 및 개입 1회
# - 방과 후: 선택 1:1 사건 1회
# - 같은 날 같은 인물 중복 금지
# ==========================================================

# ----------------------------------------------------------
# D2용 변수
# ----------------------------------------------------------

default d2_system_met = "none"
default d2_choice_met_1 = "none"
default d2_choice_met_2 = "none"
default d2_today_met = []
default d2_people_met = []

init python:
    import random

    def already_met_before_d2(name):
        return name in met_1on1

    def mark_d2_met(name):
        global d2_today_met, d2_people_met, met_1on1

        if name not in d2_today_met:
            d2_today_met.append(name)

        if name not in d2_people_met:
            d2_people_met.append(name)

        if name not in met_1on1:
            met_1on1.append(name)

    def choose_d2_system_person():
        candidates = ["jiho", "hayoung", "naeun", "sohee", "seoyeon"]

        base_candidates = [c for c in candidates if c != d1_system_met]
        not_yet_met = [c for c in base_candidates if c not in met_1on1]

        if not_yet_met:
            opposite_map = {
                "close": "seoyeon",
                "social": "naeun",
                "observe": "sohee",
                "myway": "jiho",
            }

            opposite = opposite_map.get(player_trait)

            if opposite in not_yet_met:
                return opposite

            return not_yet_met[0]

        if base_candidates:
            return random.choice(base_candidates)

        return candidates[0]


# ----------------------------------------------------------
# D2 시작
# ----------------------------------------------------------

label d2_start:
    $ day = 2
    $ d2_today_met = []
    $ d2_people_met = []
    $ d2_choice_met_1 = "none"
    $ d2_choice_met_2 = "none"
    $ d2_system_met = "none"
    $ set_bgm(audio.bgm_classroom_light)


    scene black
    with day_fade

    centered "화요일"
    pause 0.5

    scene bg_school_day with fade

    "어제와 같은 길을 걸어 학교에 도착했다."
    "교실 앞 복도에 서자, 문틈 사이로 아이들 떠드는 소리가 들렸다."

    scene bg_classroom_after with dissolve

    "문을 열자 시끌시끌한 교실이 보였다."
    "나는 내 자리에 앉아 가방을 내려놓았다."

    "교실은 어제보다 조금 자세히 보였다."

    "지호는 뒤쪽에서 친구들과 구긴 종이를 휴지통에 넣는 놀이를 하고 있었다."
    "종이가 휴지통 옆으로 떨어지자, 지호는 바로 달려가 주웠다."

    show jh1 at center_stage as jiho with dissolve
    jh "아! 이번엔 진짜 들어갈 것 같았는데!"

    hide jiho

    "친구들이 웃었다."

    show h4 at center_stage as hayoung with dissolve
    "하영이는 손거울을 꺼내 앞머리를 정리하고 있었다."
    "옆자리 친구가 귓속말을 하자, 하영이는 작게 웃었다."
    "그러다 누가 듣고 있는지 확인하듯 교실을 한 번 훑어봤다."
    hide hayoung

    
    show ne5 at center_stage as naeun with dissolve
    "나은이는 바닥에 떨어진 색연필을 조용히 주웠다."
    "주인 없는 책상 위에 올려놓았다."
    hide naeun

    
    show sh1 at center_stage as sohee with dissolve
    "소희는 교실에 들어오자마자 나를 보고 손을 크게 흔들었다."
    "가방도 내려놓지 않은 채 내 자리 쪽으로 다가왔다."

    sh "유진아! 좋은 아침!"
    "소희의 목소리는 아침부터 밝았다."
    hide sohee

    show sy2 at center_stage as seoyeon with dissolve
    "서연이는 칠판 옆 주번 이름표를 반듯하게 맞추고 있었다."
    "한 걸음 뒤로 물러나 확인했다."

    sy "이거 자꾸 비뚤어지네."

    hide seoyeon

    "아직 모두와 친해진 건 아니었다."
    "그래도 어제보다는, 같은 반이라는 느낌이 조금 들었다."

    jump d2_lunch_system_meeting
# ----------------------------------------------------------
# D2 점심 — 갈등 목격 및 개입
# 점심 후 5교시 전 쉬는 시간
# ----------------------------------------------------------

label d2_lunch_system_meeting:
    $ set_bgm(audio.bgm_classroom_light2)
    scene bg_classroom_day with fade

    "화요일 오전 수업은 월요일보다 조금 빠르게 지나갔다."

    "선생님은 5교시에 할 모둠 활동 이야기를 꺼내셨다."
    "선생님은 점심을 먹고 돌아오면 모둠별로 준비물을 확인하라고 하셨다."

    scene bg_classroom_after with fade

    "점심을 먹고 교실로 돌아오자," 
    "5교시 전 쉬는 시간이 시작되어 있었다."

    "나는 준비물을 내 자리에 올려두고 주변을 둘러봤다."
    "어디를 먼저 봐야 할지 잠깐 망설였다."

    jump d2_lunch_choose_person


label d2_lunch_choose_person:
    $ choice_question_text = "어느 쪽을 살펴볼까?"
    window hide

    menu:

        "{color=#7DB8FF}지호{/color}를 본다.":
            window show
            jump d2_preview_jiho

        "{color=#FF9ACD}하영{/color}이를 본다.":
            window show
            jump d2_preview_hayoung

        "{color=#BFA7FF}나은{/color}이를 본다.":
            window show
            jump d2_preview_naeun

        "{color=#FFCF6E}소희{/color}를 본다.":
            window show
            jump d2_preview_sohee

        "{color=#9FE0C5}서연{/color}이를 본다.":
            window show
            jump d2_preview_seoyeon
            
# ----------------------------------------------------------
# D2 갈등 미리보기 — 지호
# ----------------------------------------------------------

label d2_preview_jiho:
    show jh1 at center_stage as jiho with dissolve
    "뒷자리 쪽에서 지호가 민준이의 새 지우개를 들고 웃고 있었다."
    "장난처럼 보였지만, 민준이의 얼굴은 굳어 있었다."

    hide jiho with dissolve
    $ choice_question_text = "지호 쪽 상황을 살펴볼까?"
    window hide

    menu:

        "이 상황을 살펴본다.":
            window show
            $ d2_system_met = "jiho"
            jump d2_jiho_conflict

        "돌아간다.":
            window show
            jump d2_lunch_choose_person

# ----------------------------------------------------------
# D2 갈등 미리보기 — 하영
# ----------------------------------------------------------

label d2_preview_hayoung:

    show h4 at center_stage as hayoung with dissolve

    "교실 뒤편 하영이네 모둠이 오전에 만든 미술작품들을 붙이고 있었다."
    "바닥에는 색종이 조각과 테이프 조각이 남아 있었다."

    hide hayoung with dissolve
    $ choice_question_text = "하영이 쪽 상황을 살펴볼까?"
    window hide

    menu:

        "이 상황을 살펴본다.":
            window show
            $ d2_system_met = "hayoung"
            jump d2_hayoung_conflict

        "돌아간다.":
            window show
            jump d2_lunch_choose_person


# ----------------------------------------------------------
# D2 갈등 미리보기 — 소희
# ----------------------------------------------------------

label d2_preview_sohee:

    show sh5 at center_stage as sohee with dissolve

    "소희와 지안이는 나란히 앉아 이야기하고 있었다."
    "옆자리 친구가 다가가자, 소희의 입술이 살짝 삐죽했다."

    hide sohee with dissolve
    $ choice_question_text = "소희 쪽 상황을 살펴볼까?"
    window hide

    menu:

        "이 상황을 살펴본다.":
            window show
            $ d2_system_met = "sohee"
            jump d2_sohee_conflict

        "돌아간다.":
            window show
            jump d2_lunch_choose_person
# ----------------------------------------------------------
# D2 갈등 미리보기 — 나은
# ----------------------------------------------------------

label d2_preview_naeun:

    show ne2 at center_stage as naeun with dissolve
    "나은이, 채은이, 도윤이가 있는 모둠이 보였다."
    "나은이는 메모지가 든 투명 파일을 두 손으로 꼭 잡고 있었다."

    hide naeun with dissolve
    $ choice_question_text = "나은이 쪽 상황을 살펴볼까?"
    window hide

    menu:

        "이 상황을 살펴본다.":
            window show
            $ d2_system_met = "naeun"
            jump d2_naeun_conflict

        "돌아간다.":
            window show
            jump d2_lunch_choose_person

# ----------------------------------------------------------
# D2 갈등 미리보기 — 서연
# ----------------------------------------------------------

label d2_preview_seoyeon:
    show sy2 at center_stage as seoyeon with dissolve
    "교실 뒤쪽에서 서연이가 자를 대보며 모둠 활동지 위치를 맞추고 있었다."
    "옆에 선 민우는 그 모습을 가만히 보고 있었다."

    hide seoyeon with dissolve
    $ choice_question_text = "서연이 쪽 상황을 살펴볼까?"
    window hide

    menu:

        "이 상황을 살펴본다.":
            window show
            $ d2_system_met = "seoyeon"
            jump d2_seoyeon_conflict

        "돌아간다.":
            window show
            jump d2_lunch_choose_person

# ----------------------------------------------------------
# D2 점심 — 지호 갈등
# 장난은 밝지만, 상대가 불편해진 순간을 잘 못 보는 친구
# ----------------------------------------------------------

label d2_jiho_conflict:
    $ set_bgm(audio.bgm_jiho_active)

    $ mark_d2_met("jiho")
 
    show jh5 at center_stage as jiho with dissolve
    jh "잠깐만, 진짜 한 번만."
    jh "지금 각도 딱 좋다니까. 튕기면 바로 들어갈 것 같아."

    ex_mj "야, 그거 새 거야."

    hide jiho
    show jh1 at center_stage as jiho with dissolve
    jh "알았어, 알았어."
    jh "근데 아까 거의 들어갈 뻔했잖아."

    "지호는 민준이의 지우개를 책상 끝에 세웠다."
    "민준이의 얼굴이 굳었다."

    ex_mj "야..."

    "주변에 있던 아이 몇 명이 그쪽을 봤다."
    hide jiho
    show jh6 at center_stage as jiho with dissolve
    jh "아, 왜 그래."
    jh "안 잃어버려 걱정하지 마."
    jh "잘 봐, 이번엔 진짜 들어갈 거니까."

    "민준이는 대답하지 않고 지우개만 바라봤다."
    "지우개 한쪽 모서리에는 연필심 자국이 그새 묻었다."

    "민준이가 다시 손을 내밀었지만,"
    "지호는 지우개가 굴러갈 방향만 살피고 있었다."
    "민준이는 지호를 불러보려다 말고 손을 내렸다."
    "지호는 그런 변화를 눈치채지 못한 듯,"
    "책상 끝에 지우개를 다시 맞춰 세웠다."

    "끼어들어도 되는 걸까."
    "그냥 친구들끼리 장난치는 걸 수도 있었다."

    $ choice_question_text = "지호와 민준이 사이에 어떻게 끼어들까?"
    window hide

    menu:

        "민준아, 싫으면 싫다고 얘기해.":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", 0)
            $ choice_log.append("D2_jiho_B_check")

            n "민준아."
            n "너는 괜찮아?"
            n "싫으면 싫다고 말해도 돼."

            "민준이는 잠깐 나를 봤다."
            "그러고는 지호에게 손을 내밀었다."

            ex_mj "지호야, 나는 안 했으면 좋겠어."
            ex_mj "새 지우개라서."

            hide jiho
            show jh4 at center_stage as jiho with dissolve
            jh "아... 그래?"
            jh "그럼 안 할게."

            "지호는 지우개를 민준이에게 돌려줬다."
            "민준이는 지우개를 필통 안에 넣었다."

        "지호야, 민준이가 싫어하는 것 같아.":
            window show
            $ add_like("jiho", 2)
            $ add_neg("jiho", -1)
            $ choice_log.append("D2_jiho_A_equal")

            n "지호야."
            n "민준이가 싫어하는 것 같아."
            n "그거 민준이 거니까 돌려주는 게 좋겠어."

            hide jiho
            show jh4 at center_stage as jiho with dissolve
            jh "아..."

            "지호는 손에 든 지우개를 내려다봤다."
            "민준이는 손을 내밀었다."

            hide jiho
            show jh3 at center_stage as jiho with dissolve
            jh "미안."
            jh "난 그냥 장난친 건데..."

            "지호는 지우개를 민준이에게 건넸다."

            ex_mj "다음엔 물어보고 해."

            jh "응. 알겠어."

            "지호는 머쓱하게 뒷목을 긁었다."
            "민준이의 얼굴은 조금 풀렸다."


        "한 번만 해보고 바로 돌려주자.":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", 2)
            $ choice_log.append("D2_jiho_C_play")

            n "근데 진짜 잘 튕길 것 같긴 하다."
            n "한 번만 해보고 바로 돌려주면 안 돼?"

            hide jiho
            show jh1 at center_stage as jiho with dissolve
            jh "그치?"
            jh "딱 한 번만 해볼게."

            "지호는 다시 웃으며 지우개를 손끝으로 튕기려 했다."
            "민준이는 표정이 더 굳었다."

            ex_mj "...내가 아끼는 지우개라고."

            hide jiho
            show jh4 at center_stage as jiho with dissolve
            jh "아..."

            "지호는 그제야 손을 멈췄다."

            hide jiho
            show jh3 at center_stage as jiho with dissolve
            jh "알았어. 안 할게."
            jh "그냥 장난이었어."

            "지호는 지우개를 민준이에게 돌려줬다."
            "민준이는 지우개를 받아 필통 안에 넣었다."

            "지호는 머쓱하게 책상 위를 손가락으로 톡톡 두드렸다."

    if "D2_jiho_A_equal" in choice_log:
        "5교시 종이 치기 전, 지호가 내 자리 쪽으로 슬쩍 다가왔다."
        hide jiho
        show jh4 at center_stage as jiho with dissolve
        jh "유진, 그...아까 말해줘서 고마워."
        jh "나 민준이가 진짜 싫어하는 줄 몰랐어."

        n "민준이 표정이 안 좋아 보여서."
        n "말해주는 게 맞는 것 같았어."
        hide jiho
        show jh3 at center_stage as jiho with dissolve
        jh "응."
        jh "다음엔 먼저 물어봐야겠다."

        "지호는 민준이의 필통을 한 번 바라봤다."
        "지호는 짧게 고개를 끄덕이고 자기 자리로 돌아갔다."

    elif "D2_jiho_B_check" in choice_log:
        "5교시 종이 치기 전이었다."
        "지호는 자리에서 자신의 지우개를 굴리고 있었다."
        hide jiho
        show jh6 at center_stage as jiho with dissolve
        jh "민준이 진짜 싫었나..."
        jh "같이 재밌어하고 있던 거 아닌가."

        "지호는 작게 중얼거렸다."
        "민준이는 필통을 닫고 앞쪽만 보고 있었다."

        "지호는 민준이 쪽을 몇 번 흘끗 봤지만,"
        "먼저 말을 걸지는 못했다."
        "아까 웃고 있던 친구들도 조용히 자기 자리로 돌아갔다."

        "둘 사이가 조금 어색해 보였다."

    elif "D2_jiho_C_play" in choice_log:
        "5교시 종이 치기 전, 지호는 다시 친구들 쪽으로 돌아갔다."
        hide jiho
        show jh1 at center_stage as jiho with dissolve
        jh "아 역시 민준이 지우개가 잘 튕겼다니까."
        jh "다음엔 내 지우개로 해봐야겠다."

        "지호는 금방 다시 웃었다."
        "하지만 민준이의 표정은 여전히 굳어 있었다."
        "민준이는 지우개가 든 필통을 자기 쪽으로 당겼다."
        "지호는 그 모습을 보지 못한 채 다른 장난을 찾고 있었다."

    jump d2_after_system_to_afternoon

# ==========================================================
# 2. 하영이 분기 — 기획은 주도하지만 힘든 뒷정리는 피하려는 갈등
# ====================================================

label d2_hayoung_conflict:
    $ set_bgm(audio.bgm_hayoung_social)
    $ mark_d2_met("hayoung")
    scene bg_board_plain with fade
 
    "하영이네 모둠은 게시판 앞에서 미술작품들을 붙이고 있었다."
    "하영이가 위치를 말할 때마다 게시판은 점점 반듯해졌다."

    show h5 at center_stage as hayoung with dissolve
    hy "그건 조금만 위로."
    hy "소희 거는 조금만 오른쪽에 붙이자."

    "모둠원들은 하영이 말대로 작품들을 옮겼다."
    "확실히 게시판은 아까보다 보기 좋아졌다."
    hide hayoung

    show h1 at center_stage as hayoung with dissolve
    hy "응, 그게 낫다."

    "하지만 다 붙이고 나자, 바닥과 책상 위가 지저분했다."
    "잘린 색종이 조각과 테이프 조각, 풀 자국이 여기저기 남아 있었다."

    ex_cr "이제 정리해야겠다."
    ex_cr "누가 책상 닦을래?"

    hide hayoung    
    show h3 at center_stage as hayoung with dissolve

    "하영이는 물걸레를 보더니 손을 살짝 뒤로 뺐다."

    hy "아... 나 물걸레 냄새 나는 거 싫은데."
    hy "나는 배치랑 제목 위치 거의 다 봤잖아."
    hy "정리는 너희들이 나눠서 하면 안 돼?"

    "물걸레를 든 친구는 바로 대답하지 못했다."
    "다른 친구도 바닥에 떨어진 색종이 조각만 내려다봤다."

    "하영이는 게시판 쪽을 다시 확인했다."
    "책상 위의 풀 자국은 그대로 남아 있었다."
    "하영이가 먼저 정리를 시작하기를 기다리는 듯,"
    "모둠원들도 잠시 그 자리에 서 있었다."
    "잘 꾸민 게시판과 어수선한 바닥이 나란히 보였다."

    $ choice_question_text = "하영이네 모둠을 보며 뭐라고 할까?"
    window hide

    menu:

        "하영이만 빠지는 건 좀 그렇지 않아?":
            window show
            $ add_like("hayoung", 2)
            $ add_neg("hayoung", -1)
            $ choice_log.append("D2_hayoung_conflict_A")

            n "물걸레 냄새 싫은 건 알겠어."
            n "근데 하영이만 정리에서 빠지는 건 좀 그렇지 않아?"
            n "다 같이 만든 거잖아."

            hide hayoung
            show h2 at center_stage as hayoung with dissolve

            hy "그건 그렇긴 한데..."
            hy "내가 게시판 위치도 다 정했는데, 물걸레까지 해야 해?"
            n "하영이 덕분에 게시판이 깔끔해진 건 맞아."
            n "근데 정리까지 같이 하면 더 좋지 않을까?"

            "하영이는 입술을 삐죽였지만,"
            "바닥에 떨어진 색종이 조각을 하나씩 줍기 시작했다."

            hy "알았어, 알았어. 색종이부터 주울게."
            hy "물걸레는... 조금만 있다가."

            "물걸레를 들고 있던 친구도 다시 책상 쪽으로 몸을 숙였다."
            "조금 어색했지만, 정리는 같이 시작됐다."

        "그럼 내가 하영이 대신 물걸레 할게.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", 2)
            $ add_burnout(1)
            $ choice_log.append("D2_hayoung_conflict_B")

            n "그럼 내가 하영이 대신 물걸레 할게."
            n "하영이는 게시판 마지막으로 봐."

            hide hayoung    
            show h1 at center_stage as hayoung with dissolve

            hy "진짜?"
            hy "고마워, 유진아."

            hy "그럼 나는 삐뚤게 붙인 데만 다시 볼게."
            hy "이런 건 내가 봐야 깔끔하니까."

            "나는 물걸레를 받아 책상 위 풀 자국을 닦았다."
            "다른 친구는 바닥에 떨어진 색종이 조각을 주웠다."

            "하영이는 미술 작품들 모서리만 꾹꾹 눌렀다."
            hy "오, 이제 진짜 깔끔하다."

            "하영이는 기분 좋게 웃었다."
            "나는 물걸레를 접으며 고개를 끄덕였다."


        "그럼 하영이는 물걸레 말고 다른 정리 해.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", 1)
            $ choice_log.append("D2_hayoung_conflict_C")

            n "그럼 하영이는 물걸레 말고 다른 정리 해."
            n "색종이나 테이프 조각 줍는 건 할 수 있잖아."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "그 정도는 할 수 있지."
            hy "물걸레만 아니면 돼."

            ex_cr "그럼 내가 책상 닦을게."

            "하영이는 게시판 앞에 떨어진 색종이 조각을 하나씩 주웠다."
            "다 함께 정리를 시작하자,"
            "어색했던 분위기도 조금씩 풀렸다."
            "하영이도 주변을 둘러보며 남은 조각을 찾아 주웠다."
            "정리는 생각보다 금방 끝났다."
    
    if "D2_hayoung_conflict_A" in choice_log:
        "5교시 종이 치기 전이었다."
        "하영이가 손에 묻은 테이프 조각을 휴지통에 털어 넣었다."

        show h5 at center_stage as hayoung with dissolve

        hy "나 물걸레는 아직도 좀 싫은데..."
        hy "그래도 아까 같이 하긴 했어."

        n "응."
        n "그래서 그런지 게시판이 더 깔끔해 보이는 것 같아."

        hy "치, 그런가?"
        "하영이는 괜히 아닌 척하며 손을 털었다."
        "그러고는 게시판 쪽을 슬쩍 바라봤다."
        "표정이 아까보다 조금 편해 보였다."
        
    elif "D2_hayoung_conflict_B" in choice_log:
        "5교시 종이 치기 전," 
        "하영이는 게시판 앞에서 고개를 끄덕였다."

        show h5 at center_stage as hayoung with dissolve
        hy "역시 위치 잘 정하는게 중요하다니까."

        "하영이 발 옆에는 색종이 조각이 하나 그대로 있었다."

        "나는 물걸레를 접어서 정리함에 넣었다."
        "하영이는 그런 나를 보고 고개를 돌렸다."
        "그리고 다시 게시판 쪽을 바라봤다."

    elif "D2_hayoung_conflict_C" in choice_log:
        "5교시 종이 치기 전," 
        "하영이가 게시판 앞에서 손을 털었다."

        show h6 at center_stage as hayoung with dissolve
        hy "나 물걸레는 진짜 싫었어..."
        hy "그래도 색종이는 내가 거의 다 주웠다?"

        n "맞아. 다 같이 하니까 금방 깔끔해졌어."

        "하영이는 생색내듯 말하고는 게시판을 다시 바라봤다."

        hy "아까보다 훨씬 낫다."

        "하영이는 발밑에 남은 색종이 조각 하나를 발견하더니,"
        "마저 주워 휴지통에 넣었다."

    jump d2_after_system_to_afternoon
# ==========================================================
# 3. 나은이 분기 — 열심히 준비했지만 꺼내기도 전에 물러나는 갈등
# ==========================================================
label d2_naeun_conflict:
    $ mark_d2_met("naeun")
    $ set_bgm(audio.bgm_naeun_soft)

    scene bg_classroom_after with fade

    "채은이가 빈 메모지를 책상 가운데로 밀었다."

    ex_ce "우리 뭐 할지 빨리 정하자."
    ex_dy "응. 5교시 시작하면 바로 해야 하니까."

    show ne4 at center_stage as naeun with dissolve

    "나은이는 색깔별 메모지와 작은 그림이 든 투명 파일을 조심스럽게 꺼냈다."

    ne "나는..."
    ne "친구가 속상할 때 해주면 좋은 말이랑,"
    ne "미안하다고 말할 때 쓰면 좋은 말을 조금 찾아왔어."

    "나은이는 파일을 책상 위에 올려놓고 모서리를 꼭 잡았다."

    ex_dy "오, 나은이 많이 해왔네."
    ex_dy "그럼 자료는 나은이가 보면 되겠다."

    ex_ce "맞아."
    ex_ce "나은이는 글씨도 예쁘니까 문제 적는 것도 하면 좋겠다."

    ex_dy "그림도 가져왔잖아."
    ex_dy "그럼 꾸미는 것도 나은이가 하면 빨리 끝나지 않아?"

    "나은이는 파일을 열려던 손을 멈췄다."

    hide naeun
    show ne2 at center_stage as naeun with dissolve

    ne "어..."
    ne "내가?"

    ex_ce "응."
    ex_ce "나은이가 잘하니까."

    "나은이는 살짝 웃어 보였지만 대답은 바로 나오지 않았다."

    ne "그럼..."
    ne "내가 할 수 있는 데까지 해볼게."

    "어느새 나은이가 해야 할 일은 더 많아지고 있었다."

    $ choice_question_text = "모둠 의견을 어떻게 정할까?"
    window hide

    menu:

        "나은이 덕분에 우리 모둠 포스터 엄청 잘되겠다.":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", 2)
            $ choice_log.append("D2_naeun_conflict_C")

            n "나은이 덕분에 우리 모둠 포스터 엄청 잘되겠다."

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            ne "어...그런가?"

            ex_ce "맞아."
            ex_ce "나은이가 꼼꼼하니까 자료 더 잘 볼 거 아냐."

            ex_dy "그림도 네가 가져왔으니까,"
            ex_dy "꾸미는 것도 네가 하면 더 빠르겠지!"

            hide naeun
            show ne2 at center_stage as naeun with dissolve

            ne "응..."
            ne "내가 해볼게."

            "나은이는 빈 메모지 위에 작게 글씨를 적었다."

            "{i}자료 보기 - 나은{/i}"
            "{i}그림 고르기 - 나은{/i}"
            "{i}꾸미기 - 나은{/i}"

            "모둠 이야기는 빨리 정리됐다."
            "하지만 나은이 앞에 놓인 메모지는 점점 많아졌다."
            
        "잘한다고 다 맡는 건 아니지. 공평하게 나누자.":
            window show
            $ add_like("naeun", 2)
            $ add_neg("naeun", -1)
            $ choice_log.append("D2_naeun_conflict_A")

            n "잠깐만."
            n "나은이가 잘한다고 다 맡는 건 아니지."
            n "공평하게 나누자."

            "채은이와 도윤이가 나를 봤다."

            ex_dy "아..."
            ex_dy "그런가?"

            n "응."
            n "자료는 같이 보고,"
            n "문제 적는 거랑 꾸미는 것도 나눠서 하자."

            hide naeun
            show ne4 at center_stage as naeun with dissolve

            "나은이는 파일을 내려다보다가 밀어 넣으려던 메모지를 다시 꺼냈다."

            ne "그럼 이건 같이 보면 좋을 것 같아."
            ne "친구가 말할 때 중간에 끊지 말자는 내용이야."

            ex_ce "아, 그럼 이걸 문제로 내면 되겠다."
            ex_ce "글씨는 내가 적을게."

            ex_dy "나는 보기 만들게."

            "나은이는 작게 고개를 끄덕였고, 파일도 다시 닫지 않았다."


        "나은아, 진짜 괜찮은 거 맞아?":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", 1)
            $ choice_log.append("D2_naeun_conflict_B")

            n "나은아."
            n "진짜 괜찮은 거 맞아?"

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            ne "어...괜찮아."

            n "너무 많이 맡는 것 같아서."

            ne "아니야."
            ne "내가 준비해 온 것도 있고."
            ne "하면 금방 할 수 있을 것 같아."

            "나은이는 웃어 보였지만,"
            "파일 모서리를 잡은 손에는 힘이 들어가 있었다."

            ex_ce "그럼 한두 문제 정도는 내가 쓸게."

            ex_dy "나도 도와줄 거 있으면 말해."
            "원래는 다 같이 나눠서 해야 할 일이었다."
            "하지만 친구들은 나은이가 맡은 일을," 
            "조금씩 도와주는 것처럼 역할을 나눴다."
            
    if "D2_naeun_conflict_A" in choice_log:
        "5교시 종이 치기 전, 책상 위에는 역할을 나눈 메모지가 놓여 있었다."

        hide naeun
        show ne5 at center_stage as naeun with dissolve

        ne "나는 자료 보고 문제 하나 만들기."
        ne "채은이는 제목 쓰기, 도윤이는 그림 붙이기..."

        n "이렇게 나누니까 나은이가 다 안 해도 되잖아."

        hide naeun
        show ne3 at center_stage as naeun with dissolve

        ne "나도 이 정도면 할 수 있을 것 같아."

        "나은이는 살짝 웃어 보였다."


    elif "D2_naeun_conflict_B" in choice_log:
        "5교시 종이 치기 전," 
        "나은이는 벌써 자료들을 살펴보느라 바빠 보였다."

        n "나은아."
        n "내가 도와줄까?"

        hide naeun
        show ne2 at center_stage as naeun with dissolve

        ne "괜찮아."
        n "그래도 너무 많으면 말해."
        n "혼자 다 하지 않아도 되니까."

        hide naeun
        show ne1 at center_stage as naeun with dissolve

        ne "아... 고마워."
        "나은이는 곧장 시선을 내렸다."
        "하지만 나은이 앞에는 아직 할 일이 많이 남아 있었다."


    elif "D2_naeun_conflict_C" in choice_log:
        "5교시 종이 치기 전, 아이들은 하나둘 자기 자리로 돌아갔다."

        n "나은아. 그냥 같이 할까?"

        ne "아... 괜찮아."

        "나은이는 색연필 몇 개를 꺼냈다."

        hide naeun
        show ne1 at center_stage as naeun with dissolve

        ne "그냥 내가 빨리 하면 돼."
        "나은이는 곧장 시선을 내렸다."
        "친구들은 먼저 자리로 돌아갔고,"
        "나은이 앞에는 아직 정리할 자료가 남아 있었다."

    jump d2_after_system_to_afternoon

# ==========================================================
# 4. 소희 분기 — 약속했던 포토카드를 다른 친구에게 먼저 보여줘서 삐지는 갈등
# ==========================================================

label d2_sohee_conflict:
    $ set_bgm(audio.bgm_sohee_warm)
    $ mark_d2_met("sohee")
    scene bg_classroom_after with fade

    "교실 창가에서 지안이가 가방 앞주머니를 뒤지고 있었다."
    "소희는 점심시간부터 포토카드 이야기를 기다리고 있었다."

    show sh1 at center_stage as sohee with dissolve
    sh "지안아, 아까 말한 포토카드 진짜 가져왔어?"
    sh "어제 나한테 제일 먼저 보여준다고 했잖아."

    ex_ja "응, 가져왔어."
    ex_ja "잠깐만. 가방 안에 있을 텐데."

    "지안이는 가방에서 인기 있는 아이돌의 포토카드 한 장을 꺼냈다."

    "그때 옆자리에 있던 민서가 먼저 몸을 기울였다."

    ex_ms "와, 그거 새로 나온 거야?"
    ex_ms "진짜 예쁘다. 나 한 번만 봐도 돼?"

    ex_ja "응, 잠깐만."

    "지안이는 별생각 없이 포토카드를 민서 쪽으로 먼저 내밀었다."

    ex_ms "대박. 어디서 뽑았어?"

    ex_ja "어제 문구점 앞 뽑기에서 나왔어."
    ex_ja "나 이 멤버 제일 좋아하잖아."

    "민서와 지안이가 신나게 이야기하자 소희의 웃음이 천천히 사라졌다."

    hide sohee
    show sh5 at center_stage as sohee with dissolve
    sh "뭐야."
    sh "나한테 제일 먼저 보여준다더니."

    "지안이는 그제야 소희 쪽을 돌아봤다."

    ex_ja "아, 소희야."
    ex_ja "볼래? 그냥 민서가 먼저 물어봐서..."

    sh "됐어."
    sh "이미 둘이 잘 보고 있잖아."

    "소희가 창밖을 보는 척하자 지안이는 포토카드를 든 채 멈칫했다."
    "민서도 어색하게 손을 뗐다."

    "나는 잠깐 그 모습을 지켜봤다."
    $ choice_question_text = "이 상황에서 뭐라고 할까?"
    window hide

    menu:

        "지안아, 지금이라도 소희가 먼저 보게 해줘.":
            window show
            $ add_like("sohee", 1)
            $ add_neg("sohee", 2)
            $ choice_log.append("D2_sohee_conflict_B")

            n "소희가 지금이라도 먼저 보면 되지 않아?"
            n "소희가 아까부터 기다렸잖아."

            "지안이는 바로 고개를 끄덕였다."

            ex_ja "응. 소희야, 네가 먼저 봐."
            ex_ja "민서는 아까 잠깐 봤으니까."

            sh "흥,"
            sh "제일 먼저 보여준댔으면서."

            "소희는 삐죽거리며 포토카드 쪽으로 몸을 돌렸다."
            "표정도 조금 풀렸다."

            "민서는 손을 거두고 어색하게 웃었다."

            ex_ms "응. 난 나중에 봐도 돼."

            "분위기는 금방 조용해졌다."
            "하지만 민서는 더 이상 포토카드 쪽으로 몸을 기울이지 않았다."


        "지안이가 일부러 그런 건 아니니까 그냥 다 같이 보자.":
            window show
            $ add_like("sohee", 0)
            $ add_neg("sohee", 1)
            $ choice_log.append("D2_sohee_conflict_C")

            n "지안이가 일부러 그런 건 아닌 것 같아."
            n "그냥 같이 보면 안 돼?"

            ex_ja "맞아, 소희야."
            ex_ja "진짜 너 빼려고 한 거 아니야."
            ex_ja "그냥 민서가 바로 물어봐서..."

            hide sohee
            show sh2 at center_stage as sohee with dissolve
            sh "...알겠어."
            sh "나 제일 먼저 보여준다고 약속했었으면서."

            "소희는 알겠다고 했지만, 포토카드 쪽은 보지 않았다."
            "지안이는 포토카드를 어색하게 들고 있었다."
            "셋 다 더 이상 아무 말도 하지 않았다."

        "소희야, 지안이가 약속을 안 지켜서 서운한 거야?":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", -1)
            $ choice_log.append("D2_sohee_conflict_A")

            n "소희야."
            n "지안이가 먼저 보여주겠다는 약속을 안 지켜서 서운했던 거야?"
            n "그럼 지안이도 알 수 있게 말해봐."

            hide sohee
            show sh2 at center_stage as sohee with dissolve

            sh "응..."
            sh "나한테 먼저 보여주기로 약속했는데,"
            sh "말도 없이 민서한테 먼저 보여줘서 서운했어."

            "지안이는 포토카드를 소희 쪽으로 조심스럽게 내밀었다."

            ex_ja "미안해, 소희야."
            ex_ja "내가 약속해놓고 깜빡했어."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "괜찮아. 다음엔 먼저 보여줘."

            ex_ja "응. 약속한 대로 제일 먼저 보여줄게."

            "소희는 서운한 표정이 조금 남아 있었지만 포토카드를 받아들였다."

    if "D2_sohee_conflict_A" in choice_log:
        "5교시 종이 치기 전이었다."
        "소희는 포토카드를 보다가 지안이와 민서를 번갈아 봤다."

        show sh1 at center_stage as sohee with dissolve

        sh "우리 다 같이 볼까?"
        sh "민서도 이쪽으로 와."

        ex_ms "응. 그래도 돼?"

        sh "응. 같이 보는 게 더 재밌을 것 같아."

        "소희가 자리를 내어주자 민서도 다가와 함께 포토카드를 봤다."

    elif "D2_sohee_conflict_B" in choice_log:
        "5교시 종이 치기 전," 
        "소희는 포토카드를 한참 들여다보고 있었다."

        show sh4 at center_stage as sohee with dissolve

        sh "역시 이 아이돌이 제일 예쁘다!"

        "포토카드를 보는 소희의 얼굴은 금세 밝아졌다."
        "지안이는 어색하게 웃었고," 
        "민서는 무안한 표정으로 다른 자리로 갔다."

    elif "D2_sohee_conflict_C" in choice_log:
        "5교시 종이 치기 전," 
        "소희는 창밖을 보다가 천천히 입을 열었다."

        show sh2 at center_stage as sohee with dissolve
        sh "나 괜찮으니까 너희 둘이 봐."
        ex_ms "아니야."
        ex_ms "나중에 같이 보자."
        ex_ja "아... 그러자."
        "지안이는 포토카드를 다시 가방 안에 넣었다."

    jump d2_after_system_to_afternoon

# ==========================================================
# 5. 서연이 분기 — 결과를 맞추느라 친구의 표정을 놓치는 갈등
# ==========================================================

label d2_seoyeon_conflict:
    $ set_bgm(audio.bgm_seoyeon_clear)

    $ mark_d2_met("seoyeon")
    scene bg_classroom_after with fade
    "5교시 전 쉬는 시간,"
    "민우와 서연이는 미술 시간에 하던 포스터를 마무리하고 있었다."

    "민우가 쓴 제목은 조금 삐뚤었고,"
    "반듯하게 고치려 덧칠한 흔적이 남아 있었다."

    show sy2 at center_stage as seoyeon with dissolve
    sy "민우야, 잠깐만."
    "민우가 쓰던 손을 멈췄다."

    sy "제목이 선보다 조금 아래로 내려갔어."
    sy "계속 쓸 거야?"
    sy "오른쪽으로 갈수록 더 기울어질 것 같은데."

    "서연이는 자를 포스터 위에 반듯하게 댔다."

    sy "그리고 글씨 사이도 조금 안 맞잖아."
    sy "이러면 대충 한 것처럼 보여."

    "서연이 말대로 제목은"
    "오른쪽으로 갈수록 조금씩 내려가 있었다."

    "그 말을 듣는 민우의 얼굴은 점점 빨개졌다."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve
    sy "제목은 내가 다시 쓰는 게 나을 것 같아."

    "민우는 들고 있던 색펜 뚜껑을 손가락으로 만지작거렸다."

    ex_mw "나..."
    ex_mw "다시 써보려고 했는데."
    sy "다시 써도 선 안 맞으면 또 지워야 해."

    "서연이가 제목 쪽으로 지우개를 가져가자 민우는 한 걸음 물러났다."

    "나는 잠깐 그 모습을 지켜보다가, 두 사람 쪽으로 다가갔다."

    $ choice_question_text = "이 상황에서 뭐라고 할까?"
    window hide

    menu:

        "서연아, 열심히 한 민우가 속상할 것 같아.":
            window show
            $ add_like("seoyeon", 2)
            $ add_neg("seoyeon", -1)
            $ choice_log.append("D2_seoyeon_conflict_A")

            n "서연아."
            n "제목이 조금 삐뚤어진 건 맞아."

            "서연이는 지우개를 든 손을 멈췄다."

            n "그래도 민우가 열심히 쓴 건데, 바로 지우면 속상할 것 같아."
            n "고치기 전에 민우한테 먼저 물어보면 어때?"

            "서연이는 그제야 민우의 굳은 표정을 바라봤다."

            hide seoyeon
            show sy4 at center_stage as seoyeon with dissolve

            sy "민우야, 내가 그렇게 말해서 속상했어?"

            ex_mw "응..."
            ex_mw "나도 다시 잘 써보고 싶었어."

            "서연이는 들고 있던 지우개를 책상 위에 내려놓았다."

            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve

            sy "미안해."
            sy "빨리 고쳐야 한다는 생각만 했어."
            sy "민우가 다시 해봐. 이번에는 옆에서 기다릴게."

            "민우는 작게 고개를 끄덕이고 색펜을 다시 잡았다."

        "아쉽지만, 서연이가 대신 쓰는 게 나을 것 같아.":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", 2)
            $ choice_log.append("D2_seoyeon_conflict_C")

            n "민우야, 아무래도 시간이 없으니까,"
            n "아쉽겠지만 서연이가 제목을 쓰는 게 나을 것 같아."

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve
            sy "응. 그게 제일 빠르긴 해."

            sy "민우야."
            sy "너는 옆에 색종이 붙여줘."

            "민우는 잠깐 색펜을 내려다봤다."

            ex_mw "어...알겠어."

            "서연이가 제목을 지우자 포스터 위에 지우개 가루가 쌓였다."

            "민우는 색펜 뚜껑을 닫고 색종이 조각을 집었다."

            sy "색종이는 제목 옆에 붙여줘."

            "민우는 작게 고개를 끄덕였다."
            "포스터 가운데에는 서연이의 반듯한 글씨가 새로 적히기 시작했다."

            "포스터는 빨리 정리됐다."
            "하지만 민우의 색펜은 책상 끝에 놓인 채 다시 열리지 않았다."

        "서연이가 선만 잡아주고, 민우가 다시 써보면 어때?":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", 0)
            $ choice_log.append("D2_seoyeon_conflict_B")

            n "서연이가 선만 잡아주고 민우가 다시 써보면 어때?"

            "서연이는 자를 내려다봤다."

            n "서연이는 선 맞추는 걸 잘 보고,"
            n "민우는 제목을 맡았으니까."

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve
            sy "그럼 내가 선만 살짝 그을게."
            sy "민우가 그 안에 맞춰서 다시 쓰면 돼."

            "서연이는 포스터 위에 연필로 아주 옅은 선을 그었다."

            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve
            sy "민우야."
            sy "이 선 아래로 내려가지 않게 써."
            sy "글씨 크기도 이 칸에 맞추고."

            "서연이의 계속되는 말에," 
            "민우는 조금 민망한 듯 고개를 숙였다."
            "그래도 제목의 글씨는 점점 반듯해졌다."

    if "D2_seoyeon_conflict_A" in choice_log:
        "5교시 종이 치기 전," 
        "포스터 제목에는 굵은 테두리가 둘러져 있었다."

        "서연이는 조금 삐뚤어진 제목을 한동안 바라봤다."

        hide seoyeon
        show sy5 at center_stage as seoyeon with dissolve

        sy "민우야."
        sy "다음에는 내가 제목 쓸게."
        sy "너는 그림 맡아."

        "민우는 잠깐 서연이를 보다가 피식 웃었다."

        ex_mw "그래. 그게 낫겠다."

        "서연이도 조금 머쓱한 듯 포스터에서 시선을 돌렸다."

    elif "D2_seoyeon_conflict_B" in choice_log:
        "5교시 종이 치기 전,"
        "민우는 서연이의 말대로 제목을 끝까지 다시 썼다."

        hide seoyeon
        show sy1 at center_stage as seoyeon with dissolve

        sy "처음보다 훨씬 나아졌어."
        sy "그래도 다음에는 그냥 내가 제목을 쓰는 게 빠르겠다."

        "민우는 조금 민망한 듯 색펜 뚜껑만 만지작거렸다."

        ex_mw "응... 그렇게 하자."

        "서연이는 여전히 아쉬운 얼굴로 포스터를 다시 확인했다."

    elif "D2_seoyeon_conflict_C" in choice_log:
        "5교시 종이 치기 전, 포스터 제목은 반듯하게 완성됐다."

        hide seoyeon
        show sy1 at center_stage as seoyeon with dissolve
        sy "이제 훨씬 깔끔하다."

        "서연이는 만족한 듯 고개를 끄덕였다."

        "포스터는 깔끔해졌다."
        "하지만 민우는 제목 쪽을 다시 보지 않았다."

    jump d2_after_system_to_afternoon

# ----------------------------------------------------------
# D2 오후 — 방과 후 선택 1:1
# ----------------------------------------------------------

label d2_after_system_to_afternoon:
    scene bg_classroom_day with fade
    $ set_bgm(audio.bgm_classroom_light)

    "5교시가 시작되자 교실은 조금씩 조용해졌다."
    "금세 오후 수업과 종례까지 지나갔다."
    "곧 교실은 하교 준비로 다시 어수선해졌다."

    jump d2_afternoon_choice_1


label d2_afternoon_choice_1:
    scene bg_classroom_after with fade

    "몇 명은 실내화 가방을 흔들며 복도로 나갔다."
    "몇 명은 아직 가방 지퍼를 채우고 있었다."

    "나는 가방을 메다가 교실을 한 번 둘러봤다."
    "그냥 가기 전에, 누군가와 잠깐 이야기해볼 수도 있을 것 같았다."

    $ choice_question_text = "누구와 이야기해 볼까?"
    window hide

    menu:

        "{color=#7DB8FF}지호{/color}와 이야기한다." if "jiho" not in d2_today_met:
            window show
            $ d2_choice_met_1 = "jiho"
            $ d2_choice_met_2 = "none"
            jump d2_choice_jiho

        "{color=#FF9ACD}하영{/color}이와 이야기한다." if "hayoung" not in d2_today_met:
            window show
            $ d2_choice_met_1 = "hayoung"
            $ d2_choice_met_2 = "none"
            jump d2_choice_hayoung

        "{color=#BFA7FF}나은{/color}이와 이야기한다." if "naeun" not in d2_today_met:
            window show
            $ d2_choice_met_1 = "naeun"
            $ d2_choice_met_2 = "none"
            jump d2_choice_naeun

        "{color=#FFCF6E}소희{/color}와 이야기한다." if "sohee" not in d2_today_met:
            window show
            $ d2_choice_met_1 = "sohee"
            $ d2_choice_met_2 = "none"
            jump d2_choice_sohee

        "{color=#9FE0C5}서연{/color}이와 이야기한다." if "seoyeon" not in d2_today_met:
            window show
            $ d2_choice_met_1 = "seoyeon"
            $ d2_choice_met_2 = "none"
            jump d2_choice_seoyeon

        "오늘은 그냥 바로 집에 간다.":
            window show
            $ d2_choice_met_1 = "none"
            $ d2_choice_met_2 = "none"
            $ choice_log.append("D2_afternoon_none")
            jump d2_go_home
# ----------------------------------------------------------
# 지호 분기 — 컵스택 기록 깨기
# ----------------------------------------------------------
label d2_choice_jiho:
    $ set_bgm(audio.bgm_jiho_active)

    $ mark_d2_met("jiho")

    scene bg_cup with fade

    "교실 뒤쪽 책상 위에 종이컵 여섯 개가 쌓여 있었다."
    "게시판 한쪽에는 누가 적어둔 작은 기록이 보였다."

    "{i}컵스택 최고 기록: 현서 12초{/i}"

    "지호는 아직 집에 가지 않고 종이컵 앞에 서 있었다."
    "손목을 빙빙 돌리는 걸 보니, 도전해 볼 생각인 것 같았다."

    show jh1 at center_stage as jiho with dissolve
    jh "유진아, 마침 잘 왔다."
    jh "나 지금 저 기록 깰 수 있을 것 같아."

    "지호는 칠판에 적힌 숫자를 손가락으로 가리켰다."

    jh "12초면 충분히 깰 수 있거든?"
    jh "내가 컵 쌓고 다시 접는 동안 네가 시간 좀 재줘."

    "지호는 내가 대답하기도 전에 종이컵을 빠르게 펼쳤다."
    "컵 세 개가 위로 올라가고, 다시 아래로 내려왔다."

    "처음에는 꽤 빨랐다."
    "하지만 마지막 컵 하나가 옆으로 굴러가며 책상 아래로 떨어졌다."

    hide jiho
    show jh2 at center_stage as jiho with dissolve
    jh "아!"
    jh "아니, 이건 컵이 미끄러진 거야."

    "지호는 바로 컵을 주워 다시 책상 위에 올렸다."
    "귀 끝이 조금 빨개져 있었다."

    jh "다시."
    jh "이번엔 진짜 기록 깬다."

    "지호는 게시판에 적힌 12초를 다시 봤다."
    "장난치는 얼굴이었지만, 눈은 꽤 진지했다."

    $ choice_question_text = "지호에게 어떻게 말할까?"
    window hide

    menu:

        "이번엔 진짜 깰 것 같은데?":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", 2)
            $ choice_log.append("D2_jiho_event_B_compete")

            n "좋아."
            n "이번엔 꼭 깰 것 같은데?"
            n "내가 제대로 시간 재줄게."

            hide jiho
            show jh1 at center_stage as jiho with dissolve
            jh "그치?"
            jh "나 방금 감 잡았어."

            "지호의 눈이 반짝였다."
            "지호는 바로 컵을 펼쳤다."

            n "시작."

            "종이컵이 책상 위에서 빠르게 부딪혔다."
            "첫 번째 기록은 13초였다."

            hide jiho
            show jh2 at center_stage as jiho with dissolve
            jh "아! 1초!"

            n "진짜 아깝다."

            jh "한 번만 더."
            jh "이번엔 무조건 돼."

            "지호는 바로 다시 컵을 잡았다."
            "두 번째도 기록은 13초였다."

            jh "아니, 왜 계속 13초야?"

            "지호는 웃고 있었지만, 손에 힘이 더 들어갔다."
            "컵 하나가 세게 밀리며 날아갔다."

            ex_js "야, 조심해."
            ex_js "컵 계속 여기로 오잖아."

            hide jiho
            show jh3 at center_stage as jiho with dissolve
            jh "어, 미안."

            "하지만 지호는 친구 쪽을 보지는 않았다."
            "시선은 바로 게시판의 12초 기록으로 돌아갔다."

            hide jiho
            show jh6 at center_stage as jiho with dissolve
            jh "이번엔 책상을 바꿔봐야겠다."
            jh "진짜 마지막."

            "지호는 다시 컵을 펼쳤다."

            ex_js "계속하게?"

            hide jiho
            show jh2 at center_stage as jiho with dissolve
            jh "이번 한 번만."
            jh "나 지금 거의 깼어."

            "지호는 친구의 표정보다 초시계를 먼저 봤다."

            n "준비..."
            n "시작."

            "컵이 다시 책상 위에서 빠르게 부딪혔다."
            "이번에도 마지막 컵 하나가 옆으로 밀렸다."

            "친구는 작게 한숨을 쉬며 의자를 뒤로 뺐다."

            "하지만 지호는 기록에 더 마음이 가 있는 얼굴이었다."


        "나는 옆에서 볼게. 네가 직접 재봐.":
            window show
            $ add_like("jiho", 0)
            $ add_neg("jiho", 1)
            $ choice_log.append("D2_jiho_event_C_watch")

            n "나는 옆에서 볼게."
            n "시간은 네가 직접 재봐."

            hide jiho
            show jh4 at center_stage as jiho with dissolve
            jh "그래?"
            jh "그럼 내가 혼자 세면 되지."

            "지호는 자기 손목시계를 흘끗 보고 컵을 잡았다."

            jh "시작."

            "지호는 혼자 작게 숫자를 세며 컵을 쌓았다."
            "중간에 컵이 흔들리자, 숫자를 다시 처음부터 세었다."

            hide jiho
            show jh2 at center_stage as jiho with dissolve
            jh "아, 이건 제대로 안 쟀어."
            jh "다시."

            "지호는 다시 컵을 펼쳤다."
            "이번에는 입으로 숫자를 세지 않고, 손목시계만 힐끔힐끔 봤다."

            jh "지금... 12초쯤 된 것 같은데?"

            n "정확히는 잘 모르겠어."

            "지호는 멈춘 손목시계를 한참 들여다봤다."
            "방금 기록이 맞는지 아닌지, 지호도 확신하지 못하는 얼굴이었다."

            hide jiho
            show jh6 at center_stage as jiho with dissolve
            jh "아, 제대로 재면 됐을 것 같은데."
            jh "한 번만 더 해볼까?"

            "지호는 다시 컵을 잡았지만, 이번에는 시작 소리도 조금 늦었다."
            "혼자 세는 숫자는 자꾸 빨라졌다가 느려졌다."

            "나는 옆에서 보고만 있었다."
            "기록이 맞는지 아닌지 아무도 확실히 알 수 없었다."

            hide jiho
            show jh6 at center_stage as jiho with dissolve
            jh "아..."
            jh "누가 제대로 재줬으면 깼을 수도 있는데."

            "지호는 종이컵을 한 손에 쥐고 게시판 쪽을 바라봤다."
            "장난처럼 시작한 일이었지만, 지호는 꽤 아쉬워 보였다."
            "기록을 깼다고 말하기에도, 아니라고 말하기에도 애매했다."

        "내가 세 번만 시간 재줄게.":
            window show
            $ add_like("jiho", 2)
            $ add_neg("jiho", -1)
            $ choice_log.append("D2_jiho_event_A_equal")

            n "좋아. 내가 시간 재줄게."
            n "대신 세 번만 하자."
            n "끝나면 컵은 같이 정리하고."

            hide jiho
            show jh4 at center_stage as jiho with dissolve
            jh "세 번?"
            jh "음... 오케이. 세 번 안에 깨면 되지."

            "지호는 손가락을 털고 자세를 잡았다."

            n "준비."
            n "시작."

            "지호는 종이컵을 빠르게 쌓았다."
            "첫 번째 기록은 14초였다."

            hide jiho
            show jh2 at center_stage as jiho with dissolve
            jh "아, 손이 꼬였어."
            jh "다시."

            "두 번째 기록은 13초였다."

            jh "아!"
            jh "진짜 조금만 더 하면 되는데!"

            n "마지막 한 번 남았어."

            hide jiho
            show jh1 at center_stage as jiho with dissolve
            jh "오케이."
            jh "마지막은 집중한다."

            "세 번째 기록은 12초였다."
            "최고 기록을 깨지는 못했지만, 같은 기록이었다."

            hide jiho
            show jh2 at center_stage as jiho with dissolve
            jh "아, 잠깐."
            jh "지금 감 왔어. 한 번만 더 하면 11초 나와."

            "지호는 바로 컵을 다시 펼치려 했다."

            n "지호야."
            n "아까 세 번만 하기로 했잖아."

            jh "근데 방금 진짜 아까웠다니까."
            jh "이건 한 번 더 해야 돼."

            n "아깝긴 한데, 계속하면 끝이 안 날 것 같아."
            n "이제 컵 정리하자."

            hide jiho
            show jh6 at center_stage as jiho with dissolve
            jh "하..."
            jh "진짜 한 번만 더 하면 됐는데."

            "지호는 한참 망설이다가 컵을 하나씩 포개기 시작했다."

            hide jiho
            show jh3 at center_stage as jiho with dissolve
            jh "알았어."
            jh "아까 말했으니까 여기까지."

            "그래도 지호는 컵을 다시 펼치지는 않았다."

    if "D2_jiho_event_A_equal" in choice_log:
        "잠시 뒤, 지호는 종이컵을 가지런히 포개 책상 한쪽에 놓았다."

        hide jiho
        show jh1 at center_stage as jiho with dissolve
        jh "다음엔 11초 찍는다."
        jh "근데 세 번이라고 정해놓으니까..."
        jh "더 하고 싶어도 멈추긴 멈추게 되네."

        n "기록은 다음에 또 도전하면 되니까."

        jh "응."
        jh "다음엔 연습하고 와야겠다."

        "지호는 게시판의 기록 옆에 자기 이름을 쓰려다가 멈췄다."
        "그리고 그냥 손가락으로 12초 숫자만 톡 건드렸다."

        jh "다음엔 꼭 깬다."


    elif "D2_jiho_event_B_compete" in choice_log:
        "잠시 뒤, 지호는 다시 컵을 쌓았다."

        hide jiho
        show jh6 at center_stage as jiho with dissolve
        jh "진짜 마지막."
        jh "이번엔 무조건 11초 나온다."

        "옆자리 친구는 공책과 필통을 가방 안으로 넣었다."

        ex_js "나 여기서 숙제하려고 했는데..."

        "지호는 그 말을 듣고도 컵을 내려놓지 않았다."
        hide jiho
        show jh1 at center_stage as jiho with dissolve
        jh "아, 금방 끝나."

        "지호는 신이 나 보였지만, 준서는 내내 불편해 보였다."
        "지호는 게시판의 12초 기록만 계속 보고 있었다."


    elif "D2_jiho_event_C_watch" in choice_log:
        "잠시 뒤, 지호는 종이컵을 대충 포개 책상 위에 내려놓았다."
    
        hide jiho   
        show jh3 at center_stage as jiho with dissolve
        jh "혼자 하니까 기록이 애매하네."

        n "다음에 누가 시간 재줄 때 해."

        jh "응..."
        jh "근데 아까는 진짜 될 것 같았는데."

        "지호는 컵을 가지런히 포개려다 말고, 다시 게시판을 봤다."
        "손끝이 아직 컵 가장자리를 만지고 있었다."

        hide jiho
        show jh6 at center_stage as jiho with dissolve
        jh "내가 직접 재면 안 헷갈릴 줄 알았는데."
        jh "오히려 더 모르겠네."

        n "기록은 정확해야 하니까."

        "지호는 천천히 고개를 끄덕였다."
        "아쉬워하면서도 이번 기록은 쓰지 않았다."

        "지호는 아쉬운 얼굴로 게시판의 12초 기록을 한 번 더 봤다."

    jump d2_go_home
# ----------------------------------------------------------
# 하영이 분기 — 방과 후 문구점 약속
# ----------------------------------------------------------

label d2_choice_hayoung:
    $ mark_d2_met("hayoung")
    $ set_bgm(audio.bgm_hayoung_social)

    scene bg_classroom_evening with fade

    "방과 후 교실은 조금 어수선했다."
    "창가 쪽 책상에는 하영이가 친구들 몇 명과 모여 있었다."

    show h5 at center_stage as hayoung with dissolve
    hy "이거 어제 학교 앞 문구점에서 산 건데,"
    hy "오늘 새로 들어온 것도 있대."
    hy "반짝이 키링이랑 작은 스티커팩."

    "주변 친구들이 바로 책상 쪽으로 가까이 모였다."

    ex_ej "진짜?"
    ex_ej "나도 보고 싶다."

    ex_cr "하영이가 고르는 거 예쁘긴 해."
    ex_cr "지난번 네가 골라준 스티커 아직 아껴두고 있어."

    hide hayoung
    show h4 at center_stage as hayoung with dissolve
    hy "오늘 집에 가는 길에 잠깐 들를 거야."
    hy "은지랑 채린이는 간다고 했고..."

    hy "유진아."
    hy "너도 같이 갈래?"

    n "나?"

    hide hayoung
    show h5 at center_stage as hayoung with dissolve
    hy "응."
    hy "새로 온 애랑 같이 가면 재밌잖아."
    hy "너한테 어울리는 키링도 내가 새로 골라줄 수 있고."

    "나도 모르게 가방에 달린 키링을 한 번 만졌다."

    "그때 옆에 서 있던 수빈이가 조심스럽게 말했다."

    ex_sb "나도 같이 가도 돼?"

    hide hayoung
    show h2 at center_stage as hayoung with dissolve
    "하영이는 바로 대답하지 않고, 스티커 모서리를 톡톡 건드렸다."

    hy "음..."
    hy "오늘은 빨리 보고 바로 가려고 했는데."

    ex_sb "나도 빨리 볼게."

    hy "지난번에 너 고르느라 오래 걸렸잖아."
    hy "우리 그때 버스 놓칠 뻔했어."

    "하영이가 망설이자, 주변 친구들도 같이 조용해졌다."
    "수빈이는 가방끈을 만지작거리며 고개를 살짝 숙였다."

    hide hayoung
    show h4 at center_stage as hayoung with dissolve
    hy "유진이는 어때?"
    hy "같이 갈래?"

    "나는 대답하기 전에 책상 주변을 한 번 보았다."
    $ choice_question_text = "어떻게 답할까?"
    window hide

    menu:

        "미안해. 오늘은 집에 바로 가야 할 것 같아.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", 0)
            $ choice_log.append("D2_hayoung_event_B_plain")
            n "미안, 문구점은 궁금한데..."
            n "피곤해서 오늘은 집에 바로 가야 할 것 같아."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve
            hy "아, 그래?"
            hy "전학 오면 피곤하긴 하지."

            "수빈이는 가방끈을 만지작거리며 하영이 쪽을 봤다."

            ex_sb "그럼 나는..."

            "하영이는 별 스티커를 필통 안에 넣으며 말했다."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve
            hy "오늘은 우리끼리 빨리 보고 올게."
            hy "수빈이는 다음에 같이 가자."

            ex_sb "아, 응."
            ex_sb "알겠어."

            "수빈이는 작게 대답하고 가방을 들었다."

            hy "유진이도 다음에 같이 가자."
            hy "네 키링이랑 어울리는 거 봐둘게."

            n "응, 고마워."

            "나는 가방을 메며 책상 옆으로 물러났다."
            "문구점은 궁금했지만, 오늘은 그냥 집에 가기로 했다."

        "보는 시간 정해 놓고 다 같이 가는 건 어때?":
            window show
            $ add_like("hayoung", 2)
            $ add_neg("hayoung", -1)
            $ choice_log.append("D2_hayoung_event_A_equal")

            n "같이 가고 싶어."
            n "하영이가 골라준다는 것도 궁금하고."

            n "대신 수빈이도 같이 가면 좋겠어."
            n "오래 걸릴까 봐 그러는 거면,"
            n "십 분만 보고 바로 나오기로 하면 되잖아."

            hide hayoung
            show h3 at center_stage as hayoung with dissolve
            hy "십 분..."

            "하영이는 잠깐 생각하더니 수빈이 쪽을 봤다."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve
            hy "그럼 같이 가자."
            hy "대신 오늘은 진짜 오래 고르기 금지."
            hy "십 분 안에 마음에 드는 거 없으면 내일 다시 보는 거야."

            "수빈이의 얼굴이 조금 밝아졌다."

            ex_sb "응."
            ex_sb "오늘은 빨리 고를게."

            ex_ej "그럼 현관에서 만나면 되겠다."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve
            hy "오케이."
            hy "그럼 내가 예쁜 거 먼저 찾아줄게."

            "약속은 빠르게 다시 정해졌다."

        "좋아! 하영이가 골라주는 거 기대된다.":
            window show
            $ add_like("hayoung", 2)
            $ add_neg("hayoung", 2)
            $ choice_log.append("D2_hayoung_event_C_follow")

            n "응."
            n "오늘은 하영이가 골라주는 거 보고 싶어."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve
            hy "좋아."
            hy "그럼 유진이는 같이 가는 걸로."

            "하영이는 밝게 웃었고, 은지와 채린이도 고개를 끄덕였다."

            hy "오늘은 우리끼리 빨리 보고 오자."
            hy "사람 많아지면 고르기 힘들어."

            "수빈이는 천천히 가방을 들었다."

            ex_sb "아..."
            ex_sb "그럼 나는 다음에 갈게."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve
            hy "응."
            hy "다음에 같이 가자."
            hy "오늘은 진짜 빨리 갔다 와야 해서."

            "수빈이는 작게 고개를 끄덕였다."

            hide hayoung
            show h1 at center_stage as hayoung with dissolve
            hy "유진이 가방 키링 내가 골라줄게."
            "하영이랑 같이 가는 건 조금 기대됐다."
            "하지만 이미 가방을 들고 나가는 수빈이의 뒷모습이 마음에 걸렸다."

    if "D2_hayoung_event_A_equal" in choice_log:
        "잠시 뒤, 현관 앞에 아이들이 모였다."
        "하영이는 손목시계를 보며 시간을 확인했다."

        show h5 at center_stage as hayoung with dissolve
        hy "문구점 십 분."
        hy "늦게 고르면 내일 다시 보기."

        ex_sb "알겠어."
        ex_sb "나 오늘은 먼저 눈에 들어오는 걸로 고를게."

        "하영이는 수빈이의 가방을 보고 잠깐 눈을 좁혔다."

        hy "너는 파란색보다 연보라가 더 나을 것 같아."
        hy "가방 색이랑 같이 보면 그게 덜 튀어."

        ex_sb "진짜?"
        ex_sb "나 연보라 좋아해."

        "하영이는 어깨를 으쓱했다."

        hy "그럼 내가 찾아줄게."

        "하영이는 빠르게 앞장섰고, 수빈이도 그 뒤를 따라갔다."


    elif "D2_hayoung_event_B_plain" in choice_log:
        "잠시 뒤, 현관 쪽에서 하영이네 무리를 봤다."

        show h4 at center_stage as hayoung with dissolve
        hy "유진아."

        hy "너 오늘 안 가는 거 아쉽다."

        n "응."
        n "나중에 뭐 샀는지 보여줘."

        "조금 떨어진 곳에서 수빈이가 신발을 갈아 신고 있었다."
        "수빈이는 하영이네 쪽을 한 번 보더니," 
        "조용히 신발끈을 묶었다."

        hide hayoung
        show h5 at center_stage as hayoung with dissolve
        hy "우리도 빨리 가자."
        hy "늦으면 사람 많아질 수도 있어."

        "나는 먼저 현관을 나섰다."
        "문구점은 궁금했지만, 오늘은 그냥 집에 가기로 했다."


    elif "D2_hayoung_event_C_follow" in choice_log:
        "잠시 뒤, 현관 앞에 하영이와 은지, 채린이가 모였다."
        "나도 그 옆에 섰다."

        show h4 at center_stage as hayoung with dissolve
        hy "유진아, 네 가방은 좀 차분하니까,"
        hy "너무 알록달록한 것보다 투명 반짝이가 나을 것 같아."

        n "그런 것도 있어?"

        hy "있어."
        hy "가보면 바로 알아."

        "나는 나도 모르게 가방 키링을 만졌다."

        "수빈이는 이미 신발장 쪽에 서 있었다."
        "우리 쪽을 잠깐 보더니, 곧 고개를 돌렸다."

        ex_ej "수빈이 먼저 가나 봐."

        hide hayoung
        show h5 at center_stage as hayoung with dissolve
        hy "응."
        hy "다음에 같이 가면 되지."

        hy "가자."
        hy "늦으면 예쁜 거 다 빠질 수도 있어."

        "나는 하영이를 따라 걸음을 옮겼다."

    jump d2_go_home
# ----------------------------------------------------------
# 나은이 분기 — 허락 없이 찍은 그림
# ----------------------------------------------------------

label d2_choice_naeun:
    $ set_bgm(audio.bgm_naeun_soft)

    $ mark_d2_met("naeun")
    scene bg_classroom_evening with fade

    "방과 후 교실은 조금씩 조용해지고 있었다."

    "나는 떨어진 지우개를 찾으려고 책상 밑을 두리번거렸다."
    "그때 나은이 책상 위에 펼쳐진 공책이 보였다."

    "공책 한쪽에는 작은 캐릭터 그림이 그려져 있었다."
    "내가 좋아하는 캐릭터였다."
    "동그란 눈과 삐죽 나온 귀까지 꽤 비슷했다."

    "한쪽 팔은 아직 연필선만 남아 있었다."
    "아래에는 지우개 가루도 조금 붙어 있었다."

    n "와..."
    n "진짜 귀엽다."

    "그림이 너무 귀여워서, 나중에 다시 보고 싶었다."
    "나는 별생각 없이 핸드폰을 꺼냈다."
    "찰칵."

    "그런데 사진 찍히는 소리가 생각보다 크게 났다."

    show ne5 at center_stage as naeun with dissolve

    "그 순간, 교실 문 쪽에서 나은이가 들어왔다."
    "나은이는 내 손에 들린 휴대폰과 자기 공책을 번갈아 봤다."

    hide naeun
    show ne2 at center_stage as naeun with dissolve
    ne "아..."

    "나은이는 걸음을 멈췄다."

    ne "그거..."
    ne "내 공책인데."

    "내 손이 멈췄다."
    "휴대폰 화면에는 방금 찍은 나은이의 그림이 떠 있었다."

    n "아."

    "나은이는 공책 쪽으로 천천히 다가왔다."
    "그리고 그림이 그려진 부분을 손바닥으로 살짝 덮었다."

    hide naeun
    show ne1 at center_stage as naeun with dissolve
    ne "아직..."
    ne "다 그린 건 아니라서."

    "나은이는 작게 웃으려고 했다."
    "하지만 내 휴대폰 화면을 계속 보고 있었다."

    "나는 바로 말이 나오지 않았다."
    "귀여워서 찍은 건 맞았다."
    "하지만 허락을 받지는 않았다."
    $ choice_question_text = "나은이에게 어떻게 말할까?"
    window hide

    menu:

        "나은아, 미안해. 사진 바로 지울게.":
            window show
            $ add_like("naeun", 2)
            $ add_neg("naeun", -1)
            $ choice_log.append("D2_naeun_event_A_apology")

            n "나은아, 미안해."
            n "허락 없이 찍으면 안 되는 건데,"
            n "그림이 너무 귀여워서 내가 생각 없이 찍었어."

            hide naeun
            show ne2 at center_stage as naeun with dissolve
            "나은이는 손바닥으로 공책을 덮은 채 나를 봤다."

            n "지금 바로 지울게."
            n "다음부터는 꼭 먼저 물어볼게."

            "나는 휴대폰 화면에서 방금 찍은 사진을 삭제했다."
            "나은이가 볼 수 있게 화면을 살짝 돌려 보여주었다."

            hide naeun
            show ne4 at center_stage as naeun with dissolve
            ne "아..."
            ne "응."

            "나은이의 어깨가 조금 내려갔다."

            ne "나도..."
            ne "그 캐릭터 좋아해서 그린 거야."

            n "진짜?"
            n "그래서 더 잘 그린 것 같아."

            hide naeun
            show ne5 at center_stage as naeun with dissolve
            ne "완성하면..."
            ne "그때 보여줄게."

            n "응."
            n "그땐 먼저 물어볼게."

            "나은이는 공책을 완전히 닫지 않았다."
            "손은 아직 공책 위에 있었지만, 아까처럼 급하게 가리지는 않았다."


        "너무 귀여워서 찍었어. 저장해도 돼?":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", 0)
            $ choice_log.append("D2_naeun_event_B_late_permission")

            n "미안."
            n "내가 좋아하는 캐릭터라서..."
            n "너무 귀여워서 나도 모르게 찍었어."

            "나은이는 공책 위에 손을 올린 채 조용히 듣고 있었다."

            n "지금이라도 물어볼게."
            n "이 사진 저장해도 돼?"
            n "싫으면 바로 지울게."

            hide naeun
            show ne2 at center_stage as naeun with dissolve
            ne "음..."

            "나은이는 바로 대답하지 못했다."
            "공책 모서리를 손끝으로 살짝 눌렀다."

            ne "아직 다 안 그려서..."
            ne "지금 사진은 조금 부끄러워."

            n "아, 그렇구나."
            n "그럼 지울게."

            "나는 방금 찍은 사진을 삭제했다."

            hide naeun
            show ne1 at center_stage as naeun with dissolve
            n "완성되면 그때 다시 물어봐도 돼?"

            "나은이는 아주 작게 고개를 끄덕였다."

            hide naeun
            show ne5 at center_stage as naeun with dissolve
            ne "응."

            "나은이는 공책을 자기 쪽으로 당겼다."
            "그래도 완전히 숨기지는 않았다."


        "아, 미안. 너무 귀여워서 잠깐 봤어.":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", 1)
            $ choice_log.append("D2_naeun_event_C_quiet_delete")

            n "아, 미안."
            n "그림이 너무 귀여워서 나도 모르게 봤어."

            "나는 당황해서 휴대폰 화면을 바로 껐다."

            hide naeun
            show ne2 at center_stage as naeun with dissolve
            ne "아..."
            ne "그랬구나."

            "나은이는 공책 위에 손을 올린 채, 그림을 살짝 가렸다."

            "나는 휴대폰을 손에 쥔 채 잠깐 망설였다."

            n "미안."
            n "내가 너무 가까이 봤지."

            "나는 휴대폰을 책상 아래쪽으로 내려, 방금 찍은 사진을 조용히 삭제했다."

            "나은이는 공책을 천천히 닫았다."

            hide naeun
            show ne2 at center_stage as naeun with dissolve
            ne "나..."
            ne "이거 아직 다 못 그려서."

            n "응."
            n "완성 안 된 거였구나."

            "말은 부드럽게 이어졌지만, 사진을 찍었다는 말은 끝내 꺼내지 못했다."

            "나은이는 공책을 가방 안에 넣었다."
            "지퍼를 닫는 소리가 작게 났다."

    if "D2_naeun_event_A_apology" in choice_log:
        "잠시 뒤, 나은이는 가방을 메고 내 옆을 지나가다 잠깐 멈췄다."
        hide naeun
        show ne4 at center_stage as naeun with dissolve
        ne "아까..."
        ne "바로 지워줘서 고마워."

        n "내가 먼저 물어봤어야 했어."

        ne "응."
        ne "그래도 말해줘서 고마워."

        "나은이는 공책이 든 가방을 한 번 잡았다."

        hide naeun
        show ne3 at center_stage as naeun with dissolve
        ne "완성하면 진짜 보여줄게."

        "나은이는 작게 웃고 교실 문 쪽으로 걸어갔다."


    elif "D2_naeun_event_B_late_permission" in choice_log:
        "잠시 뒤, 나은이는 자기 자리에서 공책을 다시 꺼냈다."
        hide naeun
        show ne1 at center_stage as naeun with dissolve
        ne "여기 귀 부분이..."
        ne "조금 이상해서 고치려고 했어."

        n "아, 그래서 아직 보여주기 싫었던 거구나."

        ne "응."
        ne "완성 안 된 건 조금 부끄러워."

        "나은이는 연필로 귀 끝을 조금 고쳤다."
        "아까보다 조심스럽긴 했지만, 그림을 아예 숨기지는 않았다."

        hide naeun
        show ne5 at center_stage as naeun with dissolve
        ne "다 그리면..."
        ne "그때 찍어도 돼."

        n "응."
        n "그때는 꼭 먼저 물어볼게."


    elif "D2_naeun_event_C_quiet_delete" in choice_log:
        "잠시 뒤, 나은이는 가방을 메고 교실 문 쪽으로 걸어갔다."

        "나은이는 나가기 전에 내 쪽을 한 번 봤다."

        ne "유진아."

        n "응?"

        hide naeun
        show ne2 at center_stage as naeun with dissolve
        "나은이는 잠깐 망설였다."

        ne "아까 그림..."
        ne "아직 완성한 건 아니라서."

        n "응."
        n "알겠어."

        "나는 방금 사진을 지웠다고 말하려다가 멈췄다."

        n "다음엔 보기 전에 먼저 물어볼게."

        "나은이는 아주 작게 고개를 끄덕였다."

        ne "...응."

        "나은이는 가방끈을 꽉 쥐고 교실 문밖으로 나갔다."
        "나는 휴대폰을 한 번 내려다봤다."

        "사진은 이미 지웠지만,"
        "나은이는 그걸 모른 채 나가고 있었다."

    jump d2_go_home
# ----------------------------------------------------------
# 소희 분기 — 쌍둥이 키링과 교환일기
# ----------------------------------------------------------

label d2_choice_sohee:
    $ set_bgm(audio.bgm_sohee_warm)

    $ mark_d2_met("sohee")
    scene bg_board_plain with fade

    "방과 후 교실은 조금씩 비어가고 있었다."
    "나는 가방을 메고 사물함 쪽으로 갔다."

    "교실 뒤편 내 사물함 앞에는 소희가 서 있었다."
    "소희는 내가 다가오자 가방 앞주머니에서 작은 곰돌이 키링 두 개를 꺼냈다."

    "핑크색 곰돌이 두 마리는 똑같이 생겼다."

    show sh1 at center_stage as sohee with dissolve
    sh "유진아!"
    sh "나 아침에 학교 앞 문구점 들렀거든?"

    "소희는 손바닥 위에 키링 두 개를 나란히 올렸다."

    sh "이거 봐."
    sh "우리 3반 친구 된 기념으로 샀어."

    n "둘 다 똑같은 거야?"

    sh "응!"
    sh "하나는 내 거, 하나는 유진이 거."

    "소희는 내 가방 고리 쪽으로 손을 뻗었다."
    "그러다가 잠깐 멈추고 내 얼굴을 봤다."

    sh "달아도 돼?"
    sh "같이 달면 진짜 귀여울 것 같아."

    "나한테 주려고 골라왔다는 게 조금 신기했다."

    "소희는 키링 하나를 내 손에 살짝 올려주었다."

    sh "그리고 우리 교환일기도 해볼래?"
    sh "매일은 아니어도, 내일 교문 앞에서 한 번 바꿔 보면 재밌을 것 같아."

    hide sohee
    show sh4 at center_stage as sohee with dissolve

    "소희는 말하면서 벌써 신이 난 얼굴이었다."

    sh "우리끼리 먼저 해보고,"
    sh "재밌으면 나중에 다른 애들도 같이 해도 되고."

    "그때 민서가 가방을 메고 지나가다 키링을 봤다."

    ex_ms "우와, 귀엽다."
    ex_ms "학교 앞 문구점에서 산 거지?"

    hide sohee
    show sh5 at center_stage as sohee with dissolve

    sh "응."
    sh "근데 이건 유진이랑 나랑만 맞춘 거야."

    "소희는 웃으면서 말했지만, 키링 두 개를 손으로 살짝 감쌌다."
    "민서는 가볍게 웃고 지나갔다."

    $ choice_question_text = "소희에게 어떻게 답할까?"
    window hide

    menu:

        "키링은 고마워. 교환일기는 조금 천천히 하자.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", -1)
            $ choice_log.append("D2_sohee_event_A_equal")

            n "키링은 정말 고마워."
            n "나 주려고 골라온 거잖아."

            "소희의 얼굴이 금방 밝아졌다."

            n "근데 교환일기는 조금 천천히 하자."
            n "나 아직 전학 온 지 얼마 안 돼서,"
            n "다른 친구들이랑도 조금씩 친해지고 싶어."

            hide sohee
            show sh2 at center_stage as sohee with dissolve

            sh "아..."

            "소희는 잠깐 키링을 내려다봤다."

            n "소희랑 친해지기 싫다는 게 아니야."
            n "키링은 고맙게 받을게."
            n "교환일기는 나중에 해도 괜찮을 것 같아."

            "소희는 입술을 살짝 내밀었다가, 천천히 고개를 끄덕였다."

            sh "그럼..."
            sh "키링은 오늘부터 우정템 맞지?"

            n "응."
            n "그건 좋아."

            sh "오케이."
            sh "교환일기는 나중에 다시 물어볼게."

            "나는 키링을 가방 고리에 걸었다."
            "곰돌이 키링이 지퍼 끝에서 작게 흔들렸다."


        "고마워. 근데 똑같은 키링은 아직 조금 부담스러워.":
            window show
            $ add_like("sohee", 1)
            $ add_neg("sohee", 0)
            $ choice_log.append("D2_sohee_event_B_plain")

            n "고마워, 소희야."
            n "나 주려고 골라온 건 진짜 고마운데..."

            "나는 손에 올려진 키링을 잠깐 내려다봤다."

            n "근데 아직 같은 키링을 다는 건 조금 부담스러워."
            n "우리 아직 만난 지 얼마 안 됐잖아."

            hide sohee
            show sh2 at center_stage as sohee with dissolve

            sh "아..."
            sh "그런가?"

            n "응."
            n "키링은 진짜 귀여워."
            n "근데 지금은 마음만 받을게."

            "나는 키링을 조심스럽게 소희 쪽으로 돌려주었다."

            "소희는 키링 두 개를 손바닥 위에 다시 올려놓았다."
            "잠깐 아쉬운 얼굴이 됐지만, 곧 고개를 끄덕였다."
            sh "알겠어."
            sh "그럼 내가 일단 가지고 있을게."

            n "응."
            n "골라줘서 고마워."

            "소희는 키링 두 개를 가방 앞주머니에 넣었다."
            "아까처럼 신난 얼굴은 아니었지만, 억지로 붙잡지는 않았다."


        "좋아. 키링이랑 교환일기 우리 둘만 먼저 해보자.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", 2)
            $ add_burnout(1)
            $ choice_log.append("D2_sohee_event_C_depend")

            n "좋아."
            n "우리 둘만 먼저 해보자."

            "소희의 얼굴이 환하게 밝아졌다."

            hide sohee
            show sh4 at center_stage as sohee with dissolve

            sh "진짜?"
            sh "그럼 우리 오늘부터 쌍둥이 키링이야."

            n "응."
            n "나 전학 와서 아직 어색했는데,"
            n "소희가 먼저 챙겨줘서 고마워."

            "소희는 더 신이 난 듯 키링을 들어 올렸다."

            sh "그럼 내가 달아줄게."
            sh "여기, 가방 고리에 달면 딱 예뻐."

            "소희는 조심스럽게 내 가방 고리에 키링을 달았다."
            "핑크색 곰돌이가 내 가방 옆에서 흔들렸다."

            sh "그리고 교환일기는 우리끼리 먼저 해보자."
            sh "다른 애들한테는 아직 말하지 말고."

            n "왜?"

            hide sohee
            show sh1 at center_stage as sohee with dissolve
            sh "나는 우리 둘만 해보고 싶어."

            "소희는 환하게 웃었다."
            "나만 따로 챙겨주는 것 같아서 기분이 좋았다."

            "그런데 민서가 지나가던 쪽을 보니,"
            "아까 소희가 키링을 손으로 감싸던 모습이 다시 생각났다."


    if "D2_sohee_event_A_equal" in choice_log:
        "잠시 뒤, 소희는 교실 문 쪽으로 걸어가며 자기 가방의 키링을 흔들어 보였다."

        hide sohee
        show sh4 at center_stage as sohee with dissolve

        sh "봐봐."
        sh "내 것도 여기 달았어."

        n "귀엽다."

        sh "유진이 것도 내일 보면 바로 알아볼 수 있겠다."

        "소희는 잠깐 멈춰서 나를 봤다."

        hide sohee
        show sh2 at center_stage as sohee with dissolve

        sh "교환일기는..."
        sh "진짜 나중에 해도 되는 거지?"

        n "응."
        n "나중에 하고 싶어지면 말할게."

        "소희는 입술을 살짝 내밀었다가 고개를 끄덕였다."

        hide sohee
        show sh3 at center_stage as sohee with dissolve

        sh "그럼 오늘은 키링만."
        sh "이것도 친구 기념이니까."

        "소희는 다시 웃었다."


    elif "D2_sohee_event_B_plain" in choice_log:
        "잠시 뒤, 소희는 키링 두 개를 가방 앞주머니에 넣고 교실 문 쪽으로 걸어갔다."

        hide sohee
        show sh3 at center_stage as sohee with dissolve

        sh "그래도 나중에 마음 바뀌면 말해."
        sh "그때 같이 달자."

        n "응."
        n "고마워."

        "소희는 앞주머니를 한 번 톡톡 두드렸다."

        sh "내가 잃어버리진 않을게."
        sh "혹시 나중에 달고 싶어지면 그때 줘도 되니까."

        n "응."
        n "그때 다시 말할게."

        "소희는 작게 웃었다."
        "소희의 선물을 바로 받아주지는 않았지만,"
        "크게 어색해지지는 않았다."


    elif "D2_sohee_event_C_depend" in choice_log:
        "잠시 뒤, 교실 문 앞."

        hide sohee
        show sh4 at center_stage as sohee with dissolve
        "소희는 내 가방에 달린 키링을 보며 계속 웃었다."
        sh "진짜 귀엽다."
        sh "우리 가방 보면 바로 친구인 거 티 나겠다."

        n "그러게."

        "그때 민서가 신발장 쪽에서 우리 키링을 보고 다가왔다."

        ex_ms "유진아! 같이 달고 있으니까 더 귀엽다."

        hide sohee
        show sh5 at center_stage as sohee with dissolve

        sh "잠깐만."
        sh "근데 이건 유진이랑 나랑 먼저 맞춘 거니까 너는 다른 거 사야 해."

        ex_ms "아..."
        ex_ms "뭐, 알겠어."

        "민서는 어색하게 웃고 신발을 갈아 신었다."

        sh "우리 교환일기 첫 장에는 오늘 키링 얘기 쓰자."
        sh "다른 애들한테는 아직 비밀."

        "소희가 나를 특별하게 생각해주는 건 기분 좋았다."
        "하지만 민서가 조용히 멀어지는 모습도 눈에 들어왔다."

    jump d2_go_home

# ----------------------------------------------------------
# 서연이 분기 — 서연이에 대한 뒷말과 남겨진 쪽지
# ----------------------------------------------------------

label d2_choice_seoyeon:
    $ set_bgm(audio.bgm_seoyeon_clear)

    $ mark_d2_met("seoyeon")
    scene bg_classroom_evening with fade
    "방과 후 교실은 조금씩 비어가고 있었다."
    "나는 가방을 메고 나가려다가," 
    "사물함 옆 낮은 책상 앞에서 멈췄다."

    "책상 위에는 모둠 색연필 상자 몇 개가 놓여 있었다."
    "작은 연필깎이와 휴지 조각도 있었다."

    "종이컵 앞에는 쪽지가 붙어 있었다."

    "{i}짧은 색연필은 여분 컵에 넣기.{/i}"
    "{i}내일 색칠도구 없는 모둠은 여기서 가져가기.{/i}"

    "서연이 글씨 같았다."

    "그때 사물함 쪽에서 은지와 도윤이의 목소리가 들렸다."

    ex_ej "아까 서연이 봤어?"
    ex_ej "색연필 하나 없다고 바로 확인하라고 하던 거."

    ex_dy "응."
    ex_dy "말투가 좀 무서워."

    ex_ej "선생님도 아닌데 왜 그렇게까지 하지?"
    ex_ej "그냥 다음 시간에 없으면 그때 찾으면 되잖아."

    "도윤이는 가방끈을 고쳐 메며 작게 한숨을 쉬었다."

    ex_dy "서연이는 뭐든 너무 딱 맞아야 하나 봐."
    ex_dy "틀린 말은 아닌데, 듣고 있으면 내가 혼나는 것 같아."

    "서연이 말투가 딱딱한 건 나도 느낀 적이 있었다."
    "하지만 책상 위에는 서연이가 준비해둔 공용물품이 보였다."

    $ choice_question_text = "친구들에게 어떻게 말할까?"
    window hide

    menu:

        "서연이가 세게 말하긴 해도, 챙겨준 것도 있는 것 같아.":
            window show
            $ add_like("seoyeon", 2)
            $ add_neg("seoyeon", -1)
            $ choice_log.append("D2_seoyeon_event_A_intent")

            n "서연이가 세게 말할 때는 있긴 해."

            "은지와 도윤이가 나를 봤다."

            n "근데 저기 봐."
            n "짧은 색연필 따로 빼놓고,"
            n "없는 모둠은 가져가라고 적어놨어."

            "나는 책상 위 종이컵을 가리켰다."

            n "아까 확인하라고 한 것도,"
            n "내일 색연필 없어서 못 쓰는 모둠 생길까 봐 그런 것 같아."

            "은지는 종이컵에 붙은 쪽지를 읽었다."

            ex_ej "아..."
            ex_ej "저거 서연이가 해둔 거야?"

            n "아마 그럴걸."
            n "글씨도 서연이 글씨 같아."

            "도윤이는 깎여 있는 색연필을 내려다봤다."

            ex_dy "그러네."
            ex_dy "이걸 혼자 다 한 건가?"

            n "말투는 조금 딱딱한데,"
            n "그냥 뭐라고만 하려고 한 건 아닌 것 같아."

            "은지는 가방끈을 만지작거리며 고개를 조금 끄덕였다."

            ex_ej "음."
            ex_ej "그럼 내가 아까 너무 안 좋게 봤나."

            ex_dy "그래도 말투는 좀 무섭긴 해."

            n "응."
            n "그건 맞아."

            "친구들은 더 크게 서연이 이야기를 하지 않았다."
            "책상 위 색연필 상자도 아까와는 조금 다르게 보였다."

        "맞아. 서연이 말투는 좀 무섭게 들릴 때가 있긴 해.":
            window show
            $ add_like("seoyeon", 0)
            $ add_neg("seoyeon", 1)
            $ choice_log.append("D2_seoyeon_event_C_listen")

            n "맞아."
            n "서연이 말투는 좀 무섭게 들릴 때가 있어."

            "은지는 기다렸다는 듯 고개를 끄덕였다."

            ex_ej "그치?"
            ex_ej "틀린 말은 아닌데, 바로 지적받는 느낌이야."

            ex_dy "맞아."
            ex_dy "색연필 하나 때문에 내가 엄청 잘못한 것처럼 느껴졌어."

            n "응."
            n "왜 그렇게까지 확인하라고 하는지는 잘 모르겠는데,"
            n "듣는 사람은 좀 부담스러울 수 있을 것 같아."

            "나는 책상 위 여분 컵을 한 번 봤다."
            "짧은 색연필과 반듯한 쪽지가 그대로 놓여 있었다."

            "서연이가 미리 준비해둔 것들이었다."
            "하지만 나는 그 이야기를 꺼내지 못했다."

            ex_ej "내일 또 그러면 그냥 대충 넘겨야겠다."
            ex_ej "말하면 더 길어질 것 같아."

            ex_dy "응."
            ex_dy "괜히 따지면 더 피곤할 수도 있고."

            "친구들은 작게 웃으며 가방을 멨다."
            "서연이가 정리해둔 색연필 상자는 그대로 책상 위에 남아 있었다."

            "나는 종이컵에 붙은 쪽지를 한 번 더 봤다."

        "그렇게 들렸으면, 다음엔 서연이한테 말해보면 어때?":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", 0)
            $ choice_log.append("D2_seoyeon_event_B_direct")

            n "서연이 말투가 부담스러웠던 건 알 것 같아."
            n "나도 가끔 바로 혼나는 느낌이 들 때가 있어."

            "은지가 작게 고개를 끄덕였다."

            ex_ej "그치?"
            ex_ej "틀린 말은 아닌데, 좀 세게 들려."

            n "응."
            n "그럼 다음에 서연이한테 말해보면 어때?"
            n "말이 조금 무섭게 들렸다고."

            "도윤이가 나를 봤다."

            ex_dy "직접?"
            ex_dy "그럼 더 어색하지 않아?"

            n "뒤에서만 말하면 서연이는 모를 것 같아서."
            n "그냥 화내듯이 말고,"
            n "조금 무섭게 들렸다고 말하면 되잖아."

            "은지는 바로 대답하지 못했다."

            ex_ej "음..."

            "도윤이는 책상 위 쪽지를 한 번 봤다."

            ex_dy "그래도 저거 정리해둔 건 좀 고맙긴 하다."

            "친구들의 목소리는 아까보다 작아졌다."
            "서연이 이야기는 거기서 멈췄다."

    if "D2_seoyeon_event_A_intent" in choice_log:
        "잠시 뒤, 서연이가 교실 앞문으로 들어왔다."
        "손에는 선생님께 빌린 작은 테이프가 들려 있었다."

        hide seoyeon
        show sy5 at center_stage as seoyeon with dissolve
        sy "아직 안 갔어?"

        n "응."
        n "색연필 여분 컵 봤어."

        "서연이는 낮은 책상 쪽을 봤다."

        sy "내일 없는 색 찾으러 다니면 시간 걸리니까."

        "서연이는 별일 아니라는 듯 말했다."

        n "애들한테도 보라고 얘기했어."

        "서연이는 잠깐 나를 봤다."

        sy "굳이 설명 안 해도 되는데."

        "말은 그렇게 했지만, 서연이는 붙인 쪽지를 만지작거렸다."

        hide seoyeon
        show sy4 at center_stage as seoyeon with dissolve
        sy "그래도..."
        sy "봤으면 됐어."
        "서연이 목소리는 아까보다 조금 작아져 있었다."

    elif "D2_seoyeon_event_B_direct" in choice_log:
        "잠시 뒤, 서연이가 교실 앞문으로 들어왔다."
        "은지는 아직 사물함 앞에서 신발주머니를 찾고 있었다."

        hide seoyeon
        show sy3 at center_stage as seoyeon with dissolve
        sy "은지."
        sy "네 모둠 초록색 색연필 하나 없었어."
        sy "내일 아침에 여분 컵에서 가져가."

        "은지는 잠깐 멈칫했다."
        "그러다 조심스럽게 말했다."

        ex_ej "서연아."
        ex_ej "아까 확인하라고 한 거, 왜 그런지는 알겠는데..."

        "서연이는 은지를 봤다."

        ex_ej "말이 조금 무섭게 들렸어."
        ex_ej "내가 혼난 줄 알았어."

        "교실이 잠깐 조용해졌다."

        hide seoyeon
        show sy4 at center_stage as seoyeon with dissolve
        sy "아."
        sy "그러려고 한 건 아니었어."
        sy "색 없으면 내일 너희 모둠이 찾으러 다닐 것 같아서 말한 거야."

        ex_ej "응."
        ex_ej "그건 알겠어."

        sy "다음엔 이유부터 말할게."
        sy "색연필 확인해 봐. 내일 불편할 수 있으니까."

        "서연이는 말하다가 스스로 말을 멈췄다."

        hide seoyeon
        show sy5 at center_stage as seoyeon with dissolve
        sy "이렇게 말하면 돼?"

        "은지는 조금 웃었다."

        ex_ej "응."
        ex_ej "아까보단 나아."

        "서연이는 고개를 한 번 끄덕였다."
        "어색했지만, 둘 사이가 아까보다 덜 딱딱해졌다."


    elif "D2_seoyeon_event_C_listen" in choice_log:
        "잠시 뒤, 서연이가 교실 앞문으로 들어왔다."
        "손에는 선생님께 빌린 작은 테이프가 들려 있었다."

        show sy5 at center_stage as seoyeon with dissolve
        sy "아직 안 갔어?"

        n "응."
        n "이제 가려고."

        "서연이는 낮은 책상 위 색연필 상자를 확인했다."
        "그리고 살짝 떨어진 쪽지를 테이프로 다시 붙였다."

        sy "내일 이거 떨어지면 아무도 못 볼 것 같아서."

        "서연이는 혼잣말처럼 말했다."

        "나는 아까 은지와 도윤이가 말투를 무서워하던 걸 떠올렸다."

        n "서연아."

        hide seoyeon
        show sy3 at center_stage as seoyeon with dissolve
        sy "응?"

        "나는 잠깐 입을 열었다가, 색연필을 봤다."

        n "아니야."
        n "쪽지 잘 붙어 있나 해서."

        sy "응."
        sy "이제 안 떨어질 거야."

        "서연이는 색연필 상자를 책상 안쪽으로 조금 밀었다."

        sy "내일 없는 색 있으면 여기서 가져가면 돼."

        n "응."
        n "알겠어."

        "서연이는 가방을 들고 교실 문 쪽으로 걸어갔다."

        "나는 종이컵에 붙은 쪽지를 다시 봤다."
        "서연이가 왜 이렇게 정리했는지는 조금 알 것 같았다."

        "하지만 은지와 도윤이가 불편해했던 말은,"
        "끝내 서연이에게 말하지 못했다."

    jump d2_go_home

# ----------------------------------------------------------
# D2 하교 + 일기
# ----------------------------------------------------------

label d2_go_home:
    $ set_bgm(audio.bgm_evening)
    scene bg_school_day with fade
    "나는 교문을 나섰다."
    "오늘 하루는 어제보다 조금 더 길게 느껴졌다."

    scene bg_room_evening
    with slow_fade

    "집에 와서 가방을 내려놓았다."
    "화요일 하루가 끝났다."

    "오늘은 친구들이 어떤 아이들인지 조금은 더 알게 된 것 같았다."

    "나는 일기장을 펼쳤다."
    "오늘 있었던 일을 적어두고 싶었다."

    jump d2_diary

label d2_diary:
    scene bg_diary with fade
    window hide

    $ _focus = d2_choice_met_1 if d2_choice_met_1 != "none" else d2_system_met
    $ _focus_name = display_name(_focus)
    $ _focus_like = like_of(_focus)
    $ _focus_neg = neg_of(_focus)

    $ diary_text = ""
    $ diary_text += "학교 둘째 날이 끝났다.\n"

    if player_trait == "observe":
        $ diary_text += "오늘 나는 친구들 표정을 계속 살폈다.\n"
        $ diary_text += "표정은 웃고 있어도 마음은 안 괜찮을 수 있겠다는 생각이 들었다.\n"

    elif player_trait == "social":
        $ diary_text += "오늘 나는 친구들과 어색하게 있지 않으려고 노력했다.\n"
        $ diary_text += "하지만 마냥 괜찮다고 넘기면 안 될 때도 있었던 것 같다.\n"

    elif player_trait == "close":
        $ diary_text += "나는 빨리 친한 친구가 생기면 좋겠다고 생각했다.\n"
        $ diary_text += "하지만 그 속도가 너무 빨라도 부담스럽게 느껴질 수 있는 것 같다.\n"

    elif player_trait == "myway":
        $ diary_text += "오늘 나는 조용히 지켜보려고 했다.\n"
        $ diary_text += "하지만 가만히 있으면 안 될 때도 있었던 것 같다.\n"

    else:
        $ diary_text += "오늘은 반 친구들이 조금 더 보였다.\n"

    $ diary_text += "\n"

    if d2_system_met == "jiho":
        $ diary_text += "점심 뒤에는 지호가 민준이 지우개로 장난치는 걸 봤다.\n"
        $ diary_text += "지호는 웃고 있었지만, 민준이는 웃지 않았다.\n"

        if "D2_jiho_A_equal" in choice_log:
            $ diary_text += "나는 지호에게 지우개를 먼저 돌려주자고 했다.\n"
            $ diary_text += "지호의 장난은 멈췄고, 민준이도 더 불편해하지 않았다.\n"

        elif "D2_jiho_B_check" in choice_log:
            $ diary_text += "나는 민준이에게 괜찮냐고 물었다.\n"
            $ diary_text += "덕분에 민준이는 불편한 마음을 전할 수 있었다.\n"

        elif "D2_jiho_C_play" in choice_log:
            $ diary_text += "나는 딱 한 번만 더 해보고 돌려주자고 했다.\n"
            $ diary_text += "지호는 좋아했지만, 민준이와는 더 어색해진 것 같았다.\n"

    elif d2_system_met == "hayoung":
        $ diary_text += "게시판 앞에서는 하영이네 모둠이 보였다.\n"
        $ diary_text += "청소를 해야 하는데, 하영이는 하기 싫어하는 눈치였다.\n"

        if "D2_hayoung_conflict_A" in choice_log:
            $ diary_text += "나는 함께한 거니까 다 같이 정리하자고 했다.\n"
            $ diary_text += "하영이는 툴툴대면서도 끝까지 같이 정리했다.\n"

        elif "D2_hayoung_conflict_B" in choice_log:
            $ diary_text += "나는 하영이가 싫어하는 물걸레 대신 색종이를 줍는 게 어떻냐고 했다.\n"
            $ diary_text += "하영이는 색종이를 줍기로 했지만, 결국 물걸레는 다른 친구가 다 했다.\n"

        elif "D2_hayoung_conflict_C" in choice_log:
            $ diary_text += "나는 하영이가 게시판을 많이 봤으니 쉬어도 된다고 했다.\n"
            $ diary_text += "하영이는 편해졌지만, 정리는 다른 친구들이 더 많이 해야 했다.\n"

    elif d2_system_met == "naeun":
        $ diary_text += "모둠 활동 시작 전 나은이와 함께 모둠 자료를 살펴봤다.\n"
        $ diary_text += "하지만 이야기하다 보니 나은이가 거의 모든 일을 맡게 됐다.\n"

        if "D2_naeun_conflict_A" in choice_log:
            $ diary_text += "나는 나은이에게만 맡기지 말고 나눠서 하자고 했다.\n"
            $ diary_text += "역할이 공평하게 나뉘었고, 나은이도 조금 편해 보였다.\n"

        elif "D2_naeun_conflict_B" in choice_log:
            $ diary_text += "나는 나은이에게 괜찮냐고 물어봤다.\n"
            $ diary_text += "결국 역할은 나뉘었지만, 왠지 나은이의 일을 돕는 것처럼 보였다.\n"

        elif "D2_naeun_conflict_C" in choice_log:
            $ diary_text += "나는 나은이가 착하다고 칭찬했다.\n"
            $ diary_text += "하지만 나은이는 쉬는 시간도 없이 할 일을 해야 해서 힘들어 보였다.\n"

    elif d2_system_met == "sohee":
        $ diary_text += "소희가 지안이에게 서운해하는 모습이 눈에 띄었다.\n"
        $ diary_text += "지안이가 소희와 먼저 보기로 한 포토카드를 민서에게 먼저 보여줬기 때문이다.\n"

        if "D2_sohee_conflict_A" in choice_log:
            $ diary_text += "나는 서운해만 하지 말고 솔직하게 말해보라고 했다.\n"
            $ diary_text += "소희는 약속을 지키지 않아서 서운했다고 말했고, 둘은 금방 풀었다.\n"

        elif "D2_sohee_conflict_B" in choice_log:
            $ diary_text += "나는 약속한 대로 소희가 지금이라도 먼저 보면 된다고 했다.\n"
            $ diary_text += "소희는 좋아했지만, 민서는 조금 무안해했다.\n"

        elif "D2_sohee_conflict_C" in choice_log:
            $ diary_text += "나는 그냥 다 같이 보면 어떠냐고 했다.\n"
            $ diary_text += "다투지는 않았지만, 소희 표정은 바로 풀리지 않았다.\n"

    elif d2_system_met == "seoyeon":
        $ diary_text += "서연이는 민우가 쓴 포스터 제목을 고치려고 하고 있었다.\n"
        $ diary_text += "제목이 삐뚤긴 했지만, 민우는 속상해 보였다.\n"

        if "D2_seoyeon_conflict_A" in choice_log:
            $ diary_text += "나는 서연이에게 민우가 속상해하는 것 같다고 말했다.\n"
            $ diary_text += "서연이는 더 이상 고치려 하지 않고 민우에게 미안해했다.\n"

        elif "D2_seoyeon_conflict_B" in choice_log:
            $ diary_text += "나는 서연이가 선을 잡아주고, 민우가 다시 써보자고 했다.\n"
            $ diary_text += "하지만 서연이의 계속되는 지적에 민우의 표정이 좋지는 않았다.\n"

        elif "D2_seoyeon_conflict_C" in choice_log:
            $ diary_text += "그래도 나는 시간이 없으니 서연이 말대로 하는 게 낫겠다고 했다.\n"
            $ diary_text += "포스터는 빨리 끝났지만, 민우가 쓴 제목은 남지 않았다.\n"

    $ diary_text += "\n"

    if d2_choice_met_1 == "jiho":
        $ diary_text += "방과 후에는 지호가 컵스택을 했다.\n"

        if "D2_jiho_event_A_equal" in choice_log:
            $ diary_text += "나는 세 번만 하고 정리하자고 했다.\n"
            $ diary_text += "지호는 아쉬워했지만 약속한 만큼만 했다.\n"

        elif "D2_jiho_event_B_compete" in choice_log:
            $ diary_text += "나는 기록을 깨보라고 응원했다.\n"
            $ diary_text += "지호는 더 신났지만, 나는 내내 기록을 재야 했다.\n"

        elif "D2_jiho_event_C_watch" in choice_log:
            $ diary_text += "나는 옆에서 보기만 했다.\n"
            $ diary_text += "지호는 정확하지 않은 기록 때문에 김이 샌 것 같았다.\n"

    elif d2_choice_met_1 == "hayoung":
        $ diary_text += "방과 후에는 하영이가 문구점에 가자고 이야기를 했다.\n"

        if "D2_hayoung_event_A_equal" in choice_log:
            $ diary_text += "수빈이도 같이 가고 싶어했지만, 하영이는 불편해했다.\n"
            $ diary_text += "나는 그래도 다 같이 보고 오자고 했다.\n"

        elif "D2_hayoung_event_B_plain" in choice_log:
            $ diary_text += "나는 오늘은 먼저 가겠다고 했다.\n"
            $ diary_text += "문구점은 궁금했지만, 전학 온 지 얼마 안 돼서 그런지 피곤했다.\n"

        elif "D2_hayoung_event_C_follow" in choice_log:
            $ diary_text += "수빈이도 같이 가고 싶어했지만 결국 나만 가기로 했다.\n"
            $ diary_text += "키링은 기대됐지만, 수빈이의 뒷모습이 눈에 남았다.\n"

    elif d2_choice_met_1 == "naeun":
        $ diary_text += "방과 후에는 나은이 그림을 보고 몰래 사진을 찍다 들켰다.\n"

        if "D2_naeun_event_A_apology" in choice_log:
            $ diary_text += "나는 바로 미안하다고 하고 사진을 지웠다.\n"
            $ diary_text += "다음엔 먼저 물어봐야겠다.\n"

        elif "D2_naeun_event_B_late_permission" in choice_log:
            $ diary_text += "나는 뒤늦게 저장해도 되는지 물었다.\n"
            $ diary_text += "사진은 지웠고, 완성되면 다시 물어보기로 했다.\n"

        elif "D2_naeun_event_C_quiet_delete" in choice_log:
            $ diary_text += "나는 조용히 사진을 지웠다.\n"
            $ diary_text += "하지만 나은이는 그걸 몰라서 계속 불편해 보였다.\n"

    elif d2_choice_met_1 == "sohee":
        $ diary_text += "방과 후에는 소희가 같은 키링을 보여줬다.\n"

        if "D2_sohee_event_A_equal" in choice_log:
            $ diary_text += "나는 키링은 받고, 교환일기는 천천히 하자고 했다.\n"
            $ diary_text += "소희는 조금 아쉬워했지만 알겠다고 했다.\n"

        elif "D2_sohee_event_B_plain" in choice_log:
            $ diary_text += "나는 똑같은 키링은 아직 조금 부담스럽다고 했다.\n"
            $ diary_text += "소희는 아쉬워했지만 나중에 다시 물어보겠다고 했다.\n"

        elif "D2_sohee_event_C_depend" in choice_log:
            $ diary_text += "나는 소희와 둘만 먼저 해보겠다고 했다.\n"
            $ diary_text += "내 생각보다도 훨씬 더 좋아했다.\n"

    elif d2_choice_met_1 == "seoyeon":
        $ diary_text += "방과 후에는 친구들이 서연이의 말투에 대한 불만을 이야기하는 걸 들었다.\n"

        if "D2_seoyeon_event_A_intent" in choice_log:
            $ diary_text += "나는 그래도 서연이가 도와주려고 한 것도 보자고 말했다.\n"
            $ diary_text += "친구들은 서연이가 준비해놓은 준비물들을 보고 조금 조용해졌다.\n"

        elif "D2_seoyeon_event_B_direct" in choice_log:
            $ diary_text += "나는 서연이에게 직접 말해보면 어떠냐고 했다.\n"
            $ diary_text += "서연이한테 이야기하자 서연이는 다음엔 이유부터 말해보겠다고 했다.\n"

        elif "D2_seoyeon_event_C_listen" in choice_log:
            $ diary_text += "나는 친구들 말에 고개를 끄덕였다.\n"
            $ diary_text += "서연이가 친구들을 위해 배려한 부분도 알았지만, 말하지 못했다.\n"

    else:
        $ diary_text += "방과 후에는 따로 한 친구를 만나지 않았다.\n"

    call screen diary_page(title="화요일 일기", content=diary_text, body_yoffset=20)

    $ renpy.movie_cutscene("videos/diary.webm", stop_music=False)

    $ diary_advice_text = ""
    $ diary_advice_text += relation_status_text(_focus_like, _focus_neg) + "\n\n"

    if _focus_neg >= 4:
        $ diary_advice_text += "내일은 그냥 웃고 넘기지 말기.\n"
        $ diary_advice_text += "불편하면 작게라도 말해보기.\n"

    elif _focus_like >= 5 and _focus_neg <= 2:
        $ diary_advice_text += "아직은 괜찮게 지내고 있는 것 같다.\n"
        $ diary_advice_text += "다른 친구들과도 조금 더 이야기해보기.\n"

    else:
        $ diary_advice_text += "친구들을 조금 천천히 지켜보자.\n"
        $ diary_advice_text += "말뿐만 아니라 행동도 같이 보기.\n"

    if burnout >= 4:
        $ diary_advice_text += "\n나의 상태: 오늘은 많이 힘들었다.\n"
        $ diary_advice_text += "내일은 다 괜찮다고만 하지 말기.\n"

    elif burnout >= 3:
        $ diary_advice_text += "\n나의 상태: 생각할 일이 많았다.\n"
        $ diary_advice_text += "그래도 어제보다는 교실이 덜 낯설었다.\n"

    else:
        $ diary_advice_text += "\n나의 상태: 조금 피곤했지만 괜찮았다.\n"

    show screen diary_focus_badge(_focus)
    call screen diary_page(title="화요일 관계 메모", content=diary_advice_text, body_yoffset=145)
    hide screen diary_focus_badge

    scene bg_room_evening
    with slow_fade

    window show

    "일기장을 덮었다."
    "내일은 수요일이다."
    "체육복을 가방 안에 넣어두었다."

    jump d3_start
# ==========================================================
# D3 수요일
# - 오전: 친구 사랑 주간 체육 활동
# - 주제: 협동 부활 피구 / 역할과 친구 마음 사이의 갈등
# - 중심 갈등: 지호의 역할 중심 생각 vs 소희의 같이 있고 싶은 마음
# - 오후: 선택 1:1 대화
# - 역할: D3은 사건을 완전히 해결하지 않고, 각 인물의 입장을 보여준다.
# ==========================================================

# ----------------------------------------------------------
# D3용 변수 + 공용 함수
# ----------------------------------------------------------

default d3_conflict_seen = False
default d3_choice_met = "none"
default d3_people_met = []

# D3 협동 부활 피구 결과
default d3_pe_result = "none"        # boundary / role_first / friend_first
default d3_conflict_type = "pe_team"

init python:
    def like_of(name):
        if name == "jiho":
            return like_jiho
        if name == "hayoung":
            return like_hayoung
        if name == "naeun":
            return like_naeun
        if name == "sohee":
            return like_sohee
        if name == "seoyeon":
            return like_seoyeon
        return 0

    def neg_of(name):
        if name == "jiho":
            return neg_jiho
        if name == "hayoung":
            return neg_hayoung
        if name == "naeun":
            return neg_naeun
        if name == "sohee":
            return neg_sohee
        if name == "seoyeon":
            return neg_seoyeon
        return 0

    def mark_d3_met(name):
        global d3_people_met
        if name not in d3_people_met:
            d3_people_met.append(name)
        mark_met(name)

    def d3_route_level(name):
        like = like_of(name)
        neg = neg_of(name)

        if like >= 4 and neg <= 1:
            return "3a"
        elif like >= 2 and neg < 4:
            return "3b"
        else:
            return "2"


# ==========================================================
# D3 시작 — 협동 부활 피구
# ==========================================================

label d3_start:
    $ day = 3
    $ d3_people_met = []
    $ d3_choice_met = "none"
    $ d3_pe_result = "none"
    $ d3_conflict_seen = False
    $ set_bgm(audio.bgm_classroom_light)

    scene black
    with day_fade

    centered "수요일"
    pause 0.5
    scene bg_classroom_after with fade

    "수요일 아침."
    "교실 문을 열자마자 아이들이 평소보다 조금 들떠 있었다."
    "칠판 한쪽에는 체육 시간 안내가 적혀 있었다."

    "{b}<1교시 체육>{/b}"
    "협동 부활 피구"
    "서로 역할을 나누어 하기"

    show t1 at center_stage as teacher with dissolve

    "선생님은 오늘 체육 시간에 협동 부활 피구를 한다고 했다."
    "피구라는 말이 나오자마자 교실 여기저기서 작은 환호가 터졌다."

    t "오늘 피구는 맞으면 바로 끝나는 피구가 아니에요."
    t "맞은 친구는 부활존으로 가요."

    t "상대 팀 공을 바닥에 떨어지기 전에 잡으면,"
    t "부활존에 있던 친구 한 명이 다시 들어올 수 있어요."

    t "그러니까 공을 잘 던지는 친구만 중요한 게 아니에요."

    hide teacher
    show t3 at center_stage as teacher with dissolve

    t "잘 피하는 친구도 필요하고,"
    t "공을 잡는 친구도 필요하고,"
    t "뒤쪽을 지키는 친구도 필요해요."

    t "내가 하고 싶은 역할을 말해보고,"
    t "친구가 하고 싶은 역할도 들어주세요."

    "아이들이 웅성거리며 자리에서 일어났다."
    jump d3_morning_group_conflict_part1


label d3_morning_group_conflict_part1:
    $ d3_conflict_seen = True
    $ set_bgm(audio.bgm_classroom_light2)

    scene bg_gym_day with fade
    "체육관 한쪽 벽에는 'A팀' 종이가 붙어 있었다."
    "다른 쪽 벽에는 'B팀' 종이가 붙어 있었다."
    "가운데에는 말랑한 피구공이 바구니 안에 담겨 있었다."

    "나는 전학 온 지 얼마 안 돼서 번호가 맨 끝이었다."
    "끝번호 쪽이 A팀으로 묶이면서, 나와 지호와 소희가 같은 팀이 되었다."

    show jh5 at left_stage as jiho with dissolve
    jh "야, 이거 역할 잘 정해야 돼."
    jh "앞에서 던지는 애, 중간에서 공 보는 애, 뒤에서 버티는 애."
    jh "그냥 막 서 있으면 부활도 못 시킨다니까."

    "지호는 신이 나 보였다."

    show sh2 at right_stage as sohee with dissolve
    sh "어..."
    sh "그럼 나는 뒤쪽 할래."
    sh "공 날아오면 좀 당황해서."

    "소희는 그렇게 말하고는 내 쪽을 슬쩍 봤다."

    hide jiho
    show jh1 at left_stage as jiho with dissolve
    jh "유진이는 중간이 좋을 것 같은데."
    jh "공 피하면서 어디 비었는지 보는 역할 있잖아."

    hide sohee
    show sh5 at right_stage as sohee with dissolve
    sh "뒤쪽이 더 편할 수도 있지."
    sh "갑자기 중간에 서면 부담될 수도 있고."

    hide jiho
    show jh6 at left_stage as jiho with dissolve
    jh "부담 주려는 게 아니라, 잘할 것 같아서 말한 거야."
    jh "중간이 비면 우리 팀이 바로 흔들릴 수도 있잖아."

    hide sohee
    show sh2 at right_stage as sohee with dissolve
    sh "나는..."
    sh "처음 판은 유진이랑 같이 있으면 덜 긴장될 것 같은데."

    "소희는 체육복 소매 끝을 만졌다."
    "말끝은 작았지만, 쉽게 물러서고 싶어 하지는 않았다."

    hide jiho
    show jh2 at left_stage as jiho with dissolve
    jh "근데 둘 다 뒤쪽이면 중간은 누가 봐?"
    jh "같이 있고 싶은 것도 알겠는데, 역할도 나눠야지."

    hide sohee
    show sh5 at right_stage as sohee with dissolve
    sh "그럼 같이 있고 싶은 건 하나도 안 중요한 거야?"

    "둘 다 틀린 말을 하는 것 같지는 않았다."
    "문제는 두 사람의 말 사이에 내 이름이 들어가 있다는 거였다."

    "아이들의 시선이 나에게 모였다."
    "지호는 공을 손바닥 위에서 천천히 굴리고 있었다."
    "소희는 내 쪽을 보다가 다시 바닥을 봤다."
    $ choice_question_text = "나는 어떻게 말할까?"
    window hide

    menu:

        "첫 판은 소희랑 뒤쪽에서 하고, 다음 판엔 중간도 해볼게.":
            window show
            $ d3_pe_result = "boundary"
            $ add_like("jiho", 1)
            $ add_like("sohee", 1)
            $ add_neg("jiho", -1)
            $ add_neg("sohee", -1)
            $ choice_log.append("D3_pe_A_teacher_help")

            n "나도 아직 잘 모르겠어."
            n "소희랑 같이 뒤쪽에서 시작하면 덜 긴장될 것 같아."
            n "근데 지호 말처럼 중간 역할도 필요하다는 건 알겠어."

            show jh3 at left_stage as jiho with dissolve
            show sh2 at right_stage as sohee with dissolve

            "지호와 소희가 동시에 나를 봤다."

            n "그러니까 첫 판은 뒤쪽에서 시작하고,"
            n "다음 판에는 내가 중간도 해볼게."
            n "처음부터 하나로 딱 정하면, 나도 잘 맞는지 모르니까."

            hide sohee with dissolve
            hide jiho with dissolve

            show jh1 at center_stage as jiho with dissolve
            jh "그럼 첫 판 끝나고 바꾸는 거네."
            jh "오케이. 그건 괜찮다."

            hide jiho
            show sh2 at center_stage as sohee with dissolve
            sh "그럼 첫 판은..."
            sh "같이 뒤쪽에서 시작하는 거지?"

            n "응."
            n "근데 첫 판 끝나면 나도 중간에 가볼 수 있어."
            n "그때 다시 말해보자."

            sh "...알겠어."

            hide sohee with dissolve

            "소희는 조금 아쉬워 보였지만, 억지로 붙잡지는 않았다."
            "지호도 더 밀어붙이지는 않았다."

            "첫 판이 시작되자, 나는 소희 옆에서 뒤쪽을 지켰다."
            "소희는 처음 날아온 공을 피하고 작게 숨을 내쉬었다."

            "두 번째 판에서는 내가 중간으로 한 걸음 나갔다."
            "뒤쪽의 소희가 조금 긴장한 얼굴로 나를 봤지만," 
            "그대로 자기 자리를 지켰다."

            "완전히 편한 선택은 아니었다."
            "그래도 내 자리는 내가 정할 수 있었다."


        "나는 중간도 해보고 싶어. 팀에 도움이 될 것 같아.":
            window show
            $ d3_pe_result = "role_first"
            $ add_like("jiho", 2)
            $ add_neg("jiho", 1)
            $ add_neg("sohee", 2)
            $ choice_log.append("D3_pe_B_role_first")

            n "나는 중간 역할도 해보고 싶어."
            n "처음이라 긴장되긴 하는데,"
            n "공이 어디로 가는지 보면 팀에 도움이 될 것 같아."
            hide jiho
            hide sohee
            show sh2 at right_stage as sohee with dissolve
            show jh1 at left_stage as jiho with dissolve
            jh "그치?"
            jh "유진이 중간에 있으면 우리 팀 훨씬 잘 굴러갈걸."

            "지호의 표정은 바로 풀렸다."
            "공을 손바닥 위에서 가볍게 튕겼다."

            sh "...응."
            sh "그럼 나는 뒤쪽 할게."

            n "소희야."
            n "첫 판 끝나고 힘들면 말해줘."
            n "나도 뒤쪽으로 바꿔볼 수 있어."

            sh "괜찮아."
            sh "네가 해보고 싶다니까."
            hide jiho with dissolve
            hide sohee with dissolve

            "소희는 괜찮다고 말했다."
            "하지만 체육복 소매 끝을 잡은 손은 그대로였다."

            "경기가 시작되자, 나는 중간에서 공의 방향을 보려고 움직였다."
            "지호는 내가 빈 곳으로 움직일 때마다 손짓했다."

            show jh1 at center_stage as jiho with dissolve
            jh "좋아, 거기!"
            jh "오른쪽 비었어!"

            hide jiho with dissolve

            "중간에 서니 공이 어디로 오는지는 잘 보였다."
            "하지만 소희가 공을 피할 때마다,"
            "나는 자꾸 뒤를 돌아보게 됐다."

            "팀에는 도움이 된 것 같았다."
            "그런데 마음까지 가벼운 건 아니었다."


        "오늘은 뒤쪽에서 시작할래. 아직 중간은 좀 긴장돼.":
            window show
            $ d3_pe_result = "friend_first"
            $ add_like("sohee", 2)
            $ add_neg("sohee", 1)
            $ add_neg("jiho", 2)
            $ choice_log.append("D3_pe_C_friend_first")

            n "오늘은 뒤쪽에서 시작하고 싶어."
            n "아직 새 학교 체육 시간이 익숙하지 않아서,"
            n "처음 판은 조금 편한 자리에서 해보고 싶어."

            hide sohee
            hide jiho
            show sh1 at right_stage as sohee with dissolve
            show jh4 at left_stage as jiho with dissolve
            sh "...진짜?"

            "소희의 표정이 바로 밝아졌다."

            n "응."
            n "대신 계속 뒤에만 있겠다는 건 아니야."
            n "상황 봐서 움직일 수 있으면 나도 앞으로 나가볼게."

            hide jiho
            hide sohee
            show jh6 at center_stage as jiho with dissolve
            jh "아..."
            jh "그럼 중간은 누가 보냐."

            "지호는 작게 투덜거리며 공을 손에 쥐었다."

            n "처음부터 중간은 아직 좀 긴장돼."

            jh "알겠어."
            jh "근데 중간 비면 바로 밀릴 수도 있다?"

            hide jiho
            show sh4 at center_stage as sohee with dissolve
            sh "고마워, 유진아."
            sh "옆에 있으면 나도 좀 덜 떨릴 것 같아."

            hide sohee with dissolve

            "소희는 기뻐 보였다."

            "경기가 시작되자, 나는 소희와 함께 뒤쪽으로 갔다."
            "소희는 첫 공을 피하고 나를 보며 작게 웃었다."

            "그때 중간 쪽으로 공이 튀었다."
            "잡을 수 있을 것 같았지만, 그 자리에 있던 친구가 한 걸음 늦었다."

            show jh2 at center_stage as jiho with dissolve
            jh "아, 중간 비었다니까!"

            "지호의 말은 크게 날카롭지는 않았다."
            "그래도 내 귀에는 오래 남았다."

            hide jiho with dissolve

    jump d3_afternoon_choice

# ==========================================================
# D3 오후 선택 — 협동 부활 피구 이후 1:1 대화
# 구조: 인물 선택 → 상황 미리보기 → 대화 / 돌아가기
# ==========================================================

label d3_afternoon_choice:
    scene bg_classroom_after with fade
    $ set_bgm(audio.bgm_daily_morning)
    "방과 후, 교실에는 체육 시간 이야기가 활발히 돌았다."
    "아까 일이 그냥 넘어가도 되는 건지 조금 신경 쓰였다."
    "누구랑 한번 이야기해 보면 좋을 것 같았다."

    $ choice_question_text = "지금 누구에게 가볼까?"
    window hide

    menu:

        "{color=#7DB8FF}지호{/color}를 살펴본다":
            window show
            jump d3_preview_jiho

        "{color=#FF9ACD}하영{/color}을 살펴본다":
            window show
            jump d3_preview_hayoung

        "{color=#BFA7FF}나은{/color}을 살펴본다":
            window show
            jump d3_preview_naeun

        "{color=#FFCF6E}소희{/color}를 살펴본다":
            window show
            jump d3_preview_sohee

        "{color=#9FE0C5}서연{/color}을 살펴본다":
            window show
            jump d3_preview_seoyeon


# ----------------------------------------------------------
# 지호 미리보기
# ----------------------------------------------------------
label d3_preview_jiho:

    scene bg_playground_day with fade
    show jh4 at center_stage as jiho with dissolve 

    "운동장 벤치 근처에 지호가 앉아 있었다."
    "지호는 농구공을 발끝으로 굴리며 체육관 쪽을 보고 있었다."

    $ choice_question_text = "지호와 이야기해볼까?"
    window hide

    menu:

        "지호와 이야기한다":
            window show
            if d3_route_level("jiho") == "3a":
                jump d3_jiho_3a
            elif d3_route_level("jiho") == "3b":
                jump d3_jiho_3b
            else:
                jump d3_jiho_2

        "다른 친구를 찾아본다":
            window show
            jump d3_afternoon_choice


# ----------------------------------------------------------
# 하영 미리보기
# ----------------------------------------------------------

label d3_preview_hayoung:

    scene bg_restroom_mirror with fade
    show h4 at center_stage as hayoung with dissolve

    "화장실 거울 앞에서 하영이가 머리끈을 다시 묶고 있었다."
    "창가 쪽 친구들은 무언가 속닥거리고 있었다."

    $ choice_question_text = "하영이와 이야기해볼까?"
    window hide

    menu:

        "하영이와 이야기한다":
            window show
            if d3_route_level("hayoung") == "3a":
                jump d3_hayoung_3a
            elif d3_route_level("hayoung") == "3b":
                jump d3_hayoung_3b
            else:
                jump d3_hayoung_2

        "다른 친구를 찾아본다":
            window show
            jump d3_afternoon_choice


# ----------------------------------------------------------
# 나은 미리보기
# ----------------------------------------------------------

label d3_preview_naeun:

    scene bg_corridor_day with fade
    show ne5 at center_stage as naeun with dissolve

    "체육관 옆 복도에서 나은이가 물병을 들고 서 있었다."
    "나은이는 교실로 올라가지 못하고 체육관 문 앞에 서 있었다."

    $ choice_question_text = "나은이와 이야기해볼까?"
    window hide

    menu:

        "나은이와 이야기한다":
            window show
            if d3_route_level("naeun") == "3a":
                jump d3_naeun_3a
            elif d3_route_level("naeun") == "3b":
                jump d3_naeun_3b
            else:
                jump d3_naeun_2

        "다른 친구를 찾아본다":
            window show
            jump d3_afternoon_choice


# ----------------------------------------------------------
# 소희 미리보기
# ----------------------------------------------------------

label d3_preview_sohee:

    scene bg_board_plain with fade
    show sh2 at center_stage as sohee with dissolve

    "교실 뒤편에서 소희가 체육복 소매 끝을 만지작거리고 있었다."
    "소희는 내가 지나갈 때마다 나를 볼 듯 말 듯 고개를 들었다."

    $ choice_question_text = "소희와 이야기해볼까?"
    window hide

    menu:

        "소희와 이야기한다":
            window show
            if d3_route_level("sohee") == "3a":
                jump d3_sohee_3a
            elif d3_route_level("sohee") == "3b":
                jump d3_sohee_3b
            else:
                jump d3_sohee_2

        "다른 친구를 찾아본다":
            window show
            jump d3_afternoon_choice


# ----------------------------------------------------------
# 서연 미리보기
# ----------------------------------------------------------

label d3_preview_seoyeon:

    scene bg_classroom_after with fade
    show sy2 at center_stage as seoyeon with dissolve

    "교실 앞 칠판에 서연이가 서 있었다."
    "체육 시간에 썼던 팀 이름 옆에 무언가 적고 있었다."

    $ choice_question_text = "서연이와 이야기해볼까?"
    window hide

    menu:

        "서연이와 이야기한다":
            window show
            if d3_route_level("seoyeon") == "3a":
                jump d3_seoyeon_3a
            elif d3_route_level("seoyeon") == "3b":
                jump d3_seoyeon_3b
            else:
                jump d3_seoyeon_2

        "다른 친구를 찾아본다":
            window show
            jump d3_afternoon_choice

# ==========================================================

# 지호 — 운동장 벤치

# 핵심: 승부욕 / 역할 중심 / 말이 빠름 / 뒤끝은 짧음

# 선택지 통일:

# A = 소희 마음도 보게 함

# B = 지호의 팀 생각을 받아줌

# ==========================================================

label d3_jiho_3a:
    $ set_bgm(audio.bgm_jiho_active)
    $ mark_d3_met("jiho")
    $ d3_choice_met = "jiho"

    scene bg_playground_day with fade

    "운동장 벤치 근처에 지호가 앉아 있었다."
    "지호는 농구공을 발끝으로 굴리며 체육관 쪽을 보고 있었다."

    show jh5 at center_stage as jiho with dissolve
    jh "오, 유진."

    n "혼자 있었어?"

    jh "그냥 좀 생각 중."

    "지호는 발끝으로 굴리던 농구공을 멈췄다."
    "그리고 공을 양손으로 잡았다."

    hide jiho
    show jh4 at center_stage as jiho with dissolve

    jh "아까 내가 좀 세게 말했나?"

    n "피구 때?"

    jh "응."
    jh "나는 역할 나누는 게 중요하다고 생각했거든."
    jh "가운데가 비면 우리 팀이 바로 밀릴 것 같았고."

    "지호는 농구공의 줄무늬를 손가락으로 툭툭 건드렸다."

    jh "근데 소희 표정이 계속 생각나."
    jh "나 너무 이기는 것만 생각한 것처럼 보였나?"

    n "그게 신경 쓰였어?"

    hide jiho
    show jh3 at center_stage as jiho with dissolve

    jh "조금."
    jh "아까는 솔직히 답답했어."
    jh "같이 있고 싶은 건 알겠는데,"
    jh "둘 다 뒤에 있으면 가운데가 비잖아."

    "지호는 말을 빠르게 하다가 잠깐 멈췄다."

    jh "근데..."
    jh "네가 어디 서고 싶은지도 먼저 물어봤어야 했나?"

    "지호는 나를 보고 어색하게 웃었다."

    jh "너한테는 한번 물어보고 싶더라."

    $ choice_question_text = "지호에게 어떻게 답할까?"
    window hide

    menu:

        "네 말도 이해돼. 팀 생각해서 말한 거였잖아.":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", 1)
            $ add_neg("sohee", 1)
            $ choice_log.append("D3_jiho_3a_B_cover")

            n "네 말도 이해돼."
            n "팀 생각해서 말한 거였잖아."

            hide jiho
            show jh1 at center_stage as jiho with dissolve

            jh "그치?"
            jh "나는 딱 그거였어."

            "지호의 표정이 바로 풀렸다."

            jh "유진이는 가운데에 있으면 잘할 것 같았고,"
            jh "가운데가 비면 바로 밀려버리니까."

            n "응."
            n "네 의견이 틀렸다는 건 아니야."

            jh "역시 너랑은 말이 통하네."
            jh "괜히 계속 생각했네."

            "지호는 다시 농구공을 튀겼다."
            "공 소리가 금방 가벼워졌다."

            "나는 고개를 끄덕였지만,"
            "소희가 체육복 소매를 만지던 모습이 조금 생각났다."

        "네 말도 알겠는데, 소희는 좀 속상했을 것 같아.":
            window show
            $ add_like("jiho", 2)
            $ add_neg("jiho", -1)
            $ choice_log.append("D3_jiho_3a_A_point")

            n "네 말도 알겠어."
            n "가운데가 비면 힘든 것도 맞고."

            jh "그치."

            n "근데 소희는 그냥 역할 얘기만 한 건 아니었잖아."
            n "나랑 같이 있으면 덜 떨릴 것 같다고 한 거였어."

            jh "응..."

            n "네가 그래도 가운데가 낫다고 하니까,"
            n "소희는 자기 말이 그냥 지나간 것처럼 느꼈을 수도 있어."

            hide jiho
            show jh4 at center_stage as jiho with dissolve

            jh "...아."

            "지호는 농구공을 튀기려다 멈췄다."

            jh "나는 팀 생각한 건데."
            jh "소희는 같이 있고 싶다는 말을 먼저 한 거구나."

            n "응."
            n "그랬던 것 같아."

            hide jiho
            show jh3 at center_stage as jiho with dissolve
            jh "다시 해도 나는 가운데 얘기는 했을 거야."
            jh "근데 먼저 물어봤어야 했네."
            jh "너는 어디 서고 싶은지."

            "지호는 농구공을 손바닥 위에서 한 번 굴렸다."

            jh "내일 소희 보면 말해봐야겠다."
            jh "무시하려던 건 아니었다고."

            "지호는 다시 농구공을 튀겼다."
            "공 소리가 아까보다 조금 느려졌다."


    jump d3_go_home

label d3_jiho_3b:
    $ set_bgm(audio.bgm_jiho_active)
    $ mark_d3_met("jiho")
    $ d3_choice_met = "jiho"

    scene bg_playground_day with fade

    "운동장 벤치 근처에서 지호가 농구공을 튀기고 있었다."
    "나를 보더니 손을 가볍게 흔들었다."

    show jh1 at center_stage as jiho with dissolve
    jh "오, 유진."

    n "아까 피구 때문에 여기 있는 거야?"

    hide jiho
    show jh4 at center_stage as jiho with dissolve

    jh "뭐, 조금?"
    jh "아직도 잘 모르겠어."
    jh "소희가 왜 그렇게 서운해했는지."

    "지호는 농구공을 손바닥 위에서 굴렸다."

    if d3_pe_result == "role_first":
        jh "너는 가운데 괜찮았잖아."
        jh "그러면 된 거 아닌가 싶기도 하고."

    elif d3_pe_result == "friend_first":
        jh "네가 뒤쪽이 편하다고 한 건 알겠는데,"
        jh "가운데가 비니까 좀 답답하긴 했어."

    elif d3_pe_result == "boundary":
        jh "첫 판 해보고 바꾸는 건 괜찮았어."
        jh "근데 왜 그렇게 복잡해졌는지는 아직 모르겠고."

    else:
        jh "누가 어디 설지 정하는 게 그렇게 어려운 줄은 몰랐어."

    jh "너는 어떻게 봤어?"

    $ choice_question_text = "지호에게 어떻게 답할까?"
    window hide

    menu:

        "네 말도 이해돼. 팀 생각해서 말한 거였잖아.":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", 1)
            $ choice_log.append("D3_jiho_3b_B_role_agree")

            n "네 말도 이해돼."
            n "팀 생각해서 말한 거였잖아."

            hide jiho
            show jh1 at center_stage as jiho with dissolve

            jh "그치?"
            jh "나는 그 말 한 건데."

            n "응."
            n "가운데가 비면 막기 힘든 것도 맞고."

            jh "둘 다 뒤에 있으면 가운데가 비잖아."

            n "맞아."
            n "근데 다음엔 어디 설 건지 한 번만 물어보면 좋을 것 같아."

            jh "그 정도는 할 수 있지."

            "지호는 다시 공을 튀겼다."
            "표정은 금방 풀렸다."
            "소희 이야기는 거기서 더 이어지지 않았다."

        "네 말도 알겠는데, 소희는 좀 속상했을 것 같아.":
            window show
            $ add_like("jiho", 2)
            $ add_neg("jiho", -1)
            $ choice_log.append("D3_jiho_3b_A_balance")

            n "네 말도 알겠어."
            n "가운데가 필요한 것도 맞아."

            hide jiho
            show jh3 at center_stage as jiho with dissolve

            jh "그치."

            n "근데 소희는 처음 판이 좀 떨렸던 것 같아."
            n "나랑 옆에 있으면 덜 긴장될 것 같았던 거고."

            "지호는 공을 튀기려다 말고 멈췄다."

            jh "...그런가."

            n "같은 팀이어도,"
            n "자리가 멀어지면 혼자 있는 것처럼 느껴질 수도 있잖아."

            jh "나는 그냥 같은 팀이면 되는 줄 알았는데."

            "지호는 공을 발끝 옆에 세워두고 잠깐 바닥을 봤다."

            jh "음."
            jh "그건 좀 몰랐네."

            "지호는 다시 공을 튀겼다."
            "완전히 알겠다는 얼굴은 아니었지만, 바로 웃어넘기지는 않았다."

    jump d3_go_home

label d3_jiho_2:
    $ set_bgm(audio.bgm_jiho_active)
    $ mark_d3_met("jiho")
    $ d3_choice_met = "jiho"

    scene bg_playground_day with fade

    "운동장 벤치에서 지호가 친구 두 명과 농구공을 튀기고 있었다."
    "지호는 나를 보더니 슬쩍 손을 흔들며 다가왔다."

    show jh1 at center_stage as jiho with dissolve

    jh "오, 유진."
    jh "아까 피구 때 좀 어색했지?"

    n "어..."
    n "조금...?"

    hide jiho
    show jh3 at center_stage as jiho with dissolve

    jh "뭐, 팀 짜다 보면 그런 일도 있지."
    jh "아무튼 너도 좀 정신없었겠다."

    "지호는 다시 친구들 쪽으로 돌아가려 했다."

    n "지호야."

    jh "응?"

    $ choice_question_text = "지호에게 뭐라고 할까?"
    window hide

    menu:

        "괜찮아. 팀 생각해서 말한 거였잖아.":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", 1)
            $ choice_log.append("D3_jiho_2_B_light")

            n "괜찮아."
            n "팀 생각해서 말한 거였잖아."

            hide jiho
            show jh1 at center_stage as jiho with dissolve

            jh "맞아."
            jh "나는 딱 그거였어."

            n "응."
            n "그럴 수도 있지."

            "지호는 어깨를 으쓱했다."

            jh "나 다시 갈게."
            jh "쟤네 자유투 내기 하자고 해서."

            n "응."

            "대화는 금방 끝났다."

        "그런데, 소희는 좀 속상했을 것 같아.":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", -1)
            $ choice_log.append("D3_jiho_2_A_nudge")

            n "네 말이 맞아."
            n "가운데가 필요하다는 말."

            hide jiho
            show jh4 at center_stage as jiho with dissolve

            jh "어...?"

            n "근데 소희는 좀 속상해 했던 것 같아."

            "지호는 농구공을 옆구리에 끼고 눈을 깜박였다."

            jh "아."
            jh "그랬나."

            n "소희 말도 그냥 넘기지 않았으면 해서."

            jh "오케이."
            jh "나중에 보면 생각해볼게."

            "지호는 금방 친구들 쪽을 봤다."

    jump d3_go_home

# ==========================================================

# 소희 — 교실 뒤편

# 핵심: 같은 역할 / 확인받고 싶은 마음 / 가까운 관계 욕구

# 선택지 통일:

# A = 같이 있고 싶은 마음은 인정하되 먼저 물어보게 함

# B = 같이 하자는 마음을 받아줌

# ==========================================================

label d3_sohee_3a:
    $ set_bgm(audio.bgm_sohee_warm)
    $ mark_d3_met("sohee")
    $ d3_choice_met = "sohee"

    scene bg_board_plain with fade

    "소희는 교실 뒤편에서 체육복 소매 끝을 만지고 있었다."
    "내가 다가가자 소희는 웃으려다가, 다시 시무룩한 얼굴이 되었다."

    show sh1 at center_stage as sohee with dissolve
    sh "유진아."

    n "괜찮아?"

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "응."
    sh "괜찮아."

    "괜찮다는 말과 다르게, 소희는 소매 끝을 계속 만졌다."

    if d3_pe_result == "boundary":
        sh "아까 첫 판은 같이 뒤쪽에 서서 좋았어."
        sh "근데 다음 판에 네가 가운데로 가니까..."
        sh "조금 허전했어."

    elif d3_pe_result == "role_first":
        sh "아까 네가 가운데로 간 거,"
        sh "네가 하고 싶어서 간 거라는 건 알아."
        sh "근데 갑자기 너랑 떨어지니까 조금 놀랐어."

    elif d3_pe_result == "friend_first":
        sh "아까 네가 뒤쪽에 같이 와줘서 좋았어."
        sh "진짜 조금 덜 떨렸거든."
        sh "근데 지호가 답답해하는 것 같아서,"
        sh "나도 마음에 걸렸어."

    else:
        sh "아까 피구 때 말이야."
        sh "나 때문에 너무 당황스러웠어?"

    sh "나는 그냥..."
    sh "처음부터 혼자 하는 게 좀 무서웠어."

    n "공이 무서웠어?"

    sh "공도 조금 무서웠고."
    sh "애들이 막 움직이니까,"
    sh "나만 어디 서야 할지 모르겠더라."

    "소희는 작게 웃었다."
    "웃고 있었지만 손끝에는 힘이 들어가 있었다."

    sh "그래서 네가 옆에 있으면 괜찮을 것 같았어."
    sh "근데 내가 유진이 옆에만 있으려고 한 것 같기도 해."

    $ choice_question_text = "소희에게 어떻게 답할까?"
    window hide

    menu:

        "다음엔 나랑 같이 할지 먼저 물어봐 줘.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", -1)
            $ choice_log.append("D3_sohee_3a_A_boundary")

            n "왜 그랬는지는 알 것 같아."
            n "공이 무섭고, 혼자 있으면 떨릴 수 있잖아."

            "소희는 조용히 고개를 끄덕였다."

            n "근데 내 생각은 묻지 않고,"
            n "나랑 같이 하는 쪽으로 먼저 정하는 것 같아서 조금 당황했어."

            sh "...내가 먼저 물어봤어야 했다는 거지?"

            n "응."
            n "다음엔 나랑 같이 할지 먼저 물어봐 줘."

            "소희는 바로 대답하지 않았다."
            "대신 소매 끝을 잡고 있던 손을 천천히 풀었다."

            sh "그럼..."
            sh "같이 해도 돼? 이렇게?"

            n "응."
            n "그렇게 물어봐 주면 나도 말하기 쉬워."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "조금 서운하긴 한데..."
            sh "그래도 무슨 말인지는 알겠어."

            "소희는 작게 고개를 끄덕였다."


        "같이 하자고 해줘서 고마웠어.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", 1)
            $ choice_log.append("D3_sohee_3a_B_reassure")

            n "같이 하자고 해줘서 고마웠어."
            n "사실 나도 아직 체육 시간은 좀 어색했거든."

            hide sohee
            show sh4 at center_stage as sohee with dissolve

            sh "진짜?"

            "소희의 표정이 바로 밝아졌다."

            sh "그럼 너도 나랑 같이 있으면 좀 편한 거지?"

            n "응."
            n "소희가 먼저 말해줘서 좋았어."

            "소희는 환하게 웃었다."

            sh "그럼 다음에도 우리 같이 서자."
            sh "처음부터 같이 있으면 덜 어색하잖아."

            n "응."
            n "그렇게 해도 괜찮을 것 같아."

            "말하고 나니 마음 한쪽이 조금 걸렸다."
            "나도 가운데를 해보고 싶은 마음이 아주 없지는 않았다."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "다행이다."
            sh "나는 네가 나랑 같이 있는 거 싫은 줄 알았어."

            n "싫은 건 아니야."

            "소희는 안심한 얼굴로 고개를 끄덕였다."
            "나는 더 말하려다가 그냥 웃어 보였다."
            "다음엔 어떻게 하고 싶은지, 제대로 말하지 못했다."

    jump d3_go_home

label d3_sohee_3b:
    $ set_bgm(audio.bgm_sohee_warm)
    $ mark_d3_met("sohee")
    $ d3_choice_met = "sohee"

    scene bg_board_plain with fade

    "소희는 교실 뒤편에서 체육복 소매 끝을 만지고 있었다."
    "내가 다가가자 소희가 조심스럽게 웃었다."

    show sh1 at center_stage as sohee with dissolve

    sh "유진아."
    sh "아까 좀 놀랐지?"

    n "조금."

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "미안."
    sh "나는 그냥 같이 있으면 덜 어색할 것 같아서."

    if d3_pe_result == "boundary":
        sh "첫 판에 같이 있어서 좀 괜찮았어."
        sh "다음 판에 떨어졌을 때는 조금 아쉬웠고."

    elif d3_pe_result == "role_first":
        sh "네가 가운데로 간 건 이해해."
        sh "근데 갑자기 떨어지니까 조금 어색했어."

    elif d3_pe_result == "friend_first":
        sh "아까 뒤쪽에 같이 와줘서 고마웠어."
        sh "그때는 좀 안심됐거든."

    else:
        sh "그냥 처음부터 혼자 하려니까 좀 떨렸어."

    "소희는 웃으려고 했지만, 내 대답을 기다리는 얼굴이었다."

    $ choice_question_text = "소희에게 어떻게 답할까?"
    window hide

    menu:

        "다음엔 나랑 같이 할지 먼저 물어봐 줘.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", -1)
            $ choice_log.append("D3_sohee_3b_A_boundary")

            n "같이 있고 싶었던 건 알겠어."
            n "근데 다음엔 나랑 같이 할지 먼저 물어봐 줘."

            sh "아..."
            sh "갑자기 정해지면 당황할 수도 있구나."

            n "응."
            n "먼저 물어봐 주면 나도 말하기 쉬워."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "알겠어."
            sh "다음엔 먼저 물어볼게."

            "소희는 고개를 끄덕였지만,"
            "아직 조금 아쉬운 얼굴이었다."


        "같이 하자고 해줘서 고마웠어.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", 1)
            $ choice_log.append("D3_sohee_3b_B_promise")

            n "같이 하자고 해줘서 고마웠어."
            n "나도 아까는 좀 어색했거든."

            hide sohee
            show sh4 at center_stage as sohee with dissolve

            sh "진짜?"

            "소희의 얼굴이 바로 밝아졌다."
            "소희는 한 걸음 더 가까이 다가왔다."

            sh "그럼 너도 나랑 같이 있으면 괜찮은 거지?"
            sh "나만 그렇게 생각한 건 아니지?"

            n "응."
            n "나도 괜찮았어."

            hide sohee
            show sh1 at center_stage as sohee with dissolve

            sh "다행이다."
            sh "나 괜히 혼자만 좋아한 줄 알았어."

            "소희는 안심한 듯 웃었다."

            sh "그럼 다음에도 같이 있자."
            sh "처음엔 둘이 같이 있으면 덜 어색하잖아."

            n "응."
            n "그럴게."

            "소희는 그 말에 더 환하게 웃었다."
            "고맙다고 말한 건 맞았지만,"
            "왠지 다음에도 꼭 같이 있어야 할 것처럼 되어버렸다."

    jump d3_go_home

label d3_sohee_2:
    $ set_bgm(audio.bgm_sohee_warm)
    $ mark_d3_met("sohee")
    $ d3_choice_met = "sohee"

    scene bg_board_plain with fade

    "소희는 교실 뒤편에 서 있었다."
    "내가 지나가자 소희가 먼저 나를 불렀다."

    show sh1 at center_stage as sohee with dissolve

    sh "유진아."
    sh "아까 나 좀 이상했어?"

    n "응?"

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "그냥 너랑 같이 있으면 덜 떨릴 것 같아서."
    sh "근데 괜히 그런 말 했나 싶어서."

    "소희는 내 얼굴을 살폈다."
    "아직 많이 친한 사이는 아닌데, 대답을 기다리는 것 같았다."

    $ choice_question_text = "소희에게 어떻게 답할까?"
    window hide

    menu:

        "다음엔 나랑 같이 할지 먼저 물어봐 줘.":
            window show
            $ add_like("sohee", 1)
            $ add_neg("sohee", -1)
            $ choice_log.append("D3_sohee_2_A_later")

            n "이상한 건 아니야."
            n "근데 다음엔 나랑 같이 할지 먼저 물어봐 줘."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "아..."
            sh "알겠어."

            n "내가 어디 서고 싶은지도 있을 수 있으니까."

            sh "응."
            sh "다음엔 물어볼게."

            "대화는 거기서 끊겼다."


        "같이 하자고 해줘서 고마웠어.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", 2)
            $ choice_log.append("D3_sohee_2_B_promise")

            n "같이 하자고 해줘서 고마웠어."

            hide sohee
            show sh4 at center_stage as sohee with dissolve

            sh "진짜?"

            "소희의 표정이 금방 밝아졌다."

            sh "그럼 너도 나랑 같이 있는 게 괜찮았던 거네?"
            sh "나만 그런 줄 알았어."

            n "응."
            n "나도 좀 어색했으니까."

            sh "다행이다."
            sh "그럼 다음에도 나랑 같이 있으면 되겠다."

            n "응."
            n "그래."

            hide sohee
            show sh1 at center_stage as sohee with dissolve

            sh "진짜지?"
            sh "나 다음에도 너한테 갈게."

            n "응."

            "소희는 기분이 좋아 보였다."
            "나는 고개를 끄덕였지만,"
            "고맙다고 한 말이 약속처럼 굳어진 것 같았다."

    jump d3_go_home
# ==========================================================

# 하영 — 복도 거울 앞

# 핵심: 분위기 읽기 / 말이 퍼지는 무리 / 없는 자리에서 평가하는 말

# 선택지 통일:

# A = 하영의 평가에 바로 올라타지 않음

# B = 하영이 알아봐준 것에 기대게 됨

# ==========================================================

label d3_hayoung_3a:
    $ set_bgm(audio.bgm_hayoung_social)
    $ mark_d3_met("hayoung")
    $ d3_choice_met = "hayoung"

    scene bg_restroom_mirror with fade

    "화장실 거울 앞에서 하영이가 머리끈을 다시 묶고 있었다."
    "옆 창가에는 하영이와 자주 다니는 친구 두 명이 작게 이야기하고 있었다."

    show h5 at center_stage as hayoung with dissolve

    "내가 다가가자 하영이는 거울을 보던 손을 멈췄다."
    "하영이는 창가 쪽 친구들을 한 번 보고, 내 쪽으로 조금 다가왔다."

    hy "어, 유진아."

    n "여기서 뭐 해?"

    hy "방금까지 애들이랑 아까 피구 얘기했어."
    hy "벌써 다들 한마디씩 하더라."

    n "무슨 얘기?"

    "하영이는 바로 대답하지 않고 머리끈을 손목에 끼웠다."
    "창가 쪽 친구들이 우리 쪽을 보는지 한 번 확인했다."

    hy "지호는 너무 이기려고만 했다."
    hy "소희는 너무 유진이랑 붙어 있으려고 했다."
    hy "대충 그런 얘기."

    if d3_pe_result == "boundary":
        hy "너는 중간에서 잘 말하긴 했어."
        hy "근데 양쪽 다 신경 쓰느라 피곤했겠다."

    elif d3_pe_result == "role_first":
        hy "네가 가운데로 간 건 이해돼."
        hy "근데 소희 표정 굳은 건 다 보이더라."

    elif d3_pe_result == "friend_first":
        hy "네가 뒤쪽으로 간 것도 이해돼."
        hy "근데 지호는 좀 답답해 보이긴 했어."

    else:
        hy "너도 좀 어색했겠다."
        hy "둘이 네 얘기를 계속 했잖아."

    "창가 쪽 친구 하나가 작게 웃었다."
    "하영이는 그 반응을 놓치지 않고 봤다."

    hide hayoung
    show h2 at center_stage as hayoung with dissolve

    hy "근데 나는 좀 보이거든."
    hy "소희가 너한테 빨리 붙고 싶어 하는 거."

    hy "그게 나쁘다는 건 아닌데,"
    hy "처음부터 거기 맞춰주면 좀 힘들 수 있어."

    "하영이는 나를 걱정하는 것처럼 말했지만,"
    "자기 말이 맞는지 확인하듯 내 얼굴을 보고 있었다."

    hy "너도 그렇게 느꼈지?"

    $ choice_question_text = "하영이에게 어떻게 답할까?"
    window hide

    menu:

        "네가 알아봐주니까 위로 된다.":
            window show
            $ add_like("hayoung", 2)
            $ add_neg("hayoung", 2)
            $ add_neg("sohee", 1)
            $ choice_log.append("D3_hayoung_3a_B_rely")

            n "네가 알아봐주니까 위로 된다."
            n "아까 둘 다 내 얘기를 하는 것 같아서 좀 당황했어."

            "하영이의 표정이 바로 부드러워졌다."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve

            hy "그럴 줄 알았어."
            hy "너 아까 표정이 딱 굳었거든."

            n "응."
            n "갑자기 둘 사이에 낀 것 같았어."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "그럼 당분간은 내가 옆에서 좀 봐줄게."

            n "그래도 소희가 이상하다는 뜻은 아니야."

            hy "알아."
            hy "네가 나쁘게 말하는 건 아닌 거 알아."

            "하영이는 그렇게 말하면서도 창가 쪽 친구들을 흘긋 봤다."

            hy "야, 유진이 아직 우리 반 분위기 잘 모르잖아."
            hy "당분간 우리가 좀 봐주자."

            ex_cr "아, 응."
            ex_cr "소희가 또 너무 붙으면 우리가 도와줄게."

            n "그런 뜻은..."
            hy "괜찮아, 괜찮아."

            "내 말이 끝나기 전에 하영이가 가볍게 웃었다."

            "하영이가 내 편을 들어주는 건 든든했다."
            "그런데 내 말이,"
            "소희를 그런 애로 딱 정해버린 것 같았다."

        "아직은 잘 모르겠어. 조금 더 봐볼래.":
            window show
            $ add_like("hayoung", 2)
            $ add_neg("hayoung", -1)
            $ choice_log.append("D3_hayoung_3a_A_careful")

            n "아직은 잘 모르겠어."
            n "오늘 일만 보고 바로 정하기는 어려워."

            hide hayoung
            show h3 at center_stage as hayoung with dissolve

            hy "아..."
            hy "그렇게 생각했어?"

            n "응."
            n "지호는 팀이 이기는 것을 우선으로 생각했고,"
            n "소희는 공을 받는걸 무서워하는 것 같았어."

            hy "너 되게 천천히 본다."

            n "아직 전학 온 지 얼마 안 됐잖아."
            n "조금 더 알아가고 싶어."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "음."
            hy "그럴 수도 있지."

            "하영이는 창가 쪽 친구들에게 가볍게 손짓했다."

            hy "얘들아."
            hy "이 얘긴 나중에 하자."

            "친구들의 속닥거림이 조금 줄어들었다."
            "하영이는 조금 머쓱해 보였지만, 내 말을 가볍게 넘기지는 않았다."

    jump d3_go_home

label d3_hayoung_3b:
    $ set_bgm(audio.bgm_hayoung_social)
    $ mark_d3_met("hayoung")
    $ d3_choice_met = "hayoung"

    scene bg_restroom_mirror with fade

    "화장실 거울 앞에서 하영이가 앞머리를 정리하고 있었다."
    "옆 창가 쪽에는 친구 두 명이 작게 이야기하고 있었다."

    show h5 at center_stage as hayoung with dissolve

    hy "어, 유진아."
    hy "애들이랑 아까 피구 얘기했어."

    n "무슨 얘기?"

    hide hayoung
    show h4 at center_stage as hayoung with dissolve

    hy "지호랑 소희 얘기."
    hy "둘 다 네 얘기를 해서 좀 어색했겠다."

    if d3_pe_result == "boundary":
        hy "그래도 너는 중간에서 잘 말한 것 같아."
        hy "한쪽으로 딱 가지는 않았잖아."

    elif d3_pe_result == "role_first":
        hy "네가 가운데로 간 건 이해돼."
        hy "근데 소희는 좀 서운했을 것 같고."

    elif d3_pe_result == "friend_first":
        hy "뒤쪽으로 간 것도 이해돼."
        hy "근데 지호는 답답했을 수도 있고."

    else:
        hy "둘 때문에 분위기 좀 어색해졌잖아."

    "하영이는 창가 쪽 친구들이 듣고 있는지 흘긋 봤다."

    hy "근데 소희가 너한테 좀 빨리 붙는 느낌은 있지 않아?"

    $ choice_question_text = "하영이에게 어떻게 답할까?"
    window hide

    menu:

        "네가 알아봐주니까 위로 된다.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", 2)
            $ add_neg("sohee", 1)
            $ choice_log.append("D3_hayoung_3b_B_rely")

            n "네가 알아봐주니까 위로 된다."
            n "아까 좀 힘들긴 했어."

            hide hayoung
            show h1 at center_stage as hayoung with dissolve

            hy "그럴 줄 알았어."
            hy "너 아까 좀 굳어 보였거든."

            n "응."
            n "좀 놀랐어."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve

            hy "얘들아, 유진이도 아까 좀 힘들었대."

            ex_cr "아, 알겠어."
            ex_cr "소희가 또 너무 붙으면 말해줘."

            n "그런 뜻은..."

            "내 말이 끝나기 전에 하영이가 가볍게 웃었다."

            hy "알아."
            hy "그냥 힘들었다는 거잖아."

            "창가 쪽 친구들은 소희 이름이 나오자 서로 눈을 마주쳤다."
            "나는 고개를 끄덕였지만,"
            "아까보다 말을 꺼내기가 더 어려워졌다."

        "아직은 잘 모르겠어. 조금 더 봐볼래.":
            window show
            $ add_like("hayoung", 2)
            $ add_neg("hayoung", -1)
            $ choice_log.append("D3_hayoung_3b_A_careful")

            n "아직은 잘 모르겠어."
            n "조금 더 봐볼래."

            hide hayoung
            show h3 at center_stage as hayoung with dissolve

            hy "흐음."

            n "오늘 일만 보고 정하면,"
            n "잘못 볼 수도 있잖아."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "뭐, 그럴 수도 있겠다."

            "하영이는 머리끈을 손목에 끼웠다."

            hy "얘들아."
            hy "이 얘기 너무 길어졌다."

            "창가 쪽 친구들은 서로 눈을 마주치고 조용해졌다."

    jump d3_go_home

label d3_hayoung_2:
    $ set_bgm(audio.bgm_hayoung_social)
    $ mark_d3_met("hayoung")
    $ d3_choice_met = "hayoung"

    scene bg_restroom_mirror with fade

    "화장실 거울 앞에서 하영이가 앞머리를 정리하고 있었다."
    "옆에는 하영이와 같이 다니는 친구 두 명이 서 있었다."

    show h5 at center_stage as hayoung with dissolve

    hy "아, 유진아."
    hy "아까 체육 시간 일로 애들이 좀 말하더라."

    n "무슨 말?"

    hide hayoung
    show h4 at center_stage as hayoung with dissolve

    hy "그냥."
    hy "지호는 너무 이기려고 하고,"
    hy "소희는 너한테 너무 빨리 붙으려고 한다고."

    "하영이는 가볍게 말했지만,"
    "내가 어떤 표정을 짓는지 보고 있었다."

    hy "너도 좀 불편했지?"

    "옆에 있던 친구들도 조용히 이쪽을 봤다."

    $ choice_question_text = "하영이에게 어떻게 답할까?"
    window hide

    menu:

        "네가 알아봐주니까 위로 된다.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", 2)
            $ add_neg("sohee", 1)
            $ choice_log.append("D3_hayoung_2_B_rely")

            n "네가 알아봐주니까 위로 된다."
            n "아까 내 얘기가 계속 나와서 좀 놀랐어."

            hide hayoung
            show h1 at center_stage as hayoung with dissolve

            hy "그치?"
            hy "나 그런 거 잘 봐."

            "하영이의 표정이 바로 밝아졌다."

            hy "처음 온 애한테 둘이 계속 그러면 당황하지."

            n "응."
            n "그냥 좀 놀랐던 거야."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve

            hy "얘들아."
            hy "유진이도 아까 좀 불편했대."

            ex_cr "아, 역시."
            ex_cr "소희가 좀 빨리 붙긴 했지."

            n "그런 뜻은..."

            "내 말은 끝까지 이어지지 못했다."
            "하영이는 이미 친구들 쪽을 보고 있었다."

            "내가 말한 건 조금 놀랐다는 것뿐인데,"
            "하영이가 말하자 소희를 조심해야 한다는 말처럼 들렸다."

        "아직은 잘 모르겠어. 조금 더 봐볼래.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", -1)
            $ choice_log.append("D3_hayoung_2_A_no_gossip")

            n "아직은 잘 모르겠어."
            n "조금 더 봐볼래."

            hide hayoung
            show h3 at center_stage as hayoung with dissolve

            hy "그래?"

            n "오늘 일만 보고 바로 정하면,"
            n "잘못 생각할 수도 있잖아."

            "하영이는 잠깐 나를 보다가 어깨를 살짝 으쓱했다."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "하긴."
            hy "전학 온 지 얼마 안 됐으니까."

            "하영이는 친구들 쪽으로 몸을 돌렸다."

            hy "얘들아, 이 얘긴 그만하자."

            "대화는 거기서 끝났다."
            "하영이는 다시 거울을 봤다."

    jump d3_go_home
# ==========================================================

# 나은 — 체육관 옆 복도

# 핵심: 쉬고 싶은데 거절하지 못함 / 괜찮다고 넘김

# 선택지 통일:

# A = 쉬고 싶다는 말을 하게 도와줌

# B = 한 판 더 하게 둠

# ==========================================================

label d3_naeun_3a:
    $ set_bgm(audio.bgm_naeun_soft)
    $ mark_d3_met("naeun")
    $ d3_choice_met = "naeun"

    scene bg_corridor_day with fade

    "체육 시간이 끝나고 아이들이 교실로 올라가기 시작했다."
    "체육관 옆 복도에는 아직 공 튀는 소리가 남아 있었다."

    "지호와 몇몇 아이들이 공을 들고 체육관 문 앞에 모여 있었다."

    show jh1 at center_stage as jiho with dissolve

    jh "야, 쉬는 시간에 한 판만 더 하자."
    jh "근데 한 명이 모자라."

    hide jiho
    show ne1 at center_stage as naeun with dissolve

    "나은이는 물병을 들고 계단 쪽으로 걸어가려다 멈췄다."
    "목덜미에는 땀이 조금 남아 있었다."

    ne "나는 이제 교실에..."

    hide naeun
    show jh5 at center_stage as jiho with dissolve

    jh "나은아, 너 잠깐만."
    jh "진짜 한 판만 들어와."
    jh "너 들어오면 팀 딱 맞을듯."

    "나은이는 바로 대답하지 못했다."

    hide jiho
    show ne2 at center_stage as naeun with dissolve

    ne "아..."
    ne "한 판만?"
    n "나은아."
    n "괜찮아?"

    hide naeun
    show ne1 at center_stage as naeun with dissolve

    ne "응."
    ne "괜찮아."

    n "진짜 괜찮아?"
    n "아까 힘들어 보였어."

    "나은이는 잠깐 입을 다물었다."
    "복도 끝에서 아이들이 다시 공을 튀기는 소리가 들렸다."

    hide naeun
    show ne2 at center_stage as naeun with dissolve
    ne "사실..."
    ne "조금 쉬고 싶어."

    "나은이는 물병을 두 손으로 잡았다."

    ne "근데 내가 있어야 인원 맞다고 하니까,"
    ne "그냥 한판만..."

    $ choice_question_text = "나은이에게 어떻게 말할까?"
    window hide

    menu:

        "한 판만 해보고, 힘들면 그때 말하자.":
            window show
            $ add_like("naeun", 2)
            $ add_neg("naeun", 2)
            $ choice_log.append("D3_naeun_3a_B_one_more")

            n "한 판만 해보고,"
            n "힘들면 그때 말하자."

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            ne "응."
            ne "그렇지?"

            "나은이의 표정이 조금 편해졌다."

            ne "한 판이면 괜찮을 거야."
            ne "애들도 기다리고 있으니까."

            hide naeun
            show jh5 at left_stage as jiho with dissolve
            show ne1 at right_stage as naeun with dissolve

            jh "나은이 들어온대?"

            ne "응."
            ne "한 판만 할게."

            hide jiho
            show jh1 at left_stage as jiho with dissolve

            jh "오케이."
            jh "그럼 바로 시작하자."

            hide jiho with dissolve
            hide naeun with dissolve

            "아이들이 다시 체육관 안으로 들어갔다."
            "나은이는 물병을 벤치 위에 올려두었다."

            n "끝나면 바로 쉬자."

            show ne2 at center_stage as naeun with dissolve

            ne "응."
            ne "고마워."

            "나은이는 고맙다고 했지만,"
            "계단 쪽을 한 번 더 바라본 뒤에야 체육관 안으로 들어갔다."

        "쉬고 싶으면 쉬어도 돼.":
            window show
            $ add_like("naeun", 2)
            $ add_neg("naeun", -1)
            $ choice_log.append("D3_naeun_3a_A_rest")

            n "쉬고 싶으면 쉬어도 돼."
            n "한 명이 모자라면 다른 친구를 찾아보면 되잖아."

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            ne "...그래도 되려나?"

            n "응."
            n "못 뛰겠다고 말하는 게 잘못은 아니니까."

            "나은이는 물병을 내려다봤다."
            "잠깐 입술을 다물었다가, 지호 쪽을 봤다."

            hide naeun
            show ne4 at left_stage as naeun with dissolve
            show jh5 at right_stage as jiho with dissolve

            ne "지호야."

            jh "어?"

            ne "미안."
            ne "나 오늘은 좀 쉬고 싶어."
            ne "다른 사람 찾아보면 안 될까?"

            "나은이의 목소리는 작았다."
            "그래도 끝까지 말했다."

            jh "아, 그래?"
            jh "그럼 민준이한테 물어볼게."

            hide jiho with dissolve

            "지호는 바로 공을 들고 다른 아이들 쪽으로 갔다."

            hide naeun
            show ne4 at center_stage as naeun with dissolve

            ne "나..."
            ne "말해도 되는 거였구나."

            n "응."
            n "같이 올라가자."

            "나은이는 물병을 양손으로 잡았다."
            "아직 어색해 보였지만, 계단 쪽으로 한 걸음 먼저 움직였다."

    jump d3_go_home

label d3_naeun_3b:
    $ set_bgm(audio.bgm_naeun_soft)
    $ mark_d3_met("naeun")
    $ d3_choice_met = "naeun"

    scene bg_corridor_day with fade

    "체육 시간이 끝난 뒤였다."
    "아이들은 땀을 닦으며 교실 쪽으로 올라가고 있었다."

    "체육관 문 앞에는 지호와 몇몇 아이들이 남아 있었다."
    "지호는 공을 팔에 끼고 주변을 둘러봤다."

    show jh5 at left_stage as jiho with dissolve

    jh "한 명만 더 있으면 딱 맞는데."
    jh "나은아, 너 한 판만 더 할래?"

    "나은이는 계단 쪽으로 가려다 멈췄다."

    show ne1 at right_stage as naeun with dissolve

    ne "나?"

    jh "응."
    jh "진짜 금방 끝나."
    jh "너 들어오면 바로 시작할 수 있어."

    "나은이는 물병을 쥔 채 작게 웃었다."

    hide naeun
    show ne2 at right_stage as naeun with dissolve

    ne "아..."
    ne "그래."

    "대답은 빨랐다."
    "하지만 발은 바로 체육관 쪽으로 움직이지 않았다."

    hide jiho with dissolve
    hide naeun with dissolve

    n "나은아."
    n "괜찮아?"

    show ne1 at center_stage as naeun with dissolve

    ne "응."
    ne "괜찮아."
    ne "한 판이면 금방 끝나니까."

    "나은이는 괜찮다고 했지만, 물병을 내려놓지는 않았다."

    $ choice_question_text = "나은이에게 어떻게 말할까?"
    window hide

    menu:

        "한 판만 해보고, 힘들면 그때 말하자.":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", 2)
            $ choice_log.append("D3_naeun_3b_B_go_along")

            n "한 판만 해보고,"
            n "힘들면 그때 말하자."

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            ne "응."
            ne "그래."
            ne "한 판이면 괜찮겠지."

            "나은이는 안심한 듯 웃었다."
            "거절하지 않아도 되는 게 편해 보였다."

            hide naeun
            show jh5 at left_stage as jiho with dissolve
            show ne2 at right_stage as naeun with dissolve

            jh "나은이 하는 거지?"

            ne "응."
            ne "한 판만."

            hide jiho
            show jh1 at left_stage as jiho with dissolve

            jh "좋아."
            jh "그럼 바로 팀 나누자."

            hide jiho with dissolve
            hide naeun with dissolve

            "지호와 아이들이 다시 체육관 안으로 들어갔다."
            "나은이는 괜찮다고 말했다."
            "하지만 교실 쪽으로 돌아가려던 나은이의 발걸음은," 
            "쉽게 체육관 쪽으로 향하지 않았다."

        "쉬고 싶으면 쉬어도 돼.":
            window show
            $ add_like("naeun", 2)
            $ add_neg("naeun", -1)
            $ choice_log.append("D3_naeun_3b_A_ask_first")

            n "잠깐만."
            n "나은아, 쉬고 싶으면 쉬어도 돼."

            hide naeun with dissolve

            "지호가 공을 멈췄다."

            show jh4 at center_stage as jiho with dissolve

            jh "어?"
            jh "나은이 쉬고 싶어?"

            hide jiho
            show ne4 at center_stage as naeun with dissolve

            "나은이는 갑자기 자기에게 시선이 모이자 어깨를 조금 움츠렸다."

            ne "아..."
            ne "조금 쉬고 싶긴 했어."

            hide naeun
            show jh3 at center_stage as jiho with dissolve

            jh "아, 그래?"
            jh "그럼 다른 애 부를게."

            "지호는 머쓱하게 웃고 다른 아이들 쪽으로 고개를 돌렸다."

            jh "야, 민준이 아직 안 올라갔나?"

            "분위기는 잠깐 어색했지만, 금방 다시 이어졌다."

            hide jiho
            show ne2 at center_stage as naeun with dissolve

            ne "미안."
            ne "내가 바로 말했어야 했는데."

            n "괜찮아."
            n "쉬고 싶으면 그렇게 말해도 돼."

            "나은이는 작게 고개를 끄덕였다."
            "물병을 쥔 손에 들어갔던 힘이 조금 풀렸다."

    jump d3_go_home

label d3_naeun_2:
    $ set_bgm(audio.bgm_naeun_soft)
    $ mark_d3_met("naeun")
    $ d3_choice_met = "naeun"

    scene bg_corridor_day with fade

    "체육 시간이 끝나고 복도가 조금 시끄러웠다."
    "아이들은 물을 마시거나 교실로 올라가고 있었다."

    "나은이는 물병을 들고 계단 쪽으로 걸어가고 있었다."
    "그때 지호가 체육관 문 앞에서 나은이를 불렀다."

    show jh5 at left_stage as jiho with dissolve
    show ne5 at right_stage as naeun with dissolve

    jh "나은아."
    jh "우리 한 판만 더 하려는데,"
    jh "너 들어오면 딱 맞아."

    "나은이는 계단 쪽을 한 번 봤다."

    hide naeun
    show ne2 at right_stage as naeun with dissolve

    ne "아..."
    ne "한 판만?"

    jh "응."
    jh "진짜 금방 끝나."

    "나은이는 바로 대답하지 못했다."
    "물병을 쥔 손만 조금 움직였다."

    $ choice_question_text = "나은이에게 어떻게 할까?"
    window hide

    menu:

        "한 판만 해보고, 힘들면 그때 말하자.":
            window show
            $ add_like("naeun", 0)
            $ add_neg("naeun", 1)
            $ choice_log.append("D3_naeun_2_B_watch")

            n "한 판만 해보고,"
            n "힘들면 그때 말하자."

            hide naeun
            show ne1 at right_stage as naeun with dissolve

            ne "응."
            ne "그럼 한 판만 할게."

            hide jiho
            show jh1 at left_stage as jiho with dissolve

            jh "오케이."
            jh "바로 시작하자."

            "지호와 아이들이 체육관 안으로 들어갔다."
            "나은이는 물병을 벤치 위에 조용히 올려두었다."

            hide naeun with dissolve
            hide jiho with dissolve

            "나은이는 웃고 있었다."
            "하지만 조금 전까지 보던 계단 쪽을 한 번 더 돌아봤다."

        "쉬고 싶으면 쉬어도 돼.":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", -1)
            $ choice_log.append("D3_naeun_2_A_check")

            n "나은아."
            n "쉬고 싶으면 쉬어도 돼."

            hide naeun
            show ne1 at right_stage as naeun with dissolve

            ne "아..."

            "나은이는 나와 지호를 번갈아 봤다."

            ne "나 사실 물 마시고 좀 쉬려고 했어."

            hide jiho
            show jh4 at left_stage as jiho with dissolve

            jh "아, 그래?"
            jh "그럼 다른 애 찾아볼게."

            "지호는 공을 들고 다른 아이들 쪽으로 갔다."

            hide jiho with dissolve
            hide naeun with dissolve

            show ne3 at center_stage as naeun with dissolve

            ne "고마워."
            ne "나 그냥 한다고 할 뻔했어."

            n "응."

            "나은이는 작게 고개를 끄덕였다."
            "그리고 물병을 들고 계단 쪽으로 걸어갔다."

    jump d3_go_home

# ==========================================================

# 서연 — 교실 앞 칠판

# 핵심: 규칙 / 원칙주의 / 융통성 부족

# 선택지 통일:

# A = 자리를 정하기 전에 괜찮은지 확인

# B = 정한 규칙을 지키는 쪽

# ==========================================================

label d3_seoyeon_3a:
    $ set_bgm(audio.bgm_seoyeon_clear)
    $ mark_d3_met("seoyeon")
    $ d3_choice_met = "seoyeon"

    scene bg_classroom_after with fade

    "체육 시간이 끝난 뒤, 교실 앞 칠판에 작은 글씨가 적혀 있었다."
    "서연이가 분필을 들고 칠판 앞에 서 있었다."

    show sy5 at center_stage as seoyeon with dissolve

    "{i}다음 피구 때 규칙{/i}"
    "{i}시작 전에 자리 정하기{/i}"

    n "서연아."
    n "뭐 적는 거야?"

    sy "아까 체육 시간 때문에."
    sy "다음에 또 비슷하게 되면, 먼저 정해두는 게 나을 것 같아서."

    n "규칙?"

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "응."
    sy "정해둔 게 없으면, 먼저 크게 말한 사람이 정하게 되잖아."

    "서연이는 분필 끝을 손가락으로 문질렀다."

    if d3_pe_result == "boundary":
        sy "첫 판이랑 다음 판을 나눈 건 괜찮았어."
        sy "근데 그때그때 바꾸면 또 말 잘하는 애가 정하게 되잖아."
        sy "처음부터 정하고, 정한 대로 하는 게 제일 공평해."

    elif d3_pe_result == "role_first":
        sy "네가 가운데를 해보겠다고 한 건 이해돼."
        sy "근데 그런 것도 미리 순서를 정해둬야 해."
        sy "그래야 하고 싶은 애든, 하기 싫은 애든 똑같이 지키지."

    elif d3_pe_result == "friend_first":
        sy "네가 뒤쪽에서 시작한 것도 이해는 해."
        sy "근데 친한 애들끼리 편한 자리만 고르면 안 되잖아."
        sy "자리는 마음대로가 아니라, 규칙대로 정해야 해."

    else:
        sy "아까는 먼저 정해둔 게 없었어."
        sy "그래서 다들 자기 말부터 한 것 같아."
        sy "그럴 때일수록 규칙이 먼저 있어야 해."

    "서연이는 다시 칠판을 봤다."

    sy "누가 싫다거나 좋다거나 하면 계속 바뀌잖아."
    sy "그러면 결국 크게 말하는 애 말대로 될 수도 있고."

    "서연이는 분필로 첫 번째 줄을 한 번 더 진하게 그었다."

    sy "처음에 정했으면 그대로 하는 게 공평해."

    n "네가 왜 이렇게 적는지는 알 것 같아."
    n "그냥 네 마음대로 하자는 게 아니라,"
    n "목소리 큰 애 말대로 되는 게 싫은 거지?"

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "응."
    sy "정해둔 게 없으면 꼭 그렇게 되니까."

    "서연이는 칠판에 적힌 글씨를 한 번 더 봤다."

    $ choice_question_text = "서연이에게 어떻게 답할까?"
    window hide

    menu:

        "근데 애들이 괜찮은지도 봐야 하지 않아?":
            window show
            $ add_like("seoyeon", 2)
            $ add_neg("seoyeon", -1)
            $ choice_log.append("D3_seoyeon_3a_A_balance")

            n "근데 애들이 괜찮은지도 봐야 하지 않아?"
            n "처음에 정한 자리가 불편해도 계속 서야 하잖아."

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve

            sy "불편해도?"

            n "응."
            n "네 말처럼 규칙이 있으면 덜 싸울 수는 있는데,"
            n "말 못 하고 그냥 그 자리에 서는 애도 있을 것 같아서."

            "서연이는 분필을 든 손을 멈췄다."

            n "정하기 전에 한 번은 괜찮은지 물어봐도 되잖아."
            n "그것도 공평하게 하려고 하는 거니까."

            sy "그것도 공평한 거라고?"

            n "응."
            n "불편한 애가 없는지 보는 것도 공평한 것 같아."

            "서연이는 칠판을 다시 봤다."

            sy "그럼 묻는 것도 규칙에 넣으면 되겠네."

            "서연이는 두 번째 줄을 작게 적었다."

            "{i}자리 정하기 전에 괜찮은지 묻기{/i}"

            hide seoyeon
            show sy4 at center_stage as seoyeon with dissolve

            sy "확인하는 것도 규칙이면,"
            sy "나쁘지 않을 것 같아."

            "서연이는 분필을 내려놓고,"
            "칠판에 적힌 규칙을 눈으로 천천히 읽었다."

        "맞아. 처음에 정한 대로 하는 게 낫겠다.":
            window show
            $ add_like("seoyeon", 2)
            $ add_neg("seoyeon", 2)
            $ choice_log.append("D3_seoyeon_3a_B_rule_first")

            n "맞아."
            n "처음에 정한 대로 하는 게 낫겠다."

            hide seoyeon
            show sy1 at center_stage as seoyeon with dissolve

            sy "그렇지?"

            "서연이의 표정이 조금 밝아졌다."

            sy "누가 이 자리가 좋다, 저 자리가 싫다 하면 계속 바뀌잖아."
            sy "그러면 결국 목소리 큰 애 말대로 될 수도 있어."

            n "정해두면 덜 헷갈리긴 하겠다."

            sy "응."
            sy "처음에 정했으면 한 판 동안은 지켜야 해."
            sy "그래야 다 똑같이 하는 거니까."

            "서연이는 칠판에 줄을 하나 더 적었다."

            "{i}정한 뒤에는 마음대로 바꾸지 않기{/i}"

            "서연이는 만족한 얼굴로 분필가루를 털었다."
            "나는 칠판의 네 번째 줄을 잠깐 더 바라봤다."

            "처음에 자리를 정하면 덜 싸울 수 있었다."
            "하지만 불편해도 말하지 못하는 친구는,"
            "그냥 정해진 자리에" 
            "계속 서야 할지도 모른다는 생각이 들었다."


    jump d3_go_home
label d3_seoyeon_3b:
    $ set_bgm(audio.bgm_seoyeon_clear)
    $ mark_d3_met("seoyeon")
    $ d3_choice_met = "seoyeon"

    scene bg_classroom_after with fade

    "교실 앞 칠판에 서연이가 서 있었다."
    "칠판 한쪽에 작은 글씨가 적혀 있었다."

    show sy5 at center_stage as seoyeon with dissolve

    "{i}다음 피구 때 규칙{/i}"
    "{i}시작 전에 자리 정하기{/i}"

    n "서연아."
    n "그거 뭐야?"

    sy "아까 같은 일이 또 생기면 안 되니까."
    sy "다음에는 먼저 정해두려고."

    n "자리를?"

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "응."
    sy "처음에 안 정하면 계속 말이 바뀌잖아."

    if d3_pe_result == "boundary":
        sy "아까 첫 판이랑 다음 판을 나눈 건 괜찮았어."
        sy "근데 매번 그렇게 바로 정리되진 않을 수도 있잖아."

    elif d3_pe_result == "role_first":
        sy "네가 가운데를 해보겠다고 한 건 이해돼."
        sy "근데 그런 것도 처음에 정해두는 게 나아."

    elif d3_pe_result == "friend_first":
        sy "네가 뒤쪽에서 시작한 건 이해하지만,"
        sy "계속 편한 자리만 고르면 또 헷갈려."

    else:
        sy "아까는 다들 자기 말부터 했어."
        sy "그래서 더 복잡해진 것 같아."

    "서연이는 칠판에 적힌 글씨를 한 번 봤다."

    sy "처음에 정했으면 그대로 하는 게 공평하다고 생각해."
    sy "그래야 누가 마음대로 바꿨다는 말도 안 나오고."

    $ choice_question_text = "서연이에게 어떻게 말할까?"
    window hide

    menu:

        "근데 애들이 괜찮은지도 봐야 하지 않아?":
            window show
            $ add_like("seoyeon", 2)
            $ add_neg("seoyeon", -1)
            $ choice_log.append("D3_seoyeon_3b_A_condition")

            n "근데 애들이 괜찮은지도 봐야 하지 않아?"
            n "처음에 정한 자리가 불편해도 계속 서야 하잖아."

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve

            sy "불편해도?"

            n "응."
            n "말 못 하고 그냥 그 자리에 서는 애도 있을 것 같아서."
            n "정하기 전에 한 번은 괜찮은지 물어봐도 되잖아."

            "서연이는 잠깐 칠판을 봤다."

            sy "그러면 시간이 조금 더 걸릴 수도 있어."

            n "오래 얘기하자는 건 아니야."
            n "시작하기 전에 한 번만 물어보자는 거지."

            "서연이는 분필을 다시 들었다."

            sy "그럼 그것도 적어두면 되겠네."
            sy "미리 정해두면 헷갈리진 않을 것 같아."

            "서연이는 아래에 작은 글씨를 덧붙였다."

            "{i}자리 정하기 전에 괜찮은지 묻기{/i}"

            "서연이는 새로 적은 줄을 한 번 더 확인했다."


        "맞아. 처음에 정한 대로 하는 게 낫겠다.":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", 2)
            $ choice_log.append("D3_seoyeon_3b_B_fixed")

            n "맞아."
            n "처음에 정한 대로 하는 게 낫겠다."

            hide seoyeon
            show sy1 at center_stage as seoyeon with dissolve

            sy "응."
            sy "그래야 덜 헷갈려."

            sy "누가 좋다 싫다 하면 계속 바뀌니까."
            sy "정했으면 한 판 동안은 지켜야 해."

            n "그럼 말이 덜 나오긴 하겠다."

            "서연이는 칠판에 새 줄을 적었다."

            "{i}정한 뒤에는 마음대로 바꾸지 않기{/i}"

            "글씨는 반듯했다."
            "하지만 불편해도 말하지 못하는 친구는,"
            "그냥 정해진 자리에 계속 서야 할 수도 있었다."

    jump d3_go_home

label d3_seoyeon_2:
    $ set_bgm(audio.bgm_seoyeon_clear)
    $ mark_d3_met("seoyeon")
    $ d3_choice_met = "seoyeon"

    scene bg_classroom_after with fade

    "교실로 돌아오자 서연이가 칠판 앞에 서 있었다."
    "칠판에는 작은 글씨가 적혀 있었다."

    "{i}다음 피구 때 규칙{/i}"
    "{i}시작 전에 자리 정하기{/i}"

    n "서연아."

    show sy5 at center_stage as seoyeon with dissolve

    sy "응?"

    n "그거 네가 쓴 거야?"

    sy "응."
    sy "아까 좀 복잡했잖아."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "처음에 정하면 덜 헷갈릴 것 같아서."

    "서연이는 다시 칠판을 봤다."

    $ choice_question_text = "서연이에게 어떻게 말할까?"
    window hide

    menu:

        "근데 애들이 괜찮은지도 봐야 하지 않아?":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", -1)
            $ choice_log.append("D3_seoyeon_2_A_add_condition")

            n "근데 애들이 괜찮은지도 봐야 하지 않아?"
            n "처음에 정한 자리가 불편해도 계속 서야 하잖아."

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve

            sy "아."

            n "정하기 전에 한 번만 물어보면 될 것 같아서."

            sy "그런가?"
            sy "그럼 그것도 적어둘게."

            "서연이는 글씨 아래에 작게 덧붙였다."

            "{i}자리 괜찮은지 묻기{/i}"

            "대화는 거기서 끊겼다."


        "맞아. 처음에 정한 대로 하는 게 낫겠다.":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", 1)
            $ choice_log.append("D3_seoyeon_2_B_agree_rule")

            n "맞아."
            n "처음에 정한 대로 하는 게 낫겠다."

            hide seoyeon
            show sy1 at center_stage as seoyeon with dissolve

            sy "응."
            sy "그래야 안 헷갈려."

            n "응."

            "서연이는 칠판에 적힌 글씨를 다시 확인했다."
            "더 할 말은 잘 떠오르지 않았다."

    jump d3_go_home
# ----------------------------------------------------------
# D3 하교 + 일기
# ----------------------------------------------------------

label d3_go_home:
    $ set_bgm(audio.bgm_evening)

    scene bg_corridor_day
    with slow_fade

    if d3_pe_result == "boundary":
        "수요일 하루가 끝났다."
        "체육 시간에 내가 꺼낸 말이 계속 떠올랐다."

    elif d3_pe_result == "role_first":
        "수요일 하루가 끝났다."
        "경기는 잘 지나갔지만, 뒤쪽에 있던 소희 얼굴이 생각났다."

    elif d3_pe_result == "friend_first":
        "수요일 하루가 끝났다."
        "소희는 좋아했지만, 지호가 돌아서던 모습도 마음에 남았다."

    else:
        "수요일 하루가 끝났다."
        "체육 시간에 있었던 말들이 조금 남아 있었다."
    
    scene bg_room_evening
    with slow_fade

    "오후 수업과 청소까지 끝나고 집에 돌아왔다."
    "방 안은 조용했다."

    "가방을 내려놓자, 오늘 있었던 일이 다시 떠올랐다."
    "나는 책상 앞에 앉아 일기장을 펼쳤다."

    jump d3_diary
    
label d3_diary:
    scene bg_diary with fade
    window hide

    $ _focus = d3_choice_met if d3_choice_met != "none" else "sohee"
    $ _focus_name = display_name(_focus)
    $ _focus_like = like_of(_focus)
    $ _focus_neg = neg_of(_focus)

    $ diary_text1 = ""
    $ diary_text1 += "오늘 체육 시간에 '협동 부활 피구'를 했다.\n"
    $ diary_text1 += "처음엔 그냥 공만 피하면 되는 줄 알았다.\n"
    $ diary_text1 += "근데 어디에 설지 정하는 게 더 어려웠다.\n\n"

    if d3_pe_result == "boundary":
        $ diary_text1 += "지호와 소희가 모두 내 위치를 정해주고 싶어했다.\n"
        $ diary_text1 += "그래서 나는 첫 판은 뒤쪽, 다음 판은 가운데로 해본다고 말했다.\n"
        $ diary_text1 += "처음부터 한쪽으로 정하지 않으니 조금 덜 막막했다.\n\n"

    elif d3_pe_result == "role_first":
        $ diary_text1 += "나는 지호 말대로 가운데를 해보고 싶다고 말했다.\n"
        $ diary_text1 += "가운데 서니 공이 어디로 오는지는 잘 보였다.\n"
        $ diary_text1 += "하지만 뒤쪽에 있던 소희 얼굴이 한 번씩 생각났다.\n\n"

    elif d3_pe_result == "friend_first":
        $ diary_text1 += "나는 소희와 같이 뒤쪽에 서기로 했다.\n"
        $ diary_text1 += "나와 함께 뒤쪽에 서니 소희가 덜 긴장한 것 같았다.\n"
        $ diary_text1 += "하지만 지호는 가운데가 빈다며 답답해 했다.\n\n"

    else:
        $ diary_text1 += "자리를 정하는 동안 친구들 표정이 계속 바뀌었다.\n\n"


    if d3_choice_met == "jiho":
        $ diary_text1 += "방과 후에는 지호와 체육시간 이야기를 했다.\n"

        if "D3_jiho_3a_A_point" in choice_log or "D3_jiho_3b_A_balance" in choice_log or "D3_jiho_2_A_nudge" in choice_log:
            $ diary_text1 += "나는 소희도 속상했을 것 같다고 말했다.\n"
            $ diary_text1 += "지호는 처음엔 몰랐다는 얼굴이었다.\n"

        elif "D3_jiho_3a_B_cover" in choice_log or "D3_jiho_3b_B_role_agree" in choice_log or "D3_jiho_2_B_light" in choice_log:
            $ diary_text1 += "지호는 소희와 다툰 걸 신경 쓰는 것 같았다.\n"
            $ diary_text1 += "하지만 내가 지호 생각이 맞다고 하니 금방 괜찮아 보였다.\n"

        else:
            $ diary_text1 += "지호는 팀을 위해 말한 거라고 했다.\n"
            $ diary_text1 += "지호 말도 맞지만, 듣는 친구는 다르게 느꼈을 수도 있지 않을까?\n"


    elif d3_choice_met == "hayoung":
        $ diary_text1 += "방과 후에는 하영이와 체육시간 이야기를 했다.\n"

        if "D3_hayoung_3a_A_careful" in choice_log or "D3_hayoung_3b_A_careful" in choice_log or "D3_hayoung_2_A_no_gossip" in choice_log:
            $ diary_text1 += "하영이는 지호와 소희가 불편하지 않았냐고 물었다.\n"
            $ diary_text1 += "나는 아직 잘 모르겠다고 했다.\n"
            $ diary_text1 += "오늘 하루만 보고 지호와 소희가 어떤 앤지 정하면 안 될 것 같았다.\n"

        elif "D3_hayoung_3a_B_rely" in choice_log or "D3_hayoung_3b_B_rely" in choice_log or "D3_hayoung_2_B_rely" in choice_log:
            $ diary_text1 += "하영이는 내가 지호와 소희 사이에서 힘들었겠다고 위로해 주었다.\n"
            $ diary_text1 += "고마웠지만, 어쩐지 내 대답은 하영이 친구들한테 다르게 전해진 것 같았다.\n"

        else:
            $ diary_text1 += "하영이는 누가 어떤 말을 했는지 잘 보고 있었다.\n"
            $ diary_text1 += "하영이한테 말할 땐 다르게 전달되지 않도록 조심해야겠다.\n"


    elif d3_choice_met == "naeun":
        $ diary_text1 += "체육시간이 끝난 후 쉬고 싶어하는 나은이가 보였다.\n"

        if "D3_naeun_3a_A_rest" in choice_log or "D3_naeun_3b_A_ask_first" in choice_log or "D3_naeun_2_A_check" in choice_log:
            $ diary_text1 += "그런데 지호가 쉬는 시간에 한 번 더 게임을 하자고 했다.\n"
            $ diary_text1 += "나는 나은이에게 솔직하게 말하라고 했고,\n"
            $ diary_text1 += "나은이는 자기 상태를 말하고 쉴 수 있었다.\n"

        elif "D3_naeun_3a_B_one_more" in choice_log or "D3_naeun_3b_B_go_along" in choice_log or "D3_naeun_2_B_watch" in choice_log:
            $ diary_text1 += "그런데 지호가 쉬는 시간에 한 번 더 게임을 하자고 했다.\n"
            $ diary_text1 += "나은이가 어쩔 줄 몰라 해서, 그냥 한 판만 더 하자고 했다.\n"
            $ diary_text1 += "나은이는 알겠다고 했지만, 진짜 괜찮았는지는 잘 모르겠다.\n"

        else:
            $ diary_text1 += "나은이는 괜찮다고 했다.\n"
            $ diary_text1 += "그런데 물병을 꼭 쥔 손이 자꾸 보였다.\n"


    elif d3_choice_met == "sohee":
        $ diary_text1 += "방과 후에는 소희와 체육시간 이야기를 했다.\n"

        if "D3_sohee_3a_A_boundary" in choice_log or "D3_sohee_3b_A_boundary" in choice_log or "D3_sohee_2_A_later" in choice_log:
            $ diary_text1 += "소희는 자기 때문에 불편하지 않았냐고 걱정했다.\n"
            $ diary_text1 += "나는 다음엔 내 의견부터 물어봐달라고 했다.\n"
            $ diary_text1 += "소희는 조금 서운해 보였지만, 내 말을 듣고 고개를 끄덕였다.\n"

        elif "D3_sohee_3a_B_reassure" in choice_log or "D3_sohee_3b_B_promise" in choice_log or "D3_sohee_2_B_promise" in choice_log:
            $ diary_text1 += "소희는 자기 때문에 불편하지 않았냐고 걱정했다.\n"
            $ diary_text1 += "나는 같이 해줘서 고마웠다고 대답했다.\n"
            $ diary_text1 += "소희는 많이 기뻐했고, 다음에도 나와 함께할 거라 믿는 것 같았다.\n"
        else:
            $ diary_text1 += "소희는 내가 자기 말을 괜찮다고 해주길 기다리는 것 같았다.\n"
            $ diary_text1 += "고마운 마음과 부담스러운 마음이 같이 있었다.\n"


    elif d3_choice_met == "seoyeon":
        $ diary_text1 += "방과 후에는 서연이와 체육 시간 이야기를 했다.\n"

        if "D3_seoyeon_3a_A_balance" in choice_log or "D3_seoyeon_3b_A_condition" in choice_log or "D3_seoyeon_2_A_add_condition" in choice_log:
            $ diary_text1 += "서연이는 처음부터 자리를 정했어야 한다며 규칙을 적었다.\n"
            $ diary_text1 += "나는 정해진 자리가 괜찮은지 한 번은 물어보자고 했다.\n"
            $ diary_text1 += "서연이는 잠깐 생각하다가 규칙을 고쳐 주었다.\n"

        elif "D3_seoyeon_3a_B_rule_first" in choice_log or "D3_seoyeon_3b_B_fixed" in choice_log or "D3_seoyeon_2_B_agree_rule" in choice_log:
            $ diary_text1 += "서연이는 처음부터 자리를 정했어야 한다며 규칙을 적었다.\n"
            $ diary_text1 += "나는 서연이 말대로 규칙이 있어야 했다고 대답했다.\n"
            $ diary_text1 += "그런데 불편해도 말 못 하는 애가 있을 수도 있겠다는 생각이 들었다.\n"

        else:
            $ diary_text1 += "서연이는 틀리지 않게 정리하려고 했다.\n"
            $ diary_text1 += "하지만 자리를 정하는 말에도 누군가의 마음이 들어 있었다.\n"


    else:
        $ diary_text1 += "방과 후에는 따로 한 친구를 만나지 않았다.\n"
        $ diary_text1 += "그래도 체육 시간의 일들이 계속 떠올랐다.\n"

    call screen diary_page(title="수요일 일기", content=diary_text1, body_yoffset=20)

    $ renpy.movie_cutscene("videos/diary.webm", stop_music=False)


    $ diary_text3 = ""
    $ diary_text3 += relation_status_text(_focus_like, _focus_neg) + "\n"

    if _focus_neg >= 4:
        $ diary_text3 += "같이 있으면 좋을 때도 있지만, 오늘은 조금 걸리는 말이 있었다.\n"
        $ diary_text3 += "다음에는 불편하면 짧게라도 말해보기.\n"

    elif _focus_like >= 5 and _focus_neg <= 2:
        $ diary_text3 += "오늘은 이 친구랑 조금 더 편해진 것 같다.\n"
        $ diary_text3 += "그래도 너무 빨리 단짝처럼 정하지는 말기.\n"

    elif _focus_like >= 4 and _focus_neg >= 3:
        $ diary_text3 += "좋은 일도 있었고, 조금 불편한 일도 있었다.\n"
        $ diary_text3 += "친구가 원하는 것만 보지 말고, 내가 괜찮은지도 보기.\n"

    else:
        $ diary_text3 += "아직은 잘 모르겠다.\n"
        $ diary_text3 += "말보다 다음에 어떻게 하는지 더 봐야겠다.\n"

    if burnout >= 4:
        $ diary_text3 += "\n나의 상태: 오늘은 마음을 많이 써서 지쳤다.\n"
    elif burnout >= 3:
        $ diary_text3 += "\n나의 상태: 조금 피곤했지만, 오늘 일은 그냥 넘기기 어려웠다.\n"
    else:
        $ diary_text3 += "\n나의 상태: 오늘은 많이 힘들지는 않았지만,\n"
        $ diary_text3 += "나눴던 대화들이 오래 기억에 남았다.\n"

    show screen diary_focus_badge(_focus)
    call screen diary_page(title="수요일 관계 메모", content=diary_text3, body_yoffset=145)
    hide screen diary_focus_badge
    
    scene bg_room_evening
    with slow_fade

    window show

    "일기장을 덮었다."
    "방 안이 조용해지니 오늘 했던 말들이 다시 생각났다."

    jump d4_start

# ==========================================================
# D4 목요일
# - 오전: 전체 갈등 ② 2부
# - 오후: 선택 1:1 1회
# - D3 모둠활동 책임 분배 갈등의 심화/해결 시도
# - D4 오전의 선택이 D5 절친 이벤트 분위기에 영향을 준다.
# ==========================================================

# ----------------------------------------------------------
# D4용 변수
# ----------------------------------------------------------
default d4_choice = "none"
default d4_conflict_result = "none"
default d4_choice_met = "none"
default d4_people_met = []
default group_conflict_score = 0


init python:
    def mark_d4_met(name):
        global d4_people_met
        if name not in d4_people_met:
            d4_people_met.append(name)
        mark_met(name)

    def d4_route_level(name):
        like = like_of(name)
        neg = neg_of(name)

        if like >= 6 and neg <= 3:
            return "4a"
        elif like >= 3 or neg >= 2:
            return "4b"
        else:
            return "2"
# ----------------------------------------------------------
# D4 — 다섯 명이 차례로 들어오는 아침
# ----------------------------------------------------------

label d4_start:
    $ day = 4
    jump d4_morning_arrivals


label d4_morning_arrivals:
    scene black
    with day_fade
    $ set_bgm(audio.bgm_classroom_light)

    centered "목요일"
    pause 0.5

    scene bg_classroom_evening with fade

    "교실은 아직 조용했다."
    "나는 가방을 내려놓고 자리에 앉았다."

    show sy5 at center_stage as seoyeon with dissolve
    sy "왔어, 유진."
    sy "오늘 모둠 활동 준비물 확인해."
    n "응. 알림장 보고 챙겨볼게."
    hide seoyeon

    show ne5 at center_stage as naeun with dissolve
    ne "유진아... 안녕."
    ne "창문 조금 닫아도 돼?"
    n "응. 나도 조금 추웠어."
    hide naeun

    show jh5 at center_stage as jiho with dissolve
    jh "오, 유진! 오늘도 살아서 등교했네."
    n "그게 인사야?"
    hide jiho

    show h5 at center_stage as hayoung with dissolve
    hy "유진, 굿모닝."
    hide hayoung

    show sh1 at center_stage as sohee with dissolve
    sh "유진아, 안녕!"
    sh "오늘 같은 모둠 되면 좋겠다."
    n "응. 되면 같이 잘해보자."
    hide sohee

    scene bg_classroom_day with dissolve
    show t1 at center_stage as teacher with dissolve

    "선생님이 교실로 들어오셨다."

    t "오늘은 모둠 포스터를 만들 거예요."
    t "주제는 '친구를 존중하는 우리 반 약속'입니다."

    hide teacher
    show t2 at center_stage as teacher with dissolve

    t "조건도 있어요."
    t "약속 문구, 실천 방법 세 가지, 그림이나 색 표현이 들어가야 해요."

    hide teacher
    show t3 at center_stage as teacher with dissolve

    t "그리고 한 사람이 다 정하거나,"
    t "한 사람에게 일을 몰아주지 않도록 해요."

    t "모둠별로 책상을 붙이고 시작하세요."

    jump d4_morning_group_conflict_part2

# ----------------------------------------------------------
# D4 — 모둠 포스터 갈등
# ----------------------------------------------------------

label d4_morning_group_conflict_part2:

    hide teacher with dissolve

    "책상 네 개를 붙였다."
    "나와 서연이, 하영이, 나은이까지 같은 모둠이었다."
    "서연이가 자와 필기구를 꺼냈다."

    show sy5 at center_stage as seoyeon with dissolve
    sy "일단 조건부터 확인하자."

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve
    sy "문구. 실천 방법 세 가지. 그림과 색."
    sy "제목은 위, 그림은 가운데, 방법은 아래."

    n "벌써 정한 거야?"

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve
    sy "시간이 없잖아."

    hide seoyeon
    show h5 at center_stage as hayoung with dissolve
    hy "그렇게 하면 안내문 같아."
    hy "포스터면 딱 봤을 때 보여야지."

    n "하영이는 어떻게 하고 싶은데?"

    hy "문구는 크게."
    hy "그림은 답답하지 않게."
    hy "색도 좀 맞추고."

    hide hayoung
    show sy2 at left_stage as seoyeon with dissolve
    show h5 at right_stage as hayoung with dissolve

    sy "그럼 실천 방법은 어디에 넣어?"

    hy "작게 넣으면 되지."

    hide seoyeon
    show sy3 at left_stage as seoyeon with dissolve
    sy "작으면 안 읽혀."

    hide hayoung
    show h2 at right_stage as hayoung with dissolve
    hy "너는 조건만 보잖아."

    "나은이가 종이를 꺼냈다."

    show ne5 at center_stage as naeun with dissolve
    ne "저기... 스케치 조금 해봤는데."

    "나은이는 종이를 책상 가운데에 밀었다."

    hide seoyeon
    show sy5 at left_stage as seoyeon with dissolve
    sy "그림이 커서 조건이 가려질 것 같은데..."

    hide hayoung
    show h5 at right_stage as hayoung with dissolve
    hy "에이, 너무 흔해서 포스터가 안살겠어."

    hide naeun
    show ne2 at center_stage as naeun with dissolve
    ne "그럼... 다시 스케치 해볼게."

    n "다시?"

    "나은이는 지우개를 들었다."

    hide seoyeon
    show sy2 at left_stage as seoyeon with dissolve
    sy "잠깐만. 지금 다시 그리면 늦어."
    sy "나은이는 그림. 하영이는 색. 유진이는 문구. 나는 실천 방법."

    hide hayoung
    show h2 at right_stage as hayoung with dissolve
    hy "왜 네가 다 정해?"

    hide seoyeon
    show sy3 at left_stage as seoyeon with dissolve
    sy "그럼 너는 뭘 할 건데?"

    hy "전체 모양을 맞추는 거."

    sy "그건 맡은 일이 아니잖아."

    hide naeun
    show ne2 at center_stage as naeun with dissolve
    ne "나는... 다 괜찮으니까 정해주면 맞춰서 그릴게."

    hide seoyeon
    show sy2 at left_stage as seoyeon with dissolve
    sy "그렇게 말하면 더 못 정해."

    hide hayoung
    show h3 at right_stage as hayoung with dissolve
    hy "그렇게 말하면 우리가 네 생각을 모르잖아."

    hide naeun
    show ne1 at center_stage as naeun with dissolve
    ne "미안..."

    "나은이는 지우개를 내려놓지 못했다."
    "하영이는 팔짱을 꼈다."
    "서연이는 조건이 적힌 종이를 잡고 있었다."

    hide naeun with dissolve
    hide hayoung with dissolve
    hide seoyeon with dissolve

    show t1 at center_stage as teacher with dissolve

    t "3모둠, 아직 역할 정리가 안됐나요?"
    t "그러면 문구, 그림, 실천 방법, 색칠 중," 
    t "우선순위부터 정해보세요."

    hide teacher with dissolve

    "세 사람이 나를 봤다."

    $ choice_question_text = "나는 이 상황을 어떻게 정리해야 할까?"
    window hide
    
    menu:

        "조건부터 맞추고, 그림은 가운데에 넣자.":
            window show
            $ d4_choice = "rule_seoyeon"
            $ d4_conflict_result = "neutral"
            $ add_like("seoyeon", 2)
            $ add_neg("hayoung", 1)
            $ add_neg("naeun", 1)
            $ choice_log.append("D4_group_rule_seoyeon")
            jump d4_match_rule

        "눈에 잘 보이게 만들자. 조건도 빠뜨리지 말자.":
            window show
            $ d4_choice = "trend_hayoung"
            $ d4_conflict_result = "neutral"
            $ add_like("hayoung", 2)
            $ add_neg("seoyeon", 1)
            $ add_neg("naeun", 1)
            $ choice_log.append("D4_group_trend_hayoung")
            jump d4_match_trend

        "늦어도 각자 할 수 있는 만큼 다시 나누자.":
            window show
            $ d4_choice = "share_work"
            $ d4_conflict_result = "good"
            $ add_like("naeun", 2)
            $ add_like("seoyeon", 1)
            $ add_like("hayoung", 1)
            $ add_neg("naeun", -1)
            $ choice_log.append("D4_group_share_work")
            jump d4_match_naeun


# ----------------------------------------------------------
# D4 선택지 결과 1 — 서연 기준 우선
# ----------------------------------------------------------

label d4_match_rule:
    $ d4_choice = "rule_seoyeon"
    $ d4_conflict_result = "neutral"

    scene bg_classroom_day with dissolve
    $ set_bgm(audio.bgm_classroom_light2)

    n "조건부터 맞추자."
    n "서연이가 칸을 나누고, 그림은 가운데에 넣자."

    show sy5 at left_stage as seoyeon with dissolve
    sy "응. 빠지는 게 없어야 해."
    sy "제목 위. 그림 가운데. 실천 방법 아래."

    show h2 at right_stage as hayoung with dissolve
    hy "아니... 그럼 너무 네모네모하잖아."
    hy "포스터는 딱 봤을 때 보여야 하는데."

    n "그러니까 색은 하영이가 봐주면 좋을 것 같아."
    n "너무 딱딱해 보이지 않게."

    hy "치, 색만 잘 고르면 뭐하냐구."

    "하영이는 툴툴거리며 사인펜 몇 개를 집어 들었다."

    hide hayoung
    show h5 at right_stage as hayoung with dissolve
    hy "일단 제목 색은 초록색으로 하자."
    hy "파란색만 쓰면 너무 차가워 보이잖아."

    show ne4 at center_stage as naeun with dissolve
    ne "어... 그러면 내 스케치는 어떻게 할까."

    hide seoyeon
    show sy2 at left_stage as seoyeon with dissolve
    sy "조건을 크게 써야 하니까."
    sy "작게 그려줄 수 있어?"

    hide naeun
    show ne2 at center_stage as naeun with dissolve
    ne "알겠어."
    ne "처음보다 줄일게."

    "서연이는 자로 칸을 나눴다."
    "하영이는 제목 색을 골랐다."
    "나은이는 처음 스케치를 접어두고, 더 작은 그림을 다시 그렸다."

    "빠르게 정리되긴 했다."
    "하지만 나은이 그림은 처음보다 많이 작아졌다."

    jump d4_group_work_finish


# ----------------------------------------------------------
# D4 선택지 결과 2 — 하영 감각 우선
# ----------------------------------------------------------

label d4_match_trend:
    $ d4_choice = "trend_hayoung"
    $ d4_conflict_result = "neutral"

    scene bg_classroom_day with dissolve
    $ set_bgm(audio.bgm_classroom_light2)

    n "먼저 눈에 잘 보이게 만들자."
    n "대신 조건은 빠뜨리지 말고."

    show h1 at right_stage as hayoung with dissolve
    hy "좋아."
    hy "문구는 크게, 그림은 주변에 작게."
    hy "색은 밝게 가자."

    show sy2 at left_stage as seoyeon with dissolve
    sy "실천 방법 세 가지는 다 들어가야 해."

    hide hayoung
    show h5 at right_stage as hayoung with dissolve
    hy "안 빠뜨려."
    hy "근데 길게 쓰면 아무도 안 읽어."

    n "서연이는 문장을 짧게 정리해줘."
    n "하영이는 배치랑 색을 봐줘."

    hide seoyeon
    show sy5 at left_stage as seoyeon with dissolve
    sy "한번 줄여볼게."
    sy "우선 아래쪽 공간은 남겨둬."

    show ne4 at center_stage as naeun with dissolve
    ne "나는 그림을 작게 나눠서 그리면 돼?"

    hy "응."
    hy "네 그림 좋은데, 좀 흔하지 않은거로 작게 그려봐."

    hide naeun
    show ne2 at center_stage as naeun with dissolve
    ne "응...알겠어."

    "나은이는 처음에 보여준 스케치를 조용히 덮었다."

    hide hayoung
    show h4 at right_stage as hayoung with dissolve
    hy "노란색 넣자."
    hy "이래야 멀리서도 보여."

    hide seoyeon
    show sy2 at left_stage as seoyeon with dissolve
    sy "그 선 아래는 비워줘."

    hide hayoung
    show h5 at right_stage as hayoung with dissolve
    hy "아, 알았어."
    hy "거기는 안 건드릴게."

    "하영이는 제목 둘레에 색선을 그었다."
    "서연이는 아래쪽 빈칸을 자로 재었다."
    "나은이는 그림을 한 번 더 작게 줄였다."

    "포스터는 전보다 눈에 잘 들어왔다."
    "하지만 나은이의 처음 그림은 거의 남지 않았다."

    jump d4_group_work_finish


# ----------------------------------------------------------
# D4 선택지 결과 3 — 역할 다시 나누기
# ----------------------------------------------------------

label d4_match_naeun:
    $ d4_choice = "share_work"
    $ d4_conflict_result = "good"

    scene bg_classroom_day with dissolve
    $ set_bgm(audio.bgm_classroom_light2)

    n "조금 늦어져도 괜찮아."
    n "먼저 자기가 할 수 있는 걸 말해보자."

    show ne4 at center_stage as naeun with dissolve
    ne "나는 큰 그림 하나 정도..."
    ne "작은 장식까지 새로 그리면 오래 걸릴 것 같아."

    show sy5 at left_stage as seoyeon with dissolve
    sy "그럼 나는 실천 방법 세 가지 쓸게."

    show h5 at right_stage as hayoung with dissolve
    hy "치, 나는 제목이랑 색 볼게."

    hide naeun
    show ne2 at center_stage as naeun with dissolve
    ne "그럼 얘들아,"
    ne "혹시 처음 보여준 그림을 써도 될까?"

    hide hayoung
    show h4 at right_stage as hayoung with dissolve
    hy "음."
    hy "제목이랑 안 겹치게만 하면 괜찮아."

    hide seoyeon
    show sy5 at left_stage as seoyeon with dissolve
    sy "아래쪽은 남겨줘."
    sy "실천 방법 써야 하니까."

    hide naeun
    show ne5 at center_stage as naeun with dissolve
    ne "응."

    "나은이는 지우개를 내려놓았다."
    "서연이는 공책에 맡은 일을 적었다."
    "하영이는 제목이 들어갈 자리를 손가락으로 짚었다."

    "조금 늦어졌지만,"
    "이번에는 나은이 그림이 사라지지 않았다."

    jump d4_group_work_finish


# ----------------------------------------------------------
# D4 모둠 활동 마무리
# ----------------------------------------------------------

label d4_group_work_finish:
    $ set_bgm(audio.bgm_classroom_light2)

    if d4_choice == "none":
        $ d4_choice = "rule_seoyeon"

    scene bg_classroom_day with dissolve

    "미술 시간이 끝날 때쯤, 포스터가 완성됐다."

    if d4_choice == "rule_seoyeon":
        "도화지에는 칸이 반듯하게 나뉘어 있었다."
        "실천 방법 세 가지가 아래쪽에 가지런히 적혀 있었다."
        "나은이의 그림은 가운데에 작게 들어가 있었다."

    elif d4_choice == "trend_hayoung":
        "제목은 크게 보여서 멀리서도 눈에 들어왔다."
        "서연이는 아래쪽 실천 방법을 손가락으로 따라 읽었다."
        "나은이는 작게 그린 얼굴 옆에 색연필을 내려놓았다."

    elif d4_choice == "protect_naeun" or d4_choice == "share_work":
        "가운데에는 나은이의 동그란 그림이 남아 있었다."
        "서연이는 실천 방법 세 가지를 붙였다."
        "하영이는 제목 옆에 색을 더했다."

    show t3 at center_stage as teacher with dissolve

    t "3모둠, 이제 방향이 잡혔네요."
    t "마무리까지 각자 맡은 일을 끝내면 되겠어요."

    hide teacher with dissolve

    jump d4_after_activity


# ----------------------------------------------------------
# D4 — 활동 후 쉬는 시간
# ----------------------------------------------------------

label d4_after_activity:
    scene bg_classroom_after with fade

    "미술 시간이 끝날 무렵."

    if d4_choice == "rule_seoyeon":
        "하영이는 남은 사인펜을 정리했다."
        "나은이는 접어둔 스케치 종이를 가방에 넣었다."

    elif d4_choice == "trend_hayoung":
        "서연이는 아래쪽 문장을 다시 읽었다."
        "나은이는 작게 그린 얼굴 옆의 지우개 가루를 털었다."

    elif d4_choice == "share_work" or d4_choice == "protect_naeun":
        "서연이는 시계를 한 번 봤다."
        "하영이는 제목 색을 한 번 덧칠했다."
        "나은이는 가운데 그림을 조심스럽게 바라봤다."

    else:
        "드디어 포스터가 완성됐다."

    "그리고 쉬는 시간이 되었다."
    "나는 교실을 한 번 둘러봤다."
    "아까 일 때문인지, 몇몇 친구들 표정이 자꾸 보였다."
    "쉬는 시간이 끝나기 전에 한 명이랑은 이야기해볼 수 있을 것 같았다."


    jump d4_afternoon_pick


label d4_afternoon_pick:
    scene bg_classroom_after with fade

    $ choice_question_text = "쉬는 시간이 끝나기 전, 누구에게 가볼까?"
    window hide

    menu:

        "{color=#7DB8FF}지호{/color}에게 간다":
            window show
            jump d4_preview_jiho

        "{color=#FF9ACD}하영{/color}에게 간다":
            window show
            jump d4_preview_hayoung

        "{color=#BFA7FF}나은{/color}에게 간다":
            window show
            jump d4_preview_naeun

        "{color=#FFCF6E}소희{/color}에게 간다":
            window show
            jump d4_preview_sohee

        "{color=#9FE0C5}서연{/color}에게 간다":
            window show
            jump d4_preview_seoyeon

        "오늘은 바로 집에 간다.":
            window show
            $ d4_choice_met = "none"
            $ choice_log.append("D4_afternoon_none")
            jump d4_go_home

# ----------------------------------------------------------
# D4 오후 — 지호 미리보기
# ----------------------------------------------------------

label d4_preview_jiho:
    scene bg_playground_day with fade

    show jh6 at center_stage with dissolve
    "운동장에서 농구공 튀기는 소리가 들렸다."
    "지호는 공을 세게 튀기고 있었다."

    $ choice_question_text = "지호에게 가볼까?"
    window hide

    menu:

        "지호에게 가본다.":
            window show
            $ d4_choice_met = "jiho"
            $ mark_d4_met("jiho")
            if d4_route_level("jiho") == "4a":
                jump d4_jiho_4a
            elif d4_route_level("jiho") == "4b":
                jump d4_jiho_4b
            else:
                jump d4_jiho_2

        "다른 친구를 찾아본다.":
            window show
            jump d4_afternoon_pick


# ----------------------------------------------------------
# D4 오후 — 하영 미리보기
# ----------------------------------------------------------

label d4_preview_hayoung:
    scene bg_board3 with fade
    show h2 at center_stage with dissolve
    "하영이는 우리 모둠 포스터 앞에 서 있었다."

    $ choice_question_text = "하영에게 가볼까?"
    window hide

    menu:

        "하영에게 가본다.":
            window show
            $ d4_choice_met = "hayoung"
            $ mark_d4_met("hayoung")
            if d4_route_level("hayoung") == "4a":
                jump d4_hayoung_4a
            elif d4_route_level("hayoung") == "4b":
                jump d4_hayoung_4b
            else:
                jump d4_hayoung_2

        "다른 친구를 찾아본다.":
            window show
            jump d4_afternoon_pick


# ----------------------------------------------------------
# D4 오후 — 나은 미리보기
# ----------------------------------------------------------

label d4_preview_naeun:
    scene bg_classroom_after with fade
    show ne2 at center_stage with dissolve

    "나은이는 어질러진 모둠 책상 앞에 서 있었다."

    $ choice_question_text = "나은에게 가볼까?"
    window hide

    menu:

        "나은에게 가본다.":
            window show
            $ d4_choice_met = "naeun"
            $ mark_d4_met("naeun")
            if d4_route_level("naeun") == "4a":
                jump d4_naeun_4a
            elif d4_route_level("naeun") == "4b":
                jump d4_naeun_4b
            else:
                jump d4_naeun_2

        "다른 친구를 찾아본다.":
            window show
            jump d4_afternoon_pick


# ----------------------------------------------------------
# D4 오후 — 소희 미리보기
# ----------------------------------------------------------

label d4_preview_sohee:
    scene bg_board3 with fade
    show sh5 at center_stage with dissolve
    "소희는 자기 모둠 포스터 앞에 서 있었다."
    "나를 보더니 손을 들려다가 내렸다."

    $ choice_question_text = "소희에게 가볼까?"
    window hide

    menu:

        "소희에게 가본다.":
            window show
            $ d4_choice_met = "sohee"
            $ mark_d4_met("sohee")
            if d4_route_level("sohee") == "4a":
                jump d4_sohee_4a
            elif d4_route_level("sohee") == "4b":
                jump d4_sohee_4b
            else:
                jump d4_sohee_2

        "다른 친구를 찾아본다.":
            window show
            jump d4_afternoon_pick


# ----------------------------------------------------------
# D4 오후 — 서연 미리보기
# ----------------------------------------------------------

label d4_preview_seoyeon:
    scene bg_board3 with fade

    show sy2 at center_stage as seoyeon with dissolve
    "교실 뒤편에 서연이가 남아 있었다."
    "서연이는 마카펜을 든 채 포스터 아래쪽 이름을 확인하고 있었다."
    show sy2 at center_stage with dissolve
    $ choice_question_text = "서연에게 가볼까?"
    window hide

    menu:

        "서연에게 가본다.":
            window show
            $ d4_choice_met = "seoyeon"
            $ mark_d4_met("seoyeon")
            if d4_route_level("seoyeon") == "4a":
                jump d4_seoyeon_4a
            elif d4_route_level("seoyeon") == "4b":
                jump d4_seoyeon_4b
            else:
                jump d4_seoyeon_2

        "다른 친구를 찾아본다.":
            window show
            jump d4_afternoon_pick

label d4_jiho_4a:
    $ set_bgm(audio.bgm_jiho_active)
    $ mark_d4_met("jiho")
    $ d4_choice_met = "jiho"

    scene bg_playground_day with fade

    "운동장 농구대 쪽에서 공 튀는 소리가 크게 났다."
    "지호는 공을 두 손으로 잡았다가 다시 바닥에 내리쳤다."
    "농구대 옆에는 지호와 같은 모둠이었던 민준이가 서 있었다."

    ex_mj "아, 됐어."
    ex_mj "말을 왜 그렇게 해."

    "민준이는 팔을 문지르며 다른 애들 쪽으로 가버렸다."
    "지호는 못 들은 척 공을 한 번 더 세게 튀겼다."

    n "지호야."

    show jh6 at center_stage as jiho with dissolve

    jh "뭐."

    n "민준이랑 무슨 일 있었어?"

    jh "...아까 쟤랑 모둠 할 때부터 계속 안 맞았어."
    jh "뭘 하자고 하면 별로라 하고,"
    jh "바꾸자고 하면 늦는다고 하고."

    "지호는 공을 팔에 끼고 민준이가 간 쪽을 봤다."

    jh "농구할 때도 먼저 부딪힌 건 쟤인데,"
    jh "마지막엔 나만 말 심한 애처럼 됐잖아."

    jh "내가 목소리 크면 무조건 나만 잘못한 거야?"
    jh "너도 그렇게 말할 거면 그냥 말하지 마."

    "지호는 나를 보고 있었지만,"
    "방금 민준이한테 하던 말을 아직 멈추지 못한 것 같았다."

    $ choice_question_text = "지호에게 어떻게 답할까?"
    window hide

    menu:

        "화난 건 알겠는데, 말은 좀 세게 들렸을 수도 있어.":
            window show
            $ add_like("jiho", 2)
            $ add_neg("jiho", -1)
            $ choice_log.append("D4_jiho_4a_A_anger_spill")

            n "화난 건 알겠어."
            n "근데 말은 좀 세게 들렸을 수도 있어."
            n "방금은 나한테도 화낸 것처럼 들렸어."

            hide jiho
            show jh4 at center_stage as jiho with dissolve

            jh "뭐?"
            jh "아니, 나는 민준이 얘기한 건데."

            n "응."
            n "그건 알겠어."
            n "근데 네가 그렇게 말하니까 나도 잠깐 멈칫했어."

            "지호는 바로 대답하지 않았다."
            "손에서 공이 멈췄다."

            hide jiho
            show jh3 at center_stage as jiho with dissolve
            jh "...내가 너한테도 뭐라고 한 것처럼 들렸어?"

            n "응."
            n "나한테 화난 줄 알았어."

            "지호는 눈을 깜박였다."
            "조금 전까지 세게 쥐고 있던 공을 내려다봤다."

            jh "아..."
            jh "나는 그냥 짜증나서 말한 건데."

            n "응."
            n "그럴 때 말이 더 세게 나올 때 있잖아."

            "지호는 민준이가 간 쪽을 한 번 봤다."

            jh "그럼 민준이한테도 그렇게 들렸나."

            n "그럴 수도 있을 것 같아."

            "지호는 바로 대답하지 않았다."
            "이번에는 공을 바로 내리치지 않았다."
            hide jiho
            show jh5 at center_stage as jiho with dissolve
            jh "너한테 화난 건 아니었어."
            jh "아까 말은 미안."

            n "응."
            n "알겠어."


        "민준이가 먼저 그랬으면 너도 화날 만하지.":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", 1)
            $ choice_log.append("D4_jiho_4a_B_take_side")

            n "민준이가 먼저 그랬으면 너도 화날 만하지."
            n "계속 너만 뭐라고 들으면 짜증날 것 같아."

            hide jiho
            show jh1 at center_stage as jiho with dissolve

            jh "그치?"
            jh "내 말이 그거야."

            n "응."
            n "네가 괜히 그런 건 아닐 것 같아."

            hide jiho
            show jh6 at center_stage as jiho with dissolve

            jh "민준이는 내가 마지막에 큰소리 낸 것만 봐."
            jh "처음에 누가 먼저 부딪혔는지는 안 보고."

            "지호는 다시 공을 세게 튀겼다."

            jh "다음엔 더 세게 말해야겠어."
            jh "그래야 내가 진짜 잘못 없다는 걸 알지."

            n "...응."


    "지호는 공을 한 번 더 잡았다."
    "나는 지호가 다시 공을 잡는 모습을 잠깐 보고 있었다."

    jump d4_go_home

label d4_jiho_4b:
    $ set_bgm(audio.bgm_jiho_active)
    $ mark_d4_met("jiho")
    $ d4_choice_met = "jiho"

    scene bg_playground_day with fade

    "운동장 농구대 쪽에서 공 소리가 났다."
    "지호는 혼자 공을 튀기고 있었다."
    "조금 떨어진 곳에는 같은 모둠이었던 민준이가 친구들과 서 있었다."

    ex_mj "아까 말 좀 심했어."
    ex_mj "농구하다가 부딪힐 수도 있는 거잖아."

    "민준이는 그렇게 말하고 다른 애들 쪽으로 가버렸다."
    "지호는 못 들은 척했지만, 공을 튀기는 소리가 조금 커졌다."

    n "지호야."

    show jh6 at center_stage as jiho with dissolve

    jh "어."

    n "무슨 일 있었어?"

    jh "별거 아냐."
    jh "농구하다가 부딪혔는데,"
    jh "민준이가 아무 일도 아닌 척해서 내가 뭐라고 했어."

    "지호는 공을 잡았다가 다시 튀겼다."

    jh "어차피 마지막에 내가 넣었고,"
    jh "우리 팀이 이겼어."

    n "그런데 왜 아직 여기 있어?"
    jh "그냥 좀 짜증나서."

    "지호는 민준이가 간 쪽을 슬쩍 봤다."

    jh "아까 말 좀 심했다는 것도 웃기잖아."
    jh "부딪힌 건 걔도 똑같은데."

    $ choice_question_text = "지호에게 어떻게 답할까?"
    window hide

    menu:

        "화난 건 알겠는데, 말은 좀 세게 들렸을 수도 있어.":
            window show
            $ add_like("jiho", 2)
            $ add_neg("jiho", -1)
            $ choice_log.append("D4_jiho_4b_A_feeling_left")

            n "화난 건 알겠어."
            n "근데 말은 좀 세게 들렸을 수도 있어."

            hide jiho
            show jh4 at center_stage as jiho with dissolve

            jh "...몰라."
            jh "그런 걸 수도 있고."

            n "너도 신경쓰여서 계속 여기 있는 거잖아."
            "지호는 공을 느리게 튀겼다."

            hide jiho
            show jh6 at center_stage as jiho with dissolve

            jh "아, 진짜 귀찮다."

            "지호는 공을 옆구리에 끼고 농구대를 봤다."


            jh "그냥 부딪힌 거 미안하다고 하면 됐는데."
            jh "그 말이 안 나왔어서..."

            n "왜?"
            jh "뭘 왜야."

            n "음, 다음엔 짧게라도 먼저 말하면 어때?"
            n "미안, 하고."

            hide jiho
            show jh3 at center_stage as jiho with dissolve
            jh "음."
            jh "그 정도는 해보지 뭐."


        "민준이가 먼저 그랬으면 너도 화날 만하지.":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", 1)
            $ choice_log.append("D4_jiho_4b_B_win_covers")

            n "민준이가 먼저 그랬으면 너도 화날 만하지."
            n "아무 일도 아닌 척하면 더 짜증날 것 같아."

            hide jiho
            show jh5 at center_stage as jiho with dissolve

            jh "그치."
            jh "나만 예민한 거 아니지?"

            n "응."
            n "네가 왜 화났는지는 알겠어."

            hide jiho
            show jh1 at center_stage as jiho with dissolve

            jh "맞아."
            jh "그럼 됐지 뭐."

            hide jiho
            show jh6 at center_stage as jiho with dissolve

            jh "다음엔 처음부터 확실히 세게 말해야겠다."
            jh "그래야 나중에 나만 이상해지진 않겠지."

            "지호는 다시 농구대를 올려다봤다."
            "얼굴은 조금 풀렸지만,"
            "공을 쥔 손에는 다시 힘이 들어갔다."

    "지호는 농구대를 한 번 올려다봤다."
    "나는 지호가 다시 슛을 던질 때까지 잠깐 서 있었다."

    jump d4_go_home

label d4_jiho_2:
    $ set_bgm(audio.bgm_jiho_active)
    $ mark_d4_met("jiho")
    $ d4_choice_met = "jiho"

    scene bg_playground_day with fade

    "운동장 쪽에서 큰 공 소리가 났다."
    "지호가 농구공을 세게 튀기고 있었다."

    "농구대 옆에는 지호와 같은 모둠이었던 민준이도 있었다."
    "민준이는 팔을 문지르며 지호 쪽을 흘끗 봤다."

    ex_mj "아, 됐어."
    ex_mj "말을 왜 그렇게 해."

    "민준이는 다른 애들 쪽으로 가버렸다."
    "지호는 못 들은 척 공을 한 번 더 세게 튀겼다."

    "지호가 물을 마시러 오자, 나는 가까이 갔다."

    show jh6 at center_stage as jiho with dissolve

    n "농구하다가 무슨 일 있었어?"

    jh "별거 아냐."
    jh "이겼으면 된 거지 뭐."

    hide jiho
    show jh1 at center_stage as jiho with dissolve

    "지호는 다시 공을 들었다."
    "하지만 공을 잡은 손에는 힘이 들어가 있었다."

    $ choice_question_text = "지호에게 뭐라고 할까?"
    window hide

    menu:

        "화난 건 알겠는데, 말은 좀 세게 들렸을 수도 있어.":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", -1)
            $ choice_log.append("D4_jiho_2_A_notice_anger")

            n "화난 건 알겠어."
            n "근데 말은 좀 세게 들렸을 수도 있어."
            n "민준이가 아까 그렇게 말했으니까."

            hide jiho
            show jh4 at center_stage as jiho with dissolve

            jh "내가?"
            jh "아닌데."

            n "그냥 아까부터 공을 세게 튀기길래."

            hide jiho
            show jh6 at center_stage as jiho with dissolve

            jh "아, 별거 아니라니까."

            "지호는 짧게 말하고 고개를 돌렸다."


        "민준이가 먼저 그랬으면 너도 화날 만하지.":
            window show
            $ add_like("jiho", 1)
            $ add_neg("jiho", 1)
            $ choice_log.append("D4_jiho_2_B_win_done")

            n "민준이가 먼저 그랬으면 너도 화날 만하지."
            n "너만 뭐라고 들으면 짜증나잖아."

            hide jiho
            show jh1 at center_stage as jiho with dissolve

            jh "그치?"
            jh "어차피 내가 이겼는데."

            n "응."
            n "네가 왜 화났는지는 알겠어."

            hide jiho
            show jh6 at center_stage as jiho with dissolve

            jh "다음에 또 붙으면 또 이기면 돼."
            jh "그래 말도 좀 더 세게 해야겠어."
            jh "그래야 아무말 못 하겠지."

            "지호는 바로 공을 튀겼다."
            "공 소리가 다시 크게 났다."

    "지호는 친구들 쪽으로 뛰어갔다."
    "나는 멀어지는 공 소리를 잠깐 듣고 있다가 교실 쪽으로 걸었다."

    jump d4_go_home
# ==========================================================
# D4 하영 — 관계별 분기
# 핵심: 분위기 정리 욕구 / 중심에 있고 싶음 / 확인받고 싶음
# ==========================================================

label d4_hayoung_4a:
    $ set_bgm(audio.bgm_hayoung_social)
    $ mark_d4_met("hayoung")
    $ d4_choice_met = "hayoung"

    scene bg_board3 with fade

    "하영이가 게시판 앞에 서 있었다."

    n "하영아, 여기서 뭐 해?"

    show h3 at center_stage as hayoung with dissolve

    hy "아, 유진아. 이리와봐."
    "하영이는 내 팔을 끌어 교실 구석으로 데려갔다."
    hy "아까 나만 괜히 나대는것 같았지?"

    n "왜?"

    hy "아니, 나는 포스터처럼 보이게 하자는 거였어."
    hy "근데 서연이는 계속 조건만 보고,"
    hy "나은이는 뭐든 맞춘다고만 하니까."

    hide hayoung
    show h2 at center_stage as hayoung with dissolve

    "하영이는 게시판에 붙은 다른 포스터를 힐끗 봤다."

    hy "너는 어떻게 생각해?"

    $ choice_question_text = "하영이에게 어떻게 답할까?"
    window hide

    menu:

        "그 말은 서연이랑 나은이가 들으면 조금 속상할 수도 있어.":
            window show
            $ add_like("hayoung", 2)
            $ add_neg("hayoung", -1)
            $ choice_log.append("D4_hayoung_4a_A_burden_notice")

            n "네 말도 맞아."
            n "포스터는 잘 보여야 하니까."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "그치?"
            hy "나는 그 말 한 건데."

            n "응."
            n "근데 방금 말은,"
            n "서연이랑 나은이가 들으면 조금 속상할 수도 있어."

            hide hayoung
            show h3 at center_stage as hayoung with dissolve

            hy "왜?"

            n "모두 포스터를 잘 만들어보려고 자기 생각 말한거였잖아."

            hy "그래, 그러니까 나도 잘 되게 하려고 한 건데."
            n "알아 하영아."
            n "서연이랑 나은이도 자기 방식으로 해보려던 거고."
            n "너도 그런 마음이었던 거잖아."
            n "그런데 그렇게 말하면," 
            n "서연이랑 나은이만 잘못한 것처럼 들릴 것 같아."

            hy "...알았어, 알았어."
            
            "하영이는 게시판 쪽을 보다가 입술을 살짝 다물었다."


        "네가 봐줘서 포스터가 더 괜찮아지긴 했어.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", 1)
            $ add_neg("seoyeon", 1)
            $ add_neg("naeun", 1)
            $ choice_log.append("D4_hayoung_4a_B_take_hayoung_side")

            n "맞아."
            n "하영이가 안 말했으면 우리 포스터 너무 딱딱했을 것 같아."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve

            hy "그치?"
            hy "나는 보기 좋게 만들자는 거였어."

            n "응."
            n "조건만 맞춘다고 다 잘한 건 아니니까."
            n "나은이는 다 괜찮다고만 하고."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "하여튼 같이 모둠활동하기 불편한 애들이야 그치?"
            hy "역시 너는 알아듣는다니까."
            n "어...? 아, 음... 그게."

            "하영이는 조금 풀린 얼굴이 됐다."

            hy "다음에도 이런 거 있으면,"
            hy "너는 내 말 좀 들어줘."

    "하영이는 게시판에 붙은 포스터를 한 번 더 봤다."
    "그리고 아무렇지 않은 척 머리카락을 귀 뒤로 넘겼다."
    "나는 하영이가 교실 쪽으로 걸어가는 뒷모습을 잠깐 바라봤다."

    jump d4_go_home


label d4_hayoung_4b:
    $ set_bgm(audio.bgm_hayoung_social)
    $ mark_d4_met("hayoung")
    $ d4_choice_met = "hayoung"

    scene bg_board3 with fade

    "게시판 앞에서 하영이가 우리 모둠 포스터를 보고 있었다."

    show h5 at center_stage as hayoung with dissolve

    hy "유진아."
    hy "아까 우리 모둠 좀 정신없었지?"

    n "아니야 괜찮아."

    hide hayoung
    show h3 at center_stage as hayoung with dissolve

    hy "아니...나는 포스터가 딱 봤을 때 눈에 띄었으면 했거든."

    "하영이는 포스터 제목 쪽을 손가락으로 가리켰다."

    hy "그래도 제목 크게 한 건 괜찮지?"
    hy "이렇게 해야 멀리서도 보이잖아."

    n "응."
    n "제목은 잘 보여."

    hy "서연이랑 나은이 말만 들었으면 하나도 안 보였을걸?"

    $ choice_question_text = "하영이에게 어떻게 답할까?"
    window hide

    menu:

        "그 말은 서연이랑 나은이가 들으면 조금 속상할 수도 있어.":
            window show
            $ add_like("hayoung", 2)
            $ add_neg("hayoung", -1)
            $ choice_log.append("D4_hayoung_4b_A_balance")

            n "네 말도 맞아."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "그치?"

            n "응."
            n "제목 크게 한 건 잘 보였어."
            n "근데 서연이랑 나은이 얘기를 그렇게 말하면,"
            n "둘이 들었을 때 조금 속상할 수도 있어."

            hide hayoung
            show h3 at center_stage as hayoung with dissolve

            hy "...그렇게 들렸어?"

            n "조금은."
            n "둘도 자기 생각이 있어서 말한 거잖아."

            hy "아니, 나는 그냥 포스터가 이상해질까 봐 그런 건데."

            n "응."
            n "그냥 말할 때 조금 다르게 말하면 좋을 것 같아."

            "하영이는 입을 삐죽 내밀고 포스터를 다시 봤다."

            hy "음."
            hy "뭐, 제목은 내가 정하길 잘했다는 말이었어."

        "네가 봐줘서 포스터가 더 괜찮아지긴 했어.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", 1)
            $ add_neg("seoyeon", 1)
            $ add_neg("naeun", 1)
            $ choice_log.append("D4_hayoung_4b_B_reassure")

            n "네가 안 봤으면 포스터가 너무 딱딱했을 것 같아."
            n "색이랑 제목은 하영이가 잘 봤어."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve

            hy "역시."
            hy "너는 내가 뭘 말하려는지 알아듣네."

            "하영이는 조금 편해 보였다."

            hy "하여튼 서연이랑 나은이는 너무 답답해."
            hy "너도 그렇게 생각한다니 다행이다."

            n "어? 아... 그...런건..."

            "하영이는 자신감있게 웃으며 포스터를 봤다."

            hy "그래도 완성은 잘 됐네."

    "하영이는 포스터 제목 쪽을 손끝으로 가볍게 톡 쳤다."
    "그러고는 친구들이 있는 쪽을 한 번 돌아봤다."
    "나는 하영이와 나란히 복도 끝으로 걸었다."

    jump d4_go_home

label d4_hayoung_2:
    $ set_bgm(audio.bgm_hayoung_social)
    $ mark_d4_met("hayoung")
    $ d4_choice_met = "hayoung"

    scene bg_board3 with fade

    "교실 뒤 게시판에 하영이가 친구들과 서 있었다."
    "내가 지나가자 하영이가 손을 흔들었다."

    show h5 at center_stage as hayoung with dissolve

    hy "유진아."
    hy "아까 포스터 만들 때 좀 정신없지 않았어?"

    n "모둠 활동 때?"

    hide hayoung
    show h2 at center_stage as hayoung with dissolve

    hy "응."
    hy "서연이는 계속 칸부터 나누려고 하고,"
    hy "나은이는 계속 다 괜찮다고 하고."
    hy "하여튼 다들 참 답답하다니까."

    $ choice_question_text = "하영이에게 뭐라고 할까?"
    window hide

    menu:

        "그 말은 서연이랑 나은이가 들으면 조금 속상할 수도 있어.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", -1)
            $ choice_log.append("D4_hayoung_2_A_no_gossip")

            n "하영이 말도 맞아."
            n "제목 크게 하자는 건 괜찮았어."
            n "근데 그렇게 말하면,"
            n "서연이랑 나은이가 들었을 때 조금 속상할 수도 있어."

            hide hayoung
            show h3 at center_stage as hayoung with dissolve

            hy "...그렇게 들렸어?"

            n "응."            

            hide hayoung
            show h2 at center_stage as hayoung with dissolve
            "하영이는 입술을 삐죽 내밀었다."

            hy "뭐, 어쨌든 끝났으니까."


        "네가 봐줘서 포스터가 더 괜찮아지긴 했어.":
            window show
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", 1)
            $ add_neg("seoyeon", 1)
            $ add_neg("naeun", 1)
            $ choice_log.append("D4_hayoung_2_B_join_gossip")

            n "응."
            n "하영이가 봐줘서 덜 딱딱해진 것 같아."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve

            hy "그치? 내 말이 그거야."
            hy "너도 서연이랑 나은이가 답답했구나."

            n "응? 아니, 그런뜻은... "

            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "아무튼, 너도 고생했어."

    "하영이는 친구들 쪽으로 돌아가며 손을 흔들었다."
    "나는 게시판에 붙은 포스터들을 한 번 훑어보고 천천히 자리에 앉았다."

    jump d4_go_home

# D4 나은 — 관계별 분기
# 핵심: 맞춰주려 함 / 자기 의견을 말하기 어려움
# ==========================================================

label d4_naeun_4a:
    $ set_bgm(audio.bgm_naeun_soft)
    $ mark_d4_met("naeun")
    $ d4_choice_met = "naeun"

    scene bg_classroom_after with fade

    "어질러진 모둠 책상 앞에 나은이가 서 있었다."
    "나은이는 여기저기 흩어진 마카펜을 모으고 있었다."

    n "나은아."

    show ne5 at center_stage as naeun with dissolve

    ne "...어? 유진아."

    n "아까 미술 시간 괜찮았어?"

    hide naeun
    show ne2 at center_stage as naeun with dissolve

    ne "응."
    ne "포스터도 시간 안에 끝났고."

    "나은이는 접어둔 스케치 종이를 손에 쥐고 있었다."

    ne "근데..." 
    ne "내가 처음부터 스케치를 안 꺼냈다면,"
    ne "덜... 시끄러웠을까?"

    n "왜 그렇게 생각했어?"

    hide naeun
    show ne1 at center_stage as naeun with dissolve

    ne "내 그림 때문에 애들 목소리가 더 커졌나 싶어서."
    ne "그냥 가만히 있을걸 그랬어..."

    "나은이는 스케치 종이 끝을 손가락으로 눌렀다."

    $ choice_question_text = "나은이에게 어떻게 말할까?"
    window hide

    menu:

        "그래도 네가 맞춰준 덕분에 조용히 끝날 수 있었잖아.":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", 1)
            $ choice_log.append("D4_naeun_4a_B_keep_peace")

            n "그래도 네가 맞춰준 덕분에 조용히 끝날 수 있었잖아."
            n "처음 스케치 꺼낸 건 좀 그랬어도,"
            n "다시 그려보겠다고 먼저 말해줬으니까."

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            "나은이는 접은 스케치 종이를 조금 더 꼭 쥐었다."
            ne "아... 그치."
            ne "그래도 내가 다시 그린게 도움이 됐을까?"

            n "응. 당연하지"
            n "덕분에 말이 더 길어지지 않기도 했고."

            hide naeun
            show ne2 at center_stage as naeun with dissolve

            ne "그럼 다음엔...내 의견 내지 말고,"
            ne "처음부터 그냥 애들 말에 맞춰야겠다."
            n "어? 그런 뜻은..."
            ne "가자, 유진아."

        "스케치 꺼낸 건 잘못 아니야. 네 의견이잖아.":
            window show
            $ add_like("naeun", 2)
            $ add_neg("naeun", -1)
            $ choice_log.append("D4_naeun_4a_A_not_your_fault")

            n "스케치를 꺼낸 게 잘못은 아니야."
            n "나은이도 의견 낸 거잖아."

            hide naeun
            show ne2 at center_stage as naeun with dissolve

            ne "근데 내 그림 때문에,"
            ne "애들 목소리가 커진 것 같아서."

            n "그건 그림 때문만은 아니야."
            n "다 같이 정하는 중이었고,"
            n "서로 생각이 달라서 그런거니까."

            hide naeun
            show ne5 at center_stage as naeun with dissolve

            ne "...내가 괜히 꺼낸 건 아니었어?"

            n "응. 당연하지."
            n "다 네가 맞출 필요는 없어."
            n "다음에도 좋은 의견 있으면 언제든 말해도 돼."

            "나은이는 아주 작게 고개를 끄덕였다."

            ne "그렇게 들으니까 마음이 좋다."

    "나은이는 접은 스케치 종이를 가방 앞주머니에 넣었다."
    "손은 조금 느렸지만, 아까처럼 종이 끝을 누르고 있지는 않았다."
    "나는 나은이와 함께 복도 끝으로 천천히 걸었다."
    jump d4_go_home

label d4_naeun_4b:
    $ set_bgm(audio.bgm_naeun_soft)
    $ mark_d4_met("naeun")
    $ d4_choice_met = "naeun"

    scene bg_classroom_after with fade

    "교실 뒤편에 색연필 통이 남아 있었다."
    "나은이는 열린 뚜껑을 하나씩 닫고 있었다."

    n "나은아."
    n "아직 정리해?"

    show ne5 at center_stage as naeun with dissolve

    ne "응."
    ne "금방 끝나."

    n "아까 그림 많이 바꿨잖아."
    n "힘들지 않았어?"

    hide naeun
    show ne2 at center_stage as naeun with dissolve

    ne "조금."
    ne "사실 처음 스케치대로 큰 그림 하나만 그리려고 했거든."

    "나은이는 색연필 하나를 통 안에 넣었다."

    ne "근데 작게 나누는 게 낫다고 하니까..."

    n "말하기 어려웠어?"

    hide naeun
    show ne1 at center_stage as naeun with dissolve

    ne "응."
    ne "...괜히 처음 스케치 꺼냈나 싶어."


    $ choice_question_text = "나은이에게 어떻게 말할까?"
    window hide

    menu:

        "그래도 네가 맞춰준 덕분에 조용히 끝날 수 있었잖아.":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", 1)
            $ choice_log.append("D4_naeun_4b_B_let_it_pass")

            n "처음 스케치를 고집부리지 않고,"
            n "네가 맞춰서 그림을 바로 바꿔준 덕분에," 
            n "조용히 끝날 수 있었잖아."

            hide naeun
            show ne2 at center_stage as naeun with dissolve

            ne "그게 도움이 됐을까?"

            n "응."
            n "포스터는 잘 나왔잖아."

            "나은이는 마카펜 뚜껑을 닫았다."
            "딸깍 소리가 작게 났다."

            ne "...응."

            "나은이는 포스터 쪽을 한 번 더 봤다."

            ne "그냥 다음에도..."
            ne "내 의견보다는 친구들 의견을 더 맞춰줘야 겠다.."

            n "어? 아니 그럴 필요는..."
            ne "가자, 유진아."

        "스케치 꺼낸 건 잘못 아니야. 네 의견이잖아.":
            window show
            $ add_like("naeun", 2)
            $ add_neg("naeun", -1)
            $ choice_log.append("D4_naeun_4b_A_limit")

            n "큰 그림 그리고 싶었다고 말했어도 괜찮았을 것 같아."
            n "그것도 나은이 의견이잖아."

            hide naeun
            show ne4 at center_stage as naeun with dissolve

            ne "...그런가?"

            n "응."
            n "무작정 싫다고 말하는 게 아니라,"
            n "나는 이렇게 하고 싶다고 말하는 거니까."

            "나은이는 닫아둔 색연필 통을 두 손으로 잡았다."

            ne "그럼 다음에도..."
            ne "내 생각 말해봐도 괜찮을까?."

            hide naeun
            show ne5 at center_stage as naeun with dissolve

            n "응, 당연하지."
            ne "알았어, 그래볼게."

    "나은이는 색연필 통을 양손으로 들었다."
    "통 안에서 색연필들이 작게 부딪히는 소리가 났다."
    "나는 나은이가 정리한 책상 위를 한 번 보고 같이 걸었다."

    jump d4_go_home

label d4_naeun_2:
    $ set_bgm(audio.bgm_naeun_soft)
    $ mark_d4_met("naeun")
    $ d4_choice_met = "naeun"

    scene bg_classroom_after with fade

    "모둠 책상 위엔 색연필과 마카펜이 남아 있었다."
    "나은이가 열린 마카펜 뚜껑을 하나씩 닫고 있었다."

    n "나은아."
    n "아직 정리해?"

    show ne5 at center_stage as naeun with dissolve

    ne "응."
    ne "금방 끝나."

    "나은이는 접어둔 스케치 종이를 책상 한쪽에 올려두었다."

    n "이거 네가 처음에 그리려던 거지?"

    hide naeun
    show ne2 at center_stage as naeun with dissolve

    ne "응."
    ne "근데 작게 나누는 게 낫다고 해서..."
    ne "처음 스케치 괜히 그려왔나봐."

    $ choice_question_text = "나은이에게 뭐라고 할까?"
    window hide

    menu:

        "그래도 네가 맞춰준 덕분에 조용히 끝날 수 있었잖아.":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", 1)
            $ choice_log.append("D4_naeun_2_B_wait")

            n "그래도 네가 맞춰준 덕분에 조용히 끝날 수 있었잖아."
            n "그림을 바꿔준 덕분에 시간이 덜 걸렸고."

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            ne "그럼 괜찮은 거겠지?"

            n "응."
            n "포스터는 잘 끝났으니까."

            "나은이는 접어둔 스케치 종이를 조금 더 작게 접었다."

            ne "잘...끝났으니까."

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            ne "다음에도 이런 일이 있으면..."
            ne "그냥 내가 애들 의견에 더 맞춰줘야 겠다."
            n "...어?"

        "스케치 꺼낸 건 잘못 아니야. 네 의견이잖아.":
            window show
            $ add_like("naeun", 1)
            $ add_neg("naeun", -1)
            $ choice_log.append("D4_naeun_2_A_help")

            n "스케치 꺼낸 건 잘못 아니야."
            n "네 의견이잖아."

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            ne "그런가..."

            n "응."
            n "다음에도 의견 있으면 말해봐."

            "나은이는 접어둔 스케치 종이를 한 번 내려다봤다."

            hide naeun
            show ne5 at center_stage as naeun with dissolve

            ne "그럼 다음에..."
            ne "의견 있으면 나도 조금은, 더 말해볼게."

    "통 안에서 색연필들이 작게 부딪히는 소리가 났다."
    "나는 접힌 스케치 종이를 한 번 보고 교실 문 쪽으로 걸었다."

    jump d4_go_home
# ==========================================================
# D4 소희 — 관계별 분기
# 핵심: 먼저 봐주길 바람 / 특별하게 확인받고 싶음
# ==========================================================

label d4_sohee_4a:
    $ set_bgm(audio.bgm_sohee_warm)
    $ mark_d4_met("sohee")
    $ d4_choice_met = "sohee"

    scene bg_board3 with fade

    "게시판 앞에서 소희가 자기 모둠 포스터를 보고 있었다."
    "포스터 한쪽에는 색종이로 만든 작은 꽃들이 붙어 있었다."
    "소희는 꽃잎 끝을 손가락으로 꾹꾹 누르고 있었다."

    n "소희야."

    show sh5 at center_stage as sohee with dissolve

    sh "어."

    n "포스터 다 만든 거야?"

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "응."
    sh "우리 모둠도 꽤 열심히 했어."

    n "예쁘다."
    n "색종이 붙인 거 소희가 한 거야?"

    sh "응."
    sh "근데 이제 보여주고 싶은 마음이 좀 없어졌어."

    n "왜?"

    sh "너는 아까 계속 너희 모둠 애들이랑만 얘기했잖아."
    sh "나한테는 먼저 안 왔고."

    "소희는 색종이 조각을 손으로 구겼다 폈다."

    sh "나는 네가 우리 포스터도 먼저 봐줬으면 했어."
    sh "내가 만든 것도."

    $ choice_question_text = "소희에게 어떻게 답할까?"
    window hide

    menu:

        "미안해. 네가 기다린 줄 몰랐어. 지금 먼저 볼게.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", 2)
            $ add_burnout(1)
            $ choice_log.append("D4_sohee_4a_B_over_reassure")

            n "미안해."
            n "네가 기다린 줄 몰랐어."
            n "지금 먼저 볼게."

            hide sohee
            show sh1 at center_stage as sohee with dissolve

            sh "그러니까! 나 엄청 속상했다구."

            n "응."
            n "소희가 열심히 만든 건데."

            hide sohee
            show sh4 at center_stage as sohee with dissolve

            "소희는 만족스러운 웃음을 지었다."
            sh "알았어. 용서해줄게. 그러니까 지금 봐줘."
            sh "나 이 꽃 붙이느라 손에 풀 다 묻었단 말이야."

            n "그래, 지금 볼게."

            sh "다음엔 내가 안 불러도 와."
            sh "알겠지?"

            n "응."

        "다음엔 혼자 기다리지 말고, 같이 보자고 해줘.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", -1)
            $ choice_log.append("D4_sohee_4a_A_clear_feeling")

            n "서운했던 건 알겠어."
            n "소희가 만든 것도 같이 봐줬으면 했던 거잖아."

            hide sohee
            show sh5 at center_stage as sohee with dissolve

            sh "응."
            sh "근데 왜 바로 안 왔는데?"

            n "소희가 기다리는 줄 바로는 몰랐어."
            n "다음엔 혼자 기다리지 말고,"
            n "나한테 같이 보자고 해줘."

            hide sohee
            show sh2 at center_stage as sohee with dissolve

            sh "나는 네가 먼저 알아줬으면 했어."

            n "그럴 때도 있겠지만,"
            n "말해주면 내가 더 잘 알 수 있어."
            n "그러면 같이 볼 수 있잖아."

            "소희는 색종이 조각을 펴서 포스터 쪽을 가리켰다."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "그럼..."
            sh "이 꽃부터 봐."
            sh "내가 붙인 거야."

            n "응."
            n "같이 보자."

    "소희는 포스터 앞에 조금 더 가까이 섰다."
    "아까 구겼던 색종이는 다시 펴져 있었다."
    "나는 소희가 가리키는 꽃 장식부터 천천히 봤다."

    jump d4_go_home


label d4_sohee_4b:
    $ set_bgm(audio.bgm_sohee_warm)
    $ mark_d4_met("sohee")
    $ d4_choice_met = "sohee"

    scene bg_board3 with fade

    "교실 뒤 게시판에 포스터들이 붙어 있었다."
    "소희는 자기 모둠 포스터 옆에 서서 색종이 꽃을 만지고 있었다."

    n "소희야."

    show sh2 at center_stage as sohee with dissolve

    sh "어."
    sh "유진아."

    n "이거 소희네 모둠 거야?"

    sh "...응."
    sh "여기 꽃은 내가 붙였어."

    n "잘 붙였다."
    n "색도 눈에 잘 보여."

    hide sohee
    show sh5 at center_stage as sohee with dissolve

    sh "치, 같은 모둠이면 더 좋았을텐데."

    sh "그리고..."
    sh "우리 모둠이 만든 포스터도 안봐주고."
    sh "나 기다렸는데..."

    $ choice_question_text = "소희에게 어떻게 답할까?"
    window hide

    menu:

        "미안해. 네가 기다린 줄 몰랐어. 지금 먼저 볼게.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", 1)
            $ add_burnout(1)
            $ choice_log.append("D4_sohee_4b_B_prefer_sohee")

            n "미안해."
            n "지금 먼저 볼게."

            hide sohee
            show sh4 at center_stage as sohee with dissolve

            "소희의 표정이 눈에 띄게 밝아졌다."
            sh "치, 아까 바로 왔어야지..."
            sh "그럼 여기부터 봐!"
            sh "나 여기 붙인 거 보여주고 싶었어."            

            n "응. 예쁘다."

            hide sohee
            show sh1 at center_stage as sohee with dissolve

            sh "다음엔 내가 안불러도 먼저 와. 알았지?"

        "다음엔 혼자 기다리지 말고, 같이 보자고 해줘.":
            window show
            $ add_like("sohee", 2)
            $ add_neg("sohee", -1)
            $ choice_log.append("D4_sohee_4b_A_stable_friend")

            n "네가 보고 싶어 했던 건 알겠어."
            n "근데 혼자 기다리면 내가 바로 알기는 어려워."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "그러면...?"

            n "다음엔 같이 보자고 말해줘."
            n "그러면 내가 놓치지 않을 수 있어."


            sh "나는 네가 먼저 봐줬으면 좋겠을 때가 있단 말이야."

            n "그럴 수도 있지."
            n "그래도 말해주면 같이 볼 수 있잖아."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "그럼... 지금 봐줘."
            sh "여기 꽃이 제일 잘 된 것 같아."

            n "응."
            n "이쪽부터 같이 보자."

    "소희는 꽃 장식 옆을 손끝으로 톡톡 두드렸다."
    "표정은 아까보다 조금 풀려 있었다."

    jump d4_go_home


label d4_sohee_2:
    $ set_bgm(audio.bgm_sohee_warm)
    $ mark_d4_met("sohee")
    $ d4_choice_met = "sohee"

    scene bg_board3 with fade

    "소희는 자기 모둠 포스터 앞에서 색종이 조각을 들고 있었다."
    "나를 보더니 손을 들었다가 내렸다."

    n "포스터 아직 하는 중이야?"

    show sh5 at center_stage as sohee with dissolve

    sh "거의 끝났어."
    sh "근데 유진이는 우리 모둠꺼 별로 안 궁금하지?"

    n "어?"

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "너는 아까 너희 모둠 애들이랑 계속 얘기했잖아."
    sh "나 기다렸는데..."

    "소희는 색종이 조각을 손끝으로 만지작거렸다."

    $ choice_question_text = "소희에게 뭐라고 할까?"
    window hide

    menu:

        "미안해. 네가 기다린 줄 몰랐어. 지금 먼저 볼게.":
            window show
            $ add_like("sohee", 1)
            $ add_neg("sohee", 1)
            $ add_burnout(1)
            $ choice_log.append("D4_sohee_2_B_over_reassure")

            n "미안해."
            n "네가 기다린 줄 몰랐어."
            n "지금 먼저 볼게."

            hide sohee
            show sh1 at center_stage as sohee with dissolve

            sh "그럼 빨리 와."
            sh "여기 내가 붙인 것부터 봐."

            n "응."

            sh "다음엔 내가 부르면 바로 와야 돼."

        "다음엔 혼자 기다리지 말고, 같이 보자고 해줘.":
            window show
            $ add_like("sohee", 1)
            $ add_neg("sohee", -1)
            $ choice_log.append("D4_sohee_2_A_light_boundary")

            n "궁금해."
            n "근데 그렇게 말하면 내가 바로 알기 어려워."

            sh "그러면?"

            n "다음엔 혼자 기다리지 말고,"
            n "같이 보자고 말해줘."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "알았어..."
            sh "이쪽 봐봐."
            sh "여기 내가 붙인 거야."

            n "응. 볼게."

    "소희의 표정이 살짝 풀렸다."
    "나는 소희를 따라 소희네 포스터 쪽으로 한 걸음 더 다가갔다."

    jump d4_go_home


# ==========================================================
# D4 서연 — 관계별 분기
# 핵심: 정확함 / 혼자 고치려 함 / 같이 만든 것의 기준
# ==========================================================

label d4_seoyeon_4a:
    $ set_bgm(audio.bgm_seoyeon_clear)
    $ mark_d4_met("seoyeon")
    $ d4_choice_met = "seoyeon"

    scene bg_board3 with fade

    "쉬는 시간이 시작됐지만, 서연이는 아직 포스터 앞에 있었다."
    "서연이는 검은색 마카펜을 들고 제목 쪽을 보고 있었다."

    n "서연아."
    n "안 내려가?"

    show sy2 at center_stage as seoyeon with dissolve

    sy "제목이 살짝 기울었어."
    sy "테이프도 울었고."

    n "혼자 고치려고?"

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "조금만 손보면 돼."
    sy "잘못된 부분을 그냥 둘 수는 없잖아."

    n "다른 애들도 그렇게 하재?"

    sy "...지금 없잖아."

    "서연이는 마카펜 뚜껑을 손끝으로 만졌다."
    "바로 고치고 싶은 얼굴이었다."

    $ choice_question_text = "서연이에게 어떻게 답할까?"
    window hide

    menu:

        "네가 계속 신경 쓰이면, 지금 조금만 고치자.":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", 1)
            $ choice_log.append("D4_seoyeon_4a_B_perfect_finish")

            n "신경 쓰이면 지금 조금만 고치자."

            hide seoyeon
            show sy1 at center_stage as seoyeon with dissolve

            sy "나도 그렇게 생각해."
            sy "보이는 건 고치는 게 맞아."

            "서연이는 바로 마카펜 뚜껑을 열었다."
            "이름을 덧칠한 뒤, 제목 쪽으로 손을 옮겼다."

            hide seoyeon
            show sy3 at center_stage as seoyeon with dissolve

            "서연이는 자를 대고 제목 아래쪽을 다시 그었다."
            n "엇, 그런데 그렇게 하면..."
            sy "제목도 마음에 안들었어."
            sy "기울어진 채로 두면 계속 보일 것 같아."

            "포스터는 더 반듯해졌지만, 제목 자리는 처음과 많이 달라졌다."

        "이름은 고치고, 제목은 애들한테 한 번 물어보자.":
            window show
            $ add_like("seoyeon", 2)
            $ add_neg("seoyeon", -1)
            $ choice_log.append("D4_seoyeon_4a_A_check_together")

            n "확인하는 건 좋아."
            n "근데 지금은 이름만 진하게 하자."

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve

            sy "제목은?"

            n "제목은 애들한테 한 번 물어보고 고치자."
            n "같이 만든 거잖아."
            n "그런데 갑자기 너 혼자 고쳐서 바뀌면"
            n "다른 애들이 속상해 할거야."

            hide seoyeon
            show sy3 at center_stage as seoyeon with dissolve

            sy "...나는 더 정확하게 만들고 싶은 건데."

            n "그건 알아."
            n "그래도 제목은 다 같이 정했잖아."

            "서연이는 바로 대답하지 않았다."
            "마카펜 뚜껑을 열었다가 다시 한 번 포스터를 봤다."

            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve

            sy "그래 그럼, 이름만."
            sy "제목은 나중에 물어보고."

            "서연이는 포스터 아래쪽 이름만 조심스럽게 덧칠했다."

    "서연이는 마카펜 뚜껑을 딸깍 닫았다."
    "그러고도 제목 쪽을 한 번 더 확인했다."
    "나는 서연이가 포스터에서 시선을 떼는 걸 기다렸다."

    jump d4_go_home


label d4_seoyeon_4b:
    $ set_bgm(audio.bgm_seoyeon_clear)
    $ mark_d4_met("seoyeon")
    $ d4_choice_met = "seoyeon"

    scene bg_board3 with fade

    "쉬는 시간이 시작되기 전, 서연이가 교실 뒤편에 남아 있었다."
    "서연이는 포스터 아래쪽 이름을 마카펜 끝으로 짚었다."

    n "안 내려가?"

    show sy2 at center_stage as seoyeon with dissolve

    sy "이름 글씨가 흐려."
    sy "멀리서 보면 잘 안 보일 것 같아."

    n "지금 고치려고?"

    hide seoyeon
    show sy5 at center_stage as seoyeon with dissolve

    sy "응."
    sy "그리고 제목도 조금 삐뚤어졌어."

    n "제목도 고치게?"

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "조금."

    "서연이는 마카펜 뚜껑을 손에 쥔 채 포스터를 보고 있었다."

    $ choice_question_text = "서연이에게 어떻게 답할까?"
    window hide

    menu:

        "네가 계속 신경 쓰이면, 지금 조금만 고치자.":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", 1)
            $ choice_log.append("D4_seoyeon_4b_B_fix_more")

            n "제목도 신경 쓰이면 조금만 고치자."

            hide seoyeon
            show sy1 at center_stage as seoyeon with dissolve

            sy "그치, 너도 제목 좀 거슬렸지"

            n "음...글쎄, 조금...?"

            "서연이는 바로 마카펜 뚜껑을 열었다."
            "이름을 덧칠하고, 제목 쪽에 자를 대었다."
            "서연이는 제목 아래 선을 다시 그었다."

            n "엇, 그렇게 하면..."
            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve
            "제목 자리는 처음과 많이 달라졌다."
            sy "이정도면 모양을 다 바꾼건 아니니까."

        "이름은 고치고, 제목은 애들한테 한 번 물어보자.":
            window show
            $ add_like("seoyeon", 2)
            $ add_neg("seoyeon", -1)
            $ choice_log.append("D4_seoyeon_4b_A_limited_fix")

            n "이름만 진하게 쓰고 마무리하자."
            n "제목은 나중에 애들한테 물어보고."

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve

            sy "왜?"
            n "제목은 다같이 정한거잖아."
            n "애들이 보면 속상할 수도 있어."
            sy "...알았어. 그럼 이름만 수정할게."

            "서연이는 아쉬운 표정으로 이름 부분만 한 번 더 썼다."

            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve

            sy "이 정도면 됐어."
            sy "제목은 나중에 물어봐야겠다."

    "얼마 후 서연이는 손에 든 마카펜을 필통에 넣었다."
    "나는 서연이와 함께 교실 문 쪽으로 걸었다."

    jump d4_go_home


label d4_seoyeon_2:
    $ set_bgm(audio.bgm_seoyeon_clear)
    $ mark_d4_met("seoyeon")
    $ d4_choice_met = "seoyeon"

    scene bg_board3 with fade

    "쉬는 시간이 되기 전, 서연이가 혼자 포스터를 보고 있었다."
    "포스터 아래쪽 이름을 검은색 마카펜으로 다시 쓰는 중이었다."

    n "뭐 해?"

    show sy2 at center_stage as seoyeon with dissolve

    sy "이름이 흐려서. 제목도 삐뚤었고."

    n "다른 애들은 벌써 내려갔는데?"

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "금방 끝나."

    $ choice_question_text = "서연이에게 뭐라고 할까?"
    window hide

    menu:

        "네가 계속 신경 쓰이면, 지금 조금만 고치자.":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", 1)
            $ choice_log.append("D4_seoyeon_2_B_confirm")

            n "맞아."
            n "보이는 건 고치는 게 낫겠다."

            hide seoyeon
            show sy1 at center_stage as seoyeon with dissolve

            sy "그렇지."

            "서연이는 이름을 더 굵게 썼다."
            "그다음 제목 쪽에 자를 꺼냈다."

            n "제목도 고치려고?"

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve

            sy "삐뚤어졌잖아."
            sy "금방 끝나."
            n "엇..."

            "서연이는 자를 대고 제목 아래 선을 다시 그었다."
            "제목은 아까 자리에서 많이 달라졌다."

        "이름은 고치고, 제목은 애들한테 한 번 물어보자.":
            window show
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", -1)
            $ choice_log.append("D4_seoyeon_2_A_enough")

            n "이름만 쓰고 이제 가자."
            n "제목이 조금 삐뚤어져도 알아볼 수 있어."

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve

            sy "제목도 보이는데."

            n "응."
            n "근데 지금 다른 애들은 내려갔잖아."
            n "더 고칠 거면 나중에 같이 보고 해도 될 것 같아."

            "서연이는 잠깐 포스터를 봤다."
            "손에 든 마카펜을 한 번 굴렸다."

            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve

            sy "알겠어."
            sy "이름만."

            "서연이는 이름만 굵게 덧칠했다."
            "제목 쪽은 한 번 더 봤지만, 자는 꺼내지 않았다."

    "서연이는 마카펜을 필통에 넣었다."
    "나는 서연이가 책상 옆을 정리하는 동안 잠깐 기다렸다."

    jump d4_go_home

# ----------------------------------------------------------
# D4 목요일 — 하교
# ----------------------------------------------------------

label d4_go_home:
    scene bg_board3 with fade
    $ set_bgm(audio.bgm_classroom_light2)

    "오후 수업이 끝났다."
    "교실 게시판에는 오늘 만든 포스터들이 붙어 있었다."
    "종례까지 마친 후 나는 바로 가방을 멨다."

    scene bg_home_evening
    with slow_fade
    $ set_bgm(audio.bgm_evening)

    "집에 돌아와 가방을 내려놓았다."
    "손끝에는 아직 풀 냄새와 색연필 자국이 남아 있었다."

    "나는 책상 앞에 앉아 일기장을 폈다."

    jump d4_diary

# --------------------------------------------------------
# D4 목요일 — 일기
# ----------------------------------------------------------

label d4_diary:
    scene bg_diary with fade
    window hide

    $ _focus = d4_choice_met
    $ _focus_name = display_name(_focus)
    $ _focus_like = like_of(_focus)
    $ _focus_neg = neg_of(_focus)

    $ diary_text1 = ""
    $ diary_text1 += "오늘은 모둠 포스터를 만들었다.\n"
    $ diary_text1 += "처음엔 금방 끝날 줄 알았다.\n"
    $ diary_text1 += "그런데 다들 중요하게 생각하는 게 달라 오래 걸렸다.\n\n"

    if d4_choice == "rule_seoyeon":
        $ diary_text1 += "나는 서연이 말대로 조건부터 맞추자고 했다.\n"
        $ diary_text1 += "하지만 하영이는 답답해 했다.\n"
        $ diary_text1 += "나은이도 처음 그려왔던 그림을 작게 줄여야 했다.\n"

    elif d4_choice == "trend_hayoung":
        $ diary_text1 += "나는 하영이 말대로 먼저 눈에 잘 보이게 만들자고 했다.\n"
        $ diary_text1 += "포스터는 전보다 눈에 잘 들어왔다.\n"
        $ diary_text1 += "하지만 서연이는 조건들을 계속 신경 썼고, 나은이 그림은 많이 작아졌다.\n"

    elif d4_choice == "share_work" or d4_choice == "protect_naeun":
        $ diary_text1 += "나는 역할부터 다시 나눠보자고 했다.\n"
        $ diary_text1 += "조금 늦어졌지만, 각자 할 일이 생겼다.\n"
        $ diary_text1 += "나은이는 큰 그림 하나를 맡았다.\n"
        $ diary_text1 += "서연이는 글을 적고, 하영이는 색과 제목을 봤다.\n"

    else:
        $ diary_text1 += "포스터는 완성됐다.\n"
        $ diary_text1 += "그런데 마음은 그다지 편하지 않았던 것 같다.\n"

    $ diary_text1 += "\n"

    if d4_choice_met == "jiho":
        $ diary_text1 += "방과 후에는 어딘가 화난 표정의 지호를 만났다.\n"

        if "D4_jiho_4a_A_anger_spill" in choice_log or "D4_jiho_4b_A_feeling_left" in choice_log or "D4_jiho_2_A_notice_anger" in choice_log:
            $ diary_text1 += "민준이와 다툰 이야기를 듣고 말을 세게 한 것이 마음에 걸리냐고 물었다.\n"
            $ diary_text1 += "그러자 지호는 그냥 사과 한 번 할걸 그랬다고 후회했다.\n"

        elif "D4_jiho_4a_B_take_side" in choice_log or "D4_jiho_4b_B_win_covers" in choice_log or "D4_jiho_2_B_win_done" in choice_log:
            $ diary_text1 += "민준이와 다툰 이야기를 듣고 나는 지호가 왜 화났는지 알 것 같다고 했다.\n"
            $ diary_text1 += "그러자 지호는 조금 풀린 얼굴로 자신은 잘못이 없다는 듯 이야기했다.\n"

        else:
            $ diary_text1 += "지호는 억울한 얼굴로 공을 튀기고 있었다.\n"


    elif d4_choice_met == "hayoung":
        $ diary_text1 += "방과 후에는 하영이와 모둠 활동 이야기를 했다.\n"

        if "D4_hayoung_4a_A_burden_notice" in choice_log or "D4_hayoung_4b_A_balance" in choice_log or "D4_hayoung_2_A_no_gossip" in choice_log:
            $ diary_text1 += "하영이는 나은이와 서연이가 답답했다고 말했다.\n"
            $ diary_text1 += "하지만 나는 그 말은 친구들에게 조금 속상하게 들릴 수 있다고 했다.\n"
            $ diary_text1 += "하영이는 바로 인정하지는 않았지만, 더 이상 친구들 얘기를 하지 않았다.\n"

        elif "D4_hayoung_4a_B_take_hayoung_side" in choice_log or "D4_hayoung_4b_B_reassure" in choice_log or "D4_hayoung_2_B_join_gossip" in choice_log:
            $ diary_text1 += "하영이는 나은이와 서연이가 답답했다며, 포스터는 자기 덕분에 잘 보였다고 했다.\n"
            $ diary_text1 += "나는 포스터가 잘 보이게 된 건 맞다고 했다.\n"
            $ diary_text1 += "하지만 하영이는 내가 친구들 얘기까지 동의한 줄 아는 것 같았다.\n"

        else:
            $ diary_text1 += "하영이는 자기 말이 어떻게 들렸을지 내 표정을 살폈다.\n"


    elif d4_choice_met == "naeun":
        $ diary_text1 += "방과 후에는 나은이와 모둠 활동 이야기를 했다.\n"

        if "D4_naeun_4a_A_not_your_fault" in choice_log or "D4_naeun_4b_A_limit" in choice_log or "D4_naeun_2_A_help" in choice_log:
            $ diary_text1 += "나은이는 스케치를 꺼내지 말걸 그랬다며 후회했다.\n"
            $ diary_text1 += "나는 그건 나은이의 의견이니까, 보여주길 잘했다고 했다.\n"

        elif "D4_naeun_4a_B_keep_peace" in choice_log or "D4_naeun_4b_B_let_it_pass" in choice_log or "D4_naeun_2_B_wait" in choice_log:
            $ diary_text1 += "나은이는 스케치를 꺼내지 말걸 그랬다며 후회했다.\n"
            $ diary_text1 += "나는 그래도 나은이 덕분에 조용히 끝났다고 위로해 주었다.\n"

        else:
            $ diary_text1 += "나은이는 괜찮다고 했지만, 손은 계속 움직이고 있었다.\n"


    elif d4_choice_met == "sohee":
        $ diary_text1 += "방과 후에는 삐진 얼굴의 소희가 자기 모둠 포스터 앞에 있었다.\n"

        if "D4_sohee_4a_A_clear_feeling" in choice_log or "D4_sohee_4b_A_stable_friend" in choice_log or "D4_sohee_2_A_light_boundary" in choice_log:
            $ diary_text1 += "소희는 모둠 활동이 끝나고도 내가 자기에게 오지 않았다고 서운해했다.\n"
            $ diary_text1 += "나는 기다리지 말고 다음엔 직접 와서 말해달라고 했다.\n"
            $ diary_text1 += "소희는 알겠다고 했고, 같이 소희가 그린 꽃 장식을 봤다.\n"

        elif "D4_sohee_4a_B_over_reassure" in choice_log or "D4_sohee_4b_B_prefer_sohee" in choice_log or "D4_sohee_2_B_over_reassure" in choice_log:
            $ diary_text1 += "소희는 모둠 활동이 끝나고도 내가 자기에게 오지 않았다고 서운해했다.\n"
            $ diary_text1 += "나는 기다린 줄 몰랐다며 미안하다고 달래 줬다.\n"
            $ diary_text1 += "소희는 조금 풀렸지만, 나는 조금 답답한 기분이 들었다.\n"

        else:
            $ diary_text1 += "소희는 바로 서운하다고 말하지 않고, 포스터만 만지고 있었다.\n"


    elif d4_choice_met == "seoyeon":
        $ diary_text1 += "방과 후에는 서연이와 함께 만든 포스터 이야기를 했다.\n"

        if "D4_seoyeon_4a_A_check_together" in choice_log or "D4_seoyeon_4b_A_limited_fix" in choice_log or "D4_seoyeon_2_A_enough" in choice_log:
            $ diary_text1 += "서연이는 포스터의 이름과 제목을 둘 다 고치고 싶어했다.\n"
            $ diary_text1 += "하지만 나는 제목은 다 같이 만든 거니까 물어보고 고치자고 했다.\n"

        elif "D4_seoyeon_4a_B_perfect_finish" in choice_log or "D4_seoyeon_4b_B_fix_more" in choice_log or "D4_seoyeon_2_B_confirm" in choice_log:
            $ diary_text1 += "서연이는 포스터의 이름과 제목을 둘 다 고치고 싶어했다.\n"
            $ diary_text1 += "나는 신경 쓰이면 그렇게 하라고 했다.\n"

        else:
            $ diary_text1 += "서연이는 포스터를 더 반듯하게 끝내고 싶어 했다.\n"

    else:
        $ diary_text1 += "오늘은 아무에게도 따로 가지 않았다.\n"
        $ diary_text1 += "복도 게시판에는 완성된 포스터만 남아 있었다.\n"

    call screen diary_page(title="목요일 일기", content=diary_text1, body_yoffset=15)

    $ renpy.movie_cutscene("videos/diary.webm", stop_music=False)

    $ diary_text2 = ""
    if _focus == "none":
        $ diary_text2 += "오늘은 따로 오래 이야기한 친구가 없었다.\n"
    else:
        $ diary_text2 += relation_status_text(_focus_like, _focus_neg) + "\n"

    if _focus == "jiho":
        if "D4_jiho_4a_A_anger_spill" in choice_log or "D4_jiho_4b_A_feeling_left" in choice_log or "D4_jiho_2_A_notice_anger" in choice_log:
            $ diary_text2 += "지호는 화가 나면 바로 말이 세게 나가는 것 같았다.\n"
            $ diary_text2 += "다음엔 먼저 '뭐가 제일 속상했어?'라고 물어보기.\n"
        elif "D4_jiho_4a_B_take_side" in choice_log or "D4_jiho_4b_B_win_covers" in choice_log or "D4_jiho_2_B_win_done" in choice_log:
            $ diary_text2 += "지호는 편을 들어주자 금방 풀렸다.\n"
            $ diary_text2 += "그래도 다음엔 한쪽 말만 듣고 바로 편들지 않기.\n"
        else:
            $ diary_text2 += "지호는 웃고 있었지만 말투가 조금 세졌다.\n"
            $ diary_text2 += "웃는 얼굴만 보고 괜찮다고 넘기지 않기.\n"

    elif _focus == "hayoung":
        if "D4_hayoung_4a_A_burden_notice" in choice_log or "D4_hayoung_4b_A_balance" in choice_log or "D4_hayoung_2_A_no_gossip" in choice_log:
            $ diary_text2 += "하영이는 자기 말에 동의하는지 자주 내 표정을 봤다.\n"
            $ diary_text2 += "다른 친구 얘기가 나오면, 그 친구가 들으면 어떨지도 말해보기.\n"
        elif "D4_hayoung_4a_B_take_hayoung_side" in choice_log or "D4_hayoung_4b_B_reassure" in choice_log or "D4_hayoung_2_B_join_gossip" in choice_log:
            $ diary_text2 += "하영이는 자기 말에 동의해 주면 바로 밝아졌다.\n"
            $ diary_text2 += "그래도 다음엔 이야기 속 친구 마음도 생각하고 대답하기.\n"
        else:
            $ diary_text2 += "하영이는 포스터도 보고 친구들 얼굴도 봤다.\n"
            $ diary_text2 += "누구 이야기를 많이 하는지 조금 더 들어보기.\n"

    elif _focus == "naeun":
        if "D4_naeun_4a_A_not_your_fault" in choice_log or "D4_naeun_4b_A_limit" in choice_log or "D4_naeun_2_A_help" in choice_log:
            $ diary_text2 += "나은이는 자기가 맞추면 다 괜찮을 거라고 생각하는 것 같았다.\n"
            $ diary_text2 += "다음엔 나은이가 자기 생각을 말할 수 있게 옆에서 도와주기.\n"
        elif "D4_naeun_4a_B_keep_peace" in choice_log or "D4_naeun_4b_B_let_it_pass" in choice_log or "D4_naeun_2_B_wait" in choice_log:
            $ diary_text2 += "나은이는 자꾸 괜찮다고 하다가 많은 일을 떠맡게 된다.\n"
            $ diary_text2 += "다음엔 칭찬만 하지 말고 작은 일이라도 같이 해주기.\n"
        else:
            $ diary_text2 += "나은이는 괜찮다고 했지만 손은 계속 움직였다.\n"
            $ diary_text2 += "계속 정리하고 있으면 마카펜이라도 같이 닫기.\n"

    elif _focus == "sohee":
        if "D4_sohee_4a_A_clear_feeling" in choice_log or "D4_sohee_4b_A_stable_friend" in choice_log or "D4_sohee_2_A_light_boundary" in choice_log:
            $ diary_text2 += "소희는 서운한 마음을 바로 말하지 않고 삐질 때가 있다.\n"
            $ diary_text2 += "다음엔 뭐가 서운했는지 말해줘야 같이 풀 수 있다고 말해주기.\n"
        elif "D4_sohee_4a_B_over_reassure" in choice_log or "D4_sohee_4b_B_prefer_sohee" in choice_log or "D4_sohee_2_B_over_reassure" in choice_log:
            $ diary_text2 += "소희는 서운한 마음을 바로 말하지 않고 삐질 때가 있다.\n"
            $ diary_text2 += "다음엔 무조건 달래기보다 뭐가 서운했는지 먼저 물어보기.\n"
        else:
            $ diary_text2 += "소희는 서운해도 바로 말하지 않았다.\n"
            $ diary_text2 += "뭘 보여주고 싶은지 직접 물어보기.\n"

    elif _focus == "seoyeon":
        if "D4_seoyeon_4a_A_check_together" in choice_log or "D4_seoyeon_4b_A_limited_fix" in choice_log or "D4_seoyeon_2_A_enough" in choice_log:
            $ diary_text2 += "서연이는 고칠 곳을 보면 그냥 지나치지 못했다.\n"
            $ diary_text2 += "다음엔 고치기 전에 같이 만든 친구들 마음도 생각해 보자고 하기.\n"
        elif "D4_seoyeon_4a_B_perfect_finish" in choice_log or "D4_seoyeon_4b_B_fix_more" in choice_log or "D4_seoyeon_2_B_confirm" in choice_log:
            $ diary_text2 += "서연이는 고칠 곳을 보면 그냥 지나치지 못했다.\n"
            $ diary_text2 += "틀린 건 고쳐도, 함께 만든 건 친구들 생각도 물어보기.\n"
        else:
            $ diary_text2 += "서연이는 포스터가 반듯해야 마음이 놓이는 것 같았다.\n"
            $ diary_text2 += "고치기 전에 다른 애들도 괜찮은지 확인하기.\n"

    elif _focus != "none":
        $ diary_text2 += "오늘은 따로 오래 이야기한 친구가 없었다.\n"
        $ diary_text2 += "그냥 지나친 표정 중에 마음에 남는 게 있는지 떠올리기.\n"

    if _focus_neg >= 4:
        $ diary_text2 += "\n같이 웃은 적도 있었지만 멈칫한 적도 있었다.\n"
        $ diary_text2 += "불편하면 '그 말은 조금 불편해'라고 짧게 말해보기.\n"
    elif _focus_like >= 5 and _focus_neg <= 2:
        $ diary_text2 += "\n이 친구랑 있으면 편하다.\n"
        $ diary_text2 += "이 친구도 나와 함께일 때 편할지 한 번 돌아보기.\n"
    elif _focus_like >= 4 and _focus_neg >= 3:
        $ diary_text2 += "\n좋은 때도 있었고, 조금 신경 쓰인 때도 있었다.\n"
        $ diary_text2 += "좋아졌다고 신경 쓰인 일까지 그냥 넘기지는 말기.\n"
    else:
        $ diary_text2 += "\n아직은 조금 더 봐야겠다.\n"
        $ diary_text2 += "말보다 행동도 같이 보기.\n"

    if burnout >= 4:
        $ diary_text2 += "\n나의 상태: 오늘은 머릿속이 시끄러웠다.\n"
        $ diary_text2 += "내일은 친구들 표정보다 내 마음부터 살피기.\n"
    elif burnout >= 3:
        $ diary_text2 += "\n나의 상태: 조금 피곤했다.\n"
        $ diary_text2 += "생각이 많아지면 한 번 숨 쉬고 말하기.\n"
    else:
        $ diary_text2 += "\n나의 상태: 오늘은 많이 힘들지는 않았다.\n"
        $ diary_text2 += "그래도 마음에 남은 장면 하나는 적어두기.\n"

    if _focus != "none":
        show screen diary_focus_badge(_focus)
    call screen diary_page(title="목요일 관계 메모", content=diary_text2, body_yoffset=135)
    if _focus != "none":
        hide screen diary_focus_badge

    scene bg_home_evening
    with slow_fade

    window show

    "일기장을 덮었다."
    "손톱 옆에 남은 색연필 자국을 다시 봤다."
    "눈이 스르르 감겼다."

    jump d5_start


# ----------------------------------------------------------
# D5/D6 주말 제안 보조 변수와 함수
# ----------------------------------------------------------

default d5_allow_weekend_offers = True
default d5_card_success = False
default d5_best_friend_success = False
default d5_weekend_candidate_1 = "none"
default d5_weekend_candidate_2 = "none"
default d5_unselected_candidate = "none"

default d6_event_person = "none"
default d6_weekend_success = False
default d6_weekend_choice = "none"
default d6_deep_talk_style = "none"
default d6_solo_style = "none"
default d6_memory_line = ""

init python:
    def d5_any_observed():
        return (
            d5_obs_jiho
            or d5_obs_hayoung
            or d5_obs_naeun
            or d5_obs_sohee
            or d5_obs_seoyeon
        )

    def d5_display_name(name):
        return display_name(name)

    def d5_colored_display_name(name):
        color_table = {
            "jiho": "#7DB8FF",
            "hayoung": "#FF9ACD",
            "naeun": "#BFA7FF",
            "sohee": "#FFCF6E",
            "seoyeon": "#9FE0C5",
        }
        plain = display_name(name)
        color = color_table.get(name, "#FFFFFF")
        return "{color=" + color + "}" + plain + "{/color}"

    def d5_offer_level(name):
        like = like_of(name)
        neg = neg_of(name)

        if like >= 6 and neg <= 2:
            return "deep"
        elif neg >= 4:
            return "unstable"
        else:
            return "normal"

    def get_d5_weekend_top_two():
        names = ["jiho", "hayoung", "naeun", "sohee", "seoyeon"]

        ranked = sorted(
            names,
            key=lambda name: (
                like_of(name),
                1 if d5_leaf_person == name and d5_leaf_result == "deep_good" else 0,
                -neg_of(name)
            ),
            reverse=True
        )

        candidates = [name for name in ranked if like_of(name) > 0]

        if not candidates:
            return "none", "none"

        first = candidates[0]
        second = candidates[1] if len(candidates) >= 2 else "none"

        return first, second

    def d5_add_like(name, amount):
        add_like(name, amount)

label d5_start:
    $ day = 5
    jump d5_observation_intro

label d5_observation_intro:

    scene black
    with day_fade
    $ set_bgm(audio.bgm_classroom_light)

    centered "금요일"
    pause 0.5
    scene bg_classroom_after with fade

    "금요일 아침."
    "1교시 전 교실은 아직 어수선했다."

    scene bg_board with dissolve
    "게시판에는 큰 나무 그림이 붙어 있었다."
    "가지에는 잎이 하나도 없었다."

    "교탁 앞 바구니에는 잎사귀 종이가 담겨 있었다."
    "나는 가방을 내려놓고 자리에 앉았다."

    scene bg_d5_observation with dissolve
    "예비종이 치기 전까지 시간이 조금 남았다."
    "나는 친구들이 뭘 하고 있는지 살펴보기로 했다."

    jump d5_observation_loop

label d5_observation_loop:

    # D5 조사 화면 진입 전 UI 정리
    scene bg_d5_observation with dissolve

    $ quick_menu = False
    $ relation_note_enabled = False
    window hide

    call screen d5_observation_screen

    window auto
    $ quick_menu = True
    $ relation_note_enabled = True

    if _return == "jiho":
        jump d5_obs_jiho

    elif _return == "hayoung":
        jump d5_obs_hayoung

    elif _return == "naeun":
        jump d5_obs_naeun

    elif _return == "sohee":
        jump d5_obs_sohee

    elif _return == "seoyeon":
        jump d5_obs_seoyeon

    elif _return == "start_activity":

        if d5_any_observed():
            jump d5_first_period_bridge
        else:
            "그냥 자리에 앉기에는 아직 시간이 조금 남아 있었다."
            "친구들이 뭘 하고 있는지 한 명쯤은 더 봐도 될 것 같았다."
            jump d5_observation_loop
            
label d5_obs_jiho:

    if d5_obs_jiho:
        "지호는 아까 봤다."
        jump d5_observation_loop

    $ d5_obs_jiho = True

    "지호는 창가 쪽에서 친구 둘과 떠들고 있었다."

    jh "야, 오늘 금요일인데 얼굴이 왜 월요일이냐?"
    jh "주말이 코앞인데 좀 웃어라."

    "친구들이 웃었다."
    "지호는 책상 끝을 손바닥으로 톡 쳤다."
    "장난을 들은 친구는 표정이 살짝 굳었다."

    jump d5_observation_loop

label d5_obs_hayoung:

    if d5_obs_hayoung:
        "하영이는 아까 봤다."
        jump d5_observation_loop

    $ d5_obs_hayoung = True

    "하영이는 교실 가운데에서 친구들 이야기를 듣고 있었다."

    hy "그럼 너는 여기 앉아."
    hy "둘이 어제 살짝 어색했잖아. 오늘은 같이 앉으면 풀릴걸?"

    "하영이가 웃으며 자리를 가리켰다."
    "한 친구는 고개를 끄덕였다."
    "다른 친구는 의자 옆에 잠깐 서 있었다."

    jump d5_observation_loop

label d5_obs_naeun:

    if d5_obs_naeun:
        "나은이는 아까 봤다."
        jump d5_observation_loop

    $ d5_obs_naeun = True

    "앞자리 친구가 물병을 열다가 물을 조금 흘렸다."
    "나은이는 자기 휴지를 꺼내 건넸다."

    ne "여기."
    ne "공책 젖기 전에 닦아."

    "친구가 고맙다고 했다."
    "나은이는 고개를 끄덕였다."
    "자기 책상 끝에 튄 물은 소매로 닦았다."

    jump d5_observation_loop

label d5_obs_sohee:

    if d5_obs_sohee:
        "소희는 아까 봤다."
        jump d5_observation_loop

    $ d5_obs_sohee = True

    "소희는 자기 옆자리에 공책을 올려두고 있었다."
    "앞자리 친구가 지나가자 바로 손을 흔들었다."

    sh "여기 앉아."
    sh "내가 자리 맡아놨어."

    "친구는 웃었지만 바로 앉지는 않았다."
    "소희는 시무룩하게 공책 모서리를 손끝으로 눌렀다."

    jump d5_observation_loop

label d5_obs_seoyeon:

    if d5_obs_seoyeon:
        "서연이는 아까 봤다."
        jump d5_observation_loop

    $ d5_obs_seoyeon = True

    "서연이는 칠판 앞에 서 있었다."
    "서연이는 지우개로 날짜를 지우고 새로 적었다."
    "옆 친구가 작은 별을 그리자, 서연이가 바로 말했다."

    sy "거긴 선생님이 쓰시는 칸이야."
    sy "낙서하면 지저분해져."

    "옆 친구는 분필을 내려놓고 뒤로 물러섰다."

    jump d5_observation_loop

label d5_first_period_bridge:

    scene bg_classroom_day with dissolve

    "1교시 예비종이 울렸다."
    "아이들이 하나둘 자리에 앉았다."

    "선생님은 교탁 앞으로 오셨다."
    "카드 바구니도 교탁 위에 올려두셨다."

    show t1 at center_stage as teacher with dissolve
    t "오늘은 친구 사랑 주간의 마지막 활동을 할 거예요."

    "선생님이 게시판의 나무 그림을 가리키셨다."

    t "오늘 활동은 마음나무 만들기예요."
    t "잎사귀 카드에 친구에게 전하고 싶은 말을 씁니다."
    t "이번 주에 직접 본 친구들의 행동을 떠올려 보세요."

    hide teacher
    show t1 at center_stage as teacher with dissolve

    t "마음잎에는 두 가지를 넣습니다."
    t "그 친구만의 좋은 점 하나."
    t "그리고 그 친구에게 정말 도움이 될 말 하나."

    hide teacher
    show t2 at center_stage as teacher with dissolve

    t "그냥 '착해', '잘해'처럼 누구에게나 쓸 수 있는 말보다는,"
    t "이번 주에 직접 본 그 친구다운 모습을 떠올려 보세요."

    t "도움이 될 말도 혼내는 말이 아니에요."
    t "그 친구가 듣고 나서 다음엔 이렇게 해봐야겠다고" 
    t "생각할 수 있는 말이면 좋아요."

    hide teacher
    show t1 at center_stage as teacher with dissolve
    t "먼저 누구에게 쓸지 정해봅시다."

    hide teacher with dissolve
    "나는 빈 잎사귀 카드를 내려다보았다."

    $ choice_question_text = "누구에게 마음잎을 써볼까?"
    window hide

    menu:

        "{color=#7DB8FF}지호{/color}에게 마음잎을 쓴다." if d5_obs_jiho:
            window show
            jump d5_leaf_jiho

        "{color=#FF9ACD}하영{/color}에게 마음잎을 쓴다." if d5_obs_hayoung:
            window show
            jump d5_leaf_hayoung

        "{color=#BFA7FF}나은{/color}에게 마음잎을 쓴다." if d5_obs_naeun:
            window show
            jump d5_leaf_naeun

        "{color=#FFCF6E}소희{/color}에게 마음잎을 쓴다." if d5_obs_sohee:
            window show
            jump d5_leaf_sohee

        "{color=#9FE0C5}서연{/color}에게 마음잎을 쓴다." if d5_obs_seoyeon:
            window show
            jump d5_leaf_seoyeon


# ----------------------------------------------------------
# D5 마음잎 조합 — 지호
# ----------------------------------------------------------

label d5_leaf_jiho:
    $ set_bgm(audio.bgm_leaf_activity)

    scene bg_classroom_day with dissolve

    $ d5_leaf_person = "jiho"

    "나는 카드 첫 줄에 지호의 이름을 적었다."

    $ choice_question_text = "지호의 좋은 점으로 무엇을 적을까?"
    window hide

    menu:
        "발표할 때 목소리가 커서 잘 들리는 점.":
            $ d5_leaf_strength = "plain"
            $ d5_leaf_strength_text = "너는 발표할 때 목소리가 커서 잘 들리는 점이 좋아."

        "성격이 시원시원해서 누구든 편하게 대해주는 점.":
            $ d5_leaf_strength = "best"
            $ d5_leaf_strength_text = "너는 성격이 시원시원해서 누구든 어색하지 않게 편하게 대해줘서 좋아."

        "시합에서 어떻게든 이기려고 노력하는 점.":
            $ d5_leaf_strength = "trap"
            $ d5_leaf_strength_text = "너는 게임이나 시합에서 쉽게 물러서지 않고 끝까지 밀어붙이는 점이 좋아."

    $ choice_question_text = "나는 지호에게 어떤 친구가 되고 싶을까?"
    window hide

    menu:

        "너의 편에서 무조건 이길 수 있도록 도와주는 친구.":
            $ d5_leaf_advice = "trap"
            $ d5_leaf_advice_text = "네가 꼭 이기려고 끝까지 밀어붙일 때마다, 나도 네 편에서 같이 힘내는 친구가 되고 싶어."

        "발표할 때 큰 목소리를 응원해주는 친구.":
            $ d5_leaf_advice = "plain"
            $ d5_leaf_advice_text = "네가 발표할 때 큰 목소리로 말하면, 옆에서 잘 듣고 응원해주는 친구가 되고 싶어."

        "같이 웃고, 필요한 말을 솔직하게 말해줄 수 있는 친구.":
            $ d5_leaf_advice = "best"
            $ d5_leaf_advice_text = "너랑 장난칠 때는 같이 재밌게 놀고, 싫은 건 괜찮은 척하지 않고 솔직하게 말하는 친구가 되고 싶어."
    jump d5_leaf_finish
# ----------------------------------------------------------
# D5 마음잎 조합 — 하영
# ----------------------------------------------------------

label d5_leaf_hayoung:
    scene bg_classroom_day with dissolve

    $ d5_leaf_person = "hayoung"

    "나는 하영이의 이름을 적었다."

    $ choice_question_text = "하영이의 좋은 점으로 무엇을 적을까?"
    window hide


    menu:

        "글씨를 예쁘게 쓰고 공책을 깔끔하게 정리하는 점.":
            $ d5_leaf_strength = "plain"
            $ d5_leaf_strength_text = "너는 글씨를 예쁘게 쓰고 공책을 깔끔하게 정리하는 점이 좋아."

        "자신 있게 친구들을 이끌어 주고 칭찬도 잘해주는 점.":
            $ d5_leaf_strength = "best"
            $ d5_leaf_strength_text = "너는 언제나 자신 있게 앞에 서고, 친구들이 잘한 것도 바로 칭찬해줘서 좋아."

        "친구가 없는 자리에서도 그 친구에 대한 이야기를 잘해주는 점.":
            $ d5_leaf_strength = "trap"
            $ d5_leaf_strength_text = "너는 친구가 없는 자리에서도 그 친구가 어떤지 잘 말해줘서, 누구랑 어떻게 지내야 할지 빨리 알 수 있어서 좋아."

    $ choice_question_text = "나는 하영이에게 어떤 친구가 되고 싶을까?"
    window hide

    menu:

        "친구들 이야기가 나오면 같이 맞장구쳐주는 친구.":
            $ d5_leaf_advice = "trap"
            $ d5_leaf_advice_text = "네가 누가 누구랑 싸웠는지, 누가 누구를 싫어하는지 말해주면 나도 같이 듣고 맞장구치는 친구가 되고 싶어."

        "공책 정리를 같이 깔끔하게 하는 친구.":
            $ d5_leaf_advice = "plain"
            $ d5_leaf_advice_text = "앞으로도 공책 정리나 준비물을 같이 깔끔하게 챙기는 친구가 되고 싶어."

        "자리에 없는 친구 이야기는 조심스럽게 생각하는 친구.":
            $ d5_leaf_advice = "best"
            $ d5_leaf_advice_text = "자리에 없는 친구 이야기가 나오면, 나중에 직접 물어보자고 말하는 친구가 되고 싶어."

    jump d5_leaf_finish

# ----------------------------------------------------------
# D5 마음잎 조합 — 나은
# ----------------------------------------------------------
label d5_leaf_naeun:
    scene bg_classroom_day with dissolve

    $ d5_leaf_person = "naeun"

    "나는 나은이의 이름을 적었다."

    $ choice_question_text = "나은이의 좋은 점으로 무엇을 적을까?"
    window hide

    menu:

        "친구가 어려워할 때 조용히 도와주는 점.":
            $ d5_leaf_strength = "best"
            $ d5_leaf_strength_text = "너는 친구가 어려워하면 티 내지 않고 조용히 옆에서 도와줘서 좋아."

        "색연필을 차분하게 잘 쓰고 색칠을 꼼꼼하게 하는 점.":
            $ d5_leaf_strength = "plain"
            $ d5_leaf_strength_text = "너는 색연필을 차분하게 잘 쓰고 색칠을 꼼꼼하게 하는 점이 좋아."

        "부탁하면 싫은 티 안 내고 잘 들어주는 점.":
            $ d5_leaf_strength = "trap"
            $ d5_leaf_strength_text = "너는 부탁하면 싫은 티 안 내고 다 들어줘서 같이 있으면 편해."


    $ choice_question_text = "나는 나은이에게 어떤 친구가 되고 싶을까?"
    window hide

    menu:

        "괜찮은지 먼저 물어봐주는 친구.":
            $ d5_leaf_advice = "best"
            $ d5_leaf_advice_text = "네가 괜찮다고 해도 한 번 더 물어보고, 혼자 다 하지 않게 같이 나눠 하는 친구가 되고 싶어."

        "색칠할 때 옆에서 같이 꼼꼼히 봐주는 친구.":
            $ d5_leaf_advice = "plain"
            $ d5_leaf_advice_text = "앞으로도 색칠이나 만들기를 할 때 옆에서 같이 꼼꼼히 봐주는 친구가 되고 싶어."

        "부탁할 일이 있으면 편하게 말하는 친구.":
            $ d5_leaf_advice = "trap"
            $ d5_leaf_advice_text = "네가 부탁을 잘 들어주니까, 나도 도움이 필요할 때 편하게 부탁하는 친구가 되고 싶어."

    jump d5_leaf_finish
# ----------------------------------------------------------
# D5 마음잎 조합 — 소희
# ----------------------------------------------------------
label d5_leaf_sohee:
    scene bg_classroom_day with dissolve

    $ d5_leaf_person = "sohee"

    "나는 소희의 이름을 적었다."

    $ choice_question_text = "소희의 좋은 점으로 무엇을 적을까?"
    window hide

    menu:
        "좋아하는 마음을 솔직하게 표현해주는 점.":
            $ d5_leaf_strength = "best"
            $ d5_leaf_strength_text = "너는 좋아하는 마음을 숨기지 않고 솔직하게 표현해줘서 좋아."

        "친한 친구와 늘 같이 있으려고 하는 점.":
            $ d5_leaf_strength = "trap"
            $ d5_leaf_strength_text = "너는 친한 친구랑 늘 같이 있으려고 해서, 나를 많이 좋아해주는 것 같아."

        "아침마다 밝게 인사해주는 점.":
            $ d5_leaf_strength = "plain"
            $ d5_leaf_strength_text = "너는 아침마다 밝게 인사해줘서 좋아."

    $ choice_question_text = "나는 소희에게 어떤 친구가 되고 싶을까?"
    window hide

    menu:

        "아침에 서로 밝게 인사하는 친구.":
            $ d5_leaf_advice = "plain"
            $ d5_leaf_advice_text = "앞으로도 아침에 만나면 서로 밝게 인사하는 친구가 되고 싶어."

        "같이 있지 않아도 믿을 수 있는 친구.":
            $ d5_leaf_advice = "best"
            $ d5_leaf_advice_text = "당장 같이 있지 않아도, 서로 멀어진다고 걱정하지 않아도 되는 친구가 되고 싶어."
        
        "속상할 때마다 제일 먼저 들어주는 친구.":
            $ d5_leaf_advice = "trap"
            $ d5_leaf_advice_text = "네가 속상할 때마다, 다른 친구보다 내가 제일 먼저 들어주는 친구가 되고 싶어."

    jump d5_leaf_finish
# ----------------------------------------------------------
# D5 마음잎 조합 — 서연
# ----------------------------------------------------------
label d5_leaf_seoyeon:
    scene bg_classroom_day with dissolve

    $ d5_leaf_person = "seoyeon"

    "나는 서연이의 이름을 적었다."

    $ choice_question_text = "서연이의 좋은 점으로 무엇을 적을까?"
    window hide

    menu:

        "틀린 건 네 말대로 바로 고치게 하는 점.":
            $ d5_leaf_strength = "trap"
            $ d5_leaf_strength_text = "너는 틀린 게 보이면 바로 말해서, 애들이 네 말대로 바로 고치게 하는 점이 좋아."

        "맡은 일을 끝까지 하고 헷갈리지 않게 정리해주는 점.":
            $ d5_leaf_strength = "best"
            $ d5_leaf_strength_text = "너는 맡은 일을 끝까지 하고, 헷갈리는 게 있으면 알아보기 쉽게 정리해줘서 좋아."

        "책상과 물건을 깔끔하게 정리하는 점.":
            $ d5_leaf_strength = "plain"
            $ d5_leaf_strength_text = "너는 책상과 물건을 깔끔하게 정리하는 점이 좋아."

    $ choice_question_text = "나는 서연이에게 어떤 친구가 되고 싶을까?"
    window hide

    menu:

        "책상 정리를 같이 깔끔하게 하는 친구.":
            $ d5_leaf_advice = "plain"
            $ d5_leaf_advice_text = "앞으로도 책상이나 준비물을 같이 깔끔하게 정리하는 친구가 되고 싶어."

        "네가 맞다고 하면 바로 따라주는 친구.":
            $ d5_leaf_advice = "trap"
            $ d5_leaf_advice_text = "헷갈릴 때는 네가 맞다고 하는 대로 바로 따라주는 친구가 되고 싶어."

        "네 마음은 알아주고, 말이 세게 들리면 솔직히 말해주는 친구.":
            $ d5_leaf_advice = "best"
            $ d5_leaf_advice_text = "네가 챙기려던 마음은 알아주고, 말이 세게 들리면 솔직하게 말해주는 친구가 되고 싶어."

    jump d5_leaf_finish

# ----------------------------------------------------------
# D5 마음잎 결과 판정 + 점수 반영 + 반응 분기
# ----------------------------------------------------------

default d5_leaf_result = ""
default d5_leaf_combo = ""
default d5_reaction_tone = "normal"
default d5_reaction_shadow = "normal"
default d5_trap_count = 0

label d5_leaf_finish:

    $ d5_card_success = True

    $ d5_trap_count = 0
    # ------------------------------------------------------
    # 1. 이번 마음잎 조합 판정
    # ------------------------------------------------------


    if d5_leaf_strength == "trap":
        $ d5_trap_count += 1

    if d5_leaf_advice == "trap":
        $ d5_trap_count += 1


    if d5_leaf_strength == "best" and d5_leaf_advice == "best":
        $ d5_leaf_result = "deep_good"
        $ d5_leaf_combo = "best_best"

    elif d5_leaf_strength == "plain" and d5_leaf_advice == "plain":
        $ d5_leaf_result = "plain"
        $ d5_leaf_combo = "plain_plain"

    elif d5_leaf_strength == "trap" and d5_leaf_advice == "trap":
        $ d5_leaf_result = "trap"
        $ d5_leaf_combo = "trap_trap"

    elif d5_leaf_strength == "trap":
        $ d5_leaf_result = "trap"
        $ d5_leaf_combo = "strength_trap"

    elif d5_leaf_advice == "trap":
        $ d5_leaf_result = "trap"
        $ d5_leaf_combo = "advice_trap"

    elif d5_leaf_strength == "best" and d5_leaf_advice == "plain":
        $ d5_leaf_result = "mixed"
        $ d5_leaf_combo = "strength_best_advice_plain"

    elif d5_leaf_strength == "plain" and d5_leaf_advice == "best":
        $ d5_leaf_result = "mixed"
        $ d5_leaf_combo = "strength_plain_advice_best"

    else:
        $ d5_leaf_result = "mixed"
        $ d5_leaf_combo = "mixed"


    if d5_leaf_result == "deep_good":
        $ d5_best_friend_success = True

    
    if d5_leaf_advice == "trap":
        $ add_burnout(1)
 
    # ------------------------------------------------------
    # 2. 인물별 점수 반영 + 반응 온도 판정
    # ------------------------------------------------------

    $ apply_d5_leaf_score(d5_leaf_person, d5_leaf_result, d5_trap_count)

    if like_of(d5_leaf_person) >= 5:
        $ d5_reaction_tone = "close"
    elif like_of(d5_leaf_person) <= 1:
        $ d5_reaction_tone = "distant"
    else:
        $ d5_reaction_tone = "normal"

    if neg_of(d5_leaf_person) >= 3:
        $ d5_reaction_shadow = "high"
    else:
        $ d5_reaction_shadow = "normal"

    jump d5_leaf_share_intro
# ----------------------------------------------------------
# D5 마음잎 반응 라우터
# ----------------------------------------------------------

label d5_leaf_share_intro:

    if d5_leaf_person == "jiho":
        jump d5_react_jiho
    elif d5_leaf_person == "hayoung":
        jump d5_react_hayoung
    elif d5_leaf_person == "naeun":
        jump d5_react_naeun
    elif d5_leaf_person == "sohee":
        jump d5_react_sohee
    elif d5_leaf_person == "seoyeon":
        jump d5_react_seoyeon
    else:
        jump d5_after_leaf_reaction

# ----------------------------------------------------------
# D5 마음잎 반응 — 지호
# ----------------------------------------------------------
label d5_react_jiho:
    scene bg_classroom_day with fade

    "지호는 마음잎을 받아들더니, 바로 펼쳐 읽기 시작했다."

    if d5_leaf_combo == "best_best":

        show jh5 at center_stage as jiho with dissolve

        "지호는 좋은 점 부분을 읽다가 눈을 조금 크게 떴다."

        jh "성격이 시원시원해서 누구든 편하게 대해주는 점?"

        "지호는 카드 끝을 손가락으로 톡톡 쳤다."

        jh "나는 그냥 별생각 없이 말 거는 건데."
        jh "그게 좋은 점으로 보였구나!"

        "지호는 다음 줄을 읽다가 말이 잠깐 멈췄다."

        hide jiho
        show jh4 at center_stage as jiho with dissolve

        jh "재밌게 놀면서도 솔직하게 말하는 친구?"

        "지호는 카드에서 눈을 떼고 내 쪽을 봤다."
        hide jiho
        show jh3 at center_stage as jiho with dissolve
        jh "음, 그건 좋다."
        jh "싫은데 괜찮은 척하면 나도 잘 모르잖아."

        hide jiho
        show jh5 at center_stage as jiho with dissolve

        jh "그래, 바로 말해줘."
        jh "나도 그게 더 편해."

        if d5_reaction_tone == "close":
            jh "그냥 좋은 말만 쓴 게 아니네?"
            jh "그래서 더 좋다!"

        elif d5_reaction_tone == "distant":
            hide jiho
            show jh5 at center_stage as jiho with dissolve
            jh "네가 이런 걸 보고 있었을 줄은 몰랐네."
            jh "기억해둘게."

    elif d5_leaf_combo == "plain_plain":

        show jh1 at center_stage as jiho with dissolve

        "지호는 마음잎을 읽고 고개를 살짝 기울였다."

        jh "발표할 때 목소리가 커서 잘 들리는 점."
        jh "앞으로도 발표할 때 큰 목소리로 말해달라."

        "지호는 카드를 한 번 더 훑어봤다."

        jh "음..."
        jh "근데 이건 나 말고도 목소리 큰 애한테 다 쓸 수 있지 않나?"

        if d5_reaction_tone == "close":
            jh "그래도 네가 써준 거니까 갖고 있을게."
            jh "아무튼 고마워."

        elif d5_reaction_tone == "distant":
            jh "뭐, 그냥 평범한 말 같은데."
            jh "아무튼 고마워."

    elif d5_leaf_combo == "strength_trap":

        show jh1 at center_stage as jiho with dissolve

        "지호는 좋은 점 부분을 읽자마자 씩 웃었다."
        "카드를 든 손이 조금 올라갔다."

        jh "시합에서 꼭 이기려고 노력하는 점?"
        jh "그치. 시합은 이기려고 해야 재밌지."

        jh "다음에도 그렇게 해야겠다."

        if d5_reaction_shadow == "high":
            "지호는 기분 좋다는 듯 활짝 웃었다."

    elif d5_leaf_combo == "advice_trap":

        show jh1 at center_stage as jiho with dissolve

        "지호는 바라는 점 부분을 읽고 바로 고개를 끄덕였다."

        jh "꼭 이기려고 끝까지 밀어붙이면 더 힘이 난다고?"
        jh "그래?"

        hide jiho
        show jh2 at center_stage as jiho with dissolve

        jh "그럼 다음에도 끝까지 밀어붙여 봐야겠다."

        "지호는 마음잎을 가볍게 흔들었다."

        if d5_reaction_shadow == "high":
            "지호는 옆 친구 쪽을 보며 장난스럽게 웃었다."

    elif d5_leaf_combo == "trap_trap":

        show jh1 at center_stage as jiho with dissolve

        "지호는 마음잎을 읽다가 바로 웃음을 터뜨렸다."

        jh "야, 너 뭘 좀 아네."
        jh "시합은 끝까지 밀어붙여야 재밌지."

        jh "다음에도 내가 제대로 해봐야겠다."

        "지호는 마음잎을 책상 위에 올려두었다."
        "입꼬리는 계속 올라가 있었다."

    elif d5_leaf_combo == "strength_best_advice_plain":

        show jh1 at center_stage as jiho with dissolve

        jh "성격이 시원시원해서 누구든 편하게 대해주는 점?"
        jh "그냥 말 거는 건데, 그렇게 봐준 거면 기분 좋네."

        "지호는 다음 줄을 읽고 고개를 조금 기울였다."

        jh "발표할 때 큰 목소리로 말해달라는 것도 고마워."
        jh "근데 이건 나 아니어도 해줄 수 있는 칭찬같은데."

        if d5_reaction_tone == "close":
            jh "그래도 앞에 쓴 말은 좋네."

    elif d5_leaf_combo == "strength_plain_advice_best":

        show jh5 at center_stage as jiho with dissolve

        jh "목소리 크다는 건 뭐...발표할 때 잘 들리긴 하지."

        "그러다 바라는 점 부분에서 손이 멈췄다."

        jh "재밌게 놀면서도 솔직하게 말하는 친구?"

        hide jiho
        show jh4 at center_stage as jiho with dissolve

        jh "오..."

        "지호는 카드 아래쪽을 엄지손가락으로 문질렀다."

        jh "그래, 바로 말해줘."
        jh "사실 난 그게 더 편해."

        if d5_reaction_tone == "close":
            jh "마지막 말 기억해둘게. 고마워."

    else:

        show jh5 at center_stage as jiho with dissolve

        "지호는 마음잎을 읽고 고개를 갸웃했다."

        jh "어떤 건 내 얘기 같고, 어떤 건 그냥 칭찬 같아."
        jh "그래도 써줘서 고마워."

    "지호는 마음잎을 들고 자기 자리로 돌아갔다."

    jump d5_after_leaf_reaction
# ----------------------------------------------------------
# D5 마음잎 반응 — 하영
# ----------------------------------------------------------

label d5_react_hayoung:

    scene bg_classroom_day with fade

    "하영이는 마음잎을 받아들고, 글자를 천천히 읽었다."

    if d5_leaf_combo == "best_best":

        show h5 at center_stage as hayoung with dissolve

        "하영이는 좋은 점 부분에서 손을 멈췄다."

        hy "자신 있게 앞에 서고,"
        hy "친구들이 잘한 걸 바로 칭찬해주는 점?"

        "하영이는 마음잎 끝을 손가락으로 꾹 눌렀다."

        hy "내가 그런가?"

        hide hayoung
        show h1 at center_stage as hayoung with dissolve

        hy "근데 칭찬 잘해준다고 쓴 건 좋다."
        hy "나 애들이 잘한 거 보면 바로 말해주려고 하거든."
        hy "그래야 애들도 더 하고 싶어 하니까."

        hide hayoung
        show h6 at center_stage as hayoung with dissolve

        "하영이는 바라는 점 부분을 읽고 바로 반응하지 않았다."

        hy "친구 이야기를 들을 때,"
        hy "한쪽 말만 바로 믿지 않는 친구?"

        "하영이는 교실 뒤쪽 친구들 쪽을 한 번 봤다."
        "그리고 다시 마음잎을 내려다봤다."

        hy "음..."

        hy "사실 가끔 누구 말 들으면,"
        hy "바로 아, 그런 애구나 하고 생각할 때 있어."

        hide hayoung
        show h3 at center_stage as hayoung with dissolve

        hy "근데 다른 애 말도 들어보면 다를 수 있으니까."
        hy "내가 직접 본 것도 생각해야 하고."

        if d5_reaction_tone == "close":
            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "내 생각 많이 하고 썼구나?"
            hy "나도 내가 어땠는지 생각하게 되네."

        elif d5_reaction_tone == "distant":
            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "네가 이런 걸 봤을 줄은 몰랐어."
            hy "조금 놀랐는데. 무슨 말인지 알겠어."

    elif d5_leaf_combo == "plain_plain":

        show h4 at center_stage as hayoung with dissolve

        "하영이는 마음잎을 읽고 작게 웃었다."

        hy "글씨를 예쁘게 쓰고 공책을 깔끔하게 정리하는 점이 좋고."
        hy "공책 정리를 같이 깔끔하게 하는 친구가 되어주고 싶다고...?"

        "하영이는 마음잎을 한 번 더 훑어봤다."

        hy "고마워."
        hy "근데, 공책 깨끗한 애한테는 다 쓸 수 있는 칭찬 아닌가 싶긴 해."

        if d5_reaction_tone == "close":
            hy "그래도 네가 써준 거니까 갖고 있을게."
            hy "글씨도 예쁘게 써줬네."

        elif d5_reaction_tone == "distant":
            hy "그냥 무난한 칭찬 같아."
            hy "아무튼 고마워."

    elif d5_leaf_combo == "strength_trap":

        show h5 at center_stage as hayoung with dissolve

        "하영이는 좋은 점 부분을 읽자마자 입꼬리를 살짝 올렸다."

        hy "없는 자리에서도 친구들 이야기를 잘해주는 점?"

        hide hayoung
        show h4 at center_stage as hayoung with dissolve
        hy "맞아 내가 친구들 얘기를 많이 잘 알고 있긴 해."
        hy "너도 누가 누구랑 안 맞는지 알고 있으면 편할걸."
        hy "내가 앞으로도 많이 알려줄게."

        if d5_reaction_shadow == "high":
            "하영이는 옆자리 친구들 쪽을 한 번 보고 작게 웃었다."

    elif d5_leaf_combo == "advice_trap":

        show h4 at center_stage as hayoung with dissolve

        "하영이는 바라는 점 부분을 읽고 눈썹을 살짝 올렸다."

        hy "친구들 이야기를 들으면 같이 맞장구치는 친구?"
        hy "아."

        "하영이는 바로 웃었다."

        hy "그럼 내가 누구 얘기하면 내 편 들어 준다는 거지?"
        hy "좋지. 앞으로도 내가 말해줄게."

        hide hayoung
        show h5 at center_stage as hayoung with dissolve

        hy "너도 들은 거 있으면 나한테 먼저 말해줘."

        if d5_reaction_shadow == "high":
            "하영이는 마음잎을 손끝으로 톡톡 두드렸다."
            "표정이 조금 더 밝아졌다."

    elif d5_leaf_combo == "trap_trap":

        show h4 at center_stage as hayoung with dissolve

        "하영이는 마음잎을 끝까지 읽고 만족스러운 얼굴을 했다."

        hy "없는 자리에서도 친구들 이야기를 잘해주는 점이 좋고."
        hy "친구들 이야기를 들으면 같이 맞장구치는 친구가 되어주고 싶다라..."

        hide hayoung
        show h5 at center_stage as hayoung with dissolve
        hy "너도 나랑 생각이 비슷하구나?"
        hy "맞아, 그런 얘기 알아두면 편해."

        hy "다음에 너도 뭐 들으면 나한테 말해줘."
        hy "내가 들은 것도 말해줄테니까."

    elif d5_leaf_combo == "strength_best_advice_plain":

        show h4 at center_stage as hayoung with dissolve

        "하영이는 좋은 점 부분을 읽고 눈을 조금 크게 떴다."

        hy "자신 있게 앞에 서고,"
        hy "친구들이 잘한 걸 바로 칭찬해주는 점?"

        "하영이는 마음잎을 조금 가까이 들었다."

        hide hayoung
        show h1 at center_stage as hayoung with dissolve

        hy "칭찬 잘해준다고 쓴 건 좋다."
        hy "나 애들이 잘한 건 바로 말해주려고 하거든."

        "하영이는 마음잎 끝을 만지작거렸다."

        hy "그 말은 고마워."
        hy "이건 좀 기억날 것 같아."

        "하영이는 뒤쪽 문장을 읽고 작게 웃었다."

        hy "공책 정리는 고맙긴 한데."
        hy "뭐, 나한테 한 칭찬 맞나 싶네."

        if d5_reaction_tone == "close":
            hy "그래도 앞에 쓴 말은 진짜 나한테 쓴 것 같다."
            hy "그건 마음에 들어."

    elif d5_leaf_combo == "strength_plain_advice_best":

        show h4 at center_stage as hayoung with dissolve

        "하영이는 처음에는 가볍게 읽었다."

        hy "글씨랑 공책 정리."
        hy "이건 그냥 무난하네. 누구한테나 할 수 있는 칭찬 아닌가...?"

        "그러다 바라는 점 부분에서 말이 멈췄다."

        hide hayoung
        show h3 at center_stage as hayoung with dissolve

        hy "친구 이야기를 들을 때,"
        hy "한쪽 말만 바로 믿지 않는 친구?"

        "하영이는 마음잎을 든 손을 조금 내렸다."
        "웃던 얼굴이 조금 사라졌다."

        hy "이건 나한테 하는 말 맞네."

        "하영이는 잠깐 책상 위를 봤다."

        hy "나도 누구 말 들으면,"
        hy "바로 아, 그런 애구나 할 때 있어."

        hy "근데 다른 애 말은 다를 수도 있잖아."
        hy "내가 직접 본 것도 있고."

        "하영이는 마음잎을 다시 읽었다."

        hy "알겠어."
        hy "다음엔 한쪽 말만 듣고 바로 믿지는 않을게."
        hy "다른 애 말도 들어보고 생각해볼게."

        if d5_reaction_tone == "close":
            hy "앞부분은 평범했는데, 뒤에는 제대로 봤네."
            hy "아무튼 고마워."

    else:

        show h5 at center_stage as hayoung with dissolve

        "하영이는 마음잎을 읽고 고개를 살짝 기울였다."

        hy "좋은 말도 있고, 좀 걸리는 말도 있네."
        hy "어떤 건 나한테 하는 말 같고, 어떤 건 그냥 칭찬 같아."
        hy "그래도 나한테 써줘서 고마워."

    "하영이는 마음잎을 접지 않고 책상 위에 올려두었다."

    jump d5_after_leaf_reaction
# ----------------------------------------------------------
# D5 마음잎 반응 — 나은
# ----------------------------------------------------------
label d5_react_naeun:

    scene bg_classroom_day with fade

    "나은이는 마음잎을 두 손으로 받아들었다."

    if d5_leaf_combo == "best_best":

        show ne5 at center_stage as naeun with dissolve

        "나은이는 좋은 점 부분을 읽고도 바로 말하지 않았다."

        ne "친구가 어려워할 때 조용히 도와주는 점..."

        "나은이는 마음잎 모서리를 엄지손가락으로 천천히 눌렀다."

        ne "나는 그냥 조금 신경 쓴 것뿐인데."

        hide naeun
        show ne4 at center_stage as naeun with dissolve

        ne "그걸 좋은 점이라고 써주니까..."
        ne "쑥스러운데 기분 좋다."

        "나은이는 다음 줄을 다시 읽었다."

        hide naeun
        show ne1 at center_stage as naeun with dissolve

        ne "괜찮은지 먼저 물어봐주는 친구..."
        ne "내가 괜찮다고 해도 한 번 더 물어봐준다고?"

        "나은이는 마음잎을 한참 내려다봤다."

        ne "나 괜찮다고 자주 말하지만."
        ne "진짜 괜찮아서 그런 게 아닐 때도 있긴 해."

        hide naeun
        show ne5 at center_stage as naeun with dissolve

        ne "그럴 때 한 번 더 물어봐주면..."
        ne "고마울 것 같아."

        if d5_reaction_tone == "close":
            hide naeun
            show ne4 at center_stage as naeun with dissolve

            ne "네가 써준 거 읽으니까"
            ne "조금 위로받는 기분이야."

        elif d5_reaction_tone == "distant":
            hide naeun
            show ne5 at center_stage as naeun with dissolve

            ne "아직 솔직하게 말하는 건 좀 어렵긴 해."
            ne "그래도 네가 해준 말은 잊지 않을게."


    elif d5_leaf_combo == "plain_plain":

        show ne5 at center_stage as naeun with dissolve

        "나은이는 마음잎을 읽고 작게 고개를 끄덕였다."

        ne "색연필을 차분하게 잘 쓰고,"
        ne "색칠을 꼼꼼하게 하는 점."

        "나은이는 다음 줄도 읽었다."

        ne "색칠할 때 옆에서 같이 꼼꼼히 봐주는 친구."

        "나은이는 살짝 웃었다."

        ne "고마워."
        ne "근데 나 말고도 그림 잘 그리는 애는 많아서..."

        if d5_reaction_tone == "close":
            ne "그래도 네가 써준 거니까 잘 넣어둘게."

        elif d5_reaction_tone == "distant":
            ne "조금 어색하긴 한데 고마워."


    elif d5_leaf_combo == "strength_trap":

        show ne1 at center_stage as naeun with dissolve

        "나은이는 좋은 점 부분을 읽고 시선을 아래로 내렸다."

        ne "부탁하면 싫은 티 안 내고 다 들어주는 점..."

        "나은이는 마음잎 끝을 손끝으로 만졌다."

        ne "그게 좋은 점인가?"

        "나은이는 바로 고개를 들지 않았다."

        ne "내가 들어주면 빨리 끝나긴 해."
        ne "애들도 더 말 안 해도 되고."

        hide naeun
        show ne2 at center_stage as naeun with dissolve

        ne "그래서..."
        ne "그렇게 보였나 봐."

        if d5_reaction_shadow == "high":
            "나은이는 카드 모서리를 손끝으로 계속 눌렀다."
            "종이 끝이 살짝 휘었다."


    elif d5_leaf_combo == "advice_trap":

        show ne1 at center_stage as naeun with dissolve

        "나은이는 바라는 점 부분을 읽고 눈을 내렸다."

        ne "부탁할 일이 있으면 편하게 말하는 친구..."

        "나은이는 아주 작게 고개를 끄덕였다."

        ne "아..."
        ne "그래, 부탁할 거 있으면 말해."

        hide naeun
        show ne2 at center_stage as naeun with dissolve

        "나은이는 마음잎 끝을 손안에서 살짝 접었다."

        if d5_reaction_shadow == "high":
            "나은이는 마음잎을 바로 넣지 못했다."
            "책상 위에 내려놓았다가 다시 집어 들었다."


    elif d5_leaf_combo == "trap_trap":

        show ne1 at center_stage as naeun with dissolve

        "나은이는 마음잎을 오래 내려다보았다."

        ne "부탁하면 싫은 티 안 내고 다 들어주는 점."
        ne "부탁할 일이 있으면 편하게 말하는 친구."

        "나은이는 천천히 숨을 들이마셨다."

        ne "응..."
        ne "그게 좋은 점으로 보였구나."

        "나은이는 마음잎을 접지 않았다."
        "두 손으로 잡은 종이가 조금 구겨졌다."

        hide naeun
        show ne2 at center_stage as naeun with dissolve

        ne "그래도..."
        ne "고마워."


    elif d5_leaf_combo == "strength_best_advice_plain":

        show ne5 at center_stage as naeun with dissolve

        "나은이는 좋은 점 부분을 읽고 눈을 조금 크게 떴다."

        ne "친구가 어려워할 때 조용히 도와주는 점..."

        hide naeun
        show ne4 at center_stage as naeun with dissolve

        ne "그렇게 봐줘서 고마워."

        "나은이는 뒤쪽 문장을 읽고 작게 웃었다."

        ne "색칠할 때 옆에서 같이 꼼꼼히 봐주는 친구..."
        ne "그것도 고마워."
        ne "근데 앞에 쓴 말이 더 내 얘기 같아."

        if d5_reaction_tone == "close":
            ne "앞에 쓴 말은..."
            ne "조금 오래 생각날 것 같아."


    elif d5_leaf_combo == "strength_plain_advice_best":

        show ne5 at center_stage as naeun with dissolve

        "나은이는 색칠 이야기를 먼저 읽었다."

        ne "색연필을 차분하게 쓰고,"
        ne "색칠을 꼼꼼하게 하는 점."

        "나은이는 작게 고개를 끄덕였다."

        ne "고마워."

        "그러다 바라는 점 부분에서 손이 멈췄다."

        hide naeun
        show ne1 at center_stage as naeun with dissolve

        ne "괜찮은지 먼저 물어봐주는 친구..."

        "나은이는 그 줄을 한 번 더 읽었다."

        ne "이건... 나한테 하는 말 맞는 것 같아."

        "나은이는 마음잎을 천천히 내려다봤다."

        ne "나 괜찮다고 자주 말하니까."
        ne "근데 괜찮은지 먼저 물어봐주면..."
        ne "고마울 것 같아."

        if d5_reaction_tone == "close":
            hide naeun
            show ne4 at center_stage as naeun with dissolve

            ne "그렇게 써줘서..."
            ne "조금 더 용기가 생겼어."

    else:

        show ne4 at center_stage as naeun with dissolve

        "나은이는 마음잎을 읽고 잠깐 눈을 내렸다."

        ne "좋은 말 고마워."
        ne "어떤 말은 좋고,"
        ne "어떤 말은 조금 어렵네."

        "나은이는 마음잎을 두 손으로 한 번 더 잡았다."

        ne "그래도..."
        ne "나한테 써줘서 고마워."

    "나은이는 마음잎을 종합장 사이에 조심스럽게 끼워 넣었다."

    jump d5_after_leaf_reaction
# ----------------------------------------------------------
# D5 마음잎 반응 — 소희
# ----------------------------------------------------------

label d5_react_sohee:
    scene bg_classroom_day with fade

    "소희는 마음잎을 받자마자 바로 펼쳤다."

    if d5_leaf_combo == "best_best":

        show sh4 at center_stage as sohee with dissolve

        "소희는 좋은 점 부분을 읽자마자 환하게 웃었다."

        sh "좋아하는 마음을 솔직하게 표현하는 점?"
        sh "그거 좋다."
        sh "내가 좋으면 좋다고 말하는 거, 괜찮은 거지?"

        "소희는 마음잎을 가슴 가까이에 들었다."
        "그러다 다음 줄에서 조금 조용해졌다."

        hide sohee
        show sh3 at center_stage as sohee with dissolve

        sh "같이 있지 않아도 믿을 수 있는 친구..."
        sh "당장 옆에 없어도 친구라는 거지?"

        "소희는 마음잎 끝을 손가락으로 눌렀다."

        sh "사실, 그게 잘 안 될 때가 많아."
        sh "친구가 다른 애랑 있으면,"
        sh "나랑은 덜 친해진 건가 싶어서."

        hide sohee
        show sh1 at center_stage as sohee with dissolve

        sh "그래도..."
        sh "바로 걱정하지는 않게 해볼게."
        sh "조금 불안해도."

        if d5_reaction_tone == "close":
            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "네가 이렇게 써주니까 조금 안심돼."
            sh "믿어도 된다는 말 같아서 좋아."

        elif d5_reaction_tone == "distant":
            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "아직은 조금 어색하게 느껴져."
            sh "그래도 무슨 말인지는 알 것 같아."
            sh "고마워."

    elif d5_leaf_combo == "plain_plain":

        show sh1 at center_stage as sohee with dissolve

        "소희는 마음잎을 읽고 금방 웃었다."

        sh "아침마다 밝게 인사해주는 점."
        sh "아침에 서로 밝게 인사하는 친구."

        "소희는 고개를 작게 끄덕였다."

        sh "고마워."
        sh "인사 칭찬도 좋긴 해."

        hide sohee
        show sh5 at center_stage as sohee with dissolve

        sh "근데 이건 나 말고도,"
        sh "인사 잘하는 애한테는 다 쓸 수 있을 것 같아."

        hide sohee
        show sh2 at center_stage as sohee with dissolve

        sh "그래도 칭찬은 칭찬이니까 좋아."

    elif d5_leaf_combo == "strength_trap":

        show sh4 at center_stage as sohee with dissolve

        "소희는 좋은 점 부분을 읽자마자 얼굴이 밝아졌다."

        sh "친한 친구랑 늘 같이 있으려고 하는 점?"
        sh "맞아."
        sh "나는 친하면 같이 있고 싶어."

        hide sohee
        show sh1 at center_stage as sohee with dissolve

        sh "그만큼 좋아한다는 뜻이잖아."
        sh "계속 같이 있고 싶은 게 나쁜 건 아니지?"
        sh "그걸 좋게 봐줘서 기분 좋아."

        "소희는 마음잎을 가슴 가까이에 들었다."

        if d5_reaction_shadow == "high":
            "소희는 마음잎을 예쁘게 접었다."

    elif d5_leaf_combo == "advice_trap":

        show sh1 at center_stage as sohee with dissolve

        "소희는 바라는 점 부분을 읽고 눈을 반짝였다."

        sh "속상할 때마다 제일 먼저 들어주는 친구?"
        sh "제일 먼저?"

        hide sohee
        show sh4 at center_stage as sohee with dissolve

        sh "그 말 너무 좋다."
        sh "내가 친구들 중에 제일 우선이라는 거잖아."


        if d5_reaction_shadow == "high":
            "소희는 마음잎을 예쁘게 접었다."

    elif d5_leaf_combo == "trap_trap":

        show sh4 at center_stage as sohee with dissolve

        "소희는 마음잎을 읽자마자 환하게 웃었다."

        sh "친한 친구랑 늘 같이 있으려고 하는 점."
        sh "속상할 때마다 제일 먼저 들어주는 친구."

        hide sohee
        show sh1 at center_stage as sohee with dissolve

        sh "나 이런 말 좋아."
        sh "역시 너도 나를 제일 친한 친구로 생각하는 거지?"
        sh "그럼 너도 속상한거 있음 나한테 제일 먼저 말해줘야 해!"

    elif d5_leaf_combo == "strength_best_advice_plain":

        show sh4 at center_stage as sohee with dissolve

        "소희는 좋은 점 부분을 읽고 활짝 웃었다."

        sh "좋아하는 마음을 솔직하게 표현하는 점?"
        sh "그거 나한테 하는 말 맞지?"
        sh "내가 좋으면 좋다고 말하잖아."

        "소희는 마음잎을 살짝 흔들었다."

        sh "그걸 좋게 봐줘서 기분 좋아."

        "소희는 뒤쪽 문장을 읽고 고개를 끄덕였다."

        sh "아침에 서로 밝게 인사하는 친구."
        sh "이것도 고마워."
        sh "근데 앞에 쓴 말이 더 내 얘기 같아."

        if d5_reaction_tone == "close":
            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "좋아한다고 말하는 걸 이상하게 보지 않은 것 같아서 좋아."

    elif d5_leaf_combo == "strength_plain_advice_best":

        show sh1 at center_stage as sohee with dissolve

        "소희는 인사 이야기를 읽고 가볍게 웃었다."

        sh "아침마다 밝게 인사해주는 점."
        sh "응, 고마워."

        hide sohee
        show sh5 at center_stage as sohee with dissolve

        sh "근데 이건 좀 그냥 칭찬 같아."

        "소희는 바라는 점 부분에서 손을 멈췄다."

        hide sohee
        show sh3 at center_stage as sohee with dissolve

        sh "같이 있지 않아도 믿을 수 있는 친구..."

        "소희는 마음잎 끝을 꾹 눌렀다."
        sh "맞아, 내가 가끔 걱정하니까."

        sh "친구가 다른 애랑 논다고,"
        sh "나를 싫어하는 건 아니라는 거지?"

        hide sohee
        show sh1 at center_stage as sohee with dissolve

        sh "그 말 기억해 볼게. 고마워."

    else:

        show sh4 at center_stage as sohee with dissolve

        "소희는 마음잎을 읽고 활짝 웃다가, 중간에 잠깐 멈췄다."

        sh "좋은 말인 건 알겠어."

        hide sohee
        show sh3 at center_stage as sohee with dissolve

        sh "근데 어떤 말은..."
        sh "내가 들으라고 쓴 말 같아."
        sh "고마워."
        sh "나한테 써줬다니, 기뻐."

    "소희는 마음잎을 가방 앞주머니에 조심히 넣었다."

    jump d5_after_leaf_reaction
# ----------------------------------------------------------
# D5 마음잎 반응 — 서연
# ----------------------------------------------------------

label d5_react_seoyeon:

    scene bg_classroom_day with fade

    "서연이는 마음잎을 받아들고 천천히 읽었다."

    if d5_leaf_combo == "best_best":

        show sy2 at center_stage as seoyeon with dissolve

        sy "맡은 일을 끝까지 하고,"
        sy "헷갈리는 게 있으면 알아보기 쉽게 정리해주는 점."

        "서연이는 마음잎을 반듯하게 들고 있었다."

        sy "그렇게 봤구나."
        sy "나는 당연히 맡은 건 끝까지 해야 한다고 생각했어."

        hide seoyeon
        show sy5 at center_stage as seoyeon with dissolve

        sy "그래도 이렇게 써주니까 고마워."

        "서연이는 다음 줄을 읽고 잠깐 조용해졌다."

        hide seoyeon
        show sy2 at center_stage as seoyeon with dissolve

        sy "내가 딱 잘라 말할 때도,"
        sy "나쁘게 말하려던 게 아니라,"
        sy "뭘 챙기려고 한 건지 먼저 물어봐주는 친구."

        "서연이는 입술을 살짝 다물었다."

        sy "이건..."
        sy "나한테 하는 말 맞네."

        hide seoyeon
        show sy5 at center_stage as seoyeon with dissolve

        sy "바로 서운해하지 않고,"
        sy "왜 그렇게 말했는지 물어봐준다니 좋다."
        sy "나도 설명해줄 수 있으니까."

        if d5_reaction_tone == "close":
            sy "그냥 좋은 말만 쓴 건 아닌 것 같아."
            sy "내가 어떻게 말하는지 보고 쓴 말 같아."
            sy "그래서 더 기억날 것 같아."

        elif d5_reaction_tone == "distant":
            sy "네가 나를 이렇게 보고 있었던 건 조금 뜻밖인데."
            sy "그래도... 고마워."

    elif d5_leaf_combo == "plain_plain":

        show sy3 at center_stage as seoyeon with dissolve

        "서연이는 마음잎을 읽고 고개를 작게 끄덕였다."

        sy "책상과 물건을 깔끔하게 정리하는 점."
        sy "책상 정리를 같이 깔끔하게 하는 친구."

        "서연이는 카드를 한 번 더 확인했다."

        sy "고마워. 틀린 말은 아니지."

        hide seoyeon
        show sy2 at center_stage as seoyeon with dissolve

        sy "근데 이건 나 말고도,"
        sy "정리 잘하는 친구한테는 쓸 수 있을 것 같아."

        if d5_reaction_tone == "close":
            sy "그래도 네가 써준 거니까 받아둘게."

        elif d5_reaction_tone == "distant":
            sy "뭐, 무난한 칭찬이네."


    elif d5_leaf_combo == "strength_trap":

        show sy2 at center_stage as seoyeon with dissolve

        "서연이는 좋은 점 부분을 읽고 바로 고개를 들었다."

        sy "틀린 건 내 말대로 바로 고치게 하는 점."
        sy "음."

        "서연이는 마음잎 아래쪽을 손끝으로 짚었다."

        sy "틀린 게 보이면 고쳐야 하니까."

        hide seoyeon
        show sy3 at center_stage as seoyeon with dissolve

        sy "그래서 바로 말하는 건데."
        sy "내 말대로 고치면 더 나아지긴 해."

        "서연이는 마음잎을 책상 위에 반듯하게 내려놓았다."

        if d5_reaction_shadow == "high":
            "서연이는 카드 모서리를 맞추듯 손끝으로 정리했다."


    elif d5_leaf_combo == "advice_trap":

        show sy2 at center_stage as seoyeon with dissolve

        "서연이는 바라는 점 부분을 읽고 고개를 끄덕였다."

        sy "내가 맞다고 하는 대로 바로 따라주는 친구."
        sy "그건 내가 편하긴 하겠다."
        sy "내가 말하면 바로 따라와 주는 거니까."

        hide seoyeon
        show sy1 at center_stage as seoyeon with dissolve

        "서연이는 마음잎을 반듯하게 폈다."

        sy "다음에도 내가 잘못된건 바로 말해줄게."

        if d5_reaction_shadow == "high":
            "서연이는 다른 친구들 쪽을 한 번 보고 다시 카드를 봤다."

    elif d5_leaf_combo == "trap_trap":

        show sy1 at center_stage as seoyeon with dissolve

        "서연이는 마음잎을 끝까지 읽고 바로 고개를 끄덕였다."

        sy "틀린 건 내 말대로 바로 고치게 하는 점."
        sy "헷갈릴 때는 내가 맞다고 하는 대로 바로 따라주는 친구."

        hide seoyeon
        show sy3 at center_stage as seoyeon with dissolve

        sy "뭐, 좋네."

        sy "이상한 데가 보이면 고쳐야 하고,"
        sy "헷갈리면 누군가는 정해야 하잖아."
        sy "그래도 너는 내 말이 다 맞다고 생각하는구나."


    elif d5_leaf_combo == "strength_best_advice_plain":

        show sy5 at center_stage as seoyeon with dissolve

        "서연이는 좋은 점 부분을 읽고 조금 느리게 고개를 끄덕였다."

        sy "맡은 일을 끝까지 하고,"
        sy "헷갈리지 않게 정리해주는 점."

        "서연이는 마음잎을 조금 가까이 들었다."

        sy "고마워."

        hide seoyeon
        show sy2 at center_stage as seoyeon with dissolve

        sy "나는 당연하게 생각한 일을 한것 뿐인데"
        sy "그걸 좋게 봤다니 기분 좋네."

        "서연이는 뒤쪽 문장을 읽었다."

        sy "책상 정리 이야기는 다른 애들한테도 할 수 있는 말 같지만."
        sy "뭐, 그래도 고마워."

        if d5_reaction_tone == "close":
            sy "앞에 쓴 말은 꽤 마음에 들어."


    elif d5_leaf_combo == "strength_plain_advice_best":

        show sy5 at center_stage as seoyeon with dissolve

        "서연이는 처음에는 담담하게 읽었다."

        sy "책상과 물건을 깔끔하게 정리하는 점."
        sy "응. 틀린 말은 아니야."

        hide seoyeon
        show sy2 at center_stage as seoyeon with dissolve

        sy "근데 이건 다른 애들도 해당되는 말 아닌가 싶네."

        "그러다 바라는 점 부분에서 손가락이 멈췄다."

        sy "내가 딱 잘라 말할 때도,"
        sy "나쁘게 말하려던 게 아니라,"
        sy "뭘 챙기려고 한 건지 먼저 물어봐주는 친구."

        "서연이는 그 줄을 한 번 더 읽었다."

        sy "이건 나한테 하는 말 맞네."

        hide seoyeon
        show sy3 at center_stage as seoyeon with dissolve

        sy "내가 바로 말하면,"
        sy "애들이 서운해할 때도 있겠지."

        hide seoyeon
        show sy5 at center_stage as seoyeon with dissolve

        sy "그때 왜 그렇게 말했는지 물어봐주면,"
        sy "나도 설명할 수 있을 것 같아. 고마워."

        if d5_reaction_tone == "close":
            sy "앞부분보다 뒤쪽 말이 더 나한테 맞는 것 같아."
            sy "그건 기억해둘게. 고마워."


    else:

        show sy2 at center_stage as seoyeon with dissolve

        "서연이는 마음잎을 내려다보며 잠시 말이 없었다."

        sy "좋은 말도 있고,"
        sy "조금 생각하게 되는 말도 있네."

        hide seoyeon
        show sy5 at center_stage as seoyeon with dissolve

        sy "아무튼 나한테 써줘서 고마워."

    "서연이는 마음잎 카드를 접지 않고 책상 위에 올려놓았다."

    jump d5_after_leaf_reaction

label d5_after_leaf_reaction:
    $ set_bgm(audio.bgm_daily_morning)

    scene bg_classroom_day with dissolve

    "마음잎을 전한 뒤, 교실이 다시 조금 시끄러워졌다."
    "아이들은 받은 카드를 책상 위에 올려두거나 가방에 넣었다."

    "종례가 끝나자 아이들은 하나둘 자리에서 일어났다."
    "복도 쪽에서는 벌써 주말에 뭐 할지 이야기하는 소리가 들렸다."

    jump d5_weekend_offers

label d5_weekend_offers:

    scene bg_corridor_day with fade

    if not d5_allow_weekend_offers:

        "교실 문을 나서자 복도는 이미 시끄러웠다."
        "아이들은 주말 이야기를 하며 흩어졌다."

        $ d6_event_person = "none"
        $ d5_unselected_candidate = "none"

        jump d5_go_home


    $ d5_weekend_candidate_1, d5_weekend_candidate_2 = get_d5_weekend_top_two()

    if d5_weekend_candidate_1 == "none":

        "교실 문을 나서자 아이들 목소리가 들렸다."
        "나는 가방끈을 고쳐 메고 천천히 걸었다."

        $ d6_event_person = "none"
        $ d5_unselected_candidate = "none"

        jump d5_go_home


    "교실 문턱을 넘으려는 순간, 누군가 내 이름을 불렀다."

    call d5_weekend_offer_scene(d5_weekend_candidate_1) from _call_d5_weekend_offer_scene_1

    if d5_weekend_candidate_2 != "none":

        "대답하려는데, 또 다른 목소리가 들렸다."

        call d5_weekend_offer_scene(d5_weekend_candidate_2) from _call_d5_weekend_offer_scene_2

        "두 친구가 나를 보고 있었다."

        $ choice_question_text = "주말에 어떻게 할까?"
        window hide

        menu:
            "[d5_colored_display_name(d5_weekend_candidate_1)]와 간다.":
                window show
                $ d6_event_person = d5_weekend_candidate_1
                $ d5_unselected_candidate = d5_weekend_candidate_2
                $ choice_log.append("D5_weekend_accept_" + d6_event_person)
                jump d5_accept_weekend_offer

            "[d5_colored_display_name(d5_weekend_candidate_2)]와 간다.":
                window show
                $ d6_event_person = d5_weekend_candidate_2
                $ d5_unselected_candidate = d5_weekend_candidate_1
                $ choice_log.append("D5_weekend_accept_" + d6_event_person)
                jump d5_accept_weekend_offer

            "이번 주말은 혼자 쉰다.":
                window show
                $ d6_event_person = "none"
                $ d5_unselected_candidate = "none"
                $ choice_log.append("D5_weekend_decline")
                jump d5_decline_weekend_offer

    else:

        "친구가 대답을 기다리고 있었다."

        $ choice_question_text = "주말에 어떻게 할까?"
        window hide

        menu:
            "[d5_colored_display_name(d5_weekend_candidate_1)]와 간다.":
                window show
                $ d6_event_person = d5_weekend_candidate_1
                $ d5_unselected_candidate = "none"
                $ choice_log.append("D5_weekend_accept_" + d6_event_person)
                jump d5_accept_weekend_offer

            "이번 주말은 혼자 쉰다.":
                window show
                $ d6_event_person = "none"
                $ d5_unselected_candidate = "none"
                $ choice_log.append("D5_weekend_decline")
                jump d5_decline_weekend_offer


# ----------------------------------------------------------
# D5 주말 약속 물어보기 — 인물별 장면
# ----------------------------------------------------------

label d5_weekend_offer_scene(person):
    $ level = d5_offer_level(person)

    if person == "jiho":

        show jh5 at center_stage as jiho with dissolve

        if level == "unstable":
            jh "야, 유진. 내일 학교 앞 농구장 올래?"
            jh "우리 팀에 들어와."
        elif level == "deep":
            jh "내일 시간 돼?"
            jh "농구장 가는데, 너도 오면 좋겠어."
        else:
            jh "내일 농구장 올래?"
            jh "구경만 해도 돼."

        hide jiho with dissolve


    elif person == "hayoung":

        show h4 at center_stage as hayoung with dissolve

        if level == "unstable":
            hy "유진아, 내일 문구점 갈래?"
            hy "이건 우리 둘만 알자."
        elif level == "deep":
            hy "내일 문구점 갈래?"
            hy "네가 좋아할 만한 스티커가 있더라."
        else:
            hy "내일 시간 돼?"
            hy "문구점 같이 가면 심심하지 않을 것 같아서."

        hide hayoung with dissolve


    elif person == "naeun":

        show ne4 at center_stage as naeun with dissolve

        if level == "unstable":
            ne "내일 도서관 갈 건데..."
            ne "괜찮으면 같이 갈래?"
            ne "바쁘면 안 와도 돼."
        elif level == "deep":
            ne "내일 도서관에 가려고 해."
            ne "같이 가면 좋겠어."
        else:
            ne "내일 시간 있으면..."
            ne "도서관 같이 갈래?"

        hide naeun with dissolve


    elif person == "sohee":

        show sh4 at center_stage as sohee with dissolve

        if level == "unstable":
            sh "유진아, 내일 우리 집 올래?"
            sh "쿠키 만들 거야. 꼭 와."
        elif level == "deep":
            sh "내일 우리 집에서 쿠키 만들래?"
            sh "너랑 같이 하면 좋겠어."
        else:
            sh "내일 시간 돼?"
            sh "쿠키 만들 건데 같이 할래?"

        hide sohee with dissolve


    elif person == "seoyeon":

        show sy5 at center_stage as seoyeon with dissolve

        if level == "unstable":
            sy "내일 도서관 갈 거야."
            sy "같이 오면 활동지도 정리할 수 있어."
        elif level == "deep":
            sy "내일 도서관 갈래?"
            sy "책도 보고, 조용히 이야기할 수 있어."
        else:
            sy "내일 시간 있으면 도서관 갈래?"
            sy "부담되면 안 와도 돼."

        hide seoyeon with dissolve

    return

label d5_accept_weekend_offer:
    scene bg_corridor_day with fade

    $ d5_accept_level = d5_offer_level(d6_event_person)

    if d5_weekend_candidate_2 != "none":
        if d6_event_person == d5_weekend_candidate_1:
            $ d5_unselected_candidate = d5_weekend_candidate_2
        else:
            $ d5_unselected_candidate = d5_weekend_candidate_1

        $ _unselected_name = d5_display_name(d5_unselected_candidate)

        "나는 한쪽으로 몸을 돌렸다."
        "[_unselected_name]에게는 다음에 같이 하자고 말했다."


    if d6_event_person == "jiho":

        n "물어봐줘서 고마워, 지호야."
        n "내일 갈게."

        show jh1 at center_stage as jiho with dissolve

        if d5_accept_level == "unstable":
            jh "오, 진짜?"
            jh "약속한 거다."
        elif d5_accept_level == "deep":
            jh "좋아."
            jh "그럼 내일 보자."
        else:
            jh "완전 신난다."
            jh "내일 보자."

        hide jiho with dissolve


    elif d6_event_person == "hayoung":

        n "물어봐줘서 고마워, 하영아."
        n "내일 같이 가자."

        show h1 at center_stage as hayoung with dissolve

        if d5_accept_level == "unstable":
            hy "좋아."
            hy "그럼 우리 둘만 알고 있자."
        elif d5_accept_level == "deep":
            hy "응."
            hy "내일 같이 고르자."
        else:
            hy "좋아."
            hy "내일 보자."

        hide hayoung with dissolve


    elif d6_event_person == "naeun":

        n "물어봐줘서 고마워, 나은아."
        n "내일 같이 가자."

        show ne3 at center_stage as naeun with dissolve

        if d5_accept_level == "unstable":
            ne "정말?"
            ne "그럼... 내일 봐."
        elif d5_accept_level == "deep":
            ne "응."
            ne "기다릴게."
        else:
            ne "고마워."
            ne "내일 조용히 책 보면 좋겠다."

        hide naeun with dissolve


    elif d6_event_person == "sohee":

        n "물어봐줘서 고마워, 소희야."
        n "내일 갈게."

        show sh4 at center_stage as sohee with dissolve

        if d5_accept_level == "unstable":
            sh "진짜?"
            sh "그럼 꼭 와야 돼."
        elif d5_accept_level == "deep":
            sh "좋아!"
            sh "같이 만들자."
        else:
            sh "야호."
            sh "내일 재밌겠다."

        hide sohee with dissolve


    elif d6_event_person == "seoyeon":

        n "물어봐줘서 고마워, 서연아."
        n "내일 같이 가자."

        show sy1 at center_stage as seoyeon with dissolve

        if d5_accept_level == "unstable":
            sy "알겠어."
            sy "그럼 시간 맞춰 와."
        elif d5_accept_level == "deep":
            sy "응."
            sy "천천히 책도 보자."
        else:
            sy "좋아."
            sy "내일 보자."

        hide seoyeon with dissolve

    $ d5_add_like(d6_event_person, 1)

    jump d5_go_home

label d5_decline_weekend_offer:
    scene bg_corridor_day with fade

    $ _declined_name = d5_display_name(d6_event_person)

    "나는 잠시 고민하다가 고개를 저었다."

    n "물어봐줘서 고마워."
    n "근데 이번 주말은 집에서 쉬려고."
    n "다음 주 쉬는 시간에 얘기하자."

    "[_declined_name]은 잠깐 멈췄다가 고개를 끄덕였다."

    $ d6_event_person = "none"
    $ d5_unselected_candidate = "none"

    jump d5_go_home

label d5_go_home:
    scene bg_corridor_day with fade
    $ set_bgm(audio.bgm_classroom_light2)

    "복도에서 하던 이야기가 끝났다."
    "아이들은 신발장 쪽으로 하나둘 걸어갔다."

    if d6_event_person != "none":
        $ _event_name = d5_display_name(d6_event_person)

        "나도 가방끈을 고쳐 멨다."
        "내일 [_event_name]와 만나기로 한 일이 생각났다."

        if d5_unselected_candidate != "none":
            $ _unselected_name = d5_display_name(d5_unselected_candidate)
            "[_unselected_name]에게는 다음에 같이 하자고 말했었다."

    else:
        "나는 가방끈을 고쳐 메고 천천히 걸었다."
        "주말 이야기는 복도 끝으로 멀어졌다."

    "신발장 앞에서 운동화로 갈아 신었다."

    scene bg_home_evening with slow_fade
    $ set_bgm(audio.bgm_evening)

    "집에 오자 현관이 조용했다."
    "나는 가방을 내려놓고 손을 씻었다."

    "책상 앞에 앉으니, 오늘 쓴 마음잎 문장들이 다시 생각났다."

    if d6_event_person != "none":
        "내일 만나면 학교에서 못 한 이야기도 하게 될 것 같았다."
    else:
        "이번 주말은 따로 약속이 없었다."
        "그래도 오늘 쓴 말들은 아직 머릿속에 남아 있었다."

    jump d5_diary

label d5_diary:
    scene bg_diary with fade
    window hide

    $ _focus = d5_leaf_person if d5_leaf_person != "none" else "jiho"
    $ _focus_name = display_name(_focus)
    $ _focus_like = like_of(_focus)
    $ _focus_neg = neg_of(_focus)

    $ diary_text1 = ""
    $ diary_text1 += "오늘은 마음잎을 썼다.\n"
    $ diary_text1 += "처음에는 좋은 말만 쓰면 되니까 쉬울 줄 알았다.\n"
    $ diary_text1 += "그런데 막상 쓰려니까 생각보다 어려웠다.\n\n"

    if d5_leaf_person == "jiho":
        $ diary_text1 += "나는 지호에게 마음잎을 썼다.\n"
        $ diary_text1 += "지호는 여러 친구들과 잘 지내는 밝은 친구다.\n"
        $ diary_text1 += "그래도 가끔 너무 신나면 친구들 표정을 못 보고 지나칠 때가 있다.\n"

    elif d5_leaf_person == "hayoung":
        $ diary_text1 += "나는 하영이에게 마음잎을 썼다.\n"
        $ diary_text1 += "하영이는 센스 있고 친구들 마음을 잘 알아채는 친구다.\n"
        $ diary_text1 += "그래도 가끔 없는 친구 이야기를 할 때는 조금 신경 쓰인다.\n"

    elif d5_leaf_person == "naeun":
        $ diary_text1 += "나는 나은이에게 마음잎을 썼다.\n"
        $ diary_text1 += "나은이는 친구를 잘 배려하고 다정하게 말해주는 따뜻한 친구다.\n"
        $ diary_text1 += "그래도 힘들 때는 괜찮다고만 하지 않았으면 좋겠다.\n"

    elif d5_leaf_person == "sohee":
        $ diary_text1 += "나는 소희에게 마음잎을 썼다.\n"
        $ diary_text1 += "소희는 좋아하는 마음을 바로 표현해 주는 밝은 친구다.\n"
        $ diary_text1 += "그런데 내가 다른 친구와 친해지면 멀어질까 봐 불안해하는 것 같다.\n"

    elif d5_leaf_person == "seoyeon":
        $ diary_text1 += "나는 서연이에게 마음잎을 썼다.\n"
        $ diary_text1 += "서연이는 맡은 일을 끝까지 하고 바른 말을 해주는 믿음직스러운 친구다.\n"
        $ diary_text1 += "그런데 맞는 말도 조금 세게 들릴 때가 있다.\n"

    else:
        $ diary_text1 += "누구에게 써야 할지 한참 생각했다.\n"
        $ diary_text1 += "좋은 말을 쓰는 것도 생각보다 쉽지 않았다.\n"

    $ diary_text1 += "\n"

    if d5_leaf_result == "deep_good":
        $ diary_text1 += _focus_name + "에게 쓴 마음잎은 그냥 지나치기 아까운 말 같았다.\n"
        $ diary_text1 += _focus_name + "은 내가 쓴 말을 한 번 더 읽는 것 같았다.\n"
        $ diary_text1 += "오늘은 " + _focus_name + "을 조금 더 잘 본 것 같았다.\n"

    elif d5_leaf_result == "plain":
        $ diary_text1 += _focus_name + "에게 나쁜 말을 쓴 건 아니었다.\n"
        $ diary_text1 += "하지만 다른 친구에게 써도 될 말 같았다.\n"
        $ diary_text1 += "다음엔 " + _focus_name + "만 떠오르는 말을 쓰고 싶다.\n"

    elif d5_leaf_result == "trap":
        $ diary_text1 += _focus_name + "은 마음잎을 보고 좋아했다.\n"
        $ diary_text1 += "그런데 마음이 조금 찝찝했다.\n"
        $ diary_text1 += _focus_name + "이 듣고 싶은 말과 도움이 되는 말은 다를 수도 있다.\n"

    else:
        $ diary_text1 += _focus_name + "에게 어울리는 말도 있었고, 조금 안 맞는 말도 있었다.\n"
        $ diary_text1 += _focus_name + " 얼굴을 떠올렸는데도 어려웠다.\n"
        $ diary_text1 += "다음엔 더 자세히 보고 써야겠다.\n"

    call screen diary_page(title="금요일 일기", content=diary_text1, body_yoffset=35)

    $ renpy.movie_cutscene("videos/diary.webm", stop_music=False)
    $ diary_text3 = ""
    $ diary_text3 += "오늘은 " + _focus_name + " 생각이 계속 났다.\n"
    $ diary_text3 += relation_status_text(_focus_like, _focus_neg) + "\n"

    if d5_leaf_result == "deep_good":
        $ diary_text3 += "오늘 쓴 말은 " + _focus_name + "에게 잘 맞았던 것 같다.\n"
        $ diary_text3 += "다음에도 그냥 칭찬만 하지 말고, " + _focus_name + "에게 도움이 되는 말도 생각해야겠다.\n"

    elif d5_leaf_result == "plain":
        $ diary_text3 += "오늘 쓴 말은 나쁘지 않았지만 누구에게나 쓸 수 있는 말 같았다.\n"
        $ diary_text3 += "다음엔 " + _focus_name + "만 생각나는 모습을 찾아봐야겠다.\n"

    elif d5_leaf_result == "trap":
        $ diary_text3 += _focus_name + "은 마음잎을 좋아했다.\n"
        $ diary_text3 += "그런데 내 마음은 조금 걸렸다.\n"
        $ diary_text3 += "다음엔 " + _focus_name + "이 듣고 싶은 말만 쓰지는 말아야겠다.\n"

    else:
        $ diary_text3 += "오늘 쓴 말에는 맞는 것도 있고 아닌 것도 있었다.\n"
        $ diary_text3 += "다음엔 " + _focus_name + "이 어떤 아이인지 더 보고 써야겠다.\n"

    if burnout >= 4:
        $ diary_text3 += "\n나의 상태: 오늘은 말을 고르느라 머리가 무거웠다.\n"
    elif burnout >= 3:
        $ diary_text3 += "\n나의 상태: 조금 피곤했지만, 오늘을 무사히 잘 보낸 것 같다.\n"
    else:
        $ diary_text3 += "\n나의 상태: 오늘은 많이 힘들지는 않았다.\n"

    show screen diary_focus_badge(_focus)
    call screen diary_page(title="금요일 관계 메모", content=diary_text3, body_yoffset=145)
    hide screen diary_focus_badge

    scene bg_home_evening with slow_fade
    window show

    "일기장을 덮고 책상 위에 올려두었다."

    if d6_event_person != "none":
        $ _tomorrow_name = display_name(d6_event_person)
        "내일은 학교 밖에서 친구를 처음 본다."
    else:
        "내일은 약속 없이 쉰다."

    jump d6_start
# ----------------------------------------------------------
# D6 시작 라우터
# ----------------------------------------------------------

label d6_start:

    $ day = 6

    if d6_event_person == "jiho":
        jump d6_jiho_weekend
    elif d6_event_person == "hayoung":
        jump d6_hayoung_weekend
    elif d6_event_person == "naeun":
        jump d6_naeun_weekend
    elif d6_event_person == "sohee":
        jump d6_sohee_weekend
    elif d6_event_person == "seoyeon":
        jump d6_seoyeon_weekend
    else:
        jump d6_no_weekend_event

# ----------------------------------------------------------
# D6 약속 없는 토요일
# ----------------------------------------------------------
label d6_no_weekend_event:
    $ set_bgm(audio.bgm_daily_morning)

    scene black
    with day_fade

    centered "토요일"
    pause 0.5

    scene bg_room_morning with fade

    "책상 위 탁상시계를 봤다."
    "토요일 오전은 조용했다."

    "나는 가방을 열어 안에 든 것들을 하나씩 꺼냈다."
    "필통, 알림장, 구겨진 학습지, 다 쓴 색연필 한 자루가 나왔다."

    "이번 주에 만난 친구들 얼굴이 하나씩 떠올랐다."

    $ choice_question_text = "토요일을 어떻게 보낼까?"
    window hide

    menu:

        "도서관에 가서 책을 읽는다.":
            window show
            $ add_burnout(-1)
            $ d6_weekend_choice = "library"
            $ d6_solo_style = "library"
            $ choice_log.append("D6_no_event_library")

            scene bg_library_after with fade

            "오후에는 동네 도서관에 갔다."
            "학교 도서실보다 넓었고, 3반 교실보다 훨씬 조용했다."

            "창가 자리에 앉아 책을 펼쳤다."
            "처음 몇 장은 잘 읽히지 않았다."

            "월요일에 처음 만난 친구들."
            "화요일에 교실에서 있었던 일들."

            "조금 지나자 글자가 눈에 들어오기 시작했다."
            "옆자리에서는 책장 넘기는 소리가 작게 들렸다."

            "책을 다 읽지는 못했다."
            "그래도 앉아 있는 동안은 마음이 조금 조용해졌다."

            $ d6_memory_line = "혼자 도서관에 갔다. 조용히 책을 읽었다."


        "동네를 천천히 걷는다.":
            window show
            $ add_burnout(-1)
            $ d6_weekend_choice = "walk"
            $ d6_solo_style = "walk"
            $ choice_log.append("D6_no_event_walk")

            scene bg_front_house with fade

            "오후에는 운동화를 신고 밖으로 나갔다."
            "집 앞 골목에는 토요일 햇빛이 길게 내려와 있었다."

            "나는 갈 곳을 정하지 않고 천천히 걸었다."
            "문구점 앞을 지나고,"
            "작은 놀이터 옆을 지나고,"
            "학교로 가는 길목도 지나쳤다."

            "처음 교실에 들어갔던 날이 생각났다."
            "어색하게 이름을 말했던 것도 생각났다."

            "나는 편의점에서 작은 음료수를 하나 샀다."
            "차가운 병을 손에 쥐고 벤치에 앉았다."

            "혼자 걷는 것도 나쁘지 않았다."

            "월요일이 오면 다시 교실에 가야 한다."

            $ d6_memory_line = "혼자 동네를 걸었다. 바람을 쐬었다."


        "집에서 편하게 쉰다.":
            window show
            $ add_burnout(-1)
            $ d6_weekend_choice = "home"
            $ d6_solo_style = "home"
            $ choice_log.append("D6_no_event_home")

            scene bg_room_morning with fade

            "책상 위를 조금 치웠다."
            "침대 위에 던져둔 옷도 정리했다."

            "나는 좋아하는 간식을 꺼내고, 공책 한 권을 펼쳤다."

            "말풍선을 그리고,"
            "작은 캐릭터 얼굴을 그렸다."

            "지호."
            "하영."
            "나은."
            "소희."
            "서연."

            "이름을 하나씩 적고 나니, 학교 생각이 났다."

            "나는 좋아하는 음악을 작게 틀었다."
            "방 안은 조용했지만, 심심하지만은 않았다."

            $ d6_memory_line = "집에서 쉬었다. 방을 정리하고 낙서도 했다."

    "토요일은 조용히 지나갔다."

    if d6_weekend_choice == "library":
        "책장 넘기는 소리가 아직 귀에 남아 있었다."

    elif d6_weekend_choice == "walk":
        "운동화 밑창에 작은 모래가 붙어 있었다."

    elif d6_weekend_choice == "home":
        "책상 위는 아침보다 조금 비어 있었다."

    $ d6_weekend_choice = "solo"

    jump d6_diary
# ----------------------------------------------------------
# D6 지호 — 동네 공원 야외 농구장
# ----------------------------------------------------------

label d6_jiho_weekend:
    $ set_bgm(audio.bgm_jiho_active)

    scene bg_basketball with fade

    "토요일 오후, 동네 공원 농구장은 조용했다."
    "지호는 먼저 와서 농구공을 튕기고 있었다."

    show jh5 at center_stage as jiho with dissolve

    jh "어, 유진! 왔네?"
    n "응. 많이 기다렸어?"

    jh "아니. 나도 방금 왔어."
    jh "애들 몇 명 더 오기로 했는데, 조금 늦는대."

    hide jiho
    show jh1 at center_stage as jiho with dissolve

    jh "애들 올 때까지 우리끼리 해볼래?"
    jh "시합 말고 그냥 던져보는 거."

    n "나 농구 진짜 잘 못해."
    n "공 세게 오면 못 받을 수도 있어."

    "지호는 잠깐 공을 내려다봤다."
    "그리고 공을 내 발밑까지 천천히 굴렸다."

    hide jiho
    show jh5 at center_stage as jiho with dissolve

    jh "그럼 이렇게."
    jh "천천히 줄게."

    "나는 양손으로 공을 주워 들었다."
    "교실에서 보던 지호는 늘 빠르고 시끄러웠다."
    "그런데 지금은 천천히 해주고 있었다."

    hide jiho
    show jh1 at center_stage as jiho with dissolve

    jh "오늘은 골 넣기 말고,"
    jh "공 안 놓치기부터 하자."

    "우리는 가까운 거리에서 공을 주고받았다."
    "내가 공을 놓치면 지호가 바로 뛰어가서 주워왔다."

    jh "이야, 방금 패스 일부러 저쪽으로 던진 거지?"
    n "아니. 그냥 진짜 잘못 던진 건데."
    jh "그럼 더 대단한데? 아무도 예상 못 했잖아."

    "나는 결국 웃음이 터졌다."

    "잠시 후, 지호 친구 두 명이 자전거를 타고 왔다."

    ex_js "야, 얘가 네가 말한 전학생이야?"
    ex_js "농구 해봤대?"

    "나는 대답하려다가 잠깐 멈췄다."
    "그 순간 지호가 먼저 입을 열었다."

    hide jiho
    show jh5 at center_stage as jiho with dissolve

    jh "오늘은 세게 안 해."
    jh "유진이는 처음 해보는 거고, 우리도 그냥 가볍게 할 거야."

    "지호는 나를 봤다."

    jh "맞지?"
    jh "너는 오늘 어떻게 하고 싶어?"

    n "나 아직 잘 못해."
    n "그래도 천천히 배워보고 싶어."

    jh "들었지?"
    jh "오늘은 그렇게 하는 거야."

    window hide

    scene bg_black with Fade(0.5, 0.2, 0.5)

    show jh_weekend at weekend_movie_full
    with Dissolve(1.2)

    pause 0.3
    window auto

    "나는 여전히 공을 놓쳤고, 골대 앞에서도 몇 번이나 빗나갔다."
    "그래도 지호는 내 실수를 웃기게 받아줬다."

    jh "야, 방금 슛은 골대가 피한 거다."
    jh "골대가 잘못했네."

    "친구들이 웃었다."
    "나도 웃었다."
    "놀리는 웃음은 아니었다."

    scene bg_snack with fade

    "운동이 끝난 뒤, 우리는 근처 분식집에 갔다."
    "지호는 물컵 하나를 내 쪽으로 밀어주었다."

    show jh5 at center_stage as jiho with dissolve

    jh "너 오늘 생각보다 잘 버텼다."
    n "잘한 건 아니고?"
    jh "그건 아니지."
    jh "근데 안 도망갔잖아."

    "지호는 떡볶이를 하나 집어 먹고는 조금 조용해졌다."

    hide jiho
    show jh4 at center_stage as jiho with dissolve

    jh "사실 나도 처음부터 농구 잘한 건 아니야."
    jh "처음에는 계속 놓쳤어."
    jh "근데 동네 형들이 못하면 안 끼워줬거든."

    "지호는 젓가락으로 단무지를 콕콕 찔렀다."

    jh "그래서 빨리 잘해야 했어."
    jh "못하면 빠지라고 하고,"
    jh "느리면 답답하다고 하고."

    hide jiho
    show jh3 at center_stage as jiho with dissolve

    jh "그때부터였나 봐."
    jh "뭐든 하면 빨리 이겨야 마음이 편해."
    jh "내가 먼저 소리 지르고 세게 나가야," 
    jh "애들이 내 순서 안 빼앗고 안 쫓아내거든."

    "나는 젓가락을 내려놓았다."

    jh "근데 오늘 너랑 하면서 좀 이상했어."
    jh "너는 못해도 계속 있었잖아."

    hide jiho
    show jh5 at center_stage as jiho with dissolve

    jh "못해도 그냥 같이 하니까..."
    jh "꼭 잘해야만 같이 있을 수 있는 건 아닌가 싶었어."

    hide jiho
    show jh3 at center_stage as jiho with dissolve

    jh "나 가끔 너무 세게 말하지?"
    jh "나도 알아."
    jh "근데 가만히 있으면, 나만 바보 되고" 
    jh "친구들 무리에서 빠지게 될까 봐 그게 안 돼."

    hide jiho
    show jh4 at center_stage as jiho with dissolve

    jh "오늘은 네가 있어서 조금 천천히 해보려고 했어."
    jh "잘 됐는지는 모르겠는데."

    $ choice_question_text = "지호의 이야기를 듣고 뭐라고 말할까?"
    window hide

    menu:

        # [호감도 +1] 질문에는 답하지만 지호의 문제를 해결해주지는 않는 가벼운 피드백
        "가끔 그렇게 느낄 때는 있어. 오늘은 괜찮았어.":
            window show
            $ d6_weekend_choice = "plain"
            $ d6_deep_talk_style = "reassure"
            $ add_like("jiho", 1)
            $ choice_log.append("D6_jiho_B_plain")

            n "가끔 그렇게 느낄 때는 있어."
            n "오늘은 괜찮았어."

            hide jiho
            show jh3 at center_stage as jiho with dissolve

            jh "아... 오늘은 일부러 좀 참은 거긴 해."
            jh "애들 왔을 때도 너무 세게 안 하려고 했고."

            n "응. 그런 건 느껴졌어."

            hide jiho
            show jh5 at center_stage as jiho with dissolve

            jh "그럼 됐네."

            $ d6_memory_line = "지호는 말이 너무 세냐고 물었다. 나는 가끔 그렇지만 오늘은 괜찮았다고 말했다."


        # [호감도 +3 / 부정적 성향 -1] 똑같이 쫓겨날까 봐 불안했던 경험을 공유하여 방어기제 해제
        "실은 나도 전학 오고 무리에 안 끼워줄까 봐 맨날 긴장했어.":
            window show
            $ d6_weekend_success = True
            $ d6_weekend_choice = "equal"
            $ d6_deep_talk_style = "share_worry"
            $ add_like("jiho", 3)
            $ add_neg("jiho", -1)
            $ choice_log.append("D6_jiho_A_equal")

            n "나도 전학 온 날에 아무도 말 안 걸어줘서 속으로 엄청 겁먹었거든."
            n "말 한마디 잘못 꺼냈다가 나만 혼자 교실에서 겉돌까 봐 무서웠어."
            n "그래서 아까 네가 나 맞춰서 공 천천히 굴려줬을 때 진짜 고마웠어."

            hide jiho
            show jh4 at center_stage as jiho with dissolve

            jh "너도 나처럼 혼자 남겨질까 봐 무서웠다고? 네가?"
            jh "난 너 그냥 교실에서 혼자 책 보는 거 좋아하는 애인 줄 알았는데."

            n "편하긴. 얌전한 척 숨어 있었던 거야."

            "지호는 만지작거리던 물컵을 내려놓고 내 눈을 똑바로 쳐다봤다."

            hide jiho
            show jh3 at center_stage as jiho with dissolve

            jh "똑같았네. 나는 안 쫓겨나려고 일부러 큰소리치고," 
            jh "너는 안 들키려고 조용히 있고."
            
            hide jiho
            show jh5 at center_stage as jiho with dissolve
            
            jh "야, 그렇게 말해주니까 내가 아까 속 얘기 꺼낸 게 좀 덜 부끄럽다."
            jh "앞으로 내가 운동하다가 또 혼자 흥분해서 욱하면" 
            jh "네가 내 옷자락 좀 잡아당겨줘."
            jh "대신 너 구석에 혼자 멍하니 서 있으면" 
            jh "내가 무조건 네 팔 잡고 끌고 나올 테니까."

            n "응. 서로 말해주자."

            $ d6_memory_line = "지호는 이기려고 애쓰는 이유를 말했다. 나도 못 낄까 봐 걱정했다고 말했다."

        # [부정적 성향 +2 / 호감도 +1] 해결사 역할을 요구하여 지호의 과도한 공격성을 정당화함
        "앞으로도 다른 애들이 나 무시하면 네가 대신 화내줘.":
            window show
            $ d6_weekend_choice = "trap"
            $ d6_deep_talk_style = "depend_on_jiho"
            $ add_like("jiho", 1)
            $ add_neg("jiho", 2)
            $ choice_log.append("D6_jiho_C_trap")

            n "아까 자전거 탄 애들 왔을 때" 
            n "네가 딱 잘라 말해줘서 진짜 든든했어."
            n "나 혼자였으면 주눅 들어서 한마디도 못 했을 거야."
            n "앞으로도 교실에서 누가 나한테 시비 걸면," 
            n "오늘처럼 네가 먼저 나서서 소리 질러줘."

            hide jiho
            show jh1 at center_stage as jiho with dissolve

            jh "당연하지! 그런 건 내가 우리 학년 통틀어서 제일 잘해."
            jh "너는 그냥 내 옆에만 딱 붙어 있어." 
            jh "누가 째려보기만 해도 내가 바로 들이받아 줄 테니까."

            "지호는 가슴을 쾅쾅 치며 다시 목소리를 높였다."

            $ d6_memory_line = "나는 지호가 앞에서 말해줘서 든든했다고 했다. 지호는 더 크게 나서려 했다."

    # 메뉴 종료 후 공통 흐름
    "분식집을 나설 때, 바깥 공기는 조금 선선했다."
    "지호는 농구공을 옆구리에 끼고 천천히 걸었다."

    hide jiho
    show jh3 at center_stage as jiho with dissolve

    jh "야, 유진."
    n "응?"

    jh "오늘 얘기한 거..."
    jh "월요일에 애들한테 말하지 마라. 폼 안 나니까."

    n "안 말해. 우리끼리 한 얘기잖아."

    hide jiho
    show jh5 at center_stage as jiho with dissolve

    jh "그럼 됐어. 월요일에 교실에서 보자."

    n "응. 월요일에 봐, 지호야."

    "지호는 농구공을 한 번 가볍게 튕겼다."

    scene bg_basketball with dissolve

    "공이 바닥에 닿는 소리가 낮게 울렸다."
    "지호는 손을 흔들며 골목 쪽으로 걸어갔다."

    jump d6_diary
    
# ----------------------------------------------------------
# D6 하영 — 학교 앞 디저트 카페
# ----------------------------------------------------------

label d6_hayoung_weekend:
    $ set_bgm(audio.bgm_hayoung_social)

    scene bg_cafe_day with fade

    "토요일 오후, 학교 앞 디저트 카페는 학생들로 꽤 붐볐다."
    "하영이는 창가 자리에 먼저 앉아 있었다."
    "테이블 위에는 분홍색 음료 두 잔이 놓여 있었다."

    window hide

    scene bg_black with Fade(0.5, 0.2, 0.5)

    show hy_weekend at weekend_movie_full
    with Dissolve(1.2)

    pause 0.3
    window auto

    hy "유진아, 여기!"
    hy "자리 괜찮지? 여기가 덜 시끄러울 것 같아서."

    n "응. 좋아."
    n "너 먼저 와 있었어?"

    hy "응. 사람 많을까 봐 조금 일찍 왔어."
    hy "딸기 라떼 괜찮아?"

    n "응. 고마워."

    "나는 자리에 앉았다."
    "카페 안에서는 믹서기 소리와 컵 부딪치는 소리가 들렸다."

    "하영이는 빨대를 꽂고 컵을 내 쪽으로 밀었다."

    n "하영아."
    n "너 이런 거 잘 챙긴다."
    n "자리도 그렇고, 음료도 그렇고."

    scene bg_cafe_day with fade
    show h4 at center_stage as hayoung with dissolve

    hy "그치?"
    hy "나 이런 건 좀 잘 봐."

    "하영이는 밝게 웃었다."
    "그러다 컵을 내려다보며 빨대를 손끝으로 돌렸다."

    hide hayoung
    show h3 at center_stage as hayoung with dissolve

    hy "근데 나 처음부터 이랬던 건 아니야."

    n "그래?"

    hy "응."
    hy "작년에 우리 반에서 엄청 인기 많고" 
    hy "춤도 잘 추던 애가 있었거든."
    hy "애들 옷 입는 거나 소품 사는 것까지 걔가 다 참견하곤 했어."

    "하영이는 컵을 두 손으로 잡았다."

    hy "근데 걔가 친구 한 명이랑 크게 멀어지더니," 
    hy "다른 애들도 순식간에 걔랑 안 놀아주는 거야."
    hy "교실 구석에 혼자 앉아 있는 걸 보는데 진짜 무서웠어."

    hide hayoung
    show h6 at center_stage as hayoung with dissolve

    hy "그때 생각이 많아졌어."
    hy "내가 먼저 애들 사이에서 중심을 잡지 않으면," 
    hy "다음번에 혼자 남는 건 내가 되겠구나 싶었거든."

    "하영이는 빨대를 살짝 눌렀다."

    hy "그래서 나도 모르게 애들 눈치를 엄청 보기 시작했어."
    hy "애들이 좋아할 만한 칭찬 잔뜩 해주면서 내 편으로 만들고," 
    hy "나랑 멀어질 것 같은 애가 있으면"
    hy "다른 애들한테 은근히 걔 서운한 점 말하면서 내 편을 만들었어."

    hide hayoung
    show h3 at center_stage as hayoung with dissolve

    hy "누가 무리에 들어오고 나갈지 내가 다 결정해야 마음이 놓였거든."

    n "계속 그렇게 신경을 써야 할 것 같았어?"

    hy "응. 내가 가만히 있으면"
    hy "나 빼고 다른 애들끼리만 더 친해질 것 같았단 말이야."

    "카페 안쪽에서 같은 학교 학생 몇 명이 웃으며 지나갔다."
    "하영이는 그쪽을 한 번 봤다가 다시 컵을 봤다."

    hy "나도 알아. 다른 친구 얘기 뒤에서 옮기고 다니는 거"
    hy "진짜 못된 짓인 거."

    hide hayoung
    show h6 at center_stage as hayoung with dissolve

    hy "근데 누가 나보다 다른 애들이랑" 
    hy "더 먼저 친해지거나 돋보이면 속상하고 불안해."
    hy "맨날 무슨 말을 해야 내 편으로 붙잡아둘지 머리 쓰니까,"
    hy "사실 나 진짜 너무 피곤해."

    n "그럼 친구들이랑 있어도 편하지만은 않겠다."

    hy "응."
    hy "같이 놀고 싶은 건데,"
    hy "어느 순간부터 내가 판을 짜고 있는 것 같아."
    hy "누가 누구랑 더 친한지 계속 확인해야 마음이 놓여."

    "하영이는 목소리를 낮췄다."

    hy "너는 나랑 있으면 어때?" 
    hy "내가 또 다른 애 얘기 꺼낼까 봐 신경 쓰여?"

    "그 말은 작았다."
    "카페 소리 사이에서도 또렷하게 들렸다."

    hide hayoung
    show h3 at center_stage as hayoung with dissolve

    $ choice_question_text = "하영이의 이야기를 듣고 뭐라고 말할까?"
    window hide

    menu:

        # [부정적 성향 +2 / 호감도 +1] 하영이의 편 가르기 능력을 부추겨 해결사로 이용하려 함
        "누구랑 놀지 알려주니까 좋았는걸? 그건 너의 능력이라고 봐.":
            window show
            $ d6_weekend_choice = "trap"
            $ d6_deep_talk_style = "depend_on_mood"
            $ add_like("hayoung", 1)
            $ add_neg("hayoung", 2)
            $ choice_log.append("D6_hayoung_C_trap")

            n "난 애들 중에서 누가 누구랑 친하고 어색한지"
            n "눈치가 없어서 잘 모르거든."
            n "근데 네가 딱 정리해서 누구랑 놀지 결정해 주니까 따라가기 엄청 편해." 
            n "눈치 빠른 것도 능력이라고 생각해."

            hide hayoung
            show h4 at center_stage as hayoung with dissolve

            hy "그치? 내가 그런 눈치는 진짜 빠르잖아." 
            hy "누구랑 멀어져야 할지 정하는 건 일도 아냐."

            "하영이는 금방 평소처럼 턱을 치켜들며 차가운 표정으로 돌아왔다."
            "딸기 라떼 컵을 쥔 하영이의 손가락에 다시 힘이 들어갔다."

            hy "월요일에 우리끼리 새로 단톡방 만들어서 얘기할 거니까," 
            hy "너는 내 편에 딱 서서 내가 하는 대로만 해. 알았지?"

            n "응. 너랑 같은 편에 서 있으면"
            n "혼자 남을 일은 없으니까 든든하다."

            hide hayoung
            show h1 at center_stage as hayoung with dissolve

            hy "당연하지. 내 말만 들으면 넌 안전해."

            $ d6_memory_line = "하영이는 자기가 필요 없어질까 걱정했다. 나는 하영이에게 기대는 말을 했다."

        # [호감도 +3 / 부정적 성향 -1] 하영이의 통제본능 때문에 긴장했던 사실을 고백해 가면을 벗김
        "실은 나도 네 눈치 보느라 긴장한 적 있어.":
            window show
            $ d6_weekend_success = True
            $ d6_weekend_choice = "equal"
            $ d6_deep_talk_style = "share_pressure"
            $ add_like("hayoung", 3)
            $ add_neg("hayoung", -1)
            $ choice_log.append("D6_hayoung_A_equal")

            n "나도 처음에 네가 내 말투나 행동 유심히 쳐다볼 때"
            n "속으로 엄청 겁먹었거든."

            hide hayoung
            show h6 at center_stage as hayoung with dissolve

            hy "진짜? 난 네가 내 말 다 잘 들어주길래" 
            hy "그냥 내가 편해서 그런 줄 알았는데..."

            n "아니, 나도 친구들 사이에 못 낄까 봐 조심했던 거야." 
            n "근데 지금 이렇게 솔직하게 말해줘서 좋아."
            n "맨날 애들 기분 맞춰주고 무리 유지하려고" 
            n "너도 속으로는 진짜 지쳤던 거잖아."

            "하영이는 빨대를 만지작거리다가 고개를 작게 끄덕였다."

            hide hayoung
            show h3 at center_stage as hayoung with dissolve

            hy "응... 가만히 있으면 나 혼자 남겨질 것 같아서."

            n "네가 애들을 다 챙기려고 애쓰지 않아도,"
            n "나랑은 그냥 편하게 카페 오고 춤 연습 하러 갈 수 있어."
            n "대신 앞으로 다른 애 안 좋은 얘기 하려고 하면," 
            n "내가 대놓고 딴얘기로 휙 돌려버릴 거야."

            hide hayoung
            show h6 at center_stage as hayoung with dissolve

            hy "킥... 알겠어. 차라리 네가 먼저 그렇게 끊어주면" 
            hy "나도 마음이 편할 것 같아."

            $ d6_memory_line = "하영이는 자기가 빠질까 봐 친구들 이야기를 더 듣게 된다고 했다. 나도 하영이 눈치를 본 적 있다고 말했다."


        # [호감도 +1] 하영과 함께 있는 건 괜찮다고 가볍게 안심시킴
        "조금 신경 쓰일 때는 있어. 그래도 오늘은 재밌었어.":
            window show
            $ d6_weekend_choice = "plain"
            $ d6_deep_talk_style = "light_comfort"
            $ add_like("hayoung", 1)
            $ choice_log.append("D6_hayoung_B_plain")

            n "조금 신경 쓰일 때는 있어."
            n "그래도 오늘은 재밌었어."

            hide hayoung
            show h5 at center_stage as hayoung with dissolve

            hy "역시 좀 신경 쓰이긴 하는구나."

            n "응. 그래도 너랑 같이 있는 게 싫은 건 아니야."

            "하영이는 빨대를 한 번 휘젓다가 고개를 끄덕였다."

            hy "아... 알겠어."

            n "오늘은 그냥 편하게 놀자."

            hide hayoung
            show h6 at center_stage as hayoung with dissolve

            hy "응. 다음에 또 카페 오자."
            hy "그때는 저기 진열대에 있는 조각 케이크도 먹자."

            $ d6_memory_line = "하영이는 다른 친구 이야기가 신경 쓰이는지 물었다. 나는 조금 신경 쓰이지만 오늘은 재밌었다고 말했다."

    # 메뉴 종료 후 공통 흐름
    "카페를 나설 때, 문 위의 작은 종이 딸랑 울렸다."

    hide hayoung
    show h6 at center_stage as hayoung with dissolve

    hy "유진아."
    n "응?"

    hy "오늘 내가 말한 거, 다른 애들한테 절대 말하지 마." 
    hy "애들이 나 욕할지도 몰라."

    n "응. 안 해. 우리끼리 한 얘기잖아."

    hide hayoung
    show h1 at center_stage as hayoung with dissolve

    hy "고마워. 월요일에 교실에서 보자."

    n "응. 월요일에 봐, 하영아."

    "하영이는 손을 흔들고 골목 쪽으로 걸어갔다."

    jump d6_diary
# ----------------------------------------------------------
# D6 나은 — 작은 그림 전시실
# ----------------------------------------------------------

label d6_naeun_weekend:
    $ set_bgm(audio.bgm_naeun_soft)

    scene bg_art with fade

    "토요일 오후, 주택가 근처의 작은 그림 전시실 앞이었다."
    "입구에는 손바닥만 한 안내판이 걸려 있었다."

    "나은이는 먼저 와 있었다."
    "가방 앞주머니에는 작은 스케치북이 꽂혀 있었다."

    show ne5 at center_stage as naeun with dissolve

    ne "유진아."
    ne "일찍 왔네."

    n "응."
    n "나은이도 일찍 와 있었네?"

    ne "응."
    ne "여기... 가끔 혼자 왔거든."
    ne "그림 앞에 오래 서 있어도 아무도 빨리 가자고 안 하니까."

    "나은이는 그렇게 말하고 스케치북 끝을 손가락으로 살짝 만졌다."

    window hide

    scene bg_black with Fade(0.5, 0.2, 0.5)

    show ne_weekend at weekend_movie_full
    with Dissolve(1.2)

    pause 0.3
    window auto

    "전시실 안은 조용했다."
    "벽에는 작은 수채화와 연필 그림들이 걸려 있었다."

    "나은이는 우산 그림 앞에서 멈췄다."
    "그림 속 아이는 우산을 여러 개 들고 있었다."
    "그런데 아이의 한쪽 어깨는 젖어 있었다."

    ne "유진아."
    ne "나 때문에 너무 천천히 보는 거 아니야?"
    ne "지루하면 바로 말해. 나 진짜 괜찮아."

    n "아냐."
    n "천천히 보니까 더 잘 보여."

    "나은이는 바로 대답하지 않았다."
    "그림 속 아이를 한참 바라봤다."

    ne "나..."
    ne "이 그림 볼 때마다 마음이 좀 답답해."

    n "왜?"

    ne "친구들이 비 안 맞게 우산 씌워준 건 좋은데,"
    ne "저 아이는 자기 어깨가 다 젖는데도" 
    ne "아무한테도 말을 안 하잖아."

    scene bg_art2 with fade
    show ne1 at center_stage as naeun with dissolve

    ne "나도 그럴 때가 많아서."
    ne "속으로는 싫은데 겉으로는 괜찮다고 말할 때."

    n "속으로는 싫었는데도?"

    ne "응."
    ne "친구가 나한테 부탁한 건데," 
    ne "내가 싫다고 하면 나한테 화내거나 삐질까 봐."

    "나은이는 스케치북 끝을 손가락으로 꾹 눌렀다."

    ne "작년에 모둠 활동할 때도 그랬어."
    ne "나는 내가 하기로 한 발표 대본만 정리하면 끝이었거든."
    ne "근데 다른 친구가" 
    ne "자기 것도 조금만 대신 봐달라고 은근슬쩍 부탁했어."

    hide naeun
    show ne2 at center_stage as naeun with dissolve

    ne "처음에는 조금만 도와주려고 한 건데..."
    ne "나중에는 거의 내가 다 맡아서 밤늦게까지 하고 있더라."

    n "진짜 힘들었겠다."

    ne "근데 끝까지 힘들단 말은 못 했어."
    ne "내가 못 하겠다고 중간에 빠지면," 
    ne "다들 나를 자기밖에 모르는 애라고 생각할 것 같았어."

    hide naeun
    show ne1 at center_stage as naeun with dissolve

    ne "한 번은 진짜 용기 내서" 
    ne "못 하겠다고 말하려고 했는데..."
    ne "친구 얼굴이 확 정색하는 것 같아서 무서웠어."
    ne "그래서 나도 모르게 다시 괜찮다고 해버렸어."

    "전시실 안에 종이 넘기는 소리가 작게 났다."

    ne "그 뒤로는 누가 무슨 부탁을 하면 머리보다 입이 먼저 반응해."
    ne "안 된다고 하면 분위기 싸해질까 봐" 
    ne "'응, 내가 할게'부터 튀어나와."

    "나은이는 나를 조심스럽게 살폈다."

    ne "유진이 너는..."
    ne "친구 부탁을 못 하겠다고 말해본 적 있어?"

    n "있긴 한데, 나도 매번 쉽진 않아."

    ne "그때 친구가 너 싫어하지는 않았어?"

    "나은이는 내 대답을 기다리듯 나를 바라봤다."

    $ choice_question_text = "나은이에게 뭐라고 말할까?"
    window hide

    menu:
        # [호감도 +3 / 부정적 성향 -1] 거절=관계 단절이 아님을 짚어주고, 나은이의 번아웃을 방지함
        "싫어서 그러는 게 아니니까 힘들다고 말해도 돼.":
            window show
            $ d6_weekend_success = True
            $ d6_weekend_choice = "equal"
            $ d6_deep_talk_style = "safe_refusal"
            $ add_like("naeun", 3)
            $ add_neg("naeun", -1)
            $ choice_log.append("D6_naeun_A_equal")

            n "힘들 땐 못 하겠다고 말해도 괜찮아."
            n "친구가 싫어서 그러는 게 아니라,"
            n "지금은 내가 너무 힘들어서 못 한다는 뜻이니까."

            hide naeun
            show ne2 at center_stage as naeun with dissolve

            ne "하지만... 내가 안 도와줘서" 
            ne "그 친구가 혼자 하다가 짜증 내면 어떡해?"

            n "그냥 나 안 해! 이렇게 화내면서 말하는 게 아니잖아."
            n "‘나도 도와주고 싶은데, 오늘 학원 숙제가 너무 많아서"
            n "이번엔 진짜 못 하겠다’라고 네 상황을 그냥 말하는 거지."

            "나은이는 아주 천천히 고개를 들었다."

            hide naeun
            show ne4 at center_stage as naeun with dissolve

            ne "그렇게 말해도... 나를 이기적인 애라고 욕하진 않을까?"

            n "오히려 친구 기분 맞추려고 네가 다 억지로 떠맡다 보면," 
            n "나중엔 너 혼자 지쳐서 학교 오기도 싫어질걸?" 
            n "네 어깨부터 안 젖는 게 먼저야."

            "나은이는 그림 속 우산 든 아이를 한참 바라보았다."

            hide naeun
            show ne5 at center_stage as naeun with dissolve

            ne "그럼 저 아이도..."
            ne "‘우산이 작아서 나도 지금 한쪽 어깨가 젖고 있어’"
            ne "라고 말해도 괜찮았던 거네."

            n "응. 당연하지."
            n "말해야 상대방도 알고 우산을 더 넓게 같이 쓰지."

            "나은이는 가방에서 조심스럽게 스케치북을 열었다."
            "그리고 연필을 꺼내 우산 아래" 
            "지쳐 보이는 아이 옆에 작은 말풍선을 그렸다."

            hide naeun
            show ne4 at center_stage as naeun with dissolve

            ne "'나도 옷이 젖어서 조금 추워.'"

            "나은이는 자기가 적은 그 문장을 한참 동안 내려다보았다."

            ne "다음에 누가 또 무리한 부탁을 하면..."
            ne "착한 척하면서 무조건 알겠다고 하기 전에," 
            ne "내가 진짜 할 수 있는지 내 마음부터 먼저 생각해 볼게."

            n "응. 딱 한 번만 멈춰서 생각하는 것부터 시작해 봐."

            $ d6_memory_line = "나은이는 못 하겠다고 말하기 어렵다고 했다. 나는 힘들면 못 한다고 해도 된다고 했다."

        # [부정적 성향 +2 / 번아웃 +1 / 호감도 +1] 피플 플리징을 정당화하여 스스로 독을 차게 만듦
        "친구랑 서먹해지느니 그냥 해주는 게 편하더라.":
            window show
            $ d6_weekend_choice = "trap"
            $ d6_deep_talk_style = "keep_pleasing"
            $ add_like("naeun", 1)
            $ add_neg("naeun", 2)
            $ add_burnout(1)
            $ choice_log.append("D6_naeun_C_trap")

            n "괜히 안 된다고 했다가 교실에서" 
            n "짝꿍 할 때나 모둠 할 때 서먹해지면 그게 더 스트레스잖아."
            n "조금 힘들더라도 그냥 들어주고" 
            n "마음 편하게 지내는 게 학교 다니긴 제일 낫더라."

            "나은이는 내 말에 안도하면서도 씁쓸한 표정으로 고개를 끄덕였다."

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            ne "맞아... 교실에서 나 때문에 분위기 싸해지는 게" 
            ne "세상에서 제일 무서워." 
            ne "그냥 내가 참고 해주는 게 속 편해."

            n "그래도 혼자 다 하진 말고, 너무 지치면 가끔 쉬어."

            hide naeun
            show ne2 at center_stage as naeun with dissolve

            ne "응... 근데 아마 나는 거절 못 하고 또 알겠다고 하겠지?"
            ne "걔가 나 믿고 부탁한 걸 텐데," 
            ne "내가 안 해주면 내가 나쁜 애 된 것 같으니까..."

            "나은이는 입술을 깨물며 억지로 웃어 보였다."
            "그림 속 우산을 잔뜩 짊어진 아이를 보던" 
            "나은이의 고개가 밑으로 푹 가라앉았다."
            "상대방의 기분을 지키느라 나은이 자신의 마음에는" 
            "점점 더 무거운 돌덩이가 얹어지는 것 같았다."

            $ d6_memory_line = "나은이는 못 하겠다고 말하기 어렵다고 했다. 나는 도와주는 게 편할 때도 있다고 말했다."

        # [호감도 +1] 거절 뒤의 경험을 사실대로 말하지만 해결책까지 제시하지는 않음
        "조금 어색하긴 했어. 그 뒤엔 그냥 평소처럼 지냈어.":
            window show
            $ d6_weekend_choice = "plain"
            $ d6_deep_talk_style = "kind_praise"
            $ add_like("naeun", 1)
            $ choice_log.append("D6_naeun_B_plain")

            n "조금 어색하긴 했어."
            n "그 뒤엔 그냥 평소처럼 지냈어."

            hide naeun
            show ne5 at center_stage as naeun with dissolve

            ne "아... 그랬구나."

            n "응."

            hide naeun
            show ne1 at center_stage as naeun with dissolve

            ne "그래도 나는 아직 말하려면 좀 무서울 것 같아."
            n "그럴 수 있지."

            "나은이는 그림 속 젖은 어깨를 다시 조용히 바라보았다."

            $ d6_memory_line = "나은이는 거절하면 친구가 싫어할지 물었다. 나는 조금 어색했지만 그 뒤엔 평소처럼 지냈다고 말했다."

    # 메뉴 종료 후 공통 흐름
    "전시실을 다 둘러보고 밖으로 나왔다."
    "햇빛이 입구 계단에 길게 내려와 있었다."

    scene bg_art with fade
    show ne3 at center_stage as naeun with dissolve

    ne "오늘..."
    ne "나 때문에 천천히 같이 걸으면서 구경해 줘서 고마워."

    n "나도 재미있었어."
    n "나은이가 왜 매번 괜찮다고만 했었는지 마음을 조금은 알 것 같아."

    if d6_weekend_choice == "equal":

        hide naeun
        show ne4 at center_stage as naeun with dissolve

        ne "다음에 학교에서 누가 또 나한테 은근슬쩍 양보해 달라고 하면..."
        ne "고개부터 끄덕이지 말고," 
        ne "일단 내 마음이 진짜 괜찮은지 한 번만 꼭 먼저 물어볼게."

        n "응. 네 마음이 제일 중요해."

        ne "응. 내 마음 먼저."

        "나은이는 스케치북을 소중하게 품에 안고 활짝 웃었다."

    elif d6_weekend_choice == "trap":

        hide naeun
        show ne5 at center_stage as naeun with dissolve

        ne "월요일에 또 모둠 과제 새로 뽑을 텐데..."
        ne "그냥 남는 어려운 역할 있으면" 
        ne "내가 먼저 하겠다고 해버려야겠어. 그게 속 편해."

        n "그래... 네가 편한 대로 해."

        "나은이는 애써 씩씩하게 고개를 끄덕였지만," 
        "스케치북을 쥔 손가락 끝이 하얗게 굳어 있었다."

    else:

        hide naeun
        show ne1 at center_stage as naeun with dissolve

        ne "오늘 전시실에서 내 바보 같은 이야기 다 들어줘서" 
        ne "정말 고마워 유진아."

        n "아냐, 바보 같긴 무슨. 솔직하게 말해줘서 고마워."

    n "월요일에 교실에서 봐, 나은아."

    ne "응. 월요일에 교실에서 봐."

    jump d6_diary
# ----------------------------------------------------------
# D6 소희 — 소희 집 아파트 방
# ----------------------------------------------------------

label d6_sohee_weekend:
    $ set_bgm(audio.bgm_sohee_warm)

    scene bg_bus_stop_morning with fade

    "학교 정문에서 세 정거장 떨어진 아파트 단지 안이었다."
    "현관 벨을 누르자마자, 소희가 바로 문을 열었다."

    scene bg_shouse with dissolve
    show sh1 at center_stage as sohee with dissolve

    sh "유진아!"
    sh "왔구나. 얼른 들어와!"

    n "안녕, 소희야."
    n "어머니 계셔?"

    hide sohee
    show sh4 at center_stage as sohee with dissolve

    sh "응."
    sh "엄마 부엌에 계셔."
    sh "우리 온다고 쿠키 반죽 미리 다 준비해 주셨어."

    "소희는 내가 신발을 벗을 수 있게 한 걸음 뒤로 물러섰다."

    sh "가방은 여기 편하게 둬."
    sh "불편한 거 있으면 바로 말하고."

    n "응."
    n "고마워."

    "부엌 쪽에서는 고소한 버터 냄새가 솔솔 풍겼다."

    sh "엄마!"
    sh "내가 학교에서 매일 말했던 유진이 진짜 왔어!"

    "부엌 쪽에서 소희 어머니의 다정한 웃음소리가 들렸다."

    window hide

    scene bg_black with Fade(0.5, 0.2, 0.5)

    show sh_weekend at weekend_movie_full
    with Dissolve(1.2)

    pause 0.3
    window auto

    "소희네 거실에는 작은 낮은 탁자가 놓여 있었다."
    "탁자 위에는 쿠키가 담긴 접시와 우유컵 두 개가 있었다."

    "거실 벽에는 소희가 만든 작은 하트 장식들이 가득 붙어 있었다."

    sh "유진아."
    sh "이거 한번 먹어봐."
    sh "진짜 바삭하고 맛있어."

    n "고마워. 잘 먹을게."

    sh "저 벽에 붙은 하트 장식들 보이지?"
    sh "나 집에서 심심할 때마다 접은 거야."
    sh "어때, 예쁘지?"

    n "우와."
    n "진짜 많이 접었다. 손재주 좋네."

    sh "응."
    sh "집에 혼자 있으면 시간 안 가니까 그냥 맨날 접어."

    sh "나 사실 단짝이라는 말 엄청 좋아하거든?"
    sh "근데 오늘은..."

    sh "유진아."
    sh "우리 내 방에 들어가서 얘기할까?"

    n "응."
    n "좋아."

    scene d6_sohee_room with slow_fade

    "소희 방은 거실보다 훨씬 조용했다."

    show sh2 at center_stage as sohee with dissolve

    sh "근데 유진아... 나..."
    sh "내가 왜 이렇게 단짝이라는 말에 집착하고" 
    sh "자꾸 확인받고 싶어 하는지 알아?"

    n "왜 그런데?"

    "소희는 책상 위에 놓인 탁상달력을 멍하니 쳐다보았다."

    hide sohee
    show sh3 at center_stage as sohee with dissolve

    sh "작년에 진짜 내 모든 걸 다 공유하던 단짝 친구가 있었어."
    sh "학교에서도, 주말에도 거의 계속 같이 있었거든."
    sh "그 친구랑 노는 날에는 달력에 엄청 크게 하트를 쳐놨었어."

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "근데 2학기 때 그 친구가 방과후 미술반에 들어갔어."
    sh "거기서 새로 만난 애랑 같은 조가 되더니," 
    sh "어느 순간부터 둘이서만 집에 같이 가더라."

    n "서운했겠네..."

    sh "처음엔 방과후 수업 때문에 어쩔 수 없는 줄 알았어."
    sh "근데 점점 쉬는 시간도, 급식 줄도 나 빼고 둘이서만 있더라."

    sh "나한테 대놓고 '너랑 절교야'라고 말한 건 아니었어." 
    sh "싸운 것도 아니고."
    sh "근데 걔네 둘이 새로 산 필통 커플로 맞추고," 
    sh "나 빼고 자기들끼리만 떡볶이 먹으러 가더라." 

    n "소희야..."

    sh "차라리 싸운 거면 미안하다고 사과라도 할 텐데," 
    sh "그냥 조용히 밀려나니까 내가 버려진 것 같았어." 

    hide sohee
    show sh3 at center_stage as sohee with dissolve

    sh "그 뒤로는 좋아하는 친구가 생기면" 
    sh "나도 모르게 심장이 엄청 가라앉아." 
    sh "또 나 빼고 멀어질까 봐 무서워서 자꾸 확인하고 싶어져."

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "화요일에도 네가 다른 애들이랑 웃으면서 얘기할 때..." 
    sh "나 또 혼자 버려지는 줄 알고 괜히 정색하고 서운한 티 냈어."

    sh "오늘 너랑 노는 게 너무 재밌으면" 
    sh "내가 너한테 엄청 집착하고 매달릴 것 같아서..." 
    sh "그럼 네가 나 부담스럽다고 귀찮아할까 봐."

    sh "유진아."
    sh "나 진짜 성격 이상하지? 이런 말 하니까 나 좀 질려?"

    $ choice_question_text = "소희가 질리냐고 물었다. 뭐라고 말할까?"
    window hide

    menu:
        # [호감도 +3 / 부정적 성향 -1] 우정의 거리감을 인정하고, 집착 대신 건강한 소통 방식을 알려줌
        "근데 다른 애랑 말할 때마다 삐지면 나도 힘들것 같아.":
            window show
            $ d6_weekend_success = True
            $ d6_weekend_choice = "equal"
            $ d6_deep_talk_style = "trust_distance"
            $ add_like("sohee", 3)
            $ add_neg("sohee", -1)
            $ choice_log.append("D6_sohee_A_equal")

            n "네 솔직한 마음 말해줘서 고마워." 
            n "네가 왜 그렇게 불안해했는지 이제 이해돼."

            hide sohee
            show sh4 at center_stage as sohee with dissolve

            sh "진짜...? 나 안 귀찮아?"

            n "응. 근데 내가 다른 애랑 10분 얘기한다고 해서" 
            n "너랑 절교하는 거 아냐." 
            n "우리 우정이 그렇게 쉽게 사라지는 장난감은 아니잖아."

            n "앞으로 내가 다른 애랑 숙제 얘기나 딴 얘기 할 때," 
            n "혼자 속으로 '나 버려지나?' 하고 서운해하지 마." 
            n "매번 그러면 나도 눈치 보여서 힘들어."

            hide sohee
            show sh2 at center_stage as sohee with dissolve

            n "불안할 땐 뒤에서 째려보거나 토라져 있지 말고," 
            n "그냥 당당하게 와서 '나도 같이 끼워줘!' 하고 말해줘." 

            n "응. 꼭 매일 24시간 붙어 다니지 않아도" 
            n "우린 친한 친구 맞아." 
            n "억지로 네 존재를 증명하려고 애쓰지 않아도 돼."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "알겠어... 월요일에 네가 다른 애랑 얘기하고 있어도," 
            sh "바로 삐지지 않고 나도 같이 끼워달라고 말해볼게."

            n "말 잘 듣네. 고마워. 나도 너 서운하지 않게" 
            n "너랑 수다 떨 시간 꼭 따로 만들게."

            $ d6_memory_line = "소희는 예전 친구가 조금씩 멀어진 이야기를 했다. 나는 기다려도 친구라고 말했다."


        # [호감도 +1] 질리지는 않았다고 답하되 관계 불안을 깊게 해결해주지는 않고 화제를 돌림
        "아니, 질리진 않았어.":
            window show
            $ d6_weekend_choice = "plain"
            $ d6_deep_talk_style = "light_fun"
            $ add_like("sohee", 1)
            $ choice_log.append("D6_sohee_B_plain")

            n "아니, 질리진 않았어."

            hide sohee
            show sh3 at center_stage as sohee with dissolve

            sh "진짜?"
            n "응."
            sh "다행이다..."

            n "아까 만들던 쿠키 마저 만들까?"

            hide sohee
            show sh4 at center_stage as sohee with dissolve

            sh "응! 하트 모양도 아직 남았어."
            n "그럼 그것부터 만들자."

            "소희는 다시 쿠키 반죽을 내 쪽으로 밀어주었다."

            $ d6_memory_line = "소희는 자기가 질리냐고 물었다. 나는 질리진 않았다고 답했다."


        # [부정적 성향 +2 / 번아웃 +1 / 호감도 +1] 집착과 불안 반응을 정당화하여 소희의 확인 강박을 심화시킴 (함정)
        "불안하면 언제든 나한테 백 번이든 친하냐고 물어봐도 돼.":
            window show
            $ d6_weekend_choice = "trap"
            $ d6_deep_talk_style = "constant_reassurance"
            $ add_like("sohee", 1)
            $ add_neg("sohee", 2)
            $ add_burnout(1)
            $ choice_log.append("D6_sohee_C_trap")

            n "난 너 이해해. 전혀 귀찮지 않으니까" 
            n "불안할 때마다 나한테 계속 물어봐도 돼."

            hide sohee
            show sh4 at center_stage as sohee with dissolve

            sh "진짜...? 내가 하루에 몇 번씩 톡으로 물어봐도" 
            sh "다 대답해 줄 거야?"

            n "응. 네가 걱정 안 되게," 
            n "내가 너랑 제일 친하다고 언제든 말해줄게."

            hide sohee
            show sh2 at center_stage as sohee with dissolve

            sh "그럼... 월요일에 네가 다른 애랑 급식 줄 같이 서거나 얘기하고 있으면," 
            sh "내가 바로 너한테 가서 물어볼게."

            sh "유진아, 우리 아직 제일 친한 거 맞지? 하고."

            n "응. 불안해하는 것보단 물어보는 게 나으니까."

            hide sohee
            show sh4 at center_stage as sohee with dissolve

            sh "다행이다!" 
            sh "역시 내 마음 알아주는 건 유진이 너밖에 없어." 
            sh "나 진짜 불안해지면 바로바로 확인할게!"

            "소희는 안심한 듯 활짝 웃었지만,"
            "벌써부터 월요일에 나에게 물어볼 말을 고르는 눈치였다."

            $ d6_memory_line = "소희는 예전 친구 이야기를 했다. 나는 계속 물어봐도 된다고 했다."

    # 메뉴 종료 후 공통 흐름
    scene bg_shouse with fade

    "오븐에서 띵- 하는 소리가 울리자 소희 어머니가 우리를 부르셨다."

    show sh1 at center_stage as sohee with dissolve

    sh "앗, 여기 모서리 살짝 탄 거는 내가 먹을게!"

    n "아냐, 탄 게 더 바삭하고 맛있어. 같이 먹자."
    n "접시 가운데에 다 섞어놓고 같이 골라 먹으면 되지."

    "소희는 미소를 지으며 쿠키를 반으로 뚝 쪼갰다."

    if d6_weekend_choice == "equal":

        hide sohee
        show sh2 at center_stage as sohee with dissolve

        sh "유진아. 월요일에 또 마음 급해지면"
        sh "혼자 삐지기 전에 말로 예쁘게 물어볼게."

        n "응. 그렇게 해줘."

    elif d6_weekend_choice == "trap":

        hide sohee
        show sh4 at center_stage as sohee with dissolve

        sh "유진아, 약속한 거다?"
        sh "월요일에 내가 물어보면 꼭 친하다고 대답해 줘야 해."

        n "응, 알겠어."

        "소희는 든든한 보험을 든 것처럼 웃어 보였지만," 
        "눈빛은 여전히 내 반응을 살피고 있었다."

    else:

        hide sohee
        show sh3 at center_stage as sohee with dissolve

        sh "쿠키 더 식기 전에 얼른 먹자."

        n "우와, 진짜 귀엽게 잘 나왔다."

    n "오늘 맛있는 것도 많이 만들어주고" 
    n "초대해 줘서 고마워, 소희야."

    hide sohee
    show sh1 at center_stage as sohee with dissolve

    sh "나도 우리 집까지 와줘서 진짜 고마워."
    sh "월요일에 교실에서 제일 먼저 인사하자, 유진아!"

    n "응. 주말 잘 보내고 월요일에 봐!"

    jump d6_diary
# ----------------------------------------------------------
# D6 서연 — 동네 종합 도서관 자료실
# ----------------------------------------------------------

label d6_seoyeon_weekend:
    $ set_bgm(audio.bgm_seoyeon_clear)

    scene bg_library_after with fade

    "동네 종합 도서관 정문 앞에 도착했을 때,"
    "서연이는 이미 가방을 메고 꼿꼿하게 서 있었다."

    show sy5 at center_stage as seoyeon with dissolve

    sy "유진."
    sy "시간 딱 맞춰서 왔네. 12시 2분 전이야."

    n "응."
    n "서연이는 일찍 와 있었어?"

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "아니."
    sy "약속 시간은 12시잖아." 
    sy "너무 일찍 오면 서로 기다려야 하니까 시간 맞춰 온 거야."

    "서연이는 가방에서 깨끗한 소설책 한 권을 꺼냈다."

    hide seoyeon
    show sy5 at center_stage as seoyeon with dissolve

    sy "이거."
    sy "네가 저번에 이야기 만드는 거" 
    sy "좋아한다고 했던 게 기억나서 빌려왔어."

    n "나 주려고 골라온 거야? 고마워."

    sy "응."
    sy "마음에 안 들면 안 읽어도 돼."
    sy "그냥 도서관 책 고르다가 네 생각이 나서 가져온 거니까."

    "말투는 딱딱했지만, 책을 건네는 손끝은 조심스러웠다."

    window hide

    scene bg_black with Fade(0.5, 0.2, 0.5)

    show sy_weekend at weekend_movie_full
    with Dissolve(1.2)

    pause 0.3
    window auto

    "우리는 자료실 창가 책상에 마주 보고 앉았다."

    sy "첫 장부터 한번 읽어봐."

    n "지금 바로?"

    sy "응."
    sy "그래야 네 마음에 드는지 안 드는지 바로 알 수 있잖아."

    n "와, 재밌다."
    n "지루하게 안 끌고, 처음부터 사건이 바로 터지네."

    sy "그럴 줄 알았어."
    sy "처음부터 해결해야 할 문제가 바로 시작되는 책이거든."

    "서연이는 책갈피를 책장 사이에 반듯하게 끼워 넣었다."

    n "서연아."
    n "너는 이런 작은 책갈피 하나도" 
    n "진짜 직각 맞춰서 반듯하게 해놓는다."

    scene bg_library_after with fade
    show sy4 at center_stage as seoyeon with dissolve

    sy "삐뚤어지면 나중에 책 펼칠 때 신경 쓰이잖아." 
    sy "한 번에 똑바로 해두는 게 마음 편해."

    n "조금 삐뚤어진 채로 보면 안 돼? 피곤하잖아."

    "서연이는 책갈피 끝을 누르며 잠깐 생각에 잠겼다."

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "처음부터 내가 이렇게 짧고 딱딱하게 말했던 건 아니야."

    n "그럼? 예전엔 달랐어?"

    sy "4학년 때 사회 모둠 발표 과제가 있었어."
    sy "선생님이 꼭 넣어야 하는 항목이 적힌 체크리스트를 나눠주셨거든."

    sy "발표 전날 확인해 보니까," 
    sy "우리 모둠 애들이 '역할 분담 소개' 페이지를 통째로 빼먹었더라고." 
    sy "점수가 5점이나 깎이는 부분이었어."

    n "그래서 모둠 애들한테 말했어?"

    sy "응. ‘얘들아, 여기 보면 역할 소개가 빠진 것 같아.'" 
    sy "'다시 확인해 보는 게 좋겠어’ 라고 조심스럽게 말했어."

    sy "근데 모둠장이 귀찮아하더라고." 
    sy "시간 없으니까 그냥 이대로 내자고."
    sy "내가 자꾸 말하면 애들이 싫어할까 봐,"
    sy "나도 더는 말 안 하고 참았어."

    sy "그런데 발표 날에 선생님이 전원 앞에서 물어보셨어." 
    sy "왜 필수 항목인 역할 소개가 없냐고." 
    sy "결국 우리 모둠만 감점당했어."

    hide seoyeon
    show sy4 at center_stage as seoyeon with dissolve

    sy "아니."
    sy "끝나고 모둠장이 나한테 와서 화를 냈어."
    sy "'너 그거 빠진 거 알고 있었다면서'," 
    sy "'왜 더 세게 말 안 해줬냐' 고."

    n "그건 너무 억지다. 서연이 네가 분명히 말했었잖아."

    sy "응. 나는 분명히 말했어."
    sy "하지만 내가 끝까지 밀어붙이지 않아서 결과가 안 좋았고," 
    sy "결국 내 탓이 된 거잖아."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "그때 알았어." 
    sy "착하게 길게 말하면 사람들은 대충 듣고 넘겨 버린다는 걸."
    sy "잘못되는 걸 막으려면," 
    sy "발견한 즉시 짧고 확실하게 말해야 한다고 생각했어."

    sy "그래서 그 뒤로는 결론만 바로 말하게 됐어."
    sy "'그거 아니야', '이거 빠졌어', '그렇게 하면 안 돼..."

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "응. 그래야 애들이 실수를 안 하니까."

    sy "처음엔 다들 나한테 고마워했어."
    sy "준비물이나 숙제 확인도 자주 물어봤고."

    hide seoyeon
    show sy4 at center_stage as seoyeon with dissolve

    sy "그런데... 6학년이 되고 나서는" 
    sy "애들이 나한테 잘 안 물어봐."
    sy "오히려 내가 도와주려고 가까이 가면," 
    sy "하던 말을 멈추거나 자리를 피할 때도 있어."

    sy "나는 더 잘할 수 있도록 알려준 것뿐인데."
    sy "친구들은 내가 틀린 부분을 지적하는 것 자체를" 
    sy "싫어하는 것 같아."

    sy "유진."
    sy "솔직하게 말해줘."
    sy "내가 말할 때 너무 따지듯이 기분 나쁘게 말해?"

    $ choice_question_text = "서연이의 질문에 뭐라고 답변할까?"
    window hide

    menu:

        # [호감도 +1] 질문에는 답하지만 구체적인 해결 방법까지 제시하지는 않는 가벼운 피드백
        "나는 크게 신경 쓰이진 않았어.":
            window show
            $ d6_weekend_choice = "plain"
            $ d6_deep_talk_style = "light_respect"
            $ add_like("seoyeon", 1)
            $ choice_log.append("D6_seoyeon_B_plain")

            n "나는 크게 신경 쓰이진 않았어."

            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve

            sy "그래?"
            n "응. 그냥 그런가 보다 했어."

            sy "알겠어."

            n "여기 도서관, 조용하고 햇빛도 잘 들어와서 공부하기 딱 좋은 것 같아."

            sy "응. 동네에서 여기가 제일 조용하고 깨끗해. 그래서 나도 주말마다 와."

            "서연이는 자신의 말투에 대한 이야기를 더 깊게 이어가지 않았다."

            $ d6_memory_line = "서연이는 말이 세게 들리는지 물었다. 나는 크게 신경 쓰이지는 않았다고 말했다."

        # [부정적 성향 +2 / 호감도 +1] 직설 화법을 무조건 부추겨 고집을 강화함 (함정)
        "회장이면 틀린 건 정확히 짚어야지. 네 방식도 필요해.":
            window show
            $ d6_weekend_choice = "trap"
            $ d6_deep_talk_style = "strict_check"
            $ add_like("seoyeon", 1)
            $ add_neg("seoyeon", 2)
            $ choice_log.append("D6_seoyeon_C_trap")

            n "전혀 기분 안 나빠." 
            n "회장이라면 애들이 실수할 때 틀린 걸 정확하게 짚어줘야지."
            n "착한 척 돌려 말하다가 일 망치는 것보다" 
            n "확실하게 말하는 네 방식이 무조건 맞아."

            hide seoyeon
            show sy1 at center_stage as seoyeon with dissolve

            sy "그렇지? 바로 말해줘야" 
            sy "애들도 정신 차리고 실수를 안 하니까."
            n "응. 나도 가끔 준비물 빼먹을 때 있잖아."
            n "그럴 때 네가 바로 말해 주면,"
            n "뭐가 문제인지 빨리 알 수 있어서 좋긴 해."

            "서연이는 바로 수첩을 펼쳐 연필을 들었다."

            sy "- 준비물 안 챙긴 사람은 바로 말하기."
            sy "- 규칙을 어기면 그 자리에서 알려 주기."
            sy "- 돌려 말하지 말고 확실하게 말하기."

            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve

            sy "확인했어."
            sy "그럼 월요일부터는 더 단호하게 말할게."
            sy "애들이 헷갈리지 않게."

            n "어..."
            "서연이는 고개를 끄덕이며 수첩을 닫았다."
            "나는 괜히 말을 너무 쉽게 한 건 아닌지 조금 걱정됐다."
            "서연이는 만족스럽게 웃었지만, 눈빛은 전보다 더 완고해져 있었다."

            $ d6_memory_line = "서연이는 말이 세게 들리는지 물었다. 나는 회장이라면 바로 지적해도 된다고 말했다."

        # [호감도 +3 / 부정적 성향 -1] 서연이의 '의도'는 인정하되, '방식'이 오히려 역효과를 낸다는 것을 귀띔해줌
        "가끔 세게 들리긴 해. 맞는 말도 기분 나쁘면 애들이 안 듣거든.":
            window show
            $ d6_weekend_success = True
            $ d6_weekend_choice = "equal"
            $ d6_deep_talk_style = "soft_start"
            $ add_like("seoyeon", 3)
            $ add_neg("seoyeon", -1)
            $ choice_log.append("D6_seoyeon_A_equal")

            n "가끔 너무 단정적으로 말해서 세게 들릴 때가 있어."
            n "네가 한 말이 다 맞는데도 말이야."

            hide seoyeon
            show sy2 at center_stage as seoyeon with dissolve

            sy "내 말이 맞는데도, 그냥 말투 때문에 애들이 내 말을 안 듣는다고?"

            n "응. 바로 '그거 틀렸어, 아니야'라고 해버리면,"
            n "애들은 정답을 배우기 전에 덜컥 무안하거나" 
            n "공격받았다고 생각해서 마음을 닫아버려."
            n "그러면 아무리 맞는 말이어도 애들이 안듣게 돼."

            sy "...그렇네. 나는 잘못된 걸 고쳐주려고 한 건데," 
            sy "말투 때문에 애들이 안 들으면 결국 소용없는 거구나."

            n "맞아. 그러니까 알려줄 내용을 바꾸라는 게 아니라," 
            n "처음 꺼내는 말만 조금 부드럽게 바꿔보는 건 어때?"

            sy "말을 부드럽게? 예를 들면 어떻게?"

            n "‘이 부분 틀렸어’ 대신에,"
            n "‘우리 이 부분 같이 다시 볼래?’처럼 제안하는 거지."

            hide seoyeon
            show sy4 at center_stage as seoyeon with dissolve

            sy "‘우리 같이 다시 볼래? 하나 빠진 것 같아서’..."

            sy "기분 나쁘지 않으면서도," 
            sy "빠진 부분을 확실하게 알려줄 수 있네."

            n "응. 내용은 그대로 전하면서 말 시작만 바꾸는 거야."

            hide seoyeon
            show sy5 at center_stage as seoyeon with dissolve

            sy "유진. 월요일부터 내가 교실에서" 
            sy "또 나도 모르게 너무 뾰족하게 말하면 옆에서 눈치 좀 줘."
            sy "얼른 부드러운 말로 다시 고쳐서 말해볼 테니까."

            n "그래. 네 본심이 나쁜 게 아니라는 건 아니까," 
            n "내가 옆에서 슬쩍 알려줄게."

            $ d6_memory_line = "서연이는 말이 세게 들리는지 물었다. 나는 친구들이 덜 속상하게 말하는 방법을 알려주었다."

    # 메뉴 종료 후 공통 흐름
    scene bg_library_after with fade

    "어느새 도서관 창밖으로 저녁 노을이 번지기 시작했다."

    show sy1 at center_stage as seoyeon with dissolve

    sy "벌써 5시네. 이제 도서관 문 닫을 시간 다 됐다."

    n "그러네, 시간 진짜 빨리 갔다." 
    n "서연이 너랑 같이 보니까 공부가 더 잘된 것 같아."

    if d6_weekend_choice == "equal":

        hide seoyeon
        show sy5 at center_stage as seoyeon with dissolve

        sy "유진. 오늘 네가 알려준 대화 방법..."
        sy "월요일에 한번 써볼 테니까 꼭 지켜봐 줘."

        n "응. 서연이 너라면 금방 잘할 수 있을 거야. 월요일에 봐!"

    elif d6_weekend_choice == "trap":

        hide seoyeon
        show sy2 at center_stage as seoyeon with dissolve

        sy "월요일 1교시 학급 회의 때부터" 
        sy "딴짓하는 애들 확실하게 잡아낼 거야."
        sy "네가 내 편 들어줬으니까,"
        sy "나도 회장으로서 타협 안 할 거야."

    else:

        hide seoyeon
        show sy1 at center_stage as seoyeon with dissolve

        sy "책 다 읽으면 다음 주말에 반납일 맞춰서 한 번 더 같이 오자."
        sy "그때도 2분 전에 정문 앞에서 기다리고 있을게."

        n "그래. 연체 안 되게 부지런히 읽고 올게. 주말 잘 보내!"

    n "오늘 좋은 책 추천해 줘서 정말 고마웠어, 서연아."

    hide seoyeon
    show sy5 at center_stage as seoyeon with dissolve

    sy "나야말로 내 이야기 진지하게 들어줘서 고마워, 유진."
    sy "월요일 아침에 교실에서 만나자."

    jump d6_diary

# ----------------------------------------------------------
# D6 일기 — 학교 밖에서 본 친구의 다른 모습
# ----------------------------------------------------------
label d6_diary:
    $ set_bgm(audio.bgm_evening)

    scene bg_room_evening
    with slow_fade

    window show

    "집에 돌아와 방으로 들어왔다."
    "토요일 하루가 거의 끝나가고 있었다."

    if d6_event_person != "none":
        "학교 밖에서 보니까 친구가 교실에 있을 때와 조금 달라 보였다."
    else:
        "오늘은 혼자 보낸 토요일이었다."

    "나는 책상 앞에 앉아 일기장을 펼쳤다."

    scene bg_diary
    with fade

    window hide

    $ _d6_solo_style = d6_solo_style if "d6_solo_style" in globals() else "none"
    $ _focus = d6_event_person if d6_event_person != "none" else d5_leaf_person

    if _focus == "none":
        $ _focus = max(["jiho", "hayoung", "naeun", "sohee", "seoyeon"], key=lambda p: like_of(p))

    $ _focus_name = display_name(_focus)
    $ _focus_like = like_of(_focus)
    $ _focus_neg = neg_of(_focus)

    $ diary_text1 = ""
    if d6_event_person != "none":
        $ diary_text1 += "토요일에 교실에서만 보던 친구와 처음 밖에서 만나게 됐다.\n"
        $ diary_text1 += "어쩐지 긴장도 되고 설레기도 한 하루였다.\n\n"
    else:
        $ diary_text1 += "오늘은 혼자 보낸 토요일이었다.\n"
        $ diary_text1 += "조용했지만, 이번 주 일이 계속 떠올랐다.\n\n"

    if d6_event_person == "jiho":
        $ diary_text1 += "오늘은 지호와 농구장에 갔다.\n"
        $ diary_text1 += "농구를 한 뒤, 지호는 자기가 왜 그렇게 욱했는지 이야기해 주었다.\n"
        $ diary_text1 += "이야기를 듣고 나니 지호 마음을 조금 더 알게 된 것 같다.\n"

    elif d6_event_person == "hayoung":
        $ diary_text1 += "오늘은 하영이와 카페에 갔다.\n"
        $ diary_text1 += "하영이는 친구들과 함께 있는 게 좋지만, 가끔 버거울 때도 있다고 했다.\n"
        $ diary_text1 += "이야기를 듣고 나니 하영이 마음을 조금 더 알게 된 것 같다.\n"

    elif d6_event_person == "naeun":
        $ diary_text1 += "오늘은 나은이와 그림 전시실에 갔다.\n"
        $ diary_text1 += "그림을 보며 나은이는 싫어도 괜찮다고 말한 적이 많다고 했다.\n"
        $ diary_text1 += "이야기를 듣고 나니 나은이 마음을 조금 더 알게 된 것 같다.\n"

    elif d6_event_person == "sohee":
        $ diary_text1 += "오늘은 소희네 집에 갔다.\n"
        $ diary_text1 += "소희는 예전 친구와 조금씩 멀어진 이야기를 해주었다.\n"
        $ diary_text1 += "이야기를 듣고 나니 소희 마음을 조금 더 알게 된 것 같다.\n"

    elif d6_event_person == "seoyeon":
        $ diary_text1 += "오늘은 서연이와 도서관에 갔다.\n"
        $ diary_text1 += "서연이는 왜 말을 짧고 세게 하게 됐는지 이야기해 주었다.\n"
        $ diary_text1 += "이야기를 듣고 나니 서연이 마음을 조금 더 알게 된 것 같다.\n"

    else:
        if _d6_solo_style == "library":
            $ diary_text1 += "오늘은 혼자 도서관에 갔다.\n"
            $ diary_text1 += "창가 자리에 앉아 책을 읽었다.\n"

        elif _d6_solo_style == "walk":
            $ diary_text1 += "오늘은 동네를 천천히 걸었다.\n"
            $ diary_text1 += "학교가 보이는 길이 어쩐지 반갑게 느껴졌다.\n"

        elif _d6_solo_style == "home":
            $ diary_text1 += "오늘은 집에서 쉬었다.\n"
            $ diary_text1 += "가방을 비우고 책상 위를 정리했다.\n"

        else:
            $ diary_text1 += "오늘은 따로 약속이 없었다.\n"
            $ diary_text1 += "친구를 만나지 않은 토요일은 조용했다.\n"

    $ diary_text1 += "\n"

    if d6_event_person != "none":
        if d6_weekend_choice == "equal":
            $ diary_text1 += "오늘은 " + _focus_name + " 이야기를 그냥 넘기지 않았다.\n"
            $ diary_text1 += "내 생각도 말해서 조금 떨렸지만, 하고 나니 마음이 가벼웠다.\n"

        elif d6_weekend_choice == "plain":
            $ diary_text1 += "오늘은 즐거웠다.\n"
            $ diary_text1 += "그런데 " + _focus_name + "이 꺼낸 이야기를 조금 더 물어볼 수도 있었을 것 같다.\n"

        elif d6_weekend_choice == "trap":
            $ diary_text1 += "오늘은 " + _focus_name + "이 좋아할 만한 말로 대답했다.\n"
            $ diary_text1 += "그때는 편했지만, 일기장을 펴니 조금 마음에 걸렸다.\n"

        else:
            $ diary_text1 += "학교 밖에서 보니 " + _focus_name + "이 조금 다르게 보였다.\n"
            $ diary_text1 += "교실에서는 듣지 못한 말도 들었다.\n"

    else:
        if d6_weekend_choice == "solo":
            $ diary_text1 += "오늘은 혼자 시간을 보냈다.\n"
            $ diary_text1 += "친구를 만나지 않아도 이번 주 있었던 일들은 계속 생각났다.\n"
            $ diary_text1 += "혼자 쉬는 것도 나쁘지 않았다.\n"

        else:
            $ diary_text1 += "오늘은 약속 없는 주말이었다.\n"
            $ diary_text1 += "조용한 시간이 필요했던 것 같기도 하다.\n"

    call screen diary_page(title="토요일 일기", content=diary_text1, body_yoffset=35)

    $ renpy.movie_cutscene("videos/diary.webm", stop_music=False)

    $ diary_text3 = ""
    $ diary_text3 += "오늘은 " + _focus_name + " 생각이 계속 났다.\n"
    $ diary_text3 += relation_status_text(_focus_like, _focus_neg) + "\n\n"

    if _focus_neg >= 4:
        $ diary_text3 += _focus_name + "과 가까워진 것 같지만, 조금 불편한 순간도 있었다.\n"
        $ diary_text3 += "불편하면 웃고 넘기지 말고 짧게 말해보기.\n"

    elif _focus_like >= 7 and _focus_neg <= 3:
        $ diary_text3 += _focus_name + "과 있으면 편한 순간이 많았다.\n"
        $ diary_text3 += "월요일에는 고마웠던 말 하나만 짧게 전해보기.\n"

    elif _focus_like >= 5:
        $ diary_text3 += _focus_name + "과 조금 가까워진 것 같다.\n"
        $ diary_text3 += "그래도 너무 급하게 친해지려고 하지는 말기.\n"

    else:
        $ diary_text3 += _focus_name + "은 아직 조금 더 봐야겠다.\n"
        $ diary_text3 += "친해졌다고 혼자 확정 짓지 말고, 말과 행동을 같이 보기.\n"

    if burnout <= 2:
        $ diary_text3 += "\n나의 상태: 아직 괜찮다.\n"
        $ diary_text3 += "월요일에도 친구들에 대해 더 알아가보자.\n"

    elif burnout <= 5:
        $ diary_text3 += "\n나의 상태: 조금 지쳤다.\n"
        $ diary_text3 += "쉬는 시간에는 친구만 보지 말고 내 자리에서도 잠깐 쉬기.\n"

    else:
        $ diary_text3 += "\n나의 상태: 많이 지쳤다.\n"
        $ diary_text3 += "친구 마음을 다 챙기려고 하지 말고, 내 마음부터 보기.\n"

    show screen diary_focus_badge(_focus)
    call screen diary_page(title="토요일 관계 메모", content=diary_text3, body_yoffset=145)
    hide screen diary_focus_badge

    scene bg_room_evening
    with slow_fade

    window show

    "일기장을 덮었다."
    "내일은 일요일이다."
    "가방 지퍼를 닫자 딸깍 소리가 났다."

    jump d7_start

# ==========================================================
# D7 일요일 저녁 — 전체 회고
# ==========================================================
# 역할:
# - 전학 첫 주 동안 만난 다섯 친구를 돌아본다.
# - 친구 마음을 살피는 것과 내 마음을 지키는 것을 함께 정리한다.
# - D8 월요일 엔딩으로 넘어가기 전, 유진의 마음을 차분히 정리한다.
# ==========================================================

default d7_reflection_focus = "none"

# ----------------------------------------------------------
# D8 엔딩 판정용 변수 / 함수
# ----------------------------------------------------------

default ending_type = "none"
default ending_person = "none"
default ending_person_2 = "none"
default ending_title = ""
default ending_rank_text = ""


# ==========================================================
# D8 엔딩 판정용 변수 / 함수 - 최종 추천 버전
# ==========================================================

init python:

    def ending_all_names():
        return ["jiho", "hayoung", "naeun", "sohee", "seoyeon"]

    def ending_d6_boost(name):
        return 1 if d6_event_person == name and d6_weekend_success else 0

    def ending_d5_boost(name):
        return 1 if d5_leaf_person == name and d5_best_friend_success else 0

    def ending_has_success_marker(name):
        return (
            (d6_event_person == name and d6_weekend_success)
            or
            (d5_leaf_person == name and d5_best_friend_success)
        )

    def ending_rank_key(name):
        return (
            like_of(name),
            ending_d6_boost(name),
            ending_d5_boost(name),
            -neg_of(name)
        )

    def ending_top_person():
        ranked = sorted(ending_all_names(), key=ending_rank_key, reverse=True)
        return ranked[0]

    def ending_second_person():
        ranked = sorted(ending_all_names(), key=ending_rank_key, reverse=True)
        return ranked[1]

    def ending_count_like_at_least(value):
        return len([name for name in ending_all_names() if like_of(name) >= value])

    def ending_count_neg_at_least(value):
        return len([name for name in ending_all_names() if neg_of(name) >= value])

    def ending_total_neg():
        return sum([neg_of(name) for name in ending_all_names()])


    def ending_best_bad_candidate():
        candidates = [
            name for name in ending_all_names()
            if like_of(name) >= 5 and neg_of(name) >= 4
        ]

        if not candidates:
            return "none"

        return sorted(
            candidates,
            key=lambda name: (
                neg_of(name),
                like_of(name),
                ending_d6_boost(name),
                ending_d5_boost(name)
            ),
            reverse=True
        )[0]


    def ending_growth_evidence(name):
        healthy_logs = {
            "jiho": {
                "D2_jiho_A_equal", "D2_jiho_event_A_equal",
                "D3_jiho_3a_A_point", "D3_jiho_3b_A_balance", "D3_jiho_2_A_nudge",
                "D4_jiho_4a_A_anger_spill", "D4_jiho_4b_A_feeling_left", "D4_jiho_2_A_notice_anger",
            },
            "hayoung": {
                "D2_hayoung_conflict_A", "D2_hayoung_event_A_equal",
                "D3_hayoung_3a_A_careful", "D3_hayoung_3b_A_careful", "D3_hayoung_2_A_no_gossip",
                "D4_hayoung_4a_A_burden_notice", "D4_hayoung_4b_A_balance", "D4_hayoung_2_A_no_gossip",
            },
            "naeun": {
                "D2_naeun_conflict_A", "D2_naeun_event_A_apology",
                "D3_naeun_3a_A_rest", "D3_naeun_3b_A_ask_first", "D3_naeun_2_A_check",
                "D4_naeun_4a_A_not_your_fault", "D4_naeun_4b_A_limit", "D4_naeun_2_A_help",
            },
            "sohee": {
                "D2_sohee_conflict_A", "D2_sohee_event_A_equal",
                "D3_sohee_3a_A_boundary", "D3_sohee_3b_A_boundary", "D3_sohee_2_A_later",
                "D4_sohee_4a_A_clear_feeling", "D4_sohee_4b_A_stable_friend", "D4_sohee_2_A_light_boundary",
            },
            "seoyeon": {
                "D2_seoyeon_conflict_A", "D2_seoyeon_event_A_intent",
                "D3_seoyeon_3a_A_balance", "D3_seoyeon_3b_A_condition", "D3_seoyeon_2_A_add_condition",
                "D4_seoyeon_4a_A_check_together", "D4_seoyeon_4b_A_limited_fix", "D4_seoyeon_2_A_enough",
            },
        }

        healthy_count = sum(1 for code in healthy_logs.get(name, set()) if code in choice_log)
        return healthy_count >= 2 or ending_has_success_marker(name)


    def ending_best_good_candidate():
        top = ending_top_person()

        if (
            like_of(top) >= 8
            and neg_of(top) <= 3
            and ending_growth_evidence(top)
        ):
            return top

        return "none"


    def ending_best_pair_candidate():
        top = ending_top_person()
        second = ending_second_person()

        if (
            like_of(top) >= 6
            and like_of(second) >= 6
            and neg_of(top) <= 3
            and neg_of(second) <= 3
            and abs(like_of(top) - like_of(second)) <= 2
        ):
            return top, second

        return "none", "none"


    def ending_should_hard_burnout():
        return burnout >= 4


    def ending_should_soft_burnout():
        return burnout >= 3 and ending_count_like_at_least(5) >= 3


    def decide_final_ending():
        global ending_type, ending_person, ending_person_2, ending_title, ending_rank_text

        top = ending_top_person()
        second = ending_second_person()

        ending_person = top
        ending_person_2 = second
        ending_rank_text = (
            d5_display_name(top) + " " + str(like_of(top))
            + " / "
            + d5_display_name(second) + " " + str(like_of(second))
        )

        good_titles = {
            "jiho":    "장난을 멈출 때를 아는 사이",
            "hayoung": "같이 있어도 내 목소리를 잃지 않는 사이",
            "naeun":   "부탁보다 먼저 마음을 묻는 사이",
            "sohee":   "기다림 속에서도 믿음이 이어지는 사이",
            "seoyeon": "반듯한 말에도 마음을 담는 사이",
        }

        bad_titles = {
            "jiho":    "웃음 뒤의 불편함을 놓친 사이",
            "hayoung": "따라 웃다가 내 목소리를 잃은 사이",
            "naeun":   "괜찮다는 말만 믿다가 멀어진 사이",
            "sohee":   "붙어 있어도 편하지 않은 사이", 
            "seoyeon": "맞는 말만 남고 마음은 놓친 사이",
        }

        # 1. 강제 번아웃
        if ending_should_hard_burnout():
            ending_type = "burnout"
            ending_person = top
            ending_title = "친구 마음만 보다가 내 마음을 놓친 사이"
            return

        # 2. 심각한 개별 배드
        bad = ending_best_bad_candidate()
        if bad != "none" and (bad == top or neg_of(bad) >= 5):
            ending_type = "bad"
            ending_person = bad
            ending_title = bad_titles.get(bad, "")
            return

        # 3. 페어
        pair_1, pair_2 = ending_best_pair_candidate()
        if pair_1 != "none":
            ending_type = "pair"
            ending_person = pair_1
            ending_person_2 = pair_2
            ending_title = "두 친구 사이에서 배운 균형"
            return

        # 4. 개별 굿
        good = ending_best_good_candidate()
        if good != "none":
            ending_type = "good"
            ending_person = good
            ending_title = good_titles.get(good, "")
            return

        # 5. 일반 개별 배드
        if bad != "none":
            ending_type = "bad"
            ending_person = bad
            ending_title = bad_titles.get(bad, "")
            return

        # 6. 약한 번아웃
        if ending_should_soft_burnout():
            ending_type = "burnout"
            ending_person = top
            ending_title = "친구 마음만 보다가 내 마음을 놓친 사이"
            return

        # 7. 솔로
        ending_type = "solo"
        ending_person = top
        ending_person_2 = second
        ending_title = "서두르지 않고 천천히 다가가는 사이"


label d7_start:

    $ day = 7

    scene black
    with day_fade
    centered "일요일"
    pause 0.5
    $ set_bgm(audio.bgm_evening_reflection)

    scene bg_room_evening with fade

    "일요일 저녁."
    "책상 위에는 일기장과 필통이 놓여 있었다."
    "모둠 활동지는 아직 가방 밖에 나와 있었다."

    "첫 주가 끝났다는 게 그제야 보였다."

    "그때 방문 밖에서 엄마 목소리가 들렸다."

    m "유진아, 밥 먹자."

    jump d7_dinner

# ==========================================================
# D7-1. 엄마와 저녁 식탁
# ==========================================================
label d7_dinner:

    scene bg_kitchen_evening with fade

    "식탁에는 밥과 국, 반찬 몇 가지가 놓여 있었다."
    "엄마는 내 앞에 숟가락을 놓아주다가 내 얼굴을 보았다."

    show m1 at center_stage as mom with dissolve

    m "김치 조금 줄까?"

    n "응. 조금만."

    "엄마는 김치를 조금 덜어 내 접시에 올려주었다."
    "그걸 보는데, 이상하게 이번 주 친구들이 떠올랐다."

    m "일주일 다녀보니까 어때?"
    m "새 반은 좀 익숙해졌어?"

    n "조금."
    n "근데 아직 어려워."

    hide mom
    show m2 at center_stage as mom with dissolve

    m "친구들이?"

    n "응."
    n "다 나쁜 애들은 아닌데..."
    n "어떻게 말해야 할지 헷갈릴 때가 많아."

    "엄마는 바로 대답하지 않았다."
    "국을 한 숟가락 떠서 내 쪽으로 밀어주었다."

    m "그럴 땐 바로 정하지 않아도 돼."
    m "조금 더 봐도 되고,"
    m "힘들면 잠깐 멈춰도 돼."

    n "잠깐 멈춰도 돼?"

    m "응."
    m "친구랑 지내는 것도 쉬면서 해야 오래 가지."

    "나는 숟가락을 들었다."
    "따뜻한 국 냄새가 올라왔다."

    n "나 이번 주에 친구들 마음만 많이 본 것 같아."
    n "내가 어떤지는 잘 못 봤고."

    hide mom
    show m3 at center_stage as mom with dissolve

    m "그걸 알았으면 된 거야."
    m "내일은 그것도 같이 보면 되지."

    hide mom with dissolve

    "나는 남은 밥을 천천히 먹었다."
    "엄마는 더 묻지 않았다."

    scene bg_room_evening with fade

    "방에 돌아와 불을 조금 낮췄다."
    "오늘 들었던 말들이 하나씩 떠올랐다."

    scene black with fade

    pause 0.8

    show text "이번 주 동안 쌓인 관계를 정리해보자." at truecenter with Dissolve(1.5)
    pause 1.5
    hide text with Dissolve(1.0)

    pause 0.3

    jump d8_relation_note_check

# ----------------------------------------------------------
# D8 진입 전 — 관계 노트 확인
# ----------------------------------------------------------

label d8_relation_note_check:

    scene black with fade
    window hide

    $ result = renpy.call_screen("d8_relation_note_screen")

    if result == "go_ending":
        jump d8_start
    else:
        jump d8_relation_note_check

label d8_start:

    $ decide_final_ending()

    if ending_type == "burnout":
        jump ending_burnout
    elif ending_type == "good":
        jump ending_good_route
    elif ending_type == "bad":
        jump ending_bad_route
    elif ending_type == "pair":
        if (ending_person == "jiho" and ending_person_2 == "hayoung") or (ending_person == "hayoung" and ending_person_2 == "jiho"):
            jump ending_pair_jiho_hayoung
        elif (ending_person == "jiho" and ending_person_2 == "naeun") or (ending_person == "naeun" and ending_person_2 == "jiho"):
            jump ending_pair_jiho_naeun
        elif (ending_person == "jiho" and ending_person_2 == "sohee") or (ending_person == "sohee" and ending_person_2 == "jiho"):
            jump ending_pair_jiho_sohee
        elif (ending_person == "jiho" and ending_person_2 == "seoyeon") or (ending_person == "seoyeon" and ending_person_2 == "jiho"):
            jump ending_pair_jiho_seoyeon
        elif (ending_person == "hayoung" and ending_person_2 == "naeun") or (ending_person == "naeun" and ending_person_2 == "hayoung"):
            jump ending_pair_hayoung_naeun
        elif (ending_person == "hayoung" and ending_person_2 == "sohee") or (ending_person == "sohee" and ending_person_2 == "hayoung"):
            jump ending_pair_hayoung_sohee
        elif (ending_person == "hayoung" and ending_person_2 == "seoyeon") or (ending_person == "seoyeon" and ending_person_2 == "hayoung"):
            jump ending_pair_hayoung_seoyeon
        elif (ending_person == "naeun" and ending_person_2 == "sohee") or (ending_person == "sohee" and ending_person_2 == "naeun"):
            jump ending_pair_naeun_sohee
        elif (ending_person == "naeun" and ending_person_2 == "seoyeon") or (ending_person == "seoyeon" and ending_person_2 == "naeun"):
            jump ending_pair_naeun_seoyeon
        elif (ending_person == "sohee" and ending_person_2 == "seoyeon") or (ending_person == "seoyeon" and ending_person_2 == "sohee"):
            jump ending_pair_sohee_seoyeon
        else:
            jump ending_solo
    else:
        jump ending_solo

label d8_monday_intro:

    window hide

    scene bg_black
    with Fade(1.0, 0.5, 1.0)

    $ set_bgm(audio.bgm_daily_morning)

    pause 0.8

    centered "{cps=4}다시, 월요일{/cps}{w=1.2}{nw}"

    pause 0.5
    window auto

    scene bg_school_day with fade

    "월요일 아침."
    "가방끈을 고쳐 메고 학교 쪽으로 걸었다."

    "교실 문 앞에서 잠깐 멈췄다."
    "손잡이를 잡기 전에 숨을 크게 쉬었다."

    return
# ==========================================================
# 5. 개별 굿 엔딩 (건강한 거리감과 소통선 수립)
# ==========================================================
# ==========================================================
# 5. 개별 굿 엔딩
# ==========================================================
screen ending_title_screen(title):

    zorder 300

    add Solid("#00000088")

    frame:
        xalign 0.5
        yalign 0.5
        xpadding 40
        ypadding 22
        background Solid("#000000AA")

        text title:
            font FILE_FONT
            size 34
            color "#FFF8E8"
            outlines [(3, "#2B2118", 0, 0)]
            text_align 0.5
            xalign 0.5


label show_ending_title(title):

    $ unlock_ending_by_title(title)

    window hide

    show screen ending_title_screen(title)
    with Dissolve(0.3)

    pause 2.0

    hide screen ending_title_screen
    with Dissolve(0.3)

    window auto

    return

label ending_good_route:
    if ending_person == "jiho":
        jump ending_good_jiho
    elif ending_person == "hayoung":
        jump ending_good_hayoung
    elif ending_person == "naeun":
        jump ending_good_naeun
    elif ending_person == "sohee":
        jump ending_good_sohee
    elif ending_person == "seoyeon":
        jump ending_good_seoyeon
    else:
        jump ending_solo
label ending_good_jiho:
    $ set_bgm(audio.bgm_good)

    call d8_monday_intro from _call_d8_mon_good_jiho

    scene bg_classroom_after with fade

    "교실 문을 열자마자 뒷자리에서 지호의 목소리가 들렸다."
    "지호는 농구공을 발끝으로 살짝 굴렸다."
    "그러고는 책상 다리 앞에서 얼른 멈췄다."

    show jh3 at center_stage as jiho with dissolve

    jh "아, 위험했다."
    jh "교실에서 세게 굴리면 또 다른 애들이 깜짝 놀라지."

    n "오늘은 안 던지네?"

    hide jiho
    show jh5 at center_stage as jiho with dissolve

    jh "응."
    jh "던지고 싶었는데 진짜 꾹 참았어."
    jh "너랑 계속 같이 놀려면 나도 조심해야지."

    "지호는 민망한 듯 웃었다."
    "그때 옆 모둠 아이가 지나가다 지호의 필통을 쳤다."

    "탁."

    "필통이 바닥에 떨어졌다. 연필 몇 자루가 요란하게 굴러갔다."

    hide jiho
    show jh2 at center_stage as jiho with dissolve

    jh "야, 너 진짜—"

    "지호의 미간이 찌푸려졌다. 목소리가 커지려는 순간이었다."
    "하지만 지호는 주먹을 쥐고 심호흡을 했다."
    "화를 내지 않고 말을 끝까지 참아냈다."

    hide jiho
    show jh6 at center_stage as jiho with dissolve

    jh "아."
    jh "후... 깜짝 놀랐네."

    "지호가 먼저 허리를 숙였다. 바닥에 떨어진 연필을 주웠다."

    jh "미안. 내가 필통을 너무 길가에 뒀어."

    "옆 모둠 아이가 놀란 표정을 지었다."
    "이내 미안하고 고마운 얼굴로 고개를 숙였다."

    ex_mj "어? 아냐, 미안."
    ex_mj "내가 앞을 잘 못 봤어."

    hide jiho
    show jh3 at center_stage as jiho with dissolve

    jh "응, 괜찮아."
    jh "다음엔 둘 다 좀 조심하자."

    n "지호야."
    n "방금 너 진짜 멋있었어."

    hide jiho
    show jh5 at center_stage as jiho with dissolve

    jh "내가? 뭐가?"

    n "욱하지 않고 한 번 참아줬잖아."
    n "덕분에 교실 분위기도 안 싸해졌고," 
    n "나도 옆에서 덜 긴장했어."

    "지호는 귀 끝이 살짝 빨개졌다." 
    "괜히 농구공만 만지작거렸다."

    hide jiho
    show jh3 at center_stage as jiho with dissolve

    jh "뭐, 이제 생각 없이 화부터 내지 않으려고 노력하는 중이야."

    n "신경 써 줘서 고마워, 진짜로."

    jh "고맙긴 뭘."

    "지호는 잠깐 쑥스러운 듯 말이 없었다. 이내 환하게 웃었다."

    hide jiho
    show jh1 at center_stage as jiho with dissolve

    jh "아무튼 내 노력 알아줬으니까 점심에 농구나 하자."
    jh "오늘은 내기 같은 거 말고, 그냥 다 같이 던지고 놀자."

    n "나 완전 못 던지는데."

    hide jiho
    show jh5 at center_stage as jiho with dissolve

    jh "그럼 어때. 연습하면 되지."
    jh "들어가기만 하면 내가 제일 크게 손뼉 쳐줄게."

    n "아까처럼 소리 지르는 건 안 돼."

    jh "아, 맞다."
    jh "그럼 조용히 박수만 칠게."

    "지호는 농구공을 자기 자리 밑으로 깊숙이 밀어 넣었다."
    "이번에는 발로 세게 쾅 튕기지 않았다."

    window hide

    scene bg_black
    with Dissolve(0.8)

    show cg_jh_good at cg_slow_fadein

    $ renpy.pause(2.0, hard=True)

    pause 0.5
    window auto

    "지호는 여전히 시끄럽고 장난기가 많았다."
    "공을 보면 몸이 먼저 움직이는 것도 그대로였다."

    "그래도 이제는 소리치기 전에 스스로 멈출 줄 알았다."
    "가끔 욱할 때도 있었지만, 얼른 참으려고 애썼다."

    "지호가 완전히 다른 사람이 된 건 아니었다."
    "나도 지호의 행동을 다 받아줄 수는 없었다."

    "하지만 우리는 중요한 걸 함께 배웠다."
    "장난은 혼자만 신나면 안 된다."
    "둘 다 웃을 수 있어야 진짜 장난이다."

    "싫다고 말하는 건 친구를 밀어내려는 거절이 아니었다."
    "앞으로도 계속 같이 놀고 싶어서 보내는 서툰 신호였다."

    "우리는 서로를 완벽하게 고쳐주는 사이가 아니다."
    "상처받지 않게 거리를 조금씩 맞춰가는 사이였다."
    scene black
    with fade
    call show_ending_title("지호 성장 엔딩")

    jump d8_common_epilogue
# ────────────────────────────────────────────────────────
# [하영 굿 엔딩] 제목: 같이 있어도 내 말을 할 수 있는 사이
# ────────────────────────────────────────────────────────
label ending_good_hayoung:
    $ set_bgm(audio.bgm_good)

    call d8_monday_intro from _call_d8_mon_good_hayoung

    scene bg_classroom_after with fade

    "교실에 들어가자 창가 사물함 앞에 아이들이 모여 있었다."
    "하영이도 그 가운데에 서 있었다."

    show h5 at center_stage as hayoung with dissolve

    hy "유진아, 왔어?"

    n "응. 아침부터 많이 모여 있네."

    hy "그러게."

    "그때 채린이가 은지 쪽을 보았다."

    ex_cr "하영아, 은지 오늘 머리 묶은 거 좀 이상하지 않아?"

    "은지는 필통을 정리하다가 손을 멈췄다."

    hide hayoung
    show h3 at center_stage as hayoung with dissolve

    hy "...근데 그거 말하면 은지 신경 쓰일 것 같아."

    hy "머리 이상하다고 말하는 거 말이야."
    hy "들은 애는 하루 종일 그 생각만 할 수도 있잖아."

    hide hayoung
    show h2 at center_stage as hayoung with dissolve

    hy "근데 들은 사람이 속상해하면 별로잖아."

    hide hayoung
    show h6 at center_stage as hayoung with dissolve

    hy "은지야. 오늘 체육 줄넘기 하는 날이지?"

    hy "머리 묶으니까 편하겠다."
    hy "나도 체육 전에 묶어야겠다."

    "은지는 잠깐 놀란 얼굴을 하더니 작게 웃었다."
    "채린이도 민망한지 슬쩍 발표지를 꺼냈다."

    ex_cr "아, 하영아 우리 모둠 발표 순서 좀 정해줘."
    ex_cr "너 그런 거 잘하잖아."

    hide hayoung
    show h4 at center_stage as hayoung with dissolve

    hy "음."
    hy "내가 적어줄 수는 있어."
    hy "근데 먼저 하고 싶은 순서부터 솔직하게 말해봐."

    hide hayoung
    show h5 at center_stage as hayoung with dissolve

    hy "나는 두 번째가 좋아."
    hy "첫 번째 하고 싶은 사람 있어?"

    "아이들이 하나둘씩 눈치를 보다 손을 들었다."

    n "나는 세 번째 괜찮아."

    hide hayoung
    show h1 at center_stage as hayoung with dissolve

    hy "오케이."
    hy "유진이는 세 번째."

    "하영이는 내 말을 바로 적었다."

    "발표 준비가 끝나자 아이들이 자리로 돌아갔다."
    "사물함 앞에는 하영이와 나 둘만 남았다."

    n "아까 은지 얘기할 때..."
    n "나도 좀 마음이 걸렸어."
    n "근데 내가 먼저 말하기는 어려웠어."

    hide hayoung
    show h3 at center_stage as hayoung with dissolve

    hy "나도 전에는 애들이 웃어주면 다 괜찮은 줄 알았어."
    hy "내가 말하면 애들이 나만 보는 것도 좋았고."

    hy "근데 억지로 웃기는 것보다" 
    hy "이렇게 솔직하게 말하는 게 훨씬 마음 편하다."

    n "응."
    n "그렇게 안 해도 하영이는 하영이잖아."

    hide hayoung
    show h6 at center_stage as hayoung with dissolve

    hy "그 말 좀 부끄럽다."

    hide hayoung
    show h5 at center_stage as hayoung with dissolve

    hy "그럼 오늘 방과 후에 운동장 옆 벤치 갈래?"
    hy "그냥 아이스크림 하나씩 먹으면서."

    n "좋아."
    n "딸기맛 있으면 내가 먼저 고를 거야."

    hy "그럼 가위바위보."

    hide hayoung
    show h1 at center_stage as hayoung with dissolve

    "하영이는 장난스럽게 웃었다."
    "그 웃음은 여전히 밝았다."

    window hide

    scene bg_black
    with Dissolve(0.8)

    show cg_hy_good at cg_slow_fadein

    $ renpy.pause(2.0, hard=True)

    pause 0.5
    window auto
    "하영이는 여전히 아이들 사이의 중심이었다."
    "하지만 이제는 인기를 얻으려고 억지로 꾸며내지 않았다."

    "하영이도 자기 진짜 마음을 말하고," 
    "나도 내 생각을 당당하게 말했다."
    "누군가의 눈치를 보느라 내 목소리를 줄이지 않아도 괜찮았다."

    "함께 있어도, 억지로 맞추지 않고" 
    "내 모습 그대로 함께 웃을 수 있었다."

    "우리는 같이 있어도 서로의 목소리를 잃지 않게 지켜주는 사이였다."
    scene black
    with fade
    call show_ending_title("하영 성장 엔딩")

    jump d8_common_epilogue
# ────────────────────────────────────────────────────────
# [나은 굿 엔딩] 제목: 부탁보다 먼저 마음을 묻는 사이
# ────────────────────────────────────────────────────────
label ending_good_naeun:
    $ set_bgm(audio.bgm_good)

    call d8_monday_intro from _call_d8_mon_good_naeun

    scene bg_classroom_after with fade

    "교실에 들어가자 나은이가 자기 자리에 앉아 있었다."
    "혼자 종합장을 넘겨보다가, 나를 보고 손을 멈췄다."

    show ne5 at center_stage as naeun with dissolve

    ne "유진아."
    ne "나 전시회에서 봤던 그림 다시 그려봤어."

    n "와, 봐도 돼?"

    hide naeun
    show ne4 at center_stage as naeun with dissolve

    ne "응. 먼저 보여주고 싶었어."

    "나은이가 책상 위에 종합장을 펼쳤다."
    "그림 속 아이는 여러 우산을 들고 있었다."
    "이번에는 아이의 머리 위에도 작은 우산 하나가 씌워져 있었다."

    n "이번에는 아이도 비를 안 맞네."

    hide naeun
    show ne1 at center_stage as naeun with dissolve

    ne "응."
    ne "맨날 남한테만 우산을 주면 나중에 내가 춥잖아."

    "그림 구석에는 연필로 적은 작은 말풍선이 있었다."

    "『나도 조금 힘들어.』"

    n "이 문장 진짜 좋다."

    hide naeun
    show ne4 at center_stage as naeun with dissolve

    ne "입으로 바로 말하려면 아직 떨릴 것 같아서."
    ne "연습 삼아 그림이랑 글로 먼저 써봤어."

    "그때 모둠 과제를 하던 채은이가 우리 쪽으로 다가왔다."

    ex_ce "나은아, 나 오늘 학원 때문에 진짜 바쁘거든?"
    ex_ce "이 부분 네가 대신 정리해 주면 안 돼?"
    ex_ce "너 원래 이런 거 잘하잖아."

    "나은이는 종합장과 자기 공책을 번갈아 보더니, 숨을 작게 들이쉬었다."

    hide naeun
    show ne2 at center_stage as naeun with dissolve

    ne "음..."
    ne "이번에는 내가 다 해주기는 어려워."

    "목소리는 작았지만, 말끝은 흐려지지 않았다."

    ex_ce "어? 그럼 안 해준다는 거야?"

    hide naeun
    show ne4 at center_stage as naeun with dissolve

    ne "전부를 대신 해주는 건 힘들어."
    ne "모르는 부분이 있으면 같이 고민해 줄 수는 있어."
    ne "하지만 네가 맡은 부분은 네가 먼저 해봐."

    "나은이는 공책을 상대 아이 쪽으로 조심스럽게 밀어냈다."
    "아이는 잠깐 눈을 깜빡이다가 공책을 다시 챙겼다."

    ex_ce "어...알았어. 그럼 모르는 거 생기면 물어볼게."

    hide naeun
    show ne1 at center_stage as naeun with dissolve

    ne "응. 그건 언제든 같이 고민해줄게."

    "아이가 멀어지자, 나은이는 그제야 길게 숨을 내쉬었다."

    n "나은아."
    n "방금 거절한 거 진짜 멋있었어."

    hide naeun
    show ne3 at center_stage as naeun with dissolve

    ne "진짜로? 내 목소리 너무 작지 않았어?"

    n "조금 작긴 했어도 네 생각은 확실하게 들렸어."

    ne "응... 심장이 엄청 쿵쾅거렸어."

    hide naeun
    show ne1 at center_stage as naeun with dissolve

    ne "아직은 크게 말하진 못하겠어. 방금도 손이 계속 떨렸거든."

    n "방금처럼 작게 말해도 다 들리는걸?"

    ne "응. 작게라도 계속 말해볼게."

    "나는 활동지를 꺼내며, 방금 배운 것을 떠올렸다."

    # [수정] 엔딩 타이틀 '부탁보다 마음을 먼저 묻는 사이'를 직접적으로 보여주는 대사 추가
    n "나은아, 지금 잠깐 하나만 물어봐도 괜찮아?"

    hide naeun
    show ne5 at center_stage as naeun with dissolve

    ne "응, 괜찮아. 뭔데?"

    n "나 이거 제목이 좀 어색해서, 아이디어만 살짝 줄 수 있어?"

    ne "여기 글씨 선만 아래로 살짝 맞추면 훨씬 예쁠 것 같아."

    "나은이는 자기 종이에 작은 예시를 그려주며 나를 도와주었다."

    window hide

    scene bg_black
    with Dissolve(0.8)

    show cg_ne_good at cg_slow_fadein

    $ renpy.pause(2.0, hard=True)

    pause 0.5
    window auto

    "나은이는 여전히 조용하고 따뜻한 친구였다."

    "하지만 이제는 무조건 괜찮다고 말하지 않았다."
    "혼자 감당하기 어려운 일은 어렵다고 솔직하게 말했다."

    "부탁을 거절해도 나쁜 친구가 되는 건 아니라는 걸 깨달았기 때문이다."

    "그림 속 아이는 여전히 여러 개의 우산을 들고 있었다."
    "하지만 이제는 자기 머리 위에도 든든한 우산 하나를 받치고 있었다."

    "우리는 무작정 부탁을 던지기 전에,"
    "상대의 마음이 어떤지 먼저 물어보는 진짜 사이가 되었다."
    scene black
    with fade
    call show_ending_title("나은 성장 엔딩")

    jump d8_common_epilogue

label ending_good_sohee:
    $ set_bgm(audio.bgm_good)

    call d8_monday_intro from _call_d8_mon_good_sohee

    scene bg_classroom_after with fade

    "소희는 자기 자리에 앉아 가방 속을 정리하고 있었다."
    "내가 교실에 들어오자, 소희는 바로 고개를 들었다."

    show sh1 at center_stage as sohee with dissolve

    sh "유진아! 안녕!"
    sh "주말 잘 쉬었어?"

    n "응."
    n "소희는 잘 쉬었어?"

    hide sohee
    show sh4 at center_stage as sohee with dissolve

    sh "나도 잘 쉬었지."
    sh "어제 쿠키 먹다가 부스러기 엄청 흘렸어."

    "소희는 가방 앞주머니에서 작은 곰돌이 키링을 꺼냈다."

    hide sohee
    show sh3 at center_stage as sohee with dissolve

    sh "나 이거 오늘도 가져왔어."
    sh "근데 오늘은 네 가방에 같이 달자고 안 할래."

    n "어? 왜?"

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "전에는 똑같은 걸 나눠 가져야만 마음이 놓였거든."
    sh "눈에 안 보이면 꼭 나를 싫어하게 될 것 같아서."
    sh "근데 이제는 우선 내 가방에만 예쁘게 달아두려고."

    "그때 앞자리 친구가 의자를 돌려 내 책상 쪽으로 다가왔다."

    ex_ms "유진아! 너 어제 그 예능 프로그램 봤어?"
    ex_ms "거기서 나온 노래 진짜 좋더라. 완전 대박이지?"

    n "어? 나도 그거 봤어! 그 부분 진짜 웃겼는데."

    "앞자리 친구와 나는 주말에 본 방송 이야기로 금방 신이 났다."
    "소희는 대화에 끼지 못했지만, 예전처럼 내 팔을 당기지는 않았다."

    "소희는 자리에 앉아 공책에 뭔가를 슥슥 그리기 시작했다."
    "입술을 조금 삐죽거리긴 했지만," 
    "예전처럼 화를 내지는 않았다."

    "잠시 뒤, 앞자리 친구와의 대화가 자연스럽게 끝났다."
    "친구가 다시 자기 자리로 몸을 돌리자, 나는 소희를 보았다."

    n "소희야, 뭐 그려?"

    hide sohee
    show sh3 at center_stage as sohee with dissolve

    sh "이거? 삐진 소희."

    "소희가 공책을 보여주었다."

    sh "아까 둘이서 얘기할 때, 사실 마음속에서" 
    sh "'나랑만 놀아줘!' 하는 소리가 막 커졌거든."

    n "그랬구나..."

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "근데 눈을 감고 생각했어."
    sh "유진이가 다른 애랑 얘기한다고 해서 나를 잊어버리는 건 아니라고."

    n "마음을 공책에 털어 놓은거야?"
    sh "응. 예전에는 불안하면 무조건 너부터 붙잡았거든."
    sh "근데 이제는 공책에 적으면서 마음을 가라앉혀 보려고."
    sh "조금 기다리면 다시 유진이랑 놀 수 있을테니까."

    "소희는 스스로 마음을 달래는 방법을 찾은 것이다."

    n "소희 진짜 멋지다. 생각이 엄청 깊네."

    hide sohee
    show sh1 at center_stage as sohee with dissolve

    sh "헤헤, 그렇지? 나 이제 혼자서도 마음 잘 지킬 수 있어."
    sh "그러니까 유진이 너도 내 눈치 보지 말고" 
    sh "편하게 다른 애들이랑 얘기해."

    n "고마워, 소희야."

    "소희는 내 팔을 붙잡으려다가 멈칫했다."
    "그러고는 손을 가볍게 흔들며 환하게 웃었다."
    "그 모습이 어딘가 무척 편안해 보였다."

    window hide

    scene bg_black
    with Dissolve(0.8)

    show cg_sh_good at cg_slow_fadein

    $ renpy.pause(2.0, hard=True)

    pause 0.5
    window auto
    "소희는 여전히 나를 무척 좋아하는 다정한 친구였다."
    "여전히 혼자 남겨진 것 같아 불안할 때도 있을 것이다."

    "하지만 이제 소희는 불안하다고 해서 억지로 나를 붙잡지 않았다."
    "속상할 때도 스스로 마음을 가라앉힐 줄 알게 되었다."

    "친구와 잠시 떨어져 있어도," 
    "우리가 멀어지는 건 아니라는 걸 알게 된 것이다."

    "우리는 하루 종일 딱 붙어 있지 않아도 마음은 이어져 있었다."
    "서로의 자리를 지켜주면서,"
    "함께일 때 가장 즐거운 진짜 친구가 되었다."

    "우리는 꼭 붙어 있지 않아도 든든한 친구인 사이였다."
    scene black
    with fade
    call show_ending_title("소희 성장 엔딩")

    jump d8_common_epilogue
# ────────────────────────────────────────────────────────
# [서연 굿 엔딩] 제목: 맞는 말도 조심히 하는 사이
# ────────────────────────────────────────────────────────

label ending_good_seoyeon:
    $ set_bgm(audio.bgm_good)

    call d8_monday_intro from _call_d8_mon_good_seoyeon

    scene bg_classroom_after with fade

    "교실에 들어가자 서연이가 칠판 오른쪽에 오늘 할 일을 적고 있었다."

    "{i}1교시 국어{/i}"
    "{i}2교시 미술 - 모둠 포스터{/i}"
    "{i}도서관 책 반납{/i}"

    show sy5 at center_stage as seoyeon with dissolve

    sy "유진."
    sy "도서관 책 오늘 반납하는 날이야."

    n "맞다."
    n "알려줘서 고마워. 방과 후에 같이 가자."

    "그때 같은 모둠 민우가 포스터 종이를 들고 왔다."

    ex_mw "서연아. 제목은 그냥 크게 쓰면 되지?"

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "먼저 자로 선을 잡아야 해."

    "민우는 매직 뚜껑을 닫았다."

    ex_mw "그럼 그냥 네가 하는게 낫지 않아?"

    hide seoyeon
    show sy4 at center_stage as seoyeon with dissolve

    sy "아니... 내가 선만 같이 봐줄게."
    sy "글씨는 네가 쓰는 게 더 좋아."
    sy "우리 모둠 포스터니까, 네 글씨가 들어가는 게 맞잖아."

    "민우는 다시 매직을 들었다."
    "서연이의 글씨처럼 반듯하지는 않았다. 하지만 큼직하고 밝았다."

    n "좋네. 딱 봐도 우리 모둠이 만든 느낌 나."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "정확히 맞지는 않는데..."

    "서연이는 습관처럼 고쳐주려다가," 
    "민우가 민망해하는 표정을 보고 잠시 멈췄다."

    hide seoyeon
    show sy5 at center_stage as seoyeon with dissolve

    sy "그래도 괜찮아."
    sy "민우가 같이 만든 거라는 게 잘 보이니까 좋아."

    "민우는 안심한 듯 다시 웃었다."

    scene bg_classroom_day with fade

    "미술 시간이 되자 우리 모둠은 색지를 골랐다."
    "서연이는 시간을 보더니 마음이 급해진 것 같았다."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "벌써 시간이..."

    "서연이는 바로 '빨리 정해'라고 말하려다 잠시 멈췄다."
    "그리고 서두르는 대신 친구들을 한 번씩 둘러보았다."

    hide seoyeon
    show sy4 at center_stage as seoyeon with dissolve

    sy "우리 시간 안에 하려면 지금 정하는 게 좋겠어."
    sy "어떤 색이 좋을지 같이 이야기해 볼까?"

    n "그럼 셋 중에 손 들어서 정하자." 
    n "노란색, 하늘색, 연두색."

    hide seoyeon
    show sy1 at center_stage as seoyeon with dissolve

    sy "좋아. 손 들어서 정하자."

    "하늘색이 가장 많았다."

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "나는 노란색이 더 낫다고 생각했는데,"
    sy "다들 하늘색을 고르니까 그것도 그림이랑 잘 어울리네."

    n "서연아. 혼자 하면 훨씬 빨리 끝났을 텐데 답답하지 않아?"

    sy "응. 아마 혼자 했으면 더 빨리 끝나긴 했을거야."

    n "그런데 지금 건 어때?"

    hide seoyeon
    show sy1 at center_stage as seoyeon with dissolve

    sy "...혼자 했으면 이렇게는 안 나왔을 것 같아."
    sy "내 생각보다 친구들 생각이 더해지니까 더 멋지네."

    n "응, 나도 지금이 훨씬 좋아. 아까 친구한테 말할 때" 
    n "서연이가 표정 살피면서 천천히 말하는 거 봤거든."
    n "그렇게 하니까 친구들도 훨씬 편해 보이더라."

    hide seoyeon
    show sy5 at center_stage as seoyeon with dissolve

    sy "그런가? 친구들이 놀랄까 봐 좀 조심스럽긴 했어."
    sy "나도 바로바로 내 생각만 말하는 것보다," 
    sy "같이 확인하면서 하니까 훨씬 마음이 편하더라."

    window hide

    scene bg_black
    with Dissolve(0.8)

    show cg_sy_good at cg_slow_fadein

    $ renpy.pause(2.0, hard=True)

    pause 0.5
    window auto

    "서연이는 여전히 꼼꼼한 아이였다."

    "하지만 이제는 모든 걸 혼자 다 해내려고 서두르지 않는다."
    "친구가 삐뚤게 쓴 글씨를 보며," 
    "예전처럼 뺏어서 고쳐주지 않았다."
    "서연이는 완벽한 결과보다, 친구와 함께 채워가는 과정이" 
    "더 소중하다는 걸 조금씩 알아가고 있었다."

    "이제 서연이의 말은 날카롭지 않다."
    "아직은 서툴지만," 
    "정답보다 친구의 마음을 먼저 생각하려 했다."
    "그 진심은 조금씩 친구들에게 닿고 있었다."

    "우리는 정답을 겨루던 사이에서,"
    "서로의 마음을 맞추어가는 사이가 되어갔다."
    scene black
    with fade
    call show_ending_title("서연 성장 엔딩")

    jump d8_common_epilogue


label ending_bad_route:
    if ending_person == "jiho":
        jump ending_bad_jiho
    elif ending_person == "hayoung":
        jump ending_bad_hayoung
    elif ending_person == "naeun":
        jump ending_bad_naeun
    elif ending_person == "sohee":
        jump ending_bad_sohee
    elif ending_person == "seoyeon":
        jump ending_bad_seoyeon
    else:
        jump ending_solo
# ────────────────────────────────────────────────────────
# [지호 배드 엔딩] 제목: 웃음 뒤의 불편함을 놓친 사이
# ────────────────────────────────────────────────────────
label ending_bad_jiho:
    $ set_bgm(audio.bgm_bad)

    call d8_monday_intro from _call_d8_mon_bad_jiho

    scene bg_classroom_after
    with fade

    "교실에 들어가자 지호가 보드게임 판을 펼치고 있었다."
    "나는 지호 옆자리에 앉았다."

    show jh5 at center_stage as jiho with dissolve

    jh "유진이 내 팀."
    jh "오늘도 빨리 이기자."

    "상대 팀 친구가 규칙표를 집어 들었다."

    hide jiho
    show jh2 at center_stage as jiho with dissolve

    jh "아, 그거 안 봐도 돼."
    jh "게임은 빨리 해야 재밌지."

    n "잠깐만."
    n "순서만 다시 보면 안 돼?"

    hide jiho
    show jh6 at center_stage as jiho with dissolve

    jh "야, 우리 팀인데 왜 상대편 도와줘?"
    jh "장난이야."

    "주변 아이들이 웃었다."
    "나도 따라 웃었다."

    "상대 팀 친구는 규칙표를 조용히 내려놓았다."

    scene bg_classroom_morning
    with fade

    "두 번째 판이 시작됐다."
    "이번에는 내가 말을 놓을 차례였다."

    show jh2 at center_stage as jiho with dissolve

    jh "거기 아니고 오른쪽."
    jh "그거 놓으면 우리 진다니까."

    n "나도 생각해보고 싶은데."

    hide jiho
    show jh1 at center_stage as jiho with dissolve

    jh "유진이 오늘 스파이냐?"
    jh "우리 팀 망하게 하려고 왔냐?"

    "아이들이 다시 웃었다."
    "지호도 웃었다."

    "이번에는 그 웃음이 나한테 왔다."
    "나도 웃으려고 했지만, 입이 잘 움직이지 않았다."

    n "나 진짜 헷갈린 거야."

    hide jiho
    show jh3 at center_stage as jiho with dissolve

    jh "알아, 알아."
    jh "왜 이렇게 진지해."

    "아까 다른 친구가 들었던 말과 비슷했다."
    "그때는 나도 웃고 넘겼다."
    "그런데 내가 들으니 기분이 좋지 않았다."

    "나는 결국 지호가 말한 곳에 게임 말을 놓았다."

    hide jiho
    show jh1 at center_stage as jiho with dissolve

    jh "오케이!"
    jh "역시 내 팀."

    "게임은 이겼다."
    "하지만 이상하게 기쁘지 않았다."

    "아까 규칙을 보려던 친구는 다음 판에 끼지 않았다."
    "그 친구는 책상 끝에서 혼자 책을 보고 있었다."

    scene bg_jh_bad
    with slow_fade

    "지호는 그저 재미있어서 그랬을 것이다."
    "그게 지호가 게임을 즐기는 방식이니까."

    "하지만 그 웃음 뒤에서 누군가는 마음을 닫고 있다는 걸,"
    "우리 둘 다 몰랐다."

    "장난이라고 웃어넘기면 그만인 일들."
    "그렇게 웃음으로 덮다 보니,"
    "우리는 더 깊은 이야기를 할 수 없는 사이가 되었다."

    "그때 내가 할 수 있는 말들이 있었다."

    "잠깐만."
    "순서 다시 확인해보자."
    "방금 말은 좀 상처가 될 것 같아."

    "나는 그 말을 삼켰다."
    "지호의 방식을 바꿔줄 기회를 놓친 것인지,"
    "아니면 지호의 방식에 내가 익숙해진 것인지 알 수 없었다."

    "결국 우리 사이엔 웃음소리만 남았고,"
    "진심은 닿지 못했다."
    scene black
    with fade
    call show_ending_title("지호 후회 엔딩")

    jump d8_common_epilogue
# ────────────────────────────────────────────────────────
# [나은 배드 엔딩] 제목: 괜찮다는 말만 믿다가 멀어진 사이
# ────────────────────────────────────────────────────────
label ending_bad_naeun:
    $ set_bgm(audio.bgm_bad)

    call d8_monday_intro from _call_d8_mon_bad_naeun

    scene bg_classroom_morning
    with fade

    "교실에 들어가자 나은이는 게시판 앞에 서 있었다."
    "색종이와 풀을 정리하며 무언가 열심히 만들고 있었다."

    show ne5 at center_stage as naeun with dissolve

    n "나은아."
    n "너 혼자 다 하고 있었어?"

    ne "응."
    ne "금방 끝날 것 같아서."
    ne "괜찮아."

    "나은이는 작게 웃었다."
    "하지만 눈가는 조금 피곤해 보였다."

    n "역시 나은이는 착하다."
    n "네가 해주면 애들도 다 좋아할 거야."

    "나은이는 힘없이 웃었다."
    "천천히 사인펜 뚜껑을 닫았다."

    n "나은아, 나 이것도 제목 글씨가 좀 삐뚤어진 것 같아."
    n "내가 쓰면 자꾸 삐뚤어져서 속상해."
    n "네가 한 번만 봐줄 수 있어?"

    hide naeun
    show ne2 at center_stage as naeun with dissolve

    ne "응..."
    ne "줘 봐."
    ne "내가 다시 써줄게."

    "나는 고맙다고 생각했다."
    "나은이는 늘 괜찮다고 했으니까."
    "부탁을 들어주는 게 나은이에게도 당연한 일인 줄 알았다."

    scene bg_classroom_morning
    with fade

    "교무실에 다녀오자 게시판은 완성되어 있었다."
    "내 카드 제목은 나은이의 글씨로 깔끔하게 바뀌어 있었다."

    n "우와, 나은아."
    n "내 부탁 들어줘서 고마워."

    hide naeun
    show ne2 at center_stage as naeun with dissolve

    ne "응."
    ne "어렵지 않으니까."
    ne "괜찮아."

    "나은이는 늘 웃었다."
    "하지만 그 웃음이 조금씩 옅어지고 있었다."

    scene bg_classroom_after
    with fade

    "며칠 뒤 쉬는 시간."
    "나은이는 자기 자리에서 무언가를 그리고 있었다."

    show ne5 at center_stage as naeun with dissolve

    n "나은아."
    n "뭐 그려?"

    "나은이는 놀란 듯 급하게 종합장을 덮었다."

    hide naeun
    show ne2 at center_stage as naeun with dissolve

    ne "그냥."
    ne "별거 아니야."

    n "봐도 돼?"

    ne "아직 다 안 그렸어."
    ne "나중에 보여줄게."

    "나은이는 종합장을 가방 안으로 깊숙이 넣었다."
    "예전에는 먼저 보여주던 그림이었다."

    n "그럼 이것만 좀 봐줄 수 있어?"

    "내 활동지를 내밀자 나은이는 잠시 멈칫했다."
    "사인펜을 잡으려던 손이 작게 떨렸다."

    hide naeun
    show ne1 at center_stage as naeun with dissolve

    ne "응..."
    ne "잠깐만."

    "그때 종이 울렸다."

    ne "미안."
    ne "나 화장실 다녀올게."

    "나은이는 내 대답도 기다리지 않고 교실 밖으로 나갔다."
    "종이 울릴 때까지 나은이는 돌아오지 않았다."

    "그 뒤로 나은이는 내 옆으로 잘 오지 않았다."
    "내가 말을 걸면 자꾸만 다른 곳으로 피했다."

    scene bg_ne_bad
    with slow_fade

    "나는 나은이가 괜찮다니까 믿었다."
    "하지만 나은이는 괜찮다고 말하며," 
    "사실 조금씩 지치고 있었다."

    "나은이가 잘한다고 해서 계속 부탁해도 되는 건 아니었다."
    "착하다는 칭찬이 나은이에게는" 
    "무거운 짐이 되었을지 모른다."

    "그때 내가 할 수 있는 말들이 있었다."

    "너 혼자 다 안 해도 돼."
    "내가 다시 해볼게."
    "정말 괜찮아?"

    "나는 그렇게 묻지 않았다."
    "나은이의 '괜찮아' 뒤에 숨겨진 진짜 마음을 보지 못했다."

    "우리는 서로의 진심을 확인하지 못했다."
    "괜찮다는 말 한마디만 믿었다."

    "그렇게 우리는 조금씩 멀어졌다."
    scene black
    with fade
    call show_ending_title("나은 후회 엔딩")

    jump d8_common_epilogue
# ────────────────────────────────────────────────────────
# [소희 배드 엔딩] 제목: 붙어 있어도 편하지 않은 사이
# ────────────────────────────────────────────────────────
label ending_bad_sohee:
    $ set_bgm(audio.bgm_bad)

    call d8_monday_intro from _call_d8_mon_bad_sohee

    scene bg_corridor_day
    with fade

    "아침 등교 시간, 소희는 신발장 앞에서 나를 기다리고 있었다."

    show sh4 at center_stage as sohee with dissolve

    sh "유진아!"
    sh "왜 이렇게 늦게 왔어?"
    sh "나 계속 기다렸잖아."
    n "미안, 늦잠을 좀 잤어."

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "오늘 급식 같이 먹는 거지?"
    sh "쉬는 시간에도 계속 같이 있을 거지?"

    "나는 소희가 서운해할까 봐 무조건 고개를 끄덕였다."

    n "응, 당연하지."

    scene bg_classroom_after
    with fade

    "교실에 들어가자 앞자리 친구가 말을 걸어왔다."

    ex_ms "유진아, 어제 숙제 어디까지 했어?"

    "내가 대답하려는 순간, 소희가 내 팔을 꼭 잡았다."

    show sh5 at center_stage as sohee with dissolve

    sh "유진이 지금 나랑 얘기 중이야."
    sh "이따가 물어봐."

    "친구는 어색하게 웃더니 자리로 돌아갔다."

    hide sohee
    show sh1 at center_stage as sohee with dissolve

    sh "우리, 이거 맞추길 정말 잘했다."

    "소희는 내 가방의 키링을 만지작거렸다."

    sh "이거 보면 다들 알겠지?"
    sh "유진이는 내 제일 친한 친구라는 거."

    n "응..."

    "웃어주었지만, 마음 한구석이 답답했다."

    scene bg_corridor_day
    with fade

    "쉬는 시간에 물을 마시러 가려고 일어났다."

    show sh2 at center_stage as sohee with dissolve

    sh "나도 같이 갈래."

    "복도에서 하영이가 나를 보고 손을 흔들었다."

    hide sohee
    show h5 at center_stage as hayoung with dissolve

    hy "유진아, 이따 장기자랑 동선 얘기 좀 하자."

    hide hayoung
    show sh5 at center_stage as sohee with dissolve

    sh "유진이 오늘 나랑 약속 있어."
    sh "나중에 해."

    "하영이는 나를 빤히 보더니 그냥 지나갔다."

    sh "유진아, 너 방금 하영이 따라가고 싶었지?"

    n "아니야."
    n "그냥 인사한 것뿐이야."

    scene bg_classroom_day
    with fade

    "오후 수업 전, 숙제장을 꺼냈다."

    "하지만 쉬는 시간마다 소희를 챙기느라,"
    "숙제장은 여전히 빈칸투성이였다."

    show sh2 at center_stage as sohee with dissolve

    sh "유진아, 뭐 해?"

    n "숙제 좀 확인해야 해서."

    hide sohee
    show sh5 at center_stage as sohee with dissolve

    n "조금만 기다려 줄래?"
    n "이것만 보고 갈게."

    "소희는 대답하지 않았다."

    "숙제장을 폈지만 글자가 눈에 들어오지 않았다."
    "소희가 또 서운해할까 봐, 그게 자꾸 신경 쓰였다."

    scene bg_sh_bad
    with slow_fade

    "우리는 가까운 친구가 된 줄 알았다."
    "함께할수록 더 편해질 줄 알았다."

    "하지만 소희는 내가 조금만 떨어져도 불안해했다."
    "나는 소희가 서운해할까 봐, 무조건 괜찮다고 말했다."

    "그러다 보니 소희는 혼자 남는 걸 더 두려워하게 되었다."
    "나는 친구에게 말을 걸 때마다 소희의 눈치를 보게 되었다."

    "그때 내가 해야 했던 말은 이런 게 아니었다."

    "나도 다른 친구와 말할 수 있어."
    "지금은 숙제를 먼저 확인해야 해."
    "그래도 우리는 여전히 친구야."

    "나는 그 말을 끝내 하지 못했다."
    "그래서 우리는 가까이 붙어 있어도," 
    "전혀 편하지 않은 사이가 되었다."
    scene black
    with fade
    call show_ending_title("소희 후회 엔딩")

    jump d8_common_epilogue

label ending_bad_seoyeon:
    $ set_bgm(audio.bgm_bad)

    call d8_monday_intro from _call_d8_mon_bad_seoyeon

    scene bg_classroom_after
    with fade

    "교실에 들어가자 서연이가 칠판 오른쪽에 오늘 할 일을 적고 있었다."

    "{i}1교시 국어{/i}"
    "{i}2교시 미술 - 색지, 풀, 가위{/i}"
    "{i}도서관 책 반납{/i}"

    show sy5 at center_stage as seoyeon with dissolve

    sy "유진아."
    sy "도서관 책 오늘까지 반납해야 하는 거 알지?"

    n "응."
    n "오늘 꼭 낼게."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "늦게 내면 다음에 빌리려는 친구가 기다려야 해."

    "그때 같은 모둠 친구가 색지를 들고 다가왔다."

    ex_mw "서연아."
    ex_mw "이거 반으로 잘라야 해?"

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "어제 설명 들었잖아."
    sy "반으로 자르는 거라고 했어."

    ex_mw "아..."
    ex_mw "내가 잘 못 들었나 봐."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "설명할 때 제대로 들었으면 됐잖아."
    sy "한 명이 대충 하면 다 같이 늦어지는 거야."

    "친구는 아무 말 없이 고개를 숙였다."

    n "우리 모둠 늦어지면 안 되니까..."

    "서연이의 단호한 말에 나는 입을 다물었다."

    scene bg_classroom_morning
    with fade

    "미술 시간, 긴장한 채 그은 선 끝이 살짝 비뚤어졌다."

    show sy3 at center_stage as seoyeon with dissolve

    sy "유진아."
    sy "그 선 삐뚤어졌어."

    n "조금만 다시 맞추면—"

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "조금이 아니야."
    sy "그대로 자르면 모양이 안 맞아."

    "주변 친구들이 우리 쪽을 보자 얼굴이 화끈거렸다."

    n "응, 다시 할게."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "이번엔 내가 옆에서 보고 있을게."
    sy "또 틀리면 종이가 부족해져."

    sy "자를 더 아래로 내려."
    sy "아니, 거기 말고."

    "나는 더 긴장해서 손에 힘이 들어갔다."

    hide seoyeon
    show sy2 at center_stage as seoyeon with dissolve

    sy "내가 말했잖아."

    "그 말이 나오자 더 이상 묻기가 어려워졌다."

    n "나도 하려고 했어..."

    hide seoyeon
    show sy3 at center_stage as seoyeon with dissolve

    sy "근데 하려고만 하면 안 돼."
    sy "정확하게 해야지."

    "서연이가 나를 미워해서 하는 말은 아니라 더 반박하기 힘들었다."

    scene bg_sy_bad
    with slow_fade

    "서연이는 틀린 부분을 빨리 알려주고 싶었을 뿐이었다."

    "하지만 맞는 말이라도 너무 세게 툭 던지니까,"
    "듣는 친구들은 자꾸 주눅이 들었다."

    "서연이가 옆에 있으면 더 잘하려고 애썼는데,"
    "오히려 손이 자꾸 떨리고 긴장되었다."

    "그때 내가 할 수 있었던 말이 있지 않았을까."

    "그 말은 좀 너무 세게 들려."
    "친구들 앞에서는 조금만 부드럽게 말해줄래?"
    "도와주려는 건 고마운데, 그렇게 말하면 더 긴장돼."

    "서연이 말이 틀린 건 아니라서 그 말을 삼켰다."
    "그냥 조용히 있는 게 편했다."

    "그러는 동안 나는 모르는 것을 물어보는 게 어려워졌다."
    "다른 친구들도 서연이가 다가오면 하던 말을 멈췄다."

    "서연이는 틀린 말을 하지 않았지만,"
    "우리는 결국 그 날카로운 말들 앞에서" 
    "입을 닫는 사이가 되었다."
    scene black
    with fade
    call show_ending_title("서연 후회 엔딩")

    jump d8_common_epilogue

label ending_bad_hayoung:
    $ set_bgm(audio.bgm_bad)

    call d8_monday_intro from _call_d8_mon_bad_hayoung

    scene bg_board2
    with fade

    "교실에 들어가자 하영이 주변에 아이들이 모여 있었다."
    "하영이는 은지를 힐끔 보며 작게 웃었다."

    show h2 at center_stage as hayoung with dissolve

    hy "야, 은지 어제 춤출 때 봤어?"
    hy "박자 다 놓치고 혼자 뻘쭘해하던 거."

    "아이들이 작게 웃었다."
    "은지는 자기 자리에서 조용히 종이를 보다가 손을 멈췄다."

    "하영이는 내 반응을 기다렸다."

    n "음... 조금 어색하긴 했지만," 
    n "그래도 은지가 제일 열심히 하던데..."

    "순식간에 교실 분위기가 싸해졌다."
    "아이들은 내 눈치를 살피며 웃음을 멈췄다."

    hide hayoung
    show h4 at center_stage as hayoung with dissolve

    hy "열심히만 하면 다야?"
    hy "유진아, 너는 은지만 편이야?"

    "하영이의 목소리는 낮고 차가웠다."
    "나는 순식간에 혼자가 된 기분이었다."

    n "아니, 그냥 내 생각 말한 건데..."

    hide hayoung
    show h5 at center_stage as hayoung with dissolve

    hy "응, 그래."
    hy "생각 다를 수 있지."

    "하영이는 더 이상 나를 보지 않았다."
    "다른 아이들과 다른 이야기를 시작했다."

    scene bg_classroom_after
    with fade

    "쉬는 시간, 장기자랑 동선을 맞추러 갔다."
    "하영이는 내 옆자리로 가지 않았다."

    show h4 at center_stage as hayoung with dissolve

    hy "아, 동선 꼬이네."
    hy "유진이 때문에 다시 맞춰야겠어."

    "아이들이 한숨을 쉬었다."
    "하영이는 내 손동작을 흉내 내며 핀잔을 줬다."

    hy "손이 혼자 딴 데로 가잖아. 연습 좀 더 해."

    "이번에는 그 싸늘한 웃음이 나에게 쏟아졌다."

    n "나 아직 동선이 좀 헷갈려서..."

    hide hayoung
    show h5 at center_stage as hayoung with dissolve

    hy "말했잖아. 우리끼리는 솔직하게 말하는 거라고."
    hy "기분 나쁘면 어쩔 수 없고."

    "나는 하영이의 눈치를 보았다."
    "다시 하영이의 웃음을 얻고 싶었다."

    "웃는 쪽에 있을 땐 편했는데,"
    "밀려난 쪽이 되니 너무 외로웠다."

    scene bg_hy_bad
    with slow_fade

    "나는 하영이와 멀어지고 싶지 않았다."
    "그래서 마음에 걸리는 말에도 고개를 끄덕였다."

    "하영이는 내가 다시 자기 편이 된 줄 알았다."

    "그 뒤로 나는 내 생각을 말하지 않았다."
    "하영이가 누구를 비웃어도," 
    "나는 그저 하영이의 웃음을 따라 했다."

    "내가 할 수 있는 말은 이제 없었다."

    "나는 그렇게 생각 안 해."
    "그 말은 좀 속상할 것 같아."

    "하지만 내 생각을 말하면," 
    "다시 하영이 곁에서 밀려날 것 같았다."

    "나는 내 의견을 말하지 않고 꾹 참았다."
    "그렇게 하영이의 장단에 맞추는 동안,"
    "내 마음은 점점 하영이의 그림자 뒤로 숨어버렸다."

    "우리는 계속 같이 웃고 있었지만,"
    "결국 나는 나를 잃어버리는 사이가 되었다."
    scene black
    with fade
    call show_ending_title("하영 후회 엔딩")

    jump d8_common_epilogue

# ════════════════════════════════════════════════════════
# [페어 엔딩 ①] 지호 + 하영 - 신나게 웃어도 서로를 살피는 사이
# ════════════════════════════════════════════════════════

label ending_pair_jiho_hayoung:
    $ set_bgm(audio.bgm_pair)

    call d8_monday_intro from _call_d8_mon_pair_jh_hy

    scene bg_board2
    with fade

    "교실 뒤쪽에서 하영이가 장기자랑 동선을 정하고 있었다."

    show h5 at center_stage as hayoung with dissolve

    hy "앞줄은 동작 잘 보이는 애들이 서자."
    hy "은지는 오른쪽 뒤가 좋겠다."

    "은지는 고개를 끄덕였지만, 종이 끝을 만지작거렸다."

    n "은지야."
    n "너는 어디 서보고 싶어?"

    ex_ej "앞줄도..."
    ex_ej "한 번 해보고 싶어."

    hide hayoung
    show h6 at center_stage as hayoung with dissolve

    hy "앞줄은 틀리면 바로 보여서..."

    "하영이는 말을 멈췄다."

    hide hayoung
    show h3 at center_stage as hayoung with dissolve

    hy "아."
    hy "내가 또 먼저 정했네."
    hy "앞줄 해보고 싶은 사람부터 말해보자."

    "그때 지호가 농구공을 옆구리에 끼고 다가왔다."

    hide hayoung
    show jh5 at center_stage as jiho with dissolve

    jh "오, 장기자랑?"
    jh "나도 할래."

    n "교실에서 공 튕기면 안 돼."

    hide jiho
    show jh4 at center_stage as jiho with dissolve

    jh "안 튕겨."
    jh "오늘은 들고만 있을게."

    "연습이 시작되자 지호는 신이 나서 동작을 크게 했다."
    "뒤에 있던 은지는 박자를 놓쳤다."

    hide jiho
    show h5 at center_stage as hayoung with dissolve

    hy "잠깐."
    hy "지호야, 너 혼자 보면 재밌긴 한데,"
    hy "뒤에 있는 애들이 따라가기 힘들어 보여."

    hide hayoung
    show jh3 at center_stage as jiho with dissolve

    jh "내가 너무 컸어?"

    n "신나긴 한데, 뒤에서는 헷갈렸어."

    hide jiho
    show jh5 at center_stage as jiho with dissolve

    jh "그럼 내가 오른쪽 앞에서 조금 작게 할게."
    jh "은지는 가운데 서봐."

    hide jiho
    show h5 at center_stage as hayoung with dissolve

    hy "좋아."
    hy "나도 앞쪽만 보지 말고 뒤쪽도 볼게."

    "다시 음악이 나오자 지호는 동작을 줄였다."
    "하영이는 은지가 끝까지 따라오는지 살폈다."

    hide hayoung
    show h1 at center_stage as hayoung with dissolve

    hy "괜찮은데?"
    hy "은지, 가운데 서도 되겠다."

    hide hayoung
    show jh5 at center_stage as jiho with dissolve

    jh "사진 찍을 때 나 공 들고 서면 멋있을 듯."

    hide jiho
    show h4 at center_stage as hayoung with dissolve

    hy "지호야, 반 발만 뒤로."
    hy "뒤에 애들 얼굴 가려."

    hide hayoung
    show jh1 at center_stage as jiho with dissolve

    jh "오케이."

    "지호가 반 발 물러나자 모두가 화면 안에 들어왔다."

    scene cg_pair_jiho_hayoung
    with slow_fade

    "하지만 오늘 지호는 뒤에 있는 친구도 보았다."
    "하영이는 친구들이 자기 자리를 말하게 기다렸다."

    "신나게 웃는 건 혼자 튀는 일이 아니었다."
    "같이 웃으려면 옆 친구가 들어올 자리도 있어야 했다."

    scene black
    with fade

    call show_ending_title("지호, 하영과 함께 엔딩")

    jump d8_common_epilogue

# ════════════════════════════════════════════════════════
# [페어 엔딩 ②] 지호 + 나은 - 서로에게 배워가며 맞춰지는 사이
# ════════════════════════════════════════════════════════

label ending_pair_jiho_naeun:
    $ set_bgm(audio.bgm_pair)

    call d8_monday_intro from _call_d8_mon_pair_jh_na

    scene bg_board2
    with fade

    "교실 뒤 게시판 앞,"
    "색종이와 도안이 널려 있었다."
    "나는 나은이와 함께"
    "종이를 분류하고 있었다."

    show ne5 at center_stage as naeun with dissolve

    ne "이건 색종이... 이건 도안..."
    ne "유진아, 고마워. 혼자 하려니 좀 오래 걸리더라고."

    "그때 지호가 상자를 들고 뛰어왔다."

    hide naeun
    show jh5 at center_stage as jiho with dissolve

    jh "나은아! 유진아!"
    jh "이거 내가 한 번에 옮겨줄까?"
    jh "빨리빨리 끝내자!"

    "지호가 상자를 낚아채려 하자, 나은이가 다급하게 손을 뻗었다."

    hide jiho
    show ne4 at center_stage as naeun with dissolve

    ne "자, 잠깐만, 지호야!"
    ne "그냥 가져가면 다 섞여서..."
    ne "순서대로 해야 해."

    "지호는 나은이의 표정을 보았다."
    "그리고 그 자리에서 멈췄다."

    hide naeun
    show jh3 at center_stage as jiho with dissolve

    jh "아... 그런 거야? 몰랐네."
    jh "그럼 어떻게 하면 돼? 알려줘."

    "지호는 나은이가 알려준 순서대로"
    "종이를 분류했다."

    "그때 다른 친구가 와서 도움을 요청했다."

    ex_ce "나은아, 이거 제목 좀 써줘."
    ex_ce "네 글씨가 제일 예쁘잖아."

    "나은이가 펜을 잡으려는 순간,"
    "지호가 대신 입을 열었다."

    hide jiho
    show jh5 at center_stage as jiho with dissolve

    jh "어? 야, 안 돼!"
    jh "지금 우리 이거 하느라 엄청 바쁘거든?"
    jh "나중에 해!"

    "친구는 '아, 그래?' 하더니"
    "머쓱하게 돌아갔다."

    hide jiho
    show ne2 at center_stage as naeun with dissolve

    "나은이는 눈을 크게 뜨고"
    "지호를 보았다."
    "거절했지만 아무 일도 일어나지 않았다."

    hide naeun
    show jh1 at center_stage as jiho with dissolve

    jh "뭘 그렇게 봐? 우리 진짜 바쁘잖아."
    jh "너도 나중에 귀찮으면 그냥 바쁘다고 해."

    hide jiho
    show ne2 at center_stage as naeun with dissolve

    ne "응... 알겠어."
    ne "지호야, 고마워."

    scene cg_pair_jiho_naeun
    with slow_fade

    "지호는 나은이 옆에서 차분하게 하는 법을 배웠다."
    "나은이는 부탁을 거절해도 괜찮다는 걸 느꼈다."

    "둘이 같이 하니 혼자 할 때보다 일이 훨씬 수월했다."

    "조금 덜 빨라도, 조금 더 솔직해도 괜찮았다."
    "우리는 서로에게 배우며 더 잘 맞는 사이가 되었다."

    scene black
    with fade
    call show_ending_title("지호, 나은과 함께 엔딩")

    jump d8_common_epilogue

# [페어 엔딩 ③] 지호 + 소희 - 같이 놀아도 기다려주는 사이
# ════════════════════════════════════════════════════════

label ending_pair_jiho_sohee:
    $ set_bgm(audio.bgm_pair)

    call d8_monday_intro from _call_d8_mon_pair_jh_so

    scene bg_classroom_after
    with fade

    "아침 활동 전, 소희는 내 책상 옆에서 알림장 위의 쪽지를 보고 있었다."

    "{i}급식 먹고 도서관 책 반납하기.{/i}"

    show sh4 at center_stage as sohee with dissolve

    sh "유진아."
    sh "이따 같이 가는 거지?"

    n "응."
    n "책 오늘 반납해야 하니까."

    "그때 지호가 빠르게 다가왔다."

    hide sohee
    show jh5 at center_stage as jiho with dissolve

    jh "유진!"
    jh "급식 먹고 운동장 가자."
    jh "피구 연습해야 돼."

    hide jiho
    show sh5 at center_stage as sohee with dissolve

    sh "유진이 오늘 나랑 먼저 약속했어."

    hide sohee
    show jh4 at center_stage as jiho with dissolve

    jh "어?"
    jh "진짜?"

    n "도서관 먼저 갔다가 운동장 가면 안 될까?"

    hide jiho
    show sh2 at center_stage as sohee with dissolve

    sh "그럼 나랑 한 약속도 지키는 거지?"

    n "응."
    n "먼저 같이 도서관 갈게."

    hide sohee
    show jh3 at center_stage as jiho with dissolve

    jh "그럼 나는 팀 나눠놓고 있을게."

    hide jiho
    show sh2 at center_stage as sohee with dissolve

    sh "저기..."
    sh "나도 운동장 같이 가도 돼?"
    sh "피구는 잘 못하지만."

    hide sohee
    show jh5 at center_stage as jiho with dissolve

    jh "당연하지."
    jh "점수 봐줘도 되고, 응원만 해도 돼."

    scene bg_playground_day
    with fade

    "운동장에 도착하자 지호가 아이들을 모으고 있었다."

    show jh5 at center_stage as jiho with dissolve

    jh "잘하는 애들 한 팀에 몰리면 재미없어."
    jh "이쪽에 한 명, 저쪽에 한 명."

    hide jiho
    show sh3 at center_stage as sohee with dissolve

    sh "나는 점수판 볼래."
    sh "뛰는 건 아직 조금 무서워."

    "경기가 시작되자 지호는 빠르게 뛰었다."
    "친구가 공을 놓쳐도 놀리지 않았다."

    hide sohee
    show jh1 at center_stage as jiho with dissolve

    jh "괜찮아!"
    jh "다음에 잡으면 돼!"

    "나만 보던 소희도 곧 경기 쪽으로 고개를 돌렸다."

    hide jiho
    show sh3 at center_stage as sohee with dissolve

    sh "지호야."
    sh "방금은 바깥선 밟았어."
    sh "그 점수는 안 들어가."

    hide sohee
    show jh4 at center_stage as jiho with dissolve

    jh "쳇."
    jh "점수 담당 말은 인정."

    "소희가 점수판을 든 채 작게 웃었다. 처음보다 표정이 편해 보였다."

    scene cg_pair_jiho_sohee
    with slow_fade

    "지호는 신나면 바로 뛰어가고 싶어 했다."
    "소희는 가까운 약속을 놓치고 싶어 하지 않았다."

    "오늘 지호는 먼저 기다렸다."
    "소희는 서운한 마음을 말로 꺼냈다."

    "같이 노는 건 한 사람만 따라가는 일이 아니었다."
    "먼저 한 약속을 지키고, 새 놀이에도 천천히 들어갈 수 있었다."

    scene black
    with fade

    call show_ending_title("지호, 소희와 함께 엔딩")

    jump d8_common_epilogue


# ════════════════════════════════════════════════════════
# [페어 엔딩 ④] 지호 + 서연 - 규칙 안에서도 편하게 웃는 사이
# ════════════════════════════════════════════════════════

label ending_pair_jiho_seoyeon:
    $ set_bgm(audio.bgm_pair)

    call d8_monday_intro from _call_d8_mon_pair_jh_sy

    scene bg_classroom_after
    with fade

    "쉬는 시간, 비가 와서 운동장에 나갈 수 없었다."
    "지호는 책상 네 개를 붙이고 말판 놀이를 꺼냈다."

    show jh5 at center_stage as jiho with dissolve

    jh "자, 오늘은 교실에서 한 판 하자."

    "서연이가 알림장을 덮고 우리 쪽을 보았다."

    hide jiho
    show sy5 at center_stage as seoyeon with dissolve

    sy "나도 같이 해도 돼?"
    sy "대신 시작하기 전에 규칙은 정하자."

    hide seoyeon
    show jh6 at center_stage as jiho with dissolve

    jh "놀 건데 규칙부터 정해?"
    jh "그럼 재미없잖아."

    hide jiho
    show sy3 at center_stage as seoyeon with dissolve

    sy "규칙 없이 하면 중간에 말이 바뀌니까."
    sy "나도 그냥 같이 놀고 싶은 거야."

    n "그럼 규칙 세 개만 정하고 바로 시작하자."

    hide seoyeon
    show jh3 at center_stage as jiho with dissolve

    jh "세 개만이면 괜찮아."

    hide jiho
    show sy5 at center_stage as seoyeon with dissolve

    sy "좋아."
    sy "세 개만."

    "게임이 시작되었다."
    "지호는 첫 차례부터 큰 소리로 주사위를 던졌다."

    hide seoyeon
    show jh5 at center_stage as jiho with dissolve

    jh "나와라, 육!"

    "주사위는 다섯이 나왔다."
    "지호는 신이 나서 말을 한 칸 더 움직였다."

    hide jiho
    show sy3 at center_stage as seoyeon with dissolve

    sy "지호야."
    sy "지금 여섯 칸 갔어."

    hide seoyeon
    show jh6 at center_stage as jiho with dissolve

    jh "응?"
    jh "아, 그러네."

    hide jiho
    show sy4 at center_stage as seoyeon with dissolve

    sy "칸은 맞춰야..."

    "서연이는 말을 멈췄다."

    hide seoyeon
    show sy5 at center_stage as seoyeon with dissolve

    sy "칸을 맞추면 끝까지 헷갈리지 않고 놀 수 있어."

    hide seoyeon
    show jh1 at center_stage as jiho with dissolve

    jh "오케이."
    jh "다시 다섯 칸."

    "다음 친구가 카드를 뽑았다."
    "'두 칸 뒤로 가기'가 나왔다."

    hide jiho
    show jh6 at center_stage as jiho with dissolve

    jh "와, 완전 망—"

    "지호는 친구의 표정을 보고 말을 멈췄다."

    hide jiho
    show jh4 at center_stage as jiho with dissolve

    jh "아니."
    jh "괜찮아."
    jh "이 게임은 다시 뒤집을 수 있음."

    hide jiho
    show sy1 at center_stage as seoyeon with dissolve

    sy "맞아."
    sy "카드 때문에 뒤로 가는 건 실수한 게 아니야."

    "책상 위 말판은 조금 시끄러웠다."
    "그래도 아무도 자기 차례를 빼앗기지 않았다."

    scene cg_pair_jiho_seoyeon
    with slow_fade

    "지호는 승부를 좋아했다."
    "서연이는 규칙을 중요하게 생각했다."

    "오늘 지호는 장난치기 전에 친구 표정을 봤다."
    "서연이는 맞는 말도 조금 부드럽게 말했다."

    "규칙은 놀이를 막는 게 아니었다."
    "모두가 편하게 놀 수 있게 해주는 약속이었다."

    scene black
    with fade

    call show_ending_title("서연, 지호와 함께 엔딩")

    jump d8_common_epilogue


# ════════════════════════════════════════════════════════
# [페어 엔딩 ⑤] 하영 + 나은 - 보여주기 전에 묻고, 할 수 있는 만큼 말하는 사이
# ════════════════════════════════════════════════════════

label ending_pair_hayoung_naeun:
    $ set_bgm(audio.bgm_pair)

    call d8_monday_intro from _call_d8_mon_pair_hy_na

    scene bg_board2
    with fade

    "아침 시간, 하영이는 교실 뒤 게시판 앞에서 사진을 찍고 있었다."
    "게시판에는 친구 사랑 주간 카드들이 붙어 있었다."

    show h5 at center_stage as hayoung with dissolve

    hy "이거 예쁘다."
    hy "사진으로 남겨두면 좋겠어."

    "나은이는 자기 자리에서 종합장을 꺼내고 있었다."
    "하영이는 나은이의 우산 그림을 보고 눈을 반짝였다."

    hide hayoung
    show h4 at center_stage as hayoung with dissolve

    hy "나은아."
    hy "그 우산 그림도 같이 찍어도 돼?"
    hy "게시판이랑 잘 어울릴 것 같아."

    hide hayoung
    show ne1 at center_stage as naeun with dissolve

    ne "음..."
    ne "아직 다 그린 건 아니라서."

    hide naeun
    show h5 at center_stage as hayoung with dissolve

    hy "그래도 예쁜데."
    hy "애들도 좋아할걸?"

    "나은이는 바로 대답하지 못했다."

    n "하영아."
    n "나은이가 보여주고 싶은지 먼저 물어보자."

    hide hayoung
    show h6 at center_stage as hayoung with dissolve

    hy "아."
    hy "맞다."

    hide hayoung
    show h3 at center_stage as hayoung with dissolve

    hy "나은아."
    hy "예뻐서 찍고 싶었는데,"
    hy "네가 싫으면 안 찍을게."

    hide hayoung
    show ne4 at center_stage as naeun with dissolve

    ne "그럼..."
    ne "전체 말고 우산 부분만 찍어도 돼."
    ne "이름은 안 나오게."

    hide naeun
    show h5 at center_stage as hayoung with dissolve

    hy "좋아."
    hy "이름 안 나오게 찍을게."
    hy "보여주기 전에도 다시 물어볼게."

    "하영이는 종합장을 당기지 않았다."
    "나은이가 손으로 가리킨 부분만 조심스럽게 찍었다."

    "사진을 확인한 나은이의 표정이 조금 편해졌다."

    hide hayoung
    show ne5 at center_stage as naeun with dissolve

    ne "내 얼굴은 많이 안 나오게 해줄 수 있어?"

    hide naeun
    show h1 at center_stage as hayoung with dissolve

    hy "응."
    hy "마음에 안 들면 바로 지울게."

    "하영이는 휴대폰을 살짝 들어 올렸다."
    "나은이는 옆에서 우산 그림을 천천히 칠했다."
    "두 사람은 서로 괜찮은 속도를 기다렸다."

    scene cg_pair_hayoung_naeun
    with slow_fade

    "하영이는 예쁜 것을 잘 발견했다."
    "나은이는 자기 그림을 조용히 아끼고 있었다."

    "오늘 하영이는 보여주기 전에 먼저 물었다."
    "나은이는 어디까지 괜찮은지 말했다."

    "좋은 마음으로 하는 일도, 상대가 싫으면 멈춰야 했다."
    "보여주기 싫을 때는 싫다고 말해도 됐다."

    scene black
    with fade

    call show_ending_title("하영, 나은과 함께 엔딩")

    jump d8_common_epilogue


# ════════════════════════════════════════════════════════
# [페어 엔딩 ⑥] 하영 + 소희 - 약속을 묻고 기다려주는 사이
# ════════════════════════════════════════════════════════

label ending_pair_hayoung_sohee:
    $ set_bgm(audio.bgm_pair)

    call d8_monday_intro from _call_d8_mon_pair_hy_so

    scene bg_classroom_after
    with fade

    "쉬는 시간, 하영이는 문구점 앞 새 아이스크림 이야기를 하고 있었다."
    "주변 아이들이 하영이 쪽으로 모였다."

    show h5 at left_stage as hayoung with dissolve

    hy "유진!"
    hy "오늘 방과 후에 같이 갈래?"
    hy "딸기맛 새로 나왔대."

    "소희는 내 옆에 서 있다가 내 팔 쪽을 살짝 보았다."

    show sh2 at right_stage as sohee with dissolve

    sh "유진이는..."
    sh "오늘 나랑 먼저 약속했는데."

    hide hayoung
    show h2 at left_stage as hayoung with dissolve

    hy "아."
    hy "그랬어?"

    hide hayoung
    show h5 at left_stage as hayoung with dissolve

    hy "그럼 유진이한테 먼저 물어봐야겠다."
    hy "유진아, 오늘 소희랑 약속 있어?"

    n "응."
    n "방과 후에 같이 알림장 정리하기로 했어."

    hide sohee
    show sh3 at right_stage as sohee with dissolve

    sh "그리고 문구점도 잠깐 가기로 했어."
    sh "아주 잠깐."

    hide sohee
    show h3 at left_stage as hayoung with dissolve

    hy "그럼 내가 갑자기 끼어들면 소희가 서운하겠다."

    hide hayoung
    show sh2 at right_stage as sohee with dissolve

    sh "조금."

    hide sohee
    show h5 at left_stage as hayoung with dissolve

    hy "그럼 먼저 약속 지키고,"
    hy "그다음에 같이 가기."

    n "소희는 괜찮아?"

    hide hayoung
    show sh3 at right_stage as sohee with dissolve

    sh "응."
    sh "먼저 약속한 거 지키면 괜찮아."

    scene bg_corridor_day
    with fade

    "복도 끝 빈 공간에서 하영이는 장기자랑 동작을 보여주었다."
    "소희는 처음에는 손을 꼭 쥐고 있다가, 하영이의 박자에 맞춰 팔을 들었다."

    show h5 at left_stage as hayoung with dissolve
    show sh2 at right_stage as sohee with dissolve

    hy "하나, 둘."
    hy "여기서 손을 옆으로."

    sh "이렇게?"

    hy "응."
    hy "방금 좋았어."

    hide sohee
    show sh4 at right_stage as sohee with dissolve

    sh "진짜?"
    sh "나 방금 좀 잘한 것 같아."

    hide hayoung
    show h1 at left_stage as hayoung with dissolve

    hy "조금이 아니라 꽤 잘했어."

    "소희는 이번에는 내 표정부터 확인하지 않았다."
    "하영이와 동작을 한 번 더 맞춰보았다."
    "나는 두 사람 옆에서 천천히 박자를 셌다."

    scene cg_pair_hayoung_sohee
    with slow_fade

    "하영이는 친구들을 모으는 걸 잘했다."
    "소희는 가까운 약속을 쉽게 놓치고 싶어 하지 않았다."

    "오늘 하영이는 끼어들기 전에 먼저 물었다."
    "소희는 서운한 마음을 붙잡지 않고 말로 꺼냈다."

    "친구가 많아지는 건 가까운 친구를 밀어내는 일이 아니었다."
    "먼저 묻고 기다리면, 같이 어울리는 일도 편해질 수 있었다."

    scene black
    with fade

    call show_ending_title("하영, 소희와 함께 엔딩")

    jump d8_common_epilogue


# ════════════════════════════════════════════════════════
# [페어 엔딩 ⑦] 하영 + 서연 - 멋진 생각을 같이 바꿔가는 사이
# ════════════════════════════════════════════════════════

label ending_pair_hayoung_seoyeon:
    $ set_bgm(audio.bgm_pair)

    call d8_monday_intro from _call_d8_mon_pair_hy_sy

    scene bg_classroom_after
    with fade

    "미술 시간 전, 하영이가 포스터 시안을 펼쳤다."
    "색과 제목 위치가 보기 좋았다."

    show h5 at center_stage as hayoung with dissolve

    hy "이렇게 하면 예쁘지 않아?"
    hy "사진 찍어도 잘 나올 것 같아."

    "서연이는 시안을 보더니 자를 꺼냈다."

    hide hayoung
    show sy3 at center_stage as seoyeon with dissolve

    sy "예쁘긴 한데, 제목이 너무 위야."
    sy "아래 설명 칸도 부족해."

    hide seoyeon
    show h2 at center_stage as hayoung with dissolve

    hy "처음부터 그렇게 말하면 좀 김 빠지는데."

    hide hayoung
    show sy3 at center_stage as seoyeon with dissolve

    sy "틀린 걸 말한 거야."
    sy "나중에 고치면 오래 걸려."

    "두 사람 사이가 잠깐 굳었다."

    n "하영이는 모양을 먼저 보고,"
    n "서연이는 붙일 자리를 본 것 같아."

    hide seoyeon
    show sy4 at center_stage as seoyeon with dissolve

    sy "그럼..."
    sy "좋은 점부터 말한 뒤 고칠 점을 말해볼게."

    hide seoyeon
    show h6 at center_stage as hayoung with dissolve

    hy "나도 바로 삐지지 말고,"
    hy "왜 그런지 물어볼게."

    hide hayoung
    show sy2 at center_stage as seoyeon with dissolve

    sy "색은 잘 어울려."
    sy "제목도 눈에 잘 보여."
    sy "설명 칸이 부족하니 제목을 조금 내리면 좋겠어."

    hide seoyeon
    show h4 at center_stage as hayoung with dissolve

    hy "오."
    hy "그렇게 말하니까 덜 차갑다."
    hy "그럼 제목을 조금 내리고, 색지는 밝은 걸 유지하자."

    "두 사람은 시안을 다시 그렸다."
    "하영이는 분위기를 보고, 서연이는 칸을 맞췄다."

    "완성된 포스터는 예쁘면서도 읽기 쉬웠다."

    hide hayoung
    show h1 at center_stage as hayoung with dissolve

    hy "완성 기념으로 사진 찍자."
    hy "서연이도 같이."

    hide hayoung
    show sy5 at center_stage as seoyeon with dissolve

    sy "나?"
    sy "포스터만 찍으면 되잖아."

    hide seoyeon
    show h5 at center_stage as hayoung with dissolve

    hy "한 장만."
    hy "마음에 안 들면 지울게."

    hide hayoung
    show sy2 at center_stage as seoyeon with dissolve

    sy "그럼 너무 가까이 들이대지는 마."

    hide seoyeon
    show h4 at center_stage as hayoung with dissolve

    hy "알았어."

    "하영이는 한 발 물러서서 섰다."
    "서연이도 자를 들고 포스터 옆에 섰다."

    scene cg_pair_hayoung_seoyeon
    with slow_fade

    "하영이는 눈에 띄는 생각을 잘 떠올렸다."
    "서연이는 그 생각을 꼼꼼히 살폈다."

    "하영이는 자기 생각만 밀지 않았다."
    "서연이는 살릴 부분도 함께 보았다."

    "멋진 생각도 고치면 더 좋아질 수 있었다."
    "꼼꼼한 말도 부드럽게 하면 더 잘 들렸다."

    scene black
    with fade

    call show_ending_title("하영, 서연과 함께 엔딩")

    jump d8_common_epilogue


# ════════════════════════════════════════════════════════
# [페어 엔딩 ⑧] 나은 + 소희 - 묻고 기다리며 마음을 여는 사이
# ════════════════════════════════════════════════════════

label ending_pair_naeun_sohee:
    $ set_bgm(audio.bgm_pair)

    call d8_monday_intro from _call_d8_mon_pair_na_so

    scene bg_classroom_after
    with fade

    "아침 활동 시간, 소희는 나은이 책상 옆에 서 있었다."
    "나은이는 종합장을 조심스럽게 펼치고 있었다."

    show sh4 at center_stage as sohee with dissolve

    sh "나은아."
    sh "그림 봐도 돼?"
    sh "저번에 우산 그림 더 그렸다고 했잖아."

    hide sohee
    show ne4 at center_stage as naeun with dissolve

    ne "응..."
    ne "조금만."

    "나은이가 종합장을 펼치자 소희의 얼굴이 밝아졌다."

    hide naeun
    show sh1 at center_stage as sohee with dissolve

    sh "우와."
    sh "진짜 예쁘다."
    sh "나도 하나 그려줘!"

    "나은이의 손이 종합장 끝에서 멈췄다."

    n "소희야."
    n "지금 바로 그려달라는 건 부담될 수도 있어."

    hide sohee
    show ne2 at center_stage as naeun with dissolve

    ne "지금 바로는..."
    ne "조금 어려워."

    hide naeun
    show sh5 at center_stage as sohee with dissolve

    sh "아."
    sh "작게 하나면 괜찮을 줄 알았어."

    hide sohee
    show ne4 at center_stage as naeun with dissolve

    ne "그림을 보여주는 건 괜찮아."
    ne "근데 바로 그려달라고 하면 부담돼."

    hide naeun
    show sh2 at center_stage as sohee with dissolve

    sh "미안."
    sh "예뻐서 바로 갖고 싶어졌어."
    sh "나은이가 힘들면 안 그려줘도 돼."

    "나은이는 종합장을 덮지 않았다."

    hide sohee
    show ne5 at center_stage as naeun with dissolve

    ne "나중에 시간이 있으면 작은 우산 하나는 그려줄 수 있어."
    ne "근데 오늘 아침에는 내 그림 먼저 마무리하고 싶어."

    hide naeun
    show sh3 at center_stage as sohee with dissolve

    sh "그럼 기다릴게."
    sh "나중에 물어봐도 돼?"

    hide sohee
    show ne3 at center_stage as naeun with dissolve

    ne "응."
    ne "물어보는 건 괜찮아."

    scene bg_corridor_day
    with fade

    "점심시간이 끝나고 두 사람은 복도를 나란히 걸었다."

    show sh1 at right_stage as sohee with dissolve
    show ne4 at left_stage as naeun with dissolve

    sh "나은아."
    sh "팔짱 껴도 돼?"
    sh "싫으면 안 해도 돼."

    ne "좋아..."
    ne "근데 천천히 걸어줘."

    sh "응."
    sh "천천히 걸을게."

    "소희가 조심스럽게 팔짱을 끼자 나은이도 팔을 빼지 않았다."

    scene cg_pair_naeun_sohee
    with slow_fade

    "소희는 좋아하는 마음이 생기면 바로 가까이 가고 싶어 했다."
    "나은이는 자기 마음을 꺼내기까지 시간이 필요했다."

    "오늘 소희는 먼저 물었다."
    "나은이는 괜찮다고만 하지 않고, 부담되는 걸 말했다."

    "친구 마음을 여는 데에는 속도가 있었다."
    "묻고 기다리면, 조용한 마음도 조금씩 밖으로 나올 수 있었다."

    scene black
    with fade

    call show_ending_title("나은, 소희와 함께 엔딩")

    jump d8_common_epilogue


# ════════════════════════════════════════════════════════
# [페어 엔딩 ⑨] 나은 + 서연 - 도와주는 일도 나눠 드는 사이
# ════════════════════════════════════════════════════════

label ending_pair_naeun_seoyeon:
    $ set_bgm(audio.bgm_pair)

    call d8_monday_intro from _call_d8_mon_pair_na_sy

    scene bg_board2
    with fade

    "교실 뒤 게시판 앞에는 새 포스터가 놓여 있었다."
    "나은이는 그림을 맡았고, 서연이는 제목 줄을 확인하고 있었다."

    show ne4 at center_stage as naeun with dissolve

    ne "그림은 내가 마저 칠할게."
    ne "장식도 내가 해도 돼."

    hide naeun
    show sy5 at center_stage as seoyeon with dissolve

    sy "그럼 네가 너무 많이 해."
    sy "그림은 네가 하고, 장식은 다른 친구가 해도 돼."

    hide seoyeon
    show ne1 at center_stage as naeun with dissolve

    ne "괜찮아."
    ne "내가 하면 빨리 끝나니까."

    hide naeun
    show sy3 at center_stage as seoyeon with dissolve

    sy "그건 이유가 안 돼."
    sy "모둠 활동인데 한 사람이 다 하면 안 맞아."

    "나은이의 손이 멈췄다."

    n "서연아."
    n "맞는 말인데, 나은이가 듣기 쉽게 다시 말해볼래?"

    hide seoyeon
    show sy4 at center_stage as seoyeon with dissolve

    sy "음."
    sy "나은아."
    sy "네가 그림을 잘 그리는 건 맞아."
    sy "그래서 그림은 네가 하는 게 좋아."

    hide seoyeon
    show sy5 at center_stage as seoyeon with dissolve

    sy "근데 장식까지 다 하면 네 시간이 부족할 것 같아."
    sy "장식은 같이 나눠도 돼."

    hide seoyeon
    show ne4 at center_stage as naeun with dissolve

    ne "그렇게 말하니까..."
    ne "조금 덜 무서워."

    "나은이는 사인펜을 내려놓았다."

    ne "그럼 그림은 내가 하고,"
    ne "장식 색 고르는 건 같이 할래."

    "완성 뒤, 책상 위에는 색종이 조각이 남아 있었다."

    hide naeun
    show ne5 at center_stage as naeun with dissolve

    ne "청소는 내가 할게."

    hide naeun
    show sy5 at center_stage as seoyeon with dissolve

    sy "이번엔 같이 하자."
    sy "넌 색종이 조각을 모아줘."
    sy "나는 책상 위를 닦을게."

    hide seoyeon
    show ne3 at center_stage as naeun with dissolve

    ne "응."
    ne "좋아."

    "두 사람은 책상 양쪽에서 청소를 시작했다."
    "서연이는 지우개 가루를 모았다."
    "나은이는 색종이 조각을 쓸어 담았다."
    "혼자 할 때보다 일이 빨리 끝났다."
    "나은이도 서연이도 지친 표정이 아니었다."

    scene cg_pair_naeun_seoyeon
    with slow_fade

    "나은이는 도와주는 데 익숙했다."
    "서연이는 일을 나누고 확인하는 데 익숙했다."

    "오늘 나은이는 할 수 있는 만큼을 말했다."
    "서연이는 틀렸다고 먼저 말하지 않고, 이유를 설명했다."

    "친구 사이에서는 일을 나눠도 됐다."
    "한 명에게만 맡기지 않으면 모두가 덜 힘들 수 있었다."

    scene black
    with fade

    call show_ending_title("나은, 서연과 함께 엔딩")

    jump d8_common_epilogue


# ════════════════════════════════════════════════════════
# [페어 엔딩 ⑩] 소희 + 서연 - 확인하고 덜 아프게 말하는 사이
# ════════════════════════════════════════════════════════

label ending_pair_sohee_seoyeon:
    $ set_bgm(audio.bgm_pair)

    call d8_monday_intro from _call_d8_mon_pair_so_sy

    scene bg_classroom_after
    with fade

    "수업이 끝난 뒤, 교실에는 아직 몇 명의 아이들이 남아 있었다."
    "서연이는 알림장을 확인하고 있었고, 소희는 내 옆에 서 있었다."

    show sh2 at center_stage as sohee with dissolve

    sh "유진아."
    sh "오늘 방과 후에 나랑 같이 가는 거 맞지?"

    n "응."
    n "맞아."

    "그때 서연이가 알림장을 보며 말했다."

    hide sohee
    show sy5 at center_stage as seoyeon with dissolve

    sy "소희야."
    sy "너 오늘 가정통신문 가져가야 해."
    sy "또 잊으면 안 돼."

    hide seoyeon
    show sh5 at center_stage as sohee with dissolve

    sh "또라고 하지 마."
    sh "나도 챙기려고 했어."

    hide sohee
    show sy3 at center_stage as seoyeon with dissolve

    sy "지난번에도 두고 갔잖아."
    sy "확인해야 하는 건 맞아."

    "소희의 입술이 삐죽해졌다."

    n "서연아."
    n "확인해주는 건 좋은데, 조금 덜 아프게 말해보자."

    hide seoyeon
    show sy4 at center_stage as seoyeon with dissolve

    sy "음."

    hide seoyeon
    show sy5 at center_stage as seoyeon with dissolve

    sy "소희야."
    sy "가정통신문 챙겼는지 같이 확인할래?"
    sy "잊을까 봐 걱정돼서 말한 거야."

    hide seoyeon
    show sh3 at center_stage as sohee with dissolve

    sh "그렇게 말하면 괜찮아."
    sh "나도 확인하면 마음이 편하니까."

    "소희는 가방을 열었다."
    "하지만 가정통신문은 보이지 않았다."

    hide sohee
    show sh2 at center_stage as sohee with dissolve

    sh "어?"
    sh "없어."

    hide sohee
    show sy2 at center_stage as seoyeon with dissolve

    sy "잠깐."
    sy "책상 서랍도 확인해보자."

    "가정통신문은 교과서 사이에 끼어 있었다."

    hide seoyeon
    show sh4 at center_stage as sohee with dissolve

    sh "있다."
    sh "나 진짜 없어진 줄 알았어."

    hide sohee
    show sy1 at center_stage as seoyeon with dissolve

    sy "찾아서 다행이야."
    sy "다음에는 알림장에 '가방 안쪽 칸'이라고 적어두면 좋겠어."

    hide seoyeon
    show sh1 at center_stage as sohee with dissolve

    sh "응."
    sh "그럼 나도 덜 불안할 것 같아."

    "소희는 알림장에 잊지 않도록 적었다."
    "서연이는 다 쓸 때까지 옆에서 기다렸다."
    "확인을 마친 소희가 먼저 가방을 닫았다."

    scene cg_pair_sohee_seoyeon
    with slow_fade

    "소희는 확인을 받아야 마음이 편해지는 아이였다."
    "서연이는 확인을 잘하는 아이였다."

    "오늘 소희는 바로 삐지기 전에 같이 확인했다."
    "서연이는 틀렸다고 하기 전에 먼저 안심시켰다."

    "확인은 귀찮은 일이 아닐 수 있었다."
    "부드럽게 말하면, 정확한 말도 덜 아프게 들릴 수 있었다."

    scene black
    with fade

    call show_ending_title("소희, 서연과 함께 엔딩")

    jump d8_common_epilogue


# ==========================================================
# 2. 솔로 엔딩
# 제목: 서두르지 않고 천천히 다가가는 사이
# ==========================================================

label ending_solo_route:
    jump ending_solo


label ending_solo:
    $ set_bgm(audio.bgm_solo)

    call d8_monday_intro from _call_d8_mon_solo

    scene bg_classroom_after
    with fade

    "월요일 아침, 나는 교실 뒷문을 열고 안으로 들어갔다."
    "교실은 평소처럼 시끄러웠다."

    "누군가는 공책을 펴고 있었고,"
    "누군가는 가방에서 준비물을 꺼내고 있었다."

    "나는 내 자리에 가방을 내려놓았다."
    "그리고 천천히 의자에 앉았다."

    "이번 주 동안 나는 여러 친구들을 보았다."
    "같이 웃기도 했고, 조금 어색해지기도 했다."
    "말을 걸까 말까 망설인 순간도 있었다."

    "하지만 아직 누군가를 꼭 '가장 친한 친구'라고 정할 필요는 없었다."

    "전학 온 지 얼마 안 된 나는,"
    "빨리 단짝이 생기면 마음이 편할 줄 알았다."


    "아직 정하지 못한 것이 꼭 실패는 아니었다."
    "친구를 알아가는 데에는 시간이 필요했다."

    "나는 교실을 천천히 둘러보았다."

    scene cg_solo
    with slow_fade
    "지호는 친구들과 크게 웃고 있었다."
    "하영이는 친구들과 이야기를 나누고 있었다."
    "나은이는 자기 종합장을 조심스럽게 펼치고 있었다."
    "소희는 가방에 달린 키링을 만지작거리고 있었다."
    "서연이는 알림장에 오늘 할 일을 적고 있었다."

    "모두 조금씩 다른 친구들이었다."
    "그리고 나는 아직 그 친구들을 다 알지 못했다."

    "꼭 오늘부터 누군가와 아주 친해져야 하는 건 아니었다."
    "쉬는 시간마다 누군가 옆에 붙어 있지 않아도 괜찮았다."

    "나는 오늘 내 자리에서 시작하기로 했다."

    "교실을 피하는 게 아니라,"
    "내 속도로 교실 안에 머무르는 것."

    "그러다 인사하고 싶을 때 인사하고,"
    "궁금한 것이 생기면 물어보고,"
    "같이하고 싶은 일이 생기면 한 걸음 다가가 보기로 했다."

    "나는 알림장을 펼쳤다."
    "오늘 날짜 아래 빈칸에 연필을 대고 천천히 적었다."

    "내 속도로 가까워지기."

    "글씨는 아주 크지 않았다."

    "혼자 있는 시간도 친구를 배우는 시간이 될 수 있었다."
    "누군가를 바로 선택하지 않아도,"
    "내가 어떤 친구가 되고 싶은지 알아가는 일은 계속되고 있었다."

    "천천히 가까워지는 것도,"
    "충분히 좋은 시작이었다."

    scene black
    with fade

    call show_ending_title("혼자여도 괜찮아 엔딩")
    
    jump d8_common_epilogue


# ==========================================================
# 1. 번아웃 엔딩
# 제목: 친구 마음만 보다가 내 마음을 놓친 사이
# ==========================================================
label ending_burnout:
    $ set_bgm(audio.bgm_burnout)

    call d8_monday_intro from _call_d8_mon_burnout

    scene bg_corridor_day
    with fade

    "월요일 아침, 나는 교실 뒷문 앞에 서 있었다."
    "문 안쪽에서는 아이들이 아침 활동을 준비하는 소리가 들렸다."

    "의자 끄는 소리."
    "가방 지퍼 여는 소리."
    "누군가 내 이름을 부르는 것 같은 소리."

    "전부 싫은 소리는 아니었다."
    "오히려 내가 들어가고 싶은 소리였다."

    "그런데 손잡이를 잡은 손에 힘이 잘 들어가지 않았다."

    "교실이 싫어진 건 아니었다."
    "친구들이 미워진 것도 아니었다."

    "그저 이번 주 동안 너무 많은 마음을 보려고 했다."
    "친구가 서운해할까 봐,"
    "누가 불편해할까 봐,"
    "내가 잘못 고르면 누군가 상처받을까 봐 계속 긴장했다."

    "그러는 동안 내 마음이 어떤지는 자주 묻지 못했다."

    show t1 at center_stage as teacher with dissolve

    t "유진아. 괜찮니?"

    "선생님 목소리가 들리자, 나는 고개를 들었다."
    "괜찮다고 말하려고 했지만 바로 나오지 않았다."

    n "잘 모르겠어요."
    n "그냥..."
    n "조금 힘들어요."

    hide teacher
    show t3 at center_stage as teacher with dissolve
    t "지금은 바로 들어가지 않아도 괜찮아."
    t "잠깐 숨 고르고 들어가자."

    "나는 고개를 끄덕였다."
    "그제야 손잡이를 잡고 있던 손에 힘이 조금 풀렸다."

    scene bg_school_day
    with slow_fade

    "나는 친구들을 아끼고 싶었다."
    "그래서 친구들의 표정과 말투를 계속 살폈다."

    "내 마음이 지쳐가는 걸 늦게 알아차렸다."

    "좋은 친구가 된다는 건,"
    "모든 친구의 마음을 다 책임지는 일이 아니었다."

    "내가 힘든지 알아차리는 것도 필요했다."

    "괜찮지 않을 때 괜찮지 않다고 말하는 건,"
    "친구 관계를 망치는 일이 아니었다."

    "잠깐 쉬어가야 다시 교실에 들어갈 수 있었다."
    "내 마음을 돌보는 것도 친구를 배우는 일의 일부였다."

    scene black
    with fade

    call show_ending_title("지친 마음 쉬어가기 엔딩")

    jump d8_common_epilogue
    
label d8_common_epilogue:

    scene bg_black with fade
    pause 0.5

    scene bg_ending with fade

    "한 달쯤 지났다."
    "친구 사랑 주간 때 만들었던 마음나무는 이제 게시판에서 내려왔다."

    "나는 그때의 종이를 꺼내 책상 위에 올려두었다."

    "나는 연필을 들었다."
    "이번에는 친구 이름 대신,"
    "이 이야기를 끝까지 봐준 너에게 쓰기로 했다."

    scene bg_leaf
    with slow_fade
    window hide

    ending_centered "{i}너에게 보내는 마음잎{/i}"

    window hide
    pause 0.5

    ending_centered "{i}이 이야기를 보면서,{/i}"
    ending_centered "{i}너도 여러 번 골랐을 거야.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}다가갈지,{/i}"
    ending_centered "{i}기다릴지,{/i}"
    ending_centered "{i}말할지,{/i}"
    ending_centered "{i}조용히 지켜볼지.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}어떤 선택은 마음에 들었을 거고,{/i}"
    ending_centered "{i}어떤 선택은 조금 아쉬웠을지도 몰라.{/i}"
    ending_centered "{i}그래도 괜찮아.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}친구 사이는 한 번에 정해지는 게 아니니까.{/i}"
    ending_centered "{i}오늘 조금 서툴렀어도,{/i}"
    ending_centered "{i}다음에 다시 물어볼 수 있으니까.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}친구랑 가까워지는 방법은 하나가 아니야.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}어떤 친구는 같이 웃어야 가까워지고,{/i}"
    ending_centered "{i}어떤 친구는 기다려줘야 가까워져.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}어떤 친구는 먼저 물어봐 주면 편해지고,{/i}"
    ending_centered "{i}어떤 친구는 조금 떨어져 있어야 다시 다가올 수 있어.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}말을 많이 해야 편한 친구도 있고,{/i}"
    ending_centered "{i}말이 적어야 마음을 꺼내는 친구도 있어.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}웃고 있어도 불편할 수 있고,{/i}"
    ending_centered "{i}혼자 있어도 외로운 게 아닐 수 있어.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}친구마다 편한 거리는 달라.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}그리고 너도,{/i}"
    ending_centered "{i}너에게 편한 거리를 천천히 찾아가면 돼.{/i}"

    window hide
    pause 0.5

    ending_centered "{i}우리 사이의 알맞은 거리는,{/i}"
    ending_centered "{i}너와 친구가 ‘함께’ 편해지는 만큼이야.{/i}"

    show ending_dim zorder 100:
        alpha 0.0
        linear 5.0 alpha 1.0

    $ renpy.pause(5.0, hard=True)

    scene bg_black
    hide ending_dim
    hide ending_dim onlayer overlay
    window hide

    pause 0.5

    show expression Text("우리 사이의 알맞은 거리", size=44, color="#F7EBD8") as ending_title zorder 300 at truecenter
    with Dissolve(1.5)
    pause 1.5
    hide ending_title
    with Dissolve(1.2)

    pause 0.5

    show expression Text("제작 by '지원쌤'", size=30, color="#F7EBD8") as ending_credit zorder 300 at truecenter
    with Dissolve(1.5)
    pause 1.5
    hide ending_credit
    with Dissolve(1.5)

    pause 0.5
