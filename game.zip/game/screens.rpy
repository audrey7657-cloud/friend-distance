﻿################################################################################

init offset = -1


################################################################################
## 스타일
################################################################################

style default:
    properties gui.text_properties()
    language gui.language

style input:
    properties gui.text_properties("input", accent=True)
    adjust_spacing False

# ----------------------------------------------------------
# 하이퍼링크 글씨 보정
# 버전정보 화면의 Ren'Py / 이곳 글씨
# ----------------------------------------------------------

style hyperlink_text:
    font FILE_FONT
    size 22
    color "#3F628E"
    hover_color "#2F2118"
    insensitive_color "#8D8D8D"
    underline True
    hover_underline True
    outlines []
    hover_outlines []

style gui_text:
    properties gui.text_properties("interface")


style button:
    properties gui.button_properties("button")

style button_text is gui_text:
    properties gui.text_properties("button")
    yalign 0.5


style label_text is gui_text:
    properties gui.text_properties("label", accent=True)

style prompt_text is gui_text:
    properties gui.text_properties("prompt")


style bar:
    ysize gui.bar_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    xsize gui.bar_size
    top_bar Frame("gui/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    ysize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    xsize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    ysize gui.slider_size
    base_bar Frame("gui/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/slider/horizontal_[prefix_]thumb.png"

style vslider:
    xsize gui.slider_size
    base_bar Frame("gui/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/slider/vertical_[prefix_]thumb.png"


style frame:
    padding gui.frame_borders.padding
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)



################################################################################
## 게임내 스크린
################################################################################


## Say 스크린 #####################################################################
##
## Say 스크린은 플레이어에게 대사를 출력할 때 씁니다. 화자 who와 대사 what, 두
## 개의 매개변수를 받습니다. (화자 이름이 없으면 who는 None일 수 있음)
##
## 이 스크린은 id "what"을 가진 텍스트 디스플레이어블을 생성해야 합니다. (이 디
## 스플레이어블은 렌파이의 대사 출력에 필요합니다.) id "who" 와 id "window" 디스
## 플레이블이 존재할 경우 관련 스타일 속성이 적용됩니다.
##
## https://www.renpy.org/doc/html/screen_special.html#say

screen say(who, what):

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "namebox"

                text who id "who"

        text what id "what"

    if not renpy.variant("small"):
        add SideImage() xalign 0.0 yalign 1.0

## Character 객체를 통해 스타일을 지정할 수 있도록 namebox를 사용할 수 있게 만듭
## 니다.
init python:
    config.character_id_prefixes.append('namebox')

style window is default
style say_label is default
style say_dialogue is default
style say_thought is say_dialogue

style namebox is default
style namebox_label is say_label


style window:
    xalign 0.5
    xfill True
    yalign gui.textbox_yalign
    ysize gui.textbox_height

    background Image("gui/textbox.png", xalign=0.5, yalign=1.0)

style namebox:
    xpos gui.name_xpos
    xanchor gui.name_xalign
    xsize gui.namebox_width
    ypos gui.name_ypos
    ysize gui.namebox_height

    background Frame("gui/namebox.png", gui.namebox_borders, tile=gui.namebox_tile, xalign=gui.name_xalign)
    padding gui.namebox_borders.padding

style say_label:
    properties gui.text_properties("name", accent=True)
    xalign gui.name_xalign
    yalign 0.5

style say_dialogue:
    properties gui.text_properties("dialogue")

    xpos gui.dialogue_xpos
    xsize gui.dialogue_width
    ypos gui.dialogue_ypos

    line_spacing 8
    slow_cps 42

    slow_abortable True

    adjust_spacing False
## Input 스크린 ###################################################################
##
## 플레이어 입력을 받는 renpy.input을 출력할 때 쓰이는 스크린입니다. prompt 매개
## 변수를 통해 입력 지문을 표시할 수 있습니다.
##
## 이 스크린은 id "input"을 가진 input 디스플레이어블을 생성해야 합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#input

screen input(prompt):
    style_prefix "input"

    window:

        vbox:
            xanchor gui.dialogue_text_xalign
            xpos gui.dialogue_xpos
            xsize gui.dialogue_width
            ypos gui.dialogue_ypos

            text prompt style "input_prompt"
            input id "input"

style input_prompt is default

style input_prompt:
    xalign gui.dialogue_text_xalign
    properties gui.text_properties("input_prompt")

style input:
    xalign gui.dialogue_text_xalign
    xmaximum gui.dialogue_width


## Choice 스크린 ##################################################################
##
## menu 명령어로 생성된 게임내 선택지를 출력하는 스크린입니다. 한 개의 매개변수
## items를 받고, 이는 선택지 내용(caption)과 선택지 결과(action)이 있는 오브젝트
## 가 들어있는 리스트입니다.
##
## https://www.renpy.org/doc/html/screen_special.html#choice

screen choice(items):

    style_prefix "choice"

    vbox:
        xalign 0.5
        yalign 0.48
        spacing 10

        if getattr(store, "choice_question_text", "") != "":
            frame:
                xalign 0.5
                xsize 660
                ysize 34

                background Solid("#EFE0C2CC")

                hbox:
                    xalign 0.5
                    yalign 0.5
                    spacing 8

                    text "Q.":
                        font "fonts/RIDIBatang.otf"
                        size 14
                        color "#6B4A24"
                        bold True

                    text getattr(store, "choice_question_text", ""):
                        font "fonts/RIDIBatang.otf"
                        size 17
                        color "#2A241D"
                        outlines [(1, "#FFFFFF88", 0, 0)]

            null height 18

        for i in items:
            textbutton i.caption action [SetVariable("choice_question_text", ""), i.action]


style choice_vbox is vbox
style choice_button is button
style choice_button_text is button_text

style choice_vbox:
    xalign 0.5
    yalign 0.5
    spacing 14


style choice_button is default:
    xsize 760
    ysize 48

    left_padding 22
    right_padding 22
    top_padding 7
    bottom_padding 7

    background Solid("#1A1714B8")
    hover_background Solid("#D8C4A480")
    insensitive_background Solid("#1A171480")


style choice_button_text is button_text:
    font "fonts/RIDIBatang.otf"
    size 24

    color "#F6F1E8"
    hover_color "#FFF9F0"
    insensitive_color "#CFC7BB"

    outlines [(2, "#00000066", 0, 0)]

    text_align 0.5
    xalign 0.5
    yalign 0.5


## Quick Menu 스크린 ##############################################################
##
## 퀵메뉴는 게임 외 메뉴 접근성을 높여주기 위해 게임 내에 표시됩니다.

screen quick_menu():

    ## 다른 화면 위에 표시되는지 확인합니다.
    zorder 100

    if getattr(store, "quick_menu", True):

        hbox:
            style_prefix "quick"
            style "quick_menu"

            textbutton _("되감기") action Rollback()
            textbutton _("대사록") action ShowMenu('history')
            textbutton _("넘기기") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("자동진행") action Preference("auto-forward", "toggle")
            textbutton _("저장하기") action ShowMenu('save')
            textbutton _("Q.저장하기") action QuickSave()
            textbutton _("Q.불러오기") action QuickLoad()
            textbutton _("설정") action ShowMenu('preferences')


## 플레이어가 UI(스크린)을 일부러 숨기지 않는 한 퀵메뉴가 게임 내에 오버레이로
## 출력되게 합니다.
init python:
    config.overlay_screens.append("quick_menu")


style quick_menu is hbox
style quick_button is default
style quick_button_text is button_text


style quick_menu:
    xalign 0.5
    yalign 1.0


style quick_button:
    properties gui.button_properties("quick_button")
    background None
    xpadding 8
    ypadding 4


style quick_button_text:
    properties gui.text_properties("quick_button")

    size 26
    color "#EAEAEA"
    hover_color "#FFFFFF"
    selected_color "#FFFFFF"
    insensitive_color "#888888"
    outlines [(2, "#00000099", 0, 0)]


################################################################################
## Main과 Game Menu 스크린
################################################################################

## Navigation 스크린 ##############################################################
##
## 이 스크린은 메인메뉴와 게임외 메뉴에 포함되어 다른 메뉴로 이동하거나 게임을
## 시작/종료할 수 있게 합니다.

screen navigation():

    vbox:
        style_prefix "navigation"

        xpos gui.navigation_xpos
        yalign 0.5

        spacing gui.navigation_spacing

        if main_menu:

            textbutton _("시작하기") action Start()

        else:

            textbutton _("대사록") action ShowMenu("history")

            textbutton _("저장하기") action ShowMenu("save")

        textbutton _("불러오기") action ShowMenu("load")

        textbutton _("환경설정") action ShowMenu("preferences")

        if _in_replay:

            textbutton _("리플레이 끝내기") action EndReplay(confirm=True)

        elif not main_menu:

            textbutton _("메인 메뉴") action MainMenu()

        textbutton _("버전정보") action ShowMenu("about")

        if renpy.variant("pc") or (renpy.variant("web") and not renpy.variant("mobile")):

            ## 도움말 메뉴는 모바일 디바이스와 맞지 않아 불필요합니다.
            textbutton _("조작방법") action ShowMenu("help")

        if renpy.variant("pc"):

            ## iOS에서는 종료 버튼이 금지되어 있으며 Android 및 웹에서는 불필요
            ## 합니다.
            textbutton _("종료하기") action Quit(confirm=not main_menu)


style navigation_button is gui_button
style navigation_button_text is gui_button_text

style navigation_button:
    properties gui.button_properties("navigation_button")
    xpadding 12
    ypadding 8


style navigation_button_text:
    font "fonts/MaruBuri-SemiBold.otf"
    size 34

    color "#D6C8B5"
    hover_color "#FFF1C8"
    selected_color "#F8E7BE"
    insensitive_color "#7E746B"

    outlines [(1, "#00000088", 0, 0)]
    hover_outlines [(1, "#FFE7A866", 0, 0)]
    selected_outlines [(1, "#4A3726", 0, 0)]

style navigation_vbox:
    xpos 58
    yalign 0.5
    spacing 34
## Main Menu 스크린 ###############################################################
##
## 렌파이가 시작할 때 메인메뉴를 출력합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#main-menu

screen main_menu():

    tag menu

    # 메인 배경 영상
    add "main_menu_video"

    # 전체 화면 살짝 어둡게
    add Solid("#00000028")

    # 왼쪽 메뉴 패널
    frame:
        style "main_menu_frame"

    # 메뉴
    use navigation

    # 오른쪽 아래 제목 박스
    frame:
        style "main_title_frame"

        vbox:
            xalign 1.0
            yalign 1.0
            spacing 8

            text "우리 사이의 알맞은 거리":
                style "main_menu_title"


style main_menu_frame is empty
style main_menu_vbox is vbox
style main_menu_text is gui_text
style main_menu_title is main_menu_text
style main_menu_version is main_menu_text

style main_menu_frame:
    xsize 300
    yfill True

    background Solid("#17110D99")

style main_menu_vbox:
    xalign 1.0
    xoffset -20
    xmaximum 800
    yalign 1.0
    yoffset -20

style main_menu_text:
    properties gui.text_properties("main_menu", accent=True)

style main_title_frame:
    xalign 1.0
    yalign 1.0
    xmaximum 470

    # 배경 박스 제거
    background None
    padding (0, 0, 0, 0)

    right_margin 42
    bottom_margin 42


style main_menu_title:
    font "fonts/NanumChodingHope.ttf"
    size 62
    color "#1F1A16"
    xalign 1.0
    textalign 1.0

    # 검정 글씨라서 검은 테두리 X, 아주 연한 밝은 테두리만
    outlines [(2, "#F3E8D688", 0, 0)]


style main_menu_subtitle:
    font "fonts/NanumChodingHope.ttf"
    size 30
    color "#F0E7DA"
    xalign 1.0
    textalign 1.0

    outlines [(2, "#00000077", 0, 0)]


style main_menu_version:
    font "fonts/NanumChodingHope.ttf"
    size 15
    color "#D2C6B8"
    xalign 1.0
    textalign 1.0
    outlines [(1, "#00000066", 0, 0)]

## Game Menu 스크린 ###############################################################
##
## 게임 메뉴의 기본 틀입니다. 매개변수 title로 스크린 제목을 정하고, 배경, 제목,
## 그리고 navigation 스크린을 출력합니다.
##
## scroll 매개변수는, None, "viewport" 혹은 "vpgrid" 중 하나여야 합니다.
## transclude 명령어를 통해 다른 스크린을 이 스크린 내부에 불러옵니다.
screen game_menu(title, scroll=None, yinitial=0.0, spacing=0):

    style_prefix "game_menu"

    $ is_system_menu = title in (_("저장하기"), _("불러오기"), _("대사록"), _("버전정보"), _("조작방법"))
    $ current_menu_font = FILE_FONT if is_system_menu else MENU_FONT
    $ current_title_size = 46 if is_system_menu else 52
    $ current_return_size = 28 if is_system_menu else 34

    add "gui/main.png":
        xalign 0.5
        yalign 0.5
        xysize (1280, 720)

    # 왼쪽 메뉴 패널
    frame:
        xpos 34
        ypos 34
        xsize 310
        ysize 652
        background Solid("#17110DB8")
        padding (0, 0)

        use navigation

    # 오른쪽 내용 패널
    frame:
        xpos 350
        ypos 34
        xsize 900
        ysize 652
        background Solid("#FFF8ECE8")
        padding (38, 28)

        vbox:
            spacing 18

            text title:
                xalign 0.5
                font current_menu_font
                size current_title_size
                color "#3A2A1F"
                outlines []

            if scroll == "viewport":

                viewport:
                    yinitial yinitial
                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    pagekeys True

                    vbox:
                        spacing spacing
                        transclude

            elif scroll == "vpgrid":

                vpgrid:
                    cols 1
                    yinitial yinitial
                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    pagekeys True
                    spacing spacing
                    transclude

            else:

                transclude

    # 돌아가기
    textbutton _("돌아가기"):
        xpos 1095
        ypos 56
        text_font current_menu_font
        text_size current_return_size
        text_color "#4A3726"
        text_hover_color "#2F2118"
        text_outlines []
        text_hover_outlines []
        background None
        hover_background None
        action Return()

    key "game_menu" action Return()

style game_menu_outer_frame is empty
style game_menu_navigation_frame is empty
style game_menu_content_frame is empty
style game_menu_viewport is gui_viewport
style game_menu_side is gui_side
style game_menu_scrollbar is gui_vscrollbar

style game_menu_label is gui_label
style game_menu_label_text is gui_label_text

style return_button is navigation_button
style return_button_text is navigation_button_text

style game_menu_outer_frame:
    bottom_padding 30
    top_padding 120

    background "gui/overlay/game_menu.png"

style game_menu_navigation_frame:
    xsize 280
    yfill True

style game_menu_content_frame:
    left_margin 40
    right_margin 20
    top_margin 10

style game_menu_viewport:
    xsize 920

style game_menu_vscrollbar:
    unscrollable gui.unscrollable

style game_menu_side:
    spacing 10

style game_menu_label:
    xpos 50
    ysize 120

style game_menu_label_text:
    size 36
    color "#F4E8D4"
    outlines [(2, "#000000AA", 0, 0)]

style return_button:
    xpos gui.navigation_xpos
    yalign 1.0
    yoffset -30


## About 스크린 ###################################################################
##
## 이 스크린은 게임과 렌파이 엔진 크레딧과 저작권 정보를 표시합니다.
##
## 특별할 것이 없으므로 스크린을 새로 커스터마이징하여 만드는 예제이기도 합니다.

screen about():

    tag menu

    use game_menu(_("버전정보"), scroll="viewport"):

        style_prefix "about"

        vbox:
            xalign 0.5
            xsize 760
            spacing 22

            label "[config.name!t]"

            text _("버전 [config.version!t]\n"):
                xmaximum 760

            if gui.about:
                text "[gui.about!t]\n":
                    xmaximum 760

            text _("{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only] 으로 만들어진 게임.\n\n[renpy.license!t]"):
                xmaximum 760

style about_label is gui_label
style about_label_text is gui_label_text
style about_text is gui_text

style about_label_text:
    size gui.label_text_size


## Load 그리고 Save 스크린 ###########################################################
##
## 이 스크린은 세이브/로드에 쓰입니다. 거의 동일하기 때문에, file_slots 스크린을
## 불러와서 씁니다.
##
## https://www.renpy.org/doc/html/screen_special.html#save https://
## www.renpy.org/doc/html/screen_special.html#load

screen save():

    tag menu

    use file_slots(_("저장하기"))


screen load():

    tag menu

    use file_slots(_("불러오기"))

screen file_slots(title):

    default page_name_value = FilePageNameInputValue(
        pattern=_("{} 페이지"),
        auto=_("자동 세이브"),
        quick=_("퀵세이브")
    )

    use game_menu(title):

        fixed:
            xfill True
            ysize 540

            # 페이지 이름
            button:
                style "page_label"
                key_events True
                xalign 0.5
                ypos 0
                action page_name_value.Toggle()

                input:
                    style "page_label_text"
                    value page_name_value

            # 파일 슬롯 그리드
            grid 3 2:
                xpos 20
                ypos 58
                xspacing 30
                yspacing 28

                for i in range(6):

                    $ slot = i + 1

                    button:
                        action FileAction(slot)
                        xsize 245
                        ysize 152
                        background Solid("#FFF8ECD0")
                        hover_background Solid("#FFF2DDE8")
                        selected_background Solid("#F1DFC0E8")
                        padding (10, 8)

                        has vbox
                        spacing 4

                        add FileScreenshot(slot):
                            xalign 0.5
                            xysize (225, 104)

                        text FileTime(slot, format=_("{#file_time}%A, %B %d %Y, %H:%M"), empty=_("빈 슬롯")):
                            style "slot_time_text"
                            xalign 0.5

                        text FileSaveName(slot):
                            style "slot_name_text"
                            xalign 0.5

                        key "save_delete" action FileDelete(slot)

            # 페이지 번호
            vbox:
                style_prefix "page"
                xalign 0.5
                ypos 410

                hbox:
                    xalign 0.5
                    spacing 16

                    textbutton _("<") action FilePagePrevious()
                    key "save_page_prev" action FilePagePrevious()

                    if config.has_autosave:
                        textbutton _("{#auto_page}자동") action FilePage("auto")

                    if config.has_quicksave:
                        textbutton _("{#quick_page}퀵") action FilePage("quick")

                    for page in range(1, 10):
                        textbutton "[page]" action FilePage(page)

                    textbutton _(">") action FilePageNext()
                    key "save_page_next" action FilePageNext()

            # 동기화 버튼 - 페이지 번호와 분리
            if config.has_sync:

                if CurrentScreenName() == "save":
                    textbutton _("동기화 업로드"):
                        style "sync_button"
                        action UploadSync()
                        xalign 0.5
                        ypos 468
                else:
                    textbutton _("동기화 다운로드"):
                        style "sync_button"
                        action DownloadSync()
                        xalign 0.5
                        ypos 468

style page_label is gui_label
style page_label_text is gui_label_text
style page_button is gui_button
style page_button_text is gui_button_text

style slot_button is gui_button
style slot_button_text is gui_button_text
style slot_time_text is slot_button_text
style slot_name_text is slot_button_text

style page_label:
    xpadding 50
    ypadding 3
    xalign 0.5

define FILE_FONT = "fonts/MaruBuri-SemiBold.otf"


style page_label_text:
    font FILE_FONT
    size 24
    color "#5A4735"
    hover_color "#2F2118"
    outlines []
    textalign 0.5
    layout "subtitle"

style page_button:
    properties gui.button_properties("page_button")

style page_button_text:
    font FILE_FONT
    size 20
    color "#6A5741"
    hover_color "#2F2118"
    selected_color "#8A4F2A"
    insensitive_color "#B6A897"
    outlines []
    hover_outlines []
    selected_outlines []


style slot_button:
    properties gui.button_properties("slot_button")

style slot_button_text:
    properties gui.text_properties("slot_button")


## Preferences 스크린 #############################################################
##
## Preferences 스크린에서는 각종 환경설정을 플레이어가 지정할 수 있습니다.
##
## https://www.renpy.org/doc/html/screen_special.html#preferences
screen preferences():

    tag menu

    add "gui/main.png":
        xalign 0.5
        yalign 0.5
        xysize (1280, 720)

    frame:
        xpos 34
        ypos 34
        xsize 310
        ysize 652
        background Solid("#17110DB8")
        padding (0, 0)

        use navigation

    frame:
        xpos 350
        ypos 34
        xsize 900
        ysize 652
        background Solid("#FFF8ECE8")
        padding (0, 0)

    text "환경설정":
        xpos 800
        ypos 50
        xanchor 0.5
        font FILE_FONT
        size 44
        color "#3A2A1F"
        outlines []

    button:
        xpos 1080
        ypos 57
        background None
        hover_background Solid("#DCC49A55")
        selected_background Solid("#C9AA7755")
        action Return()
        padding (10, 4)

        text "돌아가기":
            font FILE_FONT
            size 26
            color "#4A3726"
            hover_color "#2F2118"
            outlines []

    fixed:
        xpos 390
        ypos 145
        xsize 800
        ysize 460

        vbox:
            xpos 0
            ypos 0
            spacing 8

            text "화면 모드" style "clean_pref_label_text"

            textbutton "창 화면":
                style "clean_pref_button"
                action Preference("display", "window")

            textbutton "전체 화면":
                style "clean_pref_button"
                action Preference("display", "fullscreen")

        vbox:
            xpos 290
            ypos 0
            spacing 8

            text "넘기기" style "clean_pref_label_text"

            textbutton "읽지 않은 지문":
                style "clean_pref_button"
                action Preference("skip", "toggle")

            textbutton "선택지 이후":
                style "clean_pref_button"
                action Preference("after choices", "toggle")


        vbox:
            xpos 0
            ypos 230
            spacing 10

            text "텍스트 속도" style "clean_pref_label_text"
            bar value Preference("text speed") style "clean_pref_slider"

            null height 12

            text "자동 진행 시간" style "clean_pref_label_text"
            bar value Preference("auto-forward time") style "clean_pref_slider"

        vbox:
            xpos 440
            ypos 230
            spacing 8

            if config.has_music:
                text "배경음 음량" style "clean_pref_label_text"
                bar value Preference("music volume") style "clean_pref_slider"

            if config.has_sound:
                text "효과음 음량" style "clean_pref_label_text"
                bar value Preference("sound volume") style "clean_pref_slider"

                if config.sample_sound:
                    textbutton "테스트":
                        style "clean_pref_small_button"
                        action Play("sound", config.sample_sound)

            if config.has_voice:
                text "음성 음량" style "clean_pref_label_text"
                bar value Preference("voice volume") style "clean_pref_slider"

                if config.sample_voice:
                    textbutton "테스트":
                        style "clean_pref_small_button"
                        action Play("voice", config.sample_voice)

            if config.has_music or config.has_sound or config.has_voice:
                null height 6

                textbutton "모두 음소거":
                    style "clean_pref_button"
                    action Preference("all mute", "toggle")

    key "game_menu" action Return()

    
style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox

style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox

style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox

style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox

style mute_all_button is check_button
style mute_all_button_text is check_button_text

style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 2

style pref_label_text:
    size 25
    color "#F1E4CE"
    outlines [(2, "#00000099", 0, 0)]

style pref_vbox:
    xsize 225

style radio_vbox:
    spacing gui.pref_button_spacing

style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/radio_[prefix_]foreground.png"

style radio_button_text:
    size 24

    color "#C9BBA8"
    selected_color "#FFE7A8"
    hover_color "#FFF3C4"
    insensitive_color "#6F675F"

    # 평소 그림자
    outlines [(1, "#00000088", 0, 0)]

    # 선택되었을 때 노란 테두리 제거하고 얇은 어두운 그림자만
    selected_outlines [(1, "#00000099", 0, 0)]

    # 마우스 올릴 때만 아주 얇게
    hover_outlines [(1, "#FFE7A866", 0, 0)]

style check_vbox:
    spacing gui.pref_button_spacing

style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.png"

style check_button_text:
    size 24

    color "#C9BBA8"
    selected_color "#FFE7A8"
    hover_color "#FFF3C4"
    insensitive_color "#6F675F"

    outlines [(1, "#00000088", 0, 0)]
    selected_outlines [(1, "#00000099", 0, 0)]
    hover_outlines [(1, "#FFE7A866", 0, 0)]

style slider_slider:
    xsize 350
    ysize 32

    # 채워진 부분
    left_bar Solid("#BDA987")

    # 안 채워진 부분
    right_bar Solid("#3A332B")

    # 조절 손잡이
    thumb Solid("#F7E4B8")

    # 마우스 올렸을 때 손잡이
    hover_thumb Solid("#FFE7A8")

style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 10

style slider_button_text:
    properties gui.text_properties("slider_button")

style slider_vbox:
    xsize 450


## History 스크린 #################################################################
##
## 지난 대사록을 출력합니다. _history_list 에 저장된 대사 기록을 확인합니다.
##
## https://www.renpy.org/doc/html/history.html

screen history():

    tag menu

    ## 이 스크린은 내용이 아주 많을 수 있으므로 prediction을 끕니다.
    predict False

    use game_menu(_("대사록"), scroll=("vpgrid" if gui.history_height else "viewport"), yinitial=1.0, spacing=gui.history_spacing):

        style_prefix "history"

        for h in _history_list:

            window:

                ## history_height 이 None일 경우 레이아웃이 틀어지지 않게 합니
                ## 다.
                has fixed:
                    yfit True

                if h.who:

                    label h.who:
                        style "history_name"
                        substitute False
                        text_color "#3F2D1F"



                $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                text what:
                    substitute False

        if not _history_list:
            label _("대사가 없습니다.")


## 이것은 대사록 화면에 표시할 수 있는 태그를 결정합니다.

define gui.history_allow_tags = { "alt", "noalt", "rt", "rb", "art" }


style history_window is empty

style history_name is gui_label
style history_name_text is gui_label_text
style history_text is gui_text

style history_label is gui_label
style history_label_text is gui_label_text

style history_window:
    xfill True
    ysize gui.history_height

style history_name:
    xpos gui.history_name_xpos
    xanchor gui.history_name_xalign
    ypos gui.history_name_ypos
    xsize gui.history_name_width

style history_name_text:
    min_width gui.history_name_width
    textalign gui.history_name_xalign

style history_text:
    xpos gui.history_text_xpos
    ypos gui.history_text_ypos
    xanchor gui.history_text_xalign
    xsize gui.history_text_width
    min_width gui.history_text_width
    textalign gui.history_text_xalign
    layout ("subtitle" if gui.history_text_xalign else "tex")

style history_label:
    xfill True

style history_label_text:
    xalign 0.5


## Help 스크린 ####################################################################
##
## 입력장치의 기능을 설명합니다. 각 입력장치별 설정은 keyboard_help, mouse_help,
## gamepad_help 스크린을 각각 불러와서 출력합니다.

screen help():

    tag menu

    default device = "keyboard"

    use game_menu(_("조작방법"), scroll="viewport"):

        style_prefix "help"

        vbox:
            spacing 15

            hbox:

                textbutton _("키보드") action SetScreenVariable("device", "keyboard")
                textbutton _("마우스") action SetScreenVariable("device", "mouse")

                if GamepadExists():
                    textbutton _("게임패드") action SetScreenVariable("device", "gamepad")

            if device == "keyboard":
                use keyboard_help
            elif device == "mouse":
                use mouse_help
            elif device == "gamepad":
                use gamepad_help


screen keyboard_help():

    hbox:
        label _("엔터(Enter)")
        text _("대사 진행 및 UI (선택지 포함) 선택.")

    hbox:
        label _("스페이스(Space)")
        text _("대사를 진행하되 선택지는 선택하지 않음.")

    hbox:
        label _("화살표 키")
        text _("UI 이동.")

    hbox:
        label _("이스케이프(Esc)")
        text _("게임 메뉴 불러옴.")

    hbox:
        label _("컨트롤(Ctrl)")
        text _("누르고 있는 동안 대사를 스킵.")

    hbox:
        label _("탭(Tab)")
        text _("대사 스킵 토글.")

    hbox:
        label _("페이지 업(Page Up)")
        text _("이전 대사로 롤백.")

    hbox:
        label _("페이지 다운(Page Down)")
        text _("이후 대사로 롤포워드.")

    hbox:
        label "H"
        text _("UI를 숨김.")

    hbox:
        label "S"
        text _("스크린샷 저장.")

    hbox:
        label "V"
        text _("{a=https://www.renpy.org/l/voicing}대사 읽어주기 기능{/a} 토글.")

    hbox:
        label "Shift+A"
        text _("접근성 메뉴를 엽니다.")


screen mouse_help():

    hbox:
        label _("클릭")
        text _("대사 진행 및 UI (선택지 포함) 선택.")

    hbox:
        label _("가운데 버튼이나 휠버튼 클릭")
        text _("UI를 숨김.")

    hbox:
        label _("우클릭")
        text _("게임 메뉴 불러옴.")

    hbox:
        label _("휠 위로")
        text _("이전 대사로 롤백.")

    hbox:
        label _("휠 아래로")
        text _("이후 대사로 롤포워드.")


screen gamepad_help():

    hbox:
        label _("오른쪽 트리거(RT)\nA버튼/아래 버튼")
        text _("대사 진행 및 UI (선택지 포함) 선택.")

    hbox:
        label _("왼쪽 트리거\n왼쪽 어깨")
        text _("이전 대사로 롤백.")

    hbox:
        label _("오른쪽 범퍼(RB)")
        text _("이후 대사로 롤포워드.")

    hbox:
        label _("D-Pad, 아날로그 스틱")
        text _("UI 이동.")

    hbox:
        label _("Start, Guide, B/Right Button")
        text _("게임 메뉴 불러옴.")

    hbox:
        label _("Y버튼/위 버튼")
        text _("UI를 숨김.")

    textbutton _("조정") action GamepadCalibrate()


style help_button is gui_button
style help_button_text is gui_button_text
style help_label is gui_label
style help_label_text is gui_label_text
style help_text is gui_text

style help_button:
    properties gui.button_properties("help_button")
    xmargin 8

style help_button_text:
    properties gui.text_properties("help_button")

style help_label:
    xsize 250
    right_padding 20

style help_label_text:
    size gui.text_size
    xalign 1.0
    textalign 1.0



################################################################################
## 그 외 스크린
################################################################################


## Confirm 스크린 #################################################################
##
## 게임 입력 관련 예/아니오 질문을 플레이어에게 할 때 이 스크린을 표시합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#confirm
screen confirm(message, yes_action, no_action):

    modal True
    zorder 200

    add Solid("#00000066")

    $ message_text = str(message)
    $ confirm_title = message_text
    $ confirm_sub = ""

    if message == layout.OVERWRITE_SAVE:
        $ confirm_title = "이 저장 슬롯을 덮어쓸까요?"
        $ confirm_sub = "이전 저장 내용은 사라집니다."

    elif message == layout.LOADING:
        $ confirm_title = "파일을 불러올까요?"
        $ confirm_sub = "저장하지 않은 진행은 사라집니다."

    elif message == layout.DELETE_SAVE:
        $ confirm_title = "이 저장 파일을 삭제할까요?"
        $ confirm_sub = ""

    elif message == layout.MAIN_MENU:
        $ confirm_title = "메인 메뉴로 돌아갈까요?"
        $ confirm_sub = "저장하지 않은 진행은 사라집니다."

    elif message == layout.QUIT:
        $ confirm_title = "게임을 종료할까요?"
        $ confirm_sub = ""

    frame:
        style "confirm_frame"
        xsize 550

        vbox:
            xalign 0.5
            yalign 0.5
            spacing 24

            text confirm_title:
                style "confirm_prompt_text"

            if confirm_sub != "":
                text confirm_sub:
                    style "confirm_sub_text"

            null height 6

            hbox:
                xalign 0.5
                spacing 90

                textbutton "네":
                    style "confirm_button"
                    action yes_action

                textbutton "아니오":
                    style "confirm_button"
                    action no_action

    key "game_menu" action no_action

style confirm_frame is gui_frame
style confirm_prompt_text is gui_prompt_text
style confirm_sub_text is gui_text
style confirm_button is gui_medium_button
style confirm_button_text is gui_medium_button_text

style confirm_frame:
    background Solid("#2B2724E8")
    xalign 0.5
    yalign 0.5
    xsize 620
    ysize 245
    padding (38, 30, 38, 28)

style confirm_prompt_text:
    font FILE_FONT
    size 30
    color "#FFF7E8"
    textalign 0.5
    xalign 0.5
    xmaximum 540
    line_spacing 8
    outlines []

style confirm_sub_text:
    font FILE_FONT
    size 21
    color "#D8CBB8"
    textalign 0.5
    xalign 0.5
    xmaximum 540
    outlines []

style confirm_button:
    xminimum 120
    yminimum 44
    xpadding 10
    ypadding 5
    background None
    hover_background Solid("#DCC49A33")
    selected_background Solid("#DCC49A33")

style confirm_button_text:
    font FILE_FONT
    size 24
    color "#E8DCC8"
    hover_color "#FFFFFF"
    selected_color "#FFFFFF"
    insensitive_color "#8A7D6E"
    outlines []
    hover_outlines []
    selected_outlines []

## Skip indicator 스크린 ##########################################################
##
## Skip_indicator 스크린은 스킵 중일 때 "스킵 중"을 표시하기 위해 출력됩니다.
##
## https://www.renpy.org/doc/html/screen_special.html#skip-indicator

screen skip_indicator():

    zorder 100
    style_prefix "skip"

    frame:

        hbox:
            spacing 6

            text _("넘기는 중")

            text "▸" at delayed_blink(0.0, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.2, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.4, 1.0) style "skip_triangle"


## 이 transform으로 화살표를 순서대로 페이드인/페이드아웃합니다.
transform delayed_blink(delay, cycle):
    alpha .5

    pause delay

    block:
        linear .2 alpha 1.0
        pause .2
        linear .2 alpha 0.5
        pause (cycle - .4)
        repeat


style skip_frame is empty
style skip_text is gui_text
style skip_triangle is skip_text

style skip_frame:
    ypos gui.skip_ypos
    background Frame("gui/skip.png", gui.skip_frame_borders, tile=gui.frame_tile)
    padding gui.skip_frame_borders.padding

style skip_text:
    size gui.notify_text_size

style skip_triangle:
    ## BLACK RIGHT-POINTING SMALL TRIANGLE 글리프가 있는 글꼴을 사용해야 합니다.
    font "DejaVuSans.ttf"


## Notify 스크린 ##################################################################
##
## Notify 스크린으로 플레이어에게 메시지를 출력합니다. (예를 들어 '퀵세이브 완
## 료'나 '스크린샷 저장 완료')
##
## https://www.renpy.org/doc/html/screen_special.html#notify-screen

screen notify(message):

    zorder 100
    style_prefix "notify"

    frame at notify_appear:
        text "[message!tq]"

    timer 3.25 action Hide('notify')


transform notify_appear:
    on show:
        alpha 0
        linear .25 alpha 1.0
    on hide:
        linear .5 alpha 0.0


style notify_frame is empty
style notify_text is gui_text

style notify_frame:
    ypos gui.notify_ypos

    background Frame("gui/notify.png", gui.notify_frame_borders, tile=gui.frame_tile)
    padding gui.notify_frame_borders.padding

style notify_text:
    properties gui.text_properties("notify")


## NVL 스크린 #####################################################################
##
## NVL모드 대사와 선택지를 출력합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#nvl


screen nvl(dialogue, items=None):

    window:
        style "nvl_window"

        has vbox:
            spacing gui.nvl_spacing

        ## vpgrid나 vbox 내에 대사를 출력합니다.
        if gui.nvl_height:

            vpgrid:
                cols 1
                yinitial 1.0

                use nvl_dialogue(dialogue)

        else:

            use nvl_dialogue(dialogue)

        ## 주어진 경우 메뉴를 표시합니다. config.narrator_menu가 True로 설정된
        ## 경우 메뉴가 잘못 표시될 수 있습니다.
        for i in items:

            textbutton i.caption:
                action i.action
                style "nvl_button"

    add SideImage() xalign 0.0 yalign 1.0


screen nvl_dialogue(dialogue):

    for d in dialogue:

        window:
            id d.window_id

            fixed:
                yfit gui.nvl_height is None

                if d.who is not None:

                    text d.who:
                        id d.who_id

                text d.what:
                    id d.what_id


## 동시에 출력될 수 있는 NVL 대사의 최대치를 조정합니다.
define config.nvl_list_length = gui.nvl_list_length

style nvl_window is default
style nvl_entry is default

style nvl_label is say_label
style nvl_dialogue is say_dialogue

style nvl_button is button
style nvl_button_text is button_text

style nvl_window:
    xfill True
    yfill True

    background "gui/nvl.png"
    padding gui.nvl_borders.padding

style nvl_entry:
    xfill True
    ysize gui.nvl_height

style nvl_label:
    xpos gui.nvl_name_xpos
    xanchor gui.nvl_name_xalign
    ypos gui.nvl_name_ypos
    yanchor 0.0
    xsize gui.nvl_name_width
    min_width gui.nvl_name_width
    textalign gui.nvl_name_xalign

style nvl_dialogue:
    xpos gui.nvl_text_xpos
    xanchor gui.nvl_text_xalign
    ypos gui.nvl_text_ypos
    xsize gui.nvl_text_width
    min_width gui.nvl_text_width
    textalign gui.nvl_text_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_thought:
    xpos gui.nvl_thought_xpos
    xanchor gui.nvl_thought_xalign
    ypos gui.nvl_thought_ypos
    xsize gui.nvl_thought_width
    min_width gui.nvl_thought_width
    textalign gui.nvl_thought_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_button:
    properties gui.button_properties("nvl_button")
    xpos gui.nvl_button_xpos
    xanchor gui.nvl_button_xalign

style nvl_button_text:
    properties gui.text_properties("nvl_button")


## Bubble screen ###############################################################
##
## 말풍선 화면은 말풍선을 사용할 때 플레이어에게 대화를 표시하는 데 사용됩니다.
## 말풍선 화면은 말풍선 화면과 동일한 매개변수를 사용하며, "what" 아이디로 표시
## 가능 항목을 생성해야 하며, "namebox", "who", "window" 아이디로 표시 가능 항목
## 을 생성할 수 있습니다.
##
## https://www.renpy.org/doc/html/bubble.html#bubble-screen

screen bubble(who, what):
    style_prefix "bubble"

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "bubble_namebox"

                text who:
                    id "who"

        text what:
            id "what"

        default ctc = None
        showif ctc:
            add ctc

style bubble_window is empty
style bubble_namebox is empty
style bubble_who is default
style bubble_what is default

style bubble_window:
    xpadding 30
    top_padding 5
    bottom_padding 5

style bubble_namebox:
    xalign 0.5

style bubble_who:
    xalign 0.5
    textalign 0.5
    color "#000"

style bubble_what:
    align (0.5, 0.5)
    text_align 0.5
    layout "subtitle"
    color "#000"

define bubble.frame = Frame("gui/bubble.png", 55, 55, 55, 95)
define bubble.thoughtframe = Frame("gui/thoughtbubble.png", 55, 55, 55, 55)

define bubble.properties = {
    "bottom_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "bottom_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "top_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "top_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "thought" : {
        "window_background" : bubble.thoughtframe,
    }
}

define bubble.expand_area = {
    "bottom_left" : (0, 0, 0, 22),
    "bottom_right" : (0, 0, 0, 22),
    "top_left" : (0, 22, 0, 0),
    "top_right" : (0, 22, 0, 0),
    "thought" : (0, 0, 0, 0),
}



################################################################################
## 모바일 버전
################################################################################

style pref_vbox:
    variant "medium"
    xsize 450

## 마우스가 없고 화면이 작을 가능성이 높으므로, 퀵메뉴 버튼의 크기를 키우고 가짓
## 수를 줄입니다.
screen quick_menu():
    variant "touch"

    zorder 100

    if getattr(store, "quick_menu", True):

        hbox:
            style "quick_menu"
            style_prefix "quick"

            textbutton _("되감기") action Rollback()
            textbutton _("넘기기") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("자동진행") action Preference("auto-forward", "toggle")
            textbutton _("메뉴") action ShowMenu()


style window:
    variant "small"
    background "gui/phone/textbox.png"

style radio_button:
    variant "small"
    foreground "gui/phone/button/radio_[prefix_]foreground.png"

style check_button:
    variant "small"
    foreground "gui/phone/button/check_[prefix_]foreground.png"

style nvl_window:
    variant "small"
    background "gui/phone/nvl.png"

style main_menu_frame:
    variant "small"
    background "gui/phone/overlay/main_menu.png"

style game_menu_outer_frame:
    variant "small"
    background "gui/phone/overlay/game_menu.png"

style game_menu_navigation_frame:
    variant "small"
    xsize 340

style game_menu_content_frame:
    variant "small"
    top_margin 0

style game_menu_viewport:
    variant "small"
    xsize 870

style pref_vbox:
    variant "small"
    xsize 400

style bar:
    variant "small"
    ysize gui.bar_size
    left_bar Frame("gui/phone/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/phone/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    variant "small"
    xsize gui.bar_size
    top_bar Frame("gui/phone/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/phone/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    variant "small"
    ysize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    variant "small"
    xsize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    variant "small"
    ysize gui.slider_size
    base_bar Frame("gui/phone/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/horizontal_[prefix_]thumb.png"

style vslider:
    variant "small"
    xsize gui.slider_size
    base_bar Frame("gui/phone/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/vertical_[prefix_]thumb.png"

style slider_vbox:
    variant "small"
    xsize None

style slider_slider:
    variant "small"
    xsize 600
    ysize 32

    left_bar Solid("#BDA987")
    right_bar Solid("#3A332B")
    thumb Solid("#F7E4B8")
    hover_thumb Solid("#FFE7A8")

screen diary_page(title="", content="", body_yoffset=0):
    tag menu
    modal True

    # 일기장 배경
    add "bg_diary.jpg"

    # 종이 안쪽 글씨 영역
    frame:
        background None
        xalign 0.5
        yalign 0.47
        xsize 960
        ysize 740
        padding (85, 70, 85, 60)

        vbox:
            xalign 0.5
            yalign 0.5
            spacing 35

            # 제목
            text title:
                font "fonts/HakgyoansimKkokkomaOTFR.otf"
                size 54
                color "#3C2F1F"
                xalign 0.5
                outlines [(3, "#f8f0d8", 0, 0)]
                substitute False

            # 본문 (글씨 아주 조금 작게 조정)
            viewport:
                yoffset body_yoffset
                mousewheel True
                draggable True
                scrollbars None
                yinitial 0.0
                vbox:
                    xsize 790
                    spacing 16

                    text content:
                        font "fonts/HakgyoansimKkokkomaOTFR.otf"
                        size 30          # ← 여기서 32 → 30으로 변경
                        color "#221c14"
                        line_spacing 11  # 줄 간격도 살짝 좁혀서 더 예쁘게
                        slow_cps 32
                        slow_abortable True
                        outlines [(1, "#f0e6d0", 0, 0)]
                        substitute False

    # 다음 버튼 (오른쪽 아래)
    textbutton "다음":
        xalign 0.94
        yalign 0.92
        action Return()

        text_font "fonts/HakgyoansimKkokkomaOTFR.otf"
        text_size 48
        text_color "#3C2F1F"
        text_hover_color "#8B5A2B"
        text_outlines [(3, "#f8f0d8", 0, 0)]

screen diary_focus_badge(person="none"):

    zorder 200

    $ _face = diary_focus_face(person)
    $ _name = display_name(person) if person != "none" else ""

    if _face:
        fixed:
            xpos 215
            ypos 170
            xysize (430, 100)

            add _face:
                xpos 0
                ypos 8
                xysize (74, 74)

            text "오늘 신경 쓰인 친구":
                xpos 92
                ypos 10
                size 25
                color "#3A3328"
                outlines [(2, "#FFF4DD", 0, 0)]

            text _name:
                xpos 92
                ypos 44
                size 30
                color "#1F1A14"
                outlines [(2, "#FFF4DD", 0, 0)]
# ----------------------------------------------------------
# 최종 UI 위치/크기 강제 조정
# 파일 맨 아래에 둬야 적용됨
# ----------------------------------------------------------

style namebox:
    ypos -10

style say_dialogue:
    ypos 48

style choice_button:
    xsize 720
    ysize 44
    left_padding 20
    right_padding 20
    top_padding 6
    bottom_padding 6

style choice_button_text:
    size 22

# ----------------------------------------------------------
# 최종 메뉴/환경설정/관계노트 보정
# ----------------------------------------------------------

# 파일 위치 기준:
# game/fonts/NanumChodingHope.ttf
# game/gui/main.png
# game/images/ui/note.png
# game/images/ui/relation_note_bg.png
# game/images/ui/jh.png / hy.png / ne.png / sh.png / sy.png

define NOTE_FONT = "fonts/NanumChodingHope.ttf"
define MENU_FONT = "fonts/NanumChodingHope.ttf"

# 관계 노트용 이미지 선언
image relation_note_bg = "images/ui/relation_note_bg.png"
image rel_jh = "images/ui/jh.png"
image rel_hy = "images/ui/hy.png"
image rel_ne = "images/ui/ne.png"
image rel_sh = "images/ui/sh.png"
image rel_sy = "images/ui/sy.png"

init python:
    def relation_status_text(like, neg):
        if neg >= 7:
            return "주의가 필요함"
        elif like >= 9 and neg <= 2:
            return "매우 가까움"
        elif like >= 6 and neg <= 4:
            return "조금 가까워짐"
        elif like >= 3:
            return "천천히 알아가는 중"
        else:
            return "아직 알아가는 중"


# ----------------------------------------------------------
# 환경설정 전용 스타일
# ----------------------------------------------------------

style clean_pref_label_text is gui_text:
    font FILE_FONT
    size 27
    color "#3A2A1F"
    outlines []

style clean_pref_button is gui_button:
    background None
    hover_background Solid("#DCC49A55")
    selected_background Solid("#C9AA7755")
    insensitive_background None
    xpadding 6
    ypadding 2

style clean_pref_button_text is gui_button_text:
    font FILE_FONT
    size 23
    color "#4A3726"
    hover_color "#2F2118"
    selected_color "#8A4F2A"
    insensitive_color "#A69A8C"
    outlines []
    hover_outlines []
    selected_outlines []

style clean_pref_small_button is gui_button:
    background None
    hover_background Solid("#DCC49A55")
    selected_background Solid("#C9AA7755")
    xpadding 6
    ypadding 1

style clean_pref_small_button_text is gui_button_text:
    font FILE_FONT
    size 20
    color "#4A3726"
    hover_color "#2F2118"
    selected_color "#8A4F2A"
    outlines []
    hover_outlines []
    selected_outlines []

style clean_pref_slider is gui_slider:
    xsize 360
    ysize 24
    left_bar Solid("#9D8660")
    right_bar Solid("#E8DCC2")
    thumb Solid("#4A3726")
    hover_thumb Solid("#2F2118")


# ----------------------------------------------------------
# 게임 메뉴 오른쪽 내용 가독성 보정
# 저장 / 불러오기 / 대사록 / 조작방법 / 버전정보
# ----------------------------------------------------------

style page_label_text:
    font FILE_FONT
    size 24
    color "#5A4735"
    hover_color "#2F2118"
    outlines []
    textalign 0.5
    layout "subtitle"


style page_button_text:
    font FILE_FONT
    size 20
    color "#6A5741"
    hover_color "#2F2118"
    selected_color "#8A4F2A"
    insensitive_color "#B6A897"
    outlines []
    hover_outlines []
    selected_outlines []

style slot_button:
    background Solid("#FFF8ECD0")
    hover_background Solid("#FFF2DDE8")
    selected_background Solid("#F1DFC0E8")
    padding (10, 10)

style slot_time_text:
    font FILE_FONT
    size 13
    color "#7A6855"
    outlines []
    textalign 0.5

style slot_name_text:
    font FILE_FONT
    size 14
    color "#4A3726"
    outlines []
    textalign 0.5

style about_label_text:
    font FILE_FONT
    size 30
    color "#3A2A1F"
    outlines []

style about_text:
    font FILE_FONT
    size 22
    color "#4A3726"
    line_spacing 10
    outlines []
    xmaximum 760
    layout "subtitle"

style history_name_text:
    font FILE_FONT
    size 24
    color "#3F2D1F"
    outlines []

style history_text:
    font FILE_FONT
    size 22
    color "#4A3726"
    line_spacing 8
    outlines []

style history_label_text:
    font FILE_FONT
    size 24
    color "#4A3726"
    outlines []
    xalign 0.5

style help_button_text:
    font FILE_FONT
    size 22
    color "#4A7DB3"
    hover_color "#2F2118"
    selected_color "#2F2118"
    insensitive_color "#B6A897"
    outlines []
    hover_outlines []
    selected_outlines []

style help_label_text:
    font FILE_FONT
    size 22
    color "#4A7DB3"
    outlines []
    xalign 1.0
    textalign 1.0

style help_text:
    font FILE_FONT
    size 22
    color "#4A3726"
    outlines []


# ----------------------------------------------------------
# 종료 확인창 정리
# ----------------------------------------------------------

style confirm_button:
    properties gui.button_properties("confirm_button")
    xsize 130
    ysize 48
    xpadding 6
    ypadding 4
    background None
    hover_background None
    selected_background None
    insensitive_background None

style confirm_button_text:
    properties gui.text_properties("confirm_button")
    font "fonts/RIDIBatang.otf"
    size 28
    color "#E8DCC8"
    hover_color "#D6B98E"
    selected_color "#D6B98E"
    insensitive_color "#8A7D6E"
    outlines [(1, "#00000088", 0, 0)]
    hover_outlines [(1, "#00000088", 0, 0)]
    selected_outlines [(1, "#00000088", 0, 0)]



screen d5_observation_screen():

    modal True
    zorder 200
    default hover_name = ""

    $ any_observed = d5_obs_jiho or d5_obs_hayoung or d5_obs_naeun or d5_obs_sohee or d5_obs_seoyeon

    key "dismiss" action NullAction()
    key "game_menu" action NullAction()

    # D5 조사 전용 배경 고정
    add "bg_d5_observation":
        xysize (1280, 720)

    add Solid("#00000012")

    # 상단 안내 바
    frame:
        xpos 0
        ypos 0
        xsize 1280
        ysize 86
        background Solid("#1A1714BB")
        padding (0, 0)

        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4

            text "아침 교실 둘러보기":
                xalign 0.5
                font FILE_FONT
                size 30
                color "#FFF8E8"
                outlines []

            text "학생을 클릭해서 관찰해 보자. 관찰한 친구에게만 마음잎을 쓸 수 있어.":
                xalign 0.5
                font FILE_FONT
                size 20
                color "#E8DDC8"
                outlines []


    # 마우스 오버 시 이름 표시
    if hover_name != "":
        frame:
            background Solid("#00000080")
            xalign 0.5
            ypos 96
            xpadding 18
            ypadding 7

            text hover_name:
                font FILE_FONT
                size 26
                color "#FFFFFF"
                outlines [(2, "#000000AA", 0, 0)]
                xalign 0.5

    # ------------------------------------------------------
    # 클릭 영역 — bg_d5_observation 1280x720 기준 재조정
    # ------------------------------------------------------

    # 지호 — 창가 쪽 흰 티 남학생
    button:
        xpos 280
        ypos 125
        xsize 125
        ysize 225
        background Solid("#00000000")
        hover_background Solid("#7DB8FF44")
        sensitive not d5_obs_jiho
        hovered SetScreenVariable("hover_name", "지호")
        unhovered SetScreenVariable("hover_name", "")
        action Return("jiho")

    # 하영 — 화면 아래쪽 긴머리 여학생
    button:
        xpos 410
        ypos 325
        xsize 165
        ysize 270
        background Solid("#00000000")
        hover_background Solid("#FF9ACD44")
        sensitive not d5_obs_hayoung
        hovered SetScreenVariable("hover_name", "하영")
        unhovered SetScreenVariable("hover_name", "")
        action Return("hayoung")

    # 소희 — 보라색 옷을 입은 단발머리 여학생
    button:
        xpos 715
        ypos 165
        xsize 145
        ysize 245
        background Solid("#00000000")
        hover_background Solid("#FFCF6E44")
        sensitive not d5_obs_sohee
        hovered SetScreenVariable("hover_name", "소희")
        unhovered SetScreenVariable("hover_name", "")
        action Return("sohee")

    # 나은 — 회색 맨투맨 포니테일 여학생
    button:
        xpos 830
        ypos 230
        xsize 165
        ysize 255
        background Solid("#00000000")
        hover_background Solid("#BFA7FF44")
        sensitive not d5_obs_naeun
        hovered SetScreenVariable("hover_name", "나은")
        unhovered SetScreenVariable("hover_name", "")
        action Return("naeun")

    # 서연 — 칠판 앞 안경 쓴 학생
    button:
        xpos 900
        ypos 120
        xsize 155
        ysize 245
        background Solid("#00000000")
        hover_background Solid("#9FE0C544")
        sensitive not d5_obs_seoyeon
        hovered SetScreenVariable("hover_name", "서연")
        unhovered SetScreenVariable("hover_name", "")
        action Return("seoyeon")

    # ------------------------------------------------------
    # 관찰 완료 패널
    # ------------------------------------------------------
    frame:
        xpos 760
        ypos 575
        xsize 486
        ysize 118
        background Solid("#1A1714CC")
        padding (22, 14)

        hbox:
            spacing 22
            yalign 0.5

            vbox:
                spacing 7
                xsize 260

                text "관찰 완료":
                    font FILE_FONT
                    size 19
                    color "#FFF8E8"
                    outlines []

                text ("{color=#7DB8FF}지호{/color}  " if d5_obs_jiho else "{color=#6E6E6E}지호{/color}  ") + ("{color=#FF9ACD}하영{/color}  " if d5_obs_hayoung else "{color=#6E6E6E}하영{/color}  ") + ("{color=#BFA7FF}나은{/color}" if d5_obs_naeun else "{color=#6E6E6E}나은{/color}"):
                    font FILE_FONT
                    size 18
                    color "#E8DDC8"
                    outlines [(1, "#00000099", 0, 0)]

                text ("{color=#FFCF6E}소희{/color}  " if d5_obs_sohee else "{color=#6E6E6E}소희{/color}  ") + ("{color=#9FE0C5}서연{/color}" if d5_obs_seoyeon else "{color=#6E6E6E}서연{/color}"):
                    font FILE_FONT
                    size 18
                    color "#E8DDC8"
                    outlines [(1, "#00000099", 0, 0)]

            textbutton "마음잎 활동 시작":
                xsize 160
                ysize 54
                background Solid("#FFF8ECDD")
                hover_background Solid("#FFE7B8")
                insensitive_background Solid("#A59A8AAA")
                sensitive any_observed
                action Return("start_activity")

                text_font FILE_FONT
                text_size 20
                text_color "#3A2A1F"
                text_hover_color "#2F2118"
                text_insensitive_color "#5F5A52"
                text_outlines []

# ----------------------------------------------------------
# 관계 노트 버튼
# ----------------------------------------------------------

transform relation_button_hover:
    on idle:
        linear 0.10 zoom 1.0
    on hover:
        linear 0.10 zoom 1.06

transform close_button_hover:
    on idle:
        linear 0.10 zoom 1.0
    on hover:
        linear 0.10 zoom 1.12

screen relation_note_button():

    zorder 90

    if relation_note_enabled:

        button:
            xpos 1018
            ypos 14
            xsize 220
            ysize 92
            background None
            hover_background None
            action Show("relation_note")
            at relation_button_hover

            fixed:
                xsize 220
                ysize 92

                add "relation_note_bg":
                    xalign 0.5
                    yalign 0.5
                    xysize (205, 86)
                    alpha 0.98

                text "관계 노트":
                    xalign 0.5
                    yalign 0.5
                    size 25
                    font NOTE_FONT
                    color "#3A2418"
                    outlines [(1, "#FFF4D8EE", 0, 0)]
                    bold False


# ----------------------------------------------------------
# 관계 노트 화면
# ----------------------------------------------------------

screen relation_note():

    modal True
    zorder 100

    add Solid("#000000")

    add "images/ui/note.png":
        xalign 0.5
        yalign 0.5
        xysize (1280, 720)

    button:
        xalign 0.955
        yalign 0.055
        background None
        hover_background None
        action Hide("relation_note")
        at close_button_hover

        text "닫기":
            size 34
            font NOTE_FONT
            color "#F6E8C8"
            hover_color "#FFFFFF"
            outlines [(2, "#000000CC", 0, 0)]
            bold False

    text "관계 노트":
        xpos 385
        ypos 112
        xanchor 0.5
        size 39
        font NOTE_FONT
        bold False
        color "#2A1E16"

    text "현재 친구들과의 관계 상태":
        xpos 385
        ypos 164
        xanchor 0.5
        size 23
        font NOTE_FONT
        bold False
        color "#3A2A1F"

    vbox:
        xpos 210
        ypos 220
        spacing 22

        use relation_note_row("지호", "rel_jh", like_jiho, neg_jiho, "#7DB8FF")
        use relation_note_row("하영", "rel_hy", like_hayoung, neg_hayoung, "#FF9ACD")
        use relation_note_row("나은", "rel_ne", like_naeun, neg_naeun, "#BFA7FF")

    vbox:
        xpos 690
        ypos 220
        spacing 22

        use relation_note_row("소희", "rel_sh", like_sohee, neg_sohee, "#FFCF6E")
        use relation_note_row("서연", "rel_sy", like_seoyeon, neg_seoyeon, "#9FE0C5")

        null height 10

        frame:
            background Solid("#FFF8E080")
            padding (16, 12)
            xsize 340

            vbox:
                spacing 8

                text "나의 피로도 / 소진도":
                    size 22
                    font NOTE_FONT
                    bold False
                    color "#2F2118"

                hbox:
                    spacing 10

                    text "[burnout] / 10":
                        size 22
                        font NOTE_FONT
                        bold False
                        color "#7A2E1D"
                        xsize 80

                    bar:
                        value StaticValue(burnout, 10)
                        xsize 210
                        ysize 15
                        left_bar Solid("#9B4A32")
                        right_bar Solid("#DDD1B2")
                        thumb None
                        thumb_shadow None


# ----------------------------------------------------------
# 관계 노트 한 줄
# ----------------------------------------------------------

screen relation_note_row(name, portrait, like, neg, name_color):

    frame:
        background Solid("#FFF8E080")
        padding (12, 10)
        xsize 350

        hbox:
            spacing 12

            add portrait:
                xysize (58, 58)
                yalign 0.5

            vbox:
                spacing 4
                yalign 0.5

                hbox:
                    spacing 8

                    text name:
                        size 25
                        font NOTE_FONT
                        bold False
                        color name_color
                        xsize 70
                        outlines [(1, "#2F2118AA", 0, 0)]

                    text relation_status_text(like, neg):
                        size 19
                        font NOTE_FONT
                        bold False
                        color "#3E2C20"

                hbox:
                    spacing 8

                    text "호감":
                        size 19
                        font NOTE_FONT
                        bold False
                        color "#2F2118"
                        xsize 45

                    text "[like]/12":
                        size 19
                        font NOTE_FONT
                        bold False
                        color "#2F5685"
                        xsize 55

                    bar:
                        value StaticValue(like, 12)
                        xsize 135
                        ysize 13
                        left_bar Solid("#5A7DB8")
                        right_bar Solid("#DDD1B2")
                        thumb None
                        thumb_shadow None

                hbox:
                    spacing 8

                    text "주의":
                        size 19
                        font NOTE_FONT
                        bold False
                        color "#2F2118"
                        xsize 45

                    text "[neg]/10":
                        size 19
                        font NOTE_FONT
                        bold False
                        color "#8E352C"
                        xsize 55

                    bar:
                        value StaticValue(neg, 10)
                        xsize 135
                        ysize 13
                        left_bar Solid("#B85A4A")
                        right_bar Solid("#DDD1B2")
                        thumb None
                        thumb_shadow None

style sync_button is gui_button:
    background None
    hover_background Solid("#DCC49A55")
    selected_background Solid("#C9AA7755")
    xminimum 260
    yminimum 34
    padding (12, 5)

style sync_button_text is gui_button_text:
    font FILE_FONT
    size 20
    color "#5A4735"
    hover_color "#2F2118"
    selected_color "#8A4F2A"
    outlines []
    hover_outlines []
    selected_outlines []
    textalign 0.5
    xalign 0.5


screen d8_relation_note_screen():

    modal True
    zorder 120

    # 퀵메뉴/기존 관계노트 버튼이 뒤에서 비치지 않도록 검은 배경을 먼저 깐다.
    add Solid("#000000")

    add "bg_relation_book":
        xalign 0.5
        yalign 0.5
        xysize (1280, 720)

    # ------------------------------------------------------
    # 현재 수치 계산
    # ------------------------------------------------------
    $ jiho_like = like_of("jiho")
    $ jiho_neg = neg_of("jiho")

    $ hayoung_like = like_of("hayoung")
    $ hayoung_neg = neg_of("hayoung")

    $ naeun_like = like_of("naeun")
    $ naeun_neg = neg_of("naeun")

    $ sohee_like = like_of("sohee")
    $ sohee_neg = neg_of("sohee")

    $ seoyeon_like = like_of("seoyeon")
    $ seoyeon_neg = neg_of("seoyeon")

    $ top_person = max(["jiho", "hayoung", "naeun", "sohee", "seoyeon"], key=lambda p: like_of(p))

    $ top_name = {"jiho": "지호", "hayoung": "하영", "naeun": "나은", "sohee": "소희", "seoyeon": "서연"}[top_person]
    $ top_portrait = {"jiho": "rel_jh", "hayoung": "rel_hy", "naeun": "rel_ne", "sohee": "rel_sh", "seoyeon": "rel_sy"}[top_person]
    $ top_color = {"jiho": "#7DB8FF", "hayoung": "#FF9ACD", "naeun": "#BFA7FF", "sohee": "#FFCF6E", "seoyeon": "#9FE0C5"}[top_person]


    # 왼쪽 페이지: 노트 안쪽으로 넣고, 줄 간격은 고정값으로 맞춘다.
    frame:
        background None
        xpos 220
        ypos 120
        xsize 345
        ysize 500

        fixed:
            text "관계 정리":
                xpos 0
                ypos 0
                size 26
                color "#3A281D"
                font FILE_FONT
                outlines []

            text "이번 주 동안 선택한 말과 행동이":
                xpos 0
                ypos 50
                size 15
                color "#5A4735"
                font FILE_FONT
                outlines []

            text "친구들과의 관계에 남았다.":
                xpos 0
                ypos 76
                size 15
                color "#5A4735"
                font FILE_FONT
                outlines []

            text "호감":
                xpos 0
                ypos 132
                size 21
                color "#3A281D"
                font FILE_FONT
                outlines []

            text "함께 있고 싶거나,":
                xpos 0
                ypos 165
                size 15
                color "#5A4735"
                font FILE_FONT
                outlines []

            text "다시 이야기해보고 싶은 마음.":
                xpos 0
                ypos 191
                size 15
                color "#5A4735"
                font FILE_FONT
                outlines []

            text "부담":
                xpos 0
                ypos 246
                size 21
                color "#3A281D"
                font FILE_FONT
                outlines []

            text "불편했거나,":
                xpos 0
                ypos 279
                size 15
                color "#5A4735"
                font FILE_FONT
                outlines []

            text "조금 조심해야 할 순간.":
                xpos 0
                ypos 305
                size 15
                color "#5A4735"
                font FILE_FONT
                outlines []

            text "피로":
                xpos 0
                ypos 360
                size 21
                color "#3A281D"
                font FILE_FONT
                outlines []

            if burnout >= 7:
                text "이번 주에 꽤 많이 지쳤다.":
                    xpos 0
                    ypos 393
                    size 15
                    color "#5A4735"
                    font FILE_FONT
                    outlines []
            elif burnout >= 4:
                text "조금 지쳤지만 아직 괜찮다.":
                    xpos 0
                    ypos 393
                    size 15
                    color "#5A4735"
                    font FILE_FONT
                    outlines []
            else:
                text "아직 마음에 여유가 남아 있다.":
                    xpos 0
                    ypos 393
                    size 15
                    color "#5A4735"
                    font FILE_FONT
                    outlines []

            text "가장 가까워진 친구":
                xpos 0
                ypos 448
                size 20
                font FILE_FONT
                color "#2F2118"
                outlines []

            fixed:
                xpos 210
                ypos 418
                xsize 95
                ysize 82

                add top_portrait:
                    xalign 0.5
                    ypos 0
                    xysize (54, 54)

                text top_name:
                    xalign 0.5
                    ypos 56
                    size 18
                    font NOTE_FONT
                    color top_color
                    outlines [(1, "#2F2118AA", 0, 0)]

    # 오른쪽 페이지
    frame:
        background None
        xpos 668
        ypos 120
        xsize 360
        ysize 500

        fixed:
            text "지금의 관계":
                xpos 0
                ypos 0
                size 26
                color "#3A281D"
                font FILE_FONT
                outlines []

            text "지호   호감 [jiho_like] / 부담 [jiho_neg]":
                xpos 0
                ypos 50
                size 22
                color "#4A77B5"
                font NOTE_FONT
                bold True
                outlines []

            text "하영   호감 [hayoung_like] / 부담 [hayoung_neg]":
                xpos 0
                ypos 77
                size 22
                color "#B56A8C"
                font NOTE_FONT
                bold True
                outlines []

            text "나은   호감 [naeun_like] / 부담 [naeun_neg]":
                xpos 0
                ypos 104
                size 22
                color "#7A68B3"
                font NOTE_FONT
                bold True
                outlines []

            text "소희   호감 [sohee_like] / 부담 [sohee_neg]":
                xpos 0
                ypos 131
                size 22
                color "#C4932E"
                font NOTE_FONT
                bold True
                outlines []

            text "서연   호감 [seoyeon_like] / 부담 [seoyeon_neg]":
                xpos 0
                ypos 158
                size 22
                color "#4C9A92"
                font NOTE_FONT
                bold True
                outlines []

            text "월요일 교실":
                xpos 0
                ypos 228
                size 23
                color "#3A281D"
                font FILE_FONT
                outlines []

            text "다시 교실 문을 열면,":
                xpos 0
                ypos 270
                size 16
                color "#5A4735"
                font FILE_FONT
                outlines []

            text "친구들은 어떤 얼굴로":
                xpos 0
                ypos 297
                size 16
                color "#5A4735"
                font FILE_FONT
                outlines []

            text "나를 바라볼까?":
                xpos 0
                ypos 324
                size 16
                color "#5A4735"
                font FILE_FONT
                outlines []

            text "지금까지의 선택에 따라":
                xpos 0
                ypos 390
                size 16
                color "#5A4735"
                font FILE_FONT
                outlines []

            text "다른 이야기가 이어진다.":
                xpos 0
                ypos 417
                size 16
                color "#5A4735"
                font FILE_FONT
                outlines []

    # 하단 버튼: 다시 보기 버튼은 제거, 월요일 이동만 표시
    textbutton "월요일 교실로 간다":
        xpos 760
        ypos 570
        xsize 235
        ysize 42
        background Solid("#FFF7E9AA")
        hover_background Solid("#FFF0D0DD")
        text_font FILE_FONT
        text_size 22
        text_color "#3A281D"
        text_hover_color "#8A5A35"
        text_xalign 0.5
        text_yalign 0.5
        action Return("go_ending")

